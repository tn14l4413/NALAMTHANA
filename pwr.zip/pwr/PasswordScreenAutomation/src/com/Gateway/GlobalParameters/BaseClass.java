package com.Gateway.GlobalParameters;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.NoSuchElementException;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.Gateway.ExtentReports.GetScreenShot;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.sun.jna.platform.unix.X11.Screen;

public class BaseClass {
	
	Screen s=new Screen(); 
	public static String GatewayEmailURL="https://mail-int.nesbittburns.com/owa";
	public static String GatewayTrainingURL="https://gatewaytr.bmonesbittburns.ca/client/";
	
	public static String GatewayQAURL="https://gatewayqa.bmonesbittburns.ca/client/";
	
	//public static String GatewayAdminURL="https://10.192.33.72/admin/en/AdminSignIn.html";
	public static String GatewayAdminURL="https://10.192.33.72/admin/en/AdminSignIn.html";
		
	public static  Workbook Workb;
	
	public static String password;
	
	public static String ExecutedTestCasesSheet;
	
	public static Workbook wbook;
    
	public static WritableWorkbook wwbCopy;
    
	public static WritableSheet shSheet;
	
	public static WebDriver driver;

	public static String filePath="C:\\GatewayPasswordReset\\TestData\\ExcelSample.xlsx";

	public static String sheetName="English";
	
	
	public static String fileName="C:\\GatewayPasswordReset\\Configuration\\ConfigurationPage.property";
		
	public static FetchingOR obj = null;
	
	public static String testBrowserName=null;
	
	public static String testLanguage=null;
	 
	public static ExtentTest logger;
	
	public static boolean status;
	
	public static ExtentReports extent;
		
	public static void setReport()
	{
		Date date = new Date();
		DateFormat dateFormat = new SimpleDateFormat("dd MMMM yyyy HH-mm-ss");
		
		System.out.println(dateFormat.format(date)); 
		 DateFormat df1 = new SimpleDateFormat("dd MMMM yyyy");
	     String folderName= df1.format(date);  
	        
	        File f =  new File("C:\\GatewayPasswordReset\\TestReports\\"+folderName);
	        if (!f.exists() && !f.isDirectory()) {
	        	System.out.println("Inside create");
	           f.mkdir();
	        }
		extent = new ExtentReports("C:\\GatewayPasswordReset\\TestReports\\"+folderName+"\\"+dateFormat.format(date)+".html", true);
		extent.loadConfig(new File("C:\\GatewayPasswordReset\\extent-config.xml"));
		  
	}
	   
	public static void startReporting(String TestCaseName)
	{
	
		logger=extent.startTest(TestCaseName);
	}

	public static void endReporting()
	{
		
		extent.endTest(logger);
	}

	public static void statusPass(String Message)
	{
		logger.log(LogStatus.PASS, Message);
	}

	public static void statusPassWithScreenshot(WebDriver driver,String Message,String testCaseName) throws IOException
	{
		String screenShotPath = GetScreenShot.capture(driver, "C:\\GatewayPasswordReset\\screenshot.jpg",testCaseName);
		logger.log(LogStatus.PASS, Message);
	    logger.log(LogStatus.PASS, "Snapshot below: " + logger.addScreenCapture(screenShotPath));
	}
	
	public static void statusFail(WebDriver driver,String Message,String testCaseName) throws IOException
	{
		String screenShotPath = GetScreenShot.capture(driver, "C:\\GatewayPasswordReset\\screenshot.jpg",testCaseName);
		logger.log(LogStatus.FAIL, Message);
	    logger.log(LogStatus.FAIL, "Snapshot below: " + logger.addScreenCapture(screenShotPath));
	}


	public static void closeReporting()
	{
		  extent.flush();
	      extent.close();
		
	}
	
	public static void outPut(int Sheet, int columnNumber, int rowNumber, String Data) 
	{
		try{
				wbook = Workbook.getWorkbook(new File("C:\\GatewayPasswordReset\\DriverSheet\\DriveSheetSample.xls"));
    	    	wwbCopy = Workbook.createWorkbook(new File("C:\\GatewayPasswordReset\\DriverSheet\\DriveSheetSample.xls"), wbook);
    	    }
    	catch(Exception e)
    	    {
    	        e.printStackTrace();
    	    }
    	WritableSheet wshTemp = wwbCopy.getSheet(Sheet);
        Label labTemp = new Label(columnNumber, rowNumber, Data);
                  
       try {
            wshTemp.addCell(labTemp);
            } 
            catch (Exception e) 
            {
                e.printStackTrace();
            }
       try {
           // Closing the writable work book
           wwbCopy.write();
           wwbCopy.close();

           // Closing the original work book
           wbook.close();
       } catch (Exception e)

       {
           e.printStackTrace();
       }
    }
	
}
