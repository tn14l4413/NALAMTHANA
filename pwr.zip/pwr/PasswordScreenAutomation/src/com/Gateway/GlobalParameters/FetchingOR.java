package com.Gateway.GlobalParameters;



import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

public class FetchingOR {
	public String RepositoryFile;
	
	Properties prop;
	
	public FetchingOR(String fileName) throws Exception
	{
		this.RepositoryFile = fileName;
			
		FileInputStream fis = new FileInputStream(fileName);
		
		prop = new Properties();
		
		prop.load(fis);
		
	}
	
	public String getbrowser()
	{
	
		return prop.getProperty("CHROME");
	}

	
	public String getUserName()
	{
	
		return prop.getProperty("User_Id");
	}
	public String getPassword()
	{
		
		return prop.getProperty("Password");
	}
	
	
	public String getLoginDropDown()
	{
		System.out.println(prop.getProperty("Login_DropDown"));
		return prop.getProperty("Login_DropDown");
		
	}
	
	public String getLoginButton()
	{
		
		return prop.getProperty("Sign_In");
	}
	
	
	public String getAdminUserName()
	{
		
		return prop.getProperty("Username_Admin");
	}
	public String getAdminPassword()
	{
		
		return prop.getProperty("Password_Admin");
	}
	public String getAdminLoginButton()
	{
		
		return prop.getProperty("LoginButton_Admin");
	}
	public String getPasswordLink()
	{
		
		return prop.getProperty("Password_Link");
	}
	public String getOverridePasswordLink()
	{
		
		return prop.getProperty("OverridePassword_Link");
	}
	public String getOverrideClientLoginUserId()
	{
		
		return prop.getProperty("OverrrideClientLogin_UserID");
	}
	public String getOverrideClientLoginSubmit()
	{
		
		return prop.getProperty("OverrrideClientLogin_Submit");
	}
	public String getOverrideClientLoginTempPwd()
	{
		
		return prop.getProperty("OverrrideClientLogin_TmpPassword");
	}
	public String getOverrideClientLoginSuccessMsg()
	{
		
		return prop.getProperty("OverrrideClientLogin_SuccessMsg");
	}
	
	public String getPasswordChangePageTitle()
	{
		
		return prop.getProperty("Change_Password_Title");
		
	}
	public String getNewPasswordField()
	{
	
		return prop.getProperty("New_Password_Field");
		
	}
	public String getConfirmPasswordField()
	{
		
		return prop.getProperty("Confirm_Password_Field");
		
	}
	
	
	public String getContinueButton()
	{
		System.out.println(prop.getProperty("Continue_Button"));
		return prop.getProperty("Continue_Button");
		
	}
	
	public String getMinimum8Characters()
	{
		System.out.println(prop.getProperty("Minimum_8_characters"));
		return prop.getProperty("Minimum_8_characters");
		
	}

	public String getMinimum1lowerCase()
	{
		
		return prop.getProperty("Minimum_1_lower_case_letter");
		
	}
	
	public String getMinimum1upperCase()
	{
		return prop.getProperty("Minimum_1_upper_case_letter");
		
	}
	public String getMinimum1Number()
	{
	
		return prop.getProperty("Minimum_1_number");
		
	}
	public String getSpecialCharacter()
	{
	
		return prop.getProperty("Special_Character");
		
	}
	

	public String getSpecialCharacterAlertError()
	{
	
		return prop.getProperty("Create_Password_special_Character_error");
		
	}
	
	public String getConfirmPasswords()
	{
	
		return prop.getProperty("Confirm_Password");
		
	}
	
	public String getChallengeQuestionTitle()
	{
	
		return prop.getProperty("Challenge_Questions_Title");
		
	}
	public String getChallengeQuestionTitleNew()
	{
	
		return prop.getProperty("Challenge_Questions_Title_New");
		
	}
	
	//Overide Trading Admin
	
	public String getOverrideTradingPasswordLink()
	{
		
		return prop.getProperty("OverrideTradingPassword_Link");
	}
	public String getOverrideTradingPasswordSuccess()
	{
		
		return prop.getProperty("OverrideTradingPassword_Success");
	}
	
	public String getOverrideTradingUserID()
	{
		
		return prop.getProperty("OverrrideTradingLogin_UserID");
	}
	public String getOverrideTradingSubmit()
	{
		
		return prop.getProperty("OverrrideTrading_Submit");
	}
	//Trading Password Section
	public String getTradingTitle()
	{
		
		return prop.getProperty("Trading_Password_Title");
	}
	
	
	public String getTradingDesc()
	{
		
		return prop.getProperty("Trading_Password_Desc");
	}
	
	
	public String getTradingNewPasswordField()
	{
		
		return prop.getProperty("Trading_New_Password_Field");
	}
	
	
	public String getTradingConfirmPasswordField()
	{
		
		return prop.getProperty("Trading_Confirm_Password_Field");
	}
	
	public String getTradingMinimum6chracters()
	{
		
		return prop.getProperty("Trading_Minimum_6_Characters");
	}
	
	public String getTradingSpecialCharacter()
	{
		
		return prop.getProperty("Trading_Special_Character");
	}
	
	
	public String getTradingConfirmPasswordCheck()
	{
		
		return prop.getProperty("Trading_Confirm_Password_Text");
	}
	
	
	public String getTradingContinueButton()
	{
		
		return prop.getProperty("Trading_Continue_Button");
	}
	
	
	// Security Questions OR
	
	public String getSecurityQuestionTitle()
	{
		
		return prop.getProperty("Set_Up_Challenge_Ques_Title");
	}
	public String getSecurityQuestionDesc()
	{
		
		return prop.getProperty("Set_Up_Challenge_Ques_Desc");
	}
	
	public String getQuestion1()
	{
		
		return prop.getProperty("Question_1");
	}
	
	public String getAnswer1()
	{
		
		return prop.getProperty("Answer_1");
	}
	
	public String getQuestion2()
	{
		
		return prop.getProperty("Question_2");
	}
	
	public String getAnswer2()
	{
		
		return prop.getProperty("Answer_2");
	}
	
	public String getQuestion3()
	{
		
		return prop.getProperty("Question_3");
	}
	
	public String getAnswer3()
	{
		
		return prop.getProperty("Answer_3");
	}
	
	public String getSecurityQuestionContinueBtn()
	{
		
		return prop.getProperty("Set_Up_Challenge_Ques_Continue");
	}
	
	
	public String getSecurityQuestionMessage()
	{
		
		return prop.getProperty("Set_Up_Challenge_Ques_Msg");
	}
	
	
	// Email Adddress Section
	public String getEmailAddressTitle()
	{
		
		return prop.getProperty("Email_Address_Title");
	}
	
	public String getEmailAddressDesc()
	{
		
		return prop.getProperty("Email_Address_Desc");
	}
	
	
	public String getEmailAddressNewEmail()
	{
		
		return prop.getProperty("Email_Address_New_Email");
	}
	
	public String getEmailAddressConfirmEmail()
	{
		
		return prop.getProperty("Email_Address_Confirm_Email");
	}
	
	public String getEmailAddressConfirmEmailCheck()
	{
		
		return prop.getProperty("Email_Address_Confirm_Email_Check");
	}
	
	public String getEmailAddressTermsCheckBox()
	{
		
		return prop.getProperty("Email_Address_Terms_Checkbox");
	}
	
	public String getEmailAddressPopUpLink()
	{
		
		return prop.getProperty("Email_Address_Terms_PopUp");
	}
	
	public String getEmailAddressSubmitButton()
	{
		
		return prop.getProperty("Email_Address_Submit_Button");
	}
	
	public String getEmailConfirmationPageTitle()
	{
		
		return prop.getProperty("Email_ConfirmationPage_Title");
	}


	
	//UI Security Question Section
	
	public String getProfileChallengeqtncontinuebtn()
    {
                    
                    return prop.getProperty("Profile_Challenge_qtn_continue_btn");
    }

public String getProfileChallengeqtncancelbtn()
    {
                    
                    return prop.getProperty("Profile_Challenge_qtn_cancel_btn");
    }
public String getEditChallengeqtnbtn()
    {
                    
                    return prop.getProperty("Edit_Challenge_qtn_btn");
    }
public String getProfileChallengeqtnonetextbox()
    {
                    
                    return prop.getProperty("Profile_Challenge_qtn_one_textbox");
    }
public String getProfileChallengeqtntwotextbox()
    {
                    
                    return prop.getProperty("Profile_Challenge_qtn_two_textbox");
    }
public String getProfileChallengeqtnthreetextbox()
    {
                    
                    return prop.getProperty("Profile_Challenge_qtn_three_textbox");
    }

public String getProfileChallengeansonetextbox()
    {
                    
                    return prop.getProperty("Profile_Challenge_ans_one_textbox");
    }

public String getProfileChallengeanstwotextbox()
    {
                    
                    return prop.getProperty("Profile_Challenge_ans_two_textbox");
    }
public String getProfileChallengeansthreetextbox()
    {
                    
                    return prop.getProperty("Profile_Challenge_ans_three_textbox");
    }
public String getAccountSetting_ProfileTab()
{
       
       return prop.getProperty("Profile_Tab");
}
public String getAccountSetting_ResearchTab()
{
       
       return prop.getProperty("ResearchTab");
}
public String getAccountSetting_NewsTab()
{
       
       return prop.getProperty("NewsTab");
}
public String getAccountSetting_TradingTab()
{
       
       return prop.getProperty("TradingTab");
}
public String getAccountSetting_eServicesTab()
{
       
       return prop.getProperty("eServicesTab");
}
public String getAccountSetting_ProfileTab_SecurityQuesHeading()
{
       
       return prop.getProperty("ProfileTab_SecuityQues_Heading");
}
public String getHomePageLogo()
{
       
       return prop.getProperty("HomePage_Logo");
} 

//Error message in Login Screen
public String getLoginErrorMessage()
{
       
       return prop.getProperty("Login_Error");
} 

//Go To Login Page 
public String getGoToLoginPageButton()
{
       
       return prop.getProperty("Go_To_LoginPage");
} 

public String getConfirmPasswordMatch()
{

	return prop.getProperty("Confirm_Password_Match");
	
}




public String getEmailAddressErrorMsg()
	{
		
		return prop.getProperty("Email_Address_Error_Msg");
	}

public String getEmailConfirmAddressErrorMsg()
{
	
	return prop.getProperty("Email_Confirm_Address_Error_Msg");
}

public String getTradingPwdChangeScreenHeading()
{
	
	return prop.getProperty("Trading_Password_Heading");
}

public String getEmailTitle()
{
	
	return prop.getProperty("Email_title");
}




public String getEmailTerms()
{
	
	return prop.getProperty("EmailVerification_Terms");
}

public String getWelcomeScreenTitle()
{

	return prop.getProperty("WelcomeToGateway_Heading");
	
}

public String getWelcomeScreenStartButton()
{

	return prop.getProperty("GetStarted_button");
	
} 

public String getPleaseContactInvestmentAdvisor()
{
	
	return prop.getProperty("Please_contact_Investment_advisor");
} 

public String getErrorMessageChallengeQuestion()
{
	
	return prop.getProperty("Errormessage_challangequestions_Title");
}

public String getConfirmPasswordCheck()
{

	return prop.getProperty("Confirm_Password_Check");
	
} 

public String getConfirmPasswordUnCheck()
{

	return prop.getProperty("Confirm_Password_UnCheck");
	
} 



public String getNewTradingpassword()
{

	return prop.getProperty("Trading_passwordnew");
	
}


public String getConfirmTradingpassword()
{

	return prop.getProperty("Trading_passwordConfirm");
	
} 



public String getTradingpasswordtitle()
{

	return prop.getProperty("Trading_passwordTitle");
	
} 

public String getTradingcontinue()
	{
	
		return prop.getProperty("Trading_continue");
		
	} 



public String getProfileEmailadrheader()
{
       
       return prop.getProperty("Profile_Email_adr_header");
} 

public String getProfileEmailadrtextbox()
{
       
       return prop.getProperty("Profile_Email_adr_textbox");
} 
public String getProfileEmailadrtext()
{
       
       return prop.getProperty("Profile_Email_adr_text");
} 
public String getProfileEmailadreditbtn()
{
       
       return prop.getProperty("Profile_Email_adr_edit_btn");
} 
public String  getProfileemailadrcancelbtn()
{
       
       return prop.getProperty("Profile_email_adr_cancel_btn");
} 
public String  getProfileemailadrsubmitbtn()
{
       
       return prop.getProperty("Profile_email_adr_submit_btn");
} 
public String  getProfileConfirmemailtextbox()
{
       
       return prop.getProperty("Profile_Confirm_email_textbox");
} 
public String  getProfileemailagreementlink()
{
       
       return prop.getProperty("Profile_email_agreement_link");
} 
public String  getProfileemailaccepttermscheckbox()
{
       
       return prop.getProperty("Profile_email_accept_terms_checkbox");
} 
public String  getProfileemailerrmsg()
{
       
       return prop.getProperty("Profile_email_err_msg");
} 


public String getOverrrideTradingLoginUserID()
{
	
	return prop.getProperty("OverrrideTradingLogin_UserID");
}
public String getOverrrideTradingSubmit()
{
	
	return prop.getProperty("OverrrideTrading_Submit");
}


public String getGotoLoginButton()
{
	
	return prop.getProperty("GotoLogin_Button");
}


public String getUnSecureError()
{
	
	return prop.getProperty("unsecure_error");
}
public String getLoginErrorMsg()
{
	
	return prop.getProperty("Login_ErrorMsg");
}
public String getGetStartedbutton()
{
	
	return prop.getProperty("GetStarted_button");
}
public String getWelcomeToGatewayHeading()
{
	
	return prop.getProperty("WelcomeToGateway_Heading");
}
public String getWelcomeLogo()
{
	
	return prop.getProperty("Welcome_Logo");
}


//Unsecure Password 

public String getUnsecureSetUpNowButton()
{
	
	return prop.getProperty("Unsecure_Set_Up_Now_Button");
}

public String getUnsecurePasswordTitle()
{
	
	return prop.getProperty("Unsecure_Password_Title");
}


public String getUnsecurePasswordDesc()
{
	
	return prop.getProperty("Unsecure_Desc_Text");
}

//3.2.4







public String getSecurityErrorMessage() {

    return prop.getProperty("Challenge_Question_error_35");
   }

public String getSecurityErrorMessage1() {

    return prop.getProperty("Challenge_Question_error_36");
   }

//Email



public String getEmailConfirmationTitle()
{
	
	return prop.getProperty("Email_ConfirmationPage_Title");
}


// Email
/*
public String getEmailAddressTitle() {

	return prop.getProperty("Email_Address_Title");
}
*/

public String getForgotPwdLink() {

	return prop.getProperty("Forgot_Pwd_Link");
}

public String getForgotPwdScreenTitle() {

	return prop.getProperty("Forgot_Pwd_Title");
}

public String getForgotPwdUserId() {

	return prop.getProperty("Forgot_PWD_UserID");
}

public String getForgotPwdContinueBtn() {

	return prop.getProperty("Forgot_PWD_Continue");
}

public String getForgotPwdCancelBtn() {

	return prop.getProperty("Forgot_PWD_Cancel");
}

public String getForgotPwdFAQLink() {

	return prop.getProperty("Forgot_PWD_FAQLink");
}

public String getForgotPwdClientSignIn() {

	return prop.getProperty("Client_SignIn");
}

public String getForgotPwdFooter() {

	return prop.getProperty("Forgot_PWD_Footer");
}

public String getForgotPwdAnswer1() {

	return prop.getProperty("Forgot_PWD_SecAnswer1");
}

public String getForgotPwdAnswer2() {

	return prop.getProperty("Forgot_PWD_SecAnswer2");
}

public String getForgotErrorMsg() {

	return prop.getProperty("Forgot_PWD_ErrorMsg");
}

/*
 * Poorva
 */
public String getProfileTabLoginHeader() {
	return prop.getProperty("Profile_tab_loginPwd_header");
}

public String getProfiletabOldloginPwdtextbox() {
	return prop.getProperty("Profile_tab_Old_loginPwd_textbox");
}

public String getProfiletabchallengequestionmsg() {
	return prop.getProperty("Profile_tab_challengequestion_msg");
}

/**
 * Poorva
 */

public String getProfileTabChallengeQuestionDate() {
	return prop.getProperty("Profile_tab_challenegequestion_date");
}

public String getAccountSetting_Tab() {
	return prop.getProperty("Account_setting_tab");

}

public String getSetUpNowLoginPwd() {

	return prop.getProperty("Profile_Login_adr_set_up_now_button");
}

public String getSetUpNowSecurityQues() {

	return prop.getProperty("Profile_Security_adr_set_up_now_button");
}

public String getSetUpNowEmail() {

	return prop.getProperty("Profile_Email_adr_edit_btn");
}

public String getCommunicationLink() {

	return prop.getProperty("Communication_Link_Setup");
}

public String getCommunicationLink_BannerText() {

	return prop.getProperty("Communication_Link_Text");
}

public String getAccountSettingTab() {

	return prop.getProperty("AccountSetting_Tab");
}

public String getSignInButton() {
	return prop.getProperty("Account_SignIn_Button");
}

public String getSignOutButton() {
	return prop.getProperty("Account_SignOut_Button");
}

// 21st July

public String getForgotPwdBMoLogo() {
	return prop.getProperty("Forgot_PWD_BMO_logo");
}

public String getForgotPwdSubTitle() {
	return prop.getProperty("Forgot_PWD_Sub_Title");
}

public String getForgotPwdNewSubTitle() {
	return prop.getProperty("Forgot_PWD_New_Sub_Title");

}

public String getForgotPwdSecurityQuestion1() {
	return prop.getProperty("Forgot_PWD_securityQuestion1");

}

public String getForgotPwdSecurityQuestion2() {
	return prop.getProperty("Forgot_PWD_securityQuestion2");

}

public String getPasswordValidationText() {
	return prop.getProperty("Password_validation_errorMessage");

}

public String getSecurityErrorMessages() {

	return prop.getProperty("Challenge_Question_error");
}

public String getEmailUserName() {

	return prop.getProperty("Email_UserName");
}

public String getEmailPassword() {

	return prop.getProperty("Email_Password");
}

public String getEmailSigninButton() {

	return prop.getProperty("Email_SignIn_Button");
}

public String getEmailClickHereLink() {

	return prop.getProperty("Email_Verification_ClickHere_Link");
}

public String getEmailVerifiedTitle() {

	return prop.getProperty("EmailVerified_Title");
}

public String Email_ConfirmationPage_Title() {

	return prop.getProperty("Email_ConfirmationPage_Title");
}

public String getEmailVerifiedButton() {

	return prop.getProperty("EmailVerifiedPage_Button");
}

public String getEmailConfirmationPageGoToLoginPageButton() {

	return prop.getProperty("Email_ConfirmationPage_GoToLoginPage_Button");
}

public String getEmailVerificationClickHereLink() {

	return prop.getProperty("Email_Verification_ClickHere_Link");
}

public String getForgotPWDforgotUserIdLink() {
	return prop.getProperty("Forgot_PWD_forgotUserId_Link");
}

public String getForgotPWDforgotUserIdHelpDeskText() {
	return prop.getProperty("Forgot_PWD_forgotUserId_HelpDeskText");
}


public String getProfiletextboxlogin() {
	return prop.getProperty("Profile_textbox_login");
}



public String getProfiletextboxloginheader() {
	return prop.getProperty("Profile_textbox_login_header");
}



} 



