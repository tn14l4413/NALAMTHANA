package com.Gateway.ExtentReports;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
 
public class GetScreenShot {
     
    public static String capture(WebDriver driver,String fileWithPath,String testCaseName) throws IOException
    {
    	Date date = new Date();  
    	DateFormat df = new SimpleDateFormat("dd MMMM yyyy HH-mm-ss");
        String Date = df.format(date);
        
        Calendar c = Calendar.getInstance();
        c.setTime(new Date()); 
        int millis = c.get(Calendar.MILLISECOND);
        String uniq = Date ;
        DateFormat df1 = new SimpleDateFormat("dd MMMM yyyy");
        String folderName= df1.format(date);  
        
        File f =  new File("C:\\GatewayPasswordReset\\TestReports\\"+folderName+"\\");
        if (!f.exists() && !f.isDirectory()) {
        	System.out.println("Inside create 2");
           f.mkdir();
                   }
        
        
        
        
        
        File f1= new File("C:\\GatewayPasswordReset\\TestReports\\"+folderName+"\\Screenshot\\");
        if (!f1.exists() && !f1.isDirectory()) 
        {
        	System.out.println("Inside create 3");
           f1.mkdir();
        
        }
        String ScreenshotName = testCaseName+"_" + uniq + ".png";
    System.out.println("***************"+ScreenshotName);
                File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

               try {
            	   System.out.println("into try screenshot");
                               FileUtils.copyFile(scrFile, new File("C:\\GatewayPasswordReset\\TestReports\\"+folderName+"\\Screenshot\\"+ ScreenshotName));
                               // Launching Browser
                               
                               
               } catch (IOException e) {
                               System.err.println("Caught IOException: " + e.getMessage());
               }
             String  dest ="C:\\GatewayPasswordReset\\TestReports\\"+folderName+"\\Screenshot\\"+ ScreenshotName;
			return dest;

    }
}