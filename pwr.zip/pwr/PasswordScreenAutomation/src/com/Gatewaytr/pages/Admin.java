package com.Gatewaytr.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.Gateway.GlobalParameters.BaseClass;
import com.Gateway.GlobalParameters.FetchingOR;

public class Admin extends BaseClass {
	
	
	public static  String getTemporaryPassword(WebDriver driver,String accountNumber) throws Exception {
	

		System.out.println("Temp Password1="+accountNumber);
		try{
			obj = new FetchingOR(fileName);
			System.out.println("Temp Password="+accountNumber);
		CommonFunctions.waitForElement(driver, obj.getAdminLoginButton(), 20,"Wait for Admin Go Button");
		driver.findElement(By.name(obj.getAdminUserName())).sendKeys("marty");
		driver.findElement(By.name(obj.getAdminPassword())).sendKeys("aaaaaa");
		driver.findElement(By.xpath(obj.getAdminLoginButton())).click();
		
		CommonFunctions.waitForElement(driver, obj.getPasswordLink(), 20,"Temp Pwd");
		driver.findElement(By.xpath(obj.getPasswordLink())).click();
		CommonFunctions.waitForElement(driver, obj.getOverridePasswordLink(), 20,"Temp Pwd");
		driver.findElement(By.xpath(obj.getOverridePasswordLink())).click();
		CommonFunctions.waitForElement(driver, obj.getOverrideClientLoginUserId(), 20,"Temp Pwd");
		driver.findElement(By.xpath(obj.getOverrideClientLoginUserId())).sendKeys(accountNumber);
		driver.findElement(By.xpath(obj.getOverrideClientLoginSubmit())).click();
		CommonFunctions.waitForElement(driver, obj.getOverrideClientLoginTempPwd(), 20,"Temp Pwd");
		String tmpPassword=driver.findElement(By.xpath(obj.getOverrideClientLoginTempPwd())).getText();
		System.out.println("Temp Password="+tmpPassword);
		return tmpPassword;
		}
		catch(Exception e)
		{
			System.out.println("Exception caught in Admin Method:"+e.getMessage());
		}
		return null;
	
	}
	
public static  String getTemporaryTradingPassword(WebDriver driver,String accountNumber) throws Exception {
		
		try{
			obj = new FetchingOR(fileName);
			CommonFunctions.waitForElement(driver, obj.getOverrideTradingPasswordLink(), 20,"Override Login Pwd");
			driver.findElement(By.xpath(obj.getOverrideTradingPasswordLink())).click();
			CommonFunctions.waitForElement(driver, obj.getOverrideTradingUserID(), 20,"Client UserID");
			driver.findElement(By.xpath(obj.getOverrideTradingUserID())).sendKeys(accountNumber);
			driver.findElement(By.xpath(obj.getOverrideTradingSubmit())).click();
			CommonFunctions.waitForElement(driver, obj.getOverrideTradingPasswordSuccess(), 20,"Temp Pwd");			
			statusPass("Trading Password Reset Success"); 
		}
		catch(Exception e)
		{
			System.out.println("Exception caught in Admin Trading Pwd Reset Method:"+e.getMessage());
		}
		return null;
	}

}
