package com.Gatewaytr.pages;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.sikuli.script.*;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;



import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.Gateway.GlobalParameters.BaseClass;
import com.Gateway.GlobalParameters.FetchingOR;
import com.Gatewaytr.ExcelFile.ExcelJXL;
import com.Gatewaytr.ExcelFile.ReadExcelFile;
import com.Gatewaytr.Testcases.ExtentReport;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class CommonFunctions extends BaseClass{

	static WebDriverWait wait;
	public static void scrolltoElement(WebDriver driver,String element) throws IOException{
		try
		{

			WebElement ele=driver.findElement(By.xpath(element));
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			
			
		
			jse.executeScript("arguments[0].scrollIntoView(true);",ele);
			
			
			

		} 
		catch(Exception e)
		{
			 System.out.println("Exception caught in scrollToElement Method-------"+e.getMessage());
			 statusFail(driver,"Screenshot not properly Captured",element);
			 
		 } 
	} 

	
	public static void select(WebDriver driver,String dropDownText,String element,String testCaseName) throws IOException{
		try
		{
	
	Select sl=new Select(driver.findElement(By.xpath(element)));
	System.out.println("Exception select------"+dropDownText);
	sl.selectByVisibleText(dropDownText);
		} 
		catch(Exception e)
		{
			 System.out.println("Exception caught in Select Method-------"+e.getMessage());
			 statusFail(driver,"Selection of DropDown Text Failed"+dropDownText,testCaseName);
			 
		 } 
	} 
	
	
	public static void selectByIndex(WebDriver driver,int dropDownValue,String element,String testCaseName) throws IOException{
		try
		{
	
	Select sl=new Select(driver.findElement(By.xpath(element)));
	System.out.println("select------"+dropDownValue);
	sl.selectByIndex(dropDownValue);
		} 
		catch(Exception e)
		{
			 System.out.println("Exception caught in Select Method-------"+e.getMessage());
			 statusFail(driver,"Selection of DropDown Text Failed"+dropDownValue,testCaseName);
			 
		 } 
	} 
	
	public static void verifyText(WebDriver driver,String expText,String element,String testCaseName) throws IOException{
		try
		{
			CommonFunctions.waitForElement(driver, element,60, "Change a New Password Screen");
		System.out.println("***************Actual Text From Application*********** : "+driver.findElement(By.xpath(element)).getText().trim());
			

	 if(driver.findElement(By.xpath(element)).getText().trim().equalsIgnoreCase(expText.trim()))
		 
	 {

		 statusPass("Verification of Text Success:"+expText);
	 } 
	 else
	 {

		 statusFail(driver,"Verification of Text Failed:"+expText,testCaseName);
	 } 
	 
		} 
		catch(Exception e)
		{
			 System.out.println("Exception caught in VerifyText Method-------"+e.getMessage());
			 statusFail(driver,"Verification of Text Failed:"+expText,testCaseName);
			 
		 } 
	} 

	public static void verifyElement(WebDriver driver,String text,String element,String testCaseName) throws IOException{
		try
		{
			
			CommonFunctions.waitForElement(driver, element, 60, testCaseName);
		
	 if(driver.findElement(By.xpath(element)).isDisplayed())
		 
	 {

		 statusPass("Element Displayed Successfully:"+text);
	 } 
	
	 
		} 
		catch(Exception e)
		{
			 System.out.println("Exception caught in VerifyElement Method-------"+e.getMessage());
			 statusFail(driver,"Element is not displayed in Application:" + text,testCaseName);
			 endReporting();
			 Assert.fail("Verify elements");
			
			 
		 } 
	} 
	
	public static void waitForElement(WebDriver driver,String element,int Seconds,String elementName) throws IOException{
		try{
		
		
			wait=new WebDriverWait(driver, Seconds);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element)));
			System.out.println("***********Waiting for element***********");
			
		}
		catch(Exception e)
		{
			System.out.println("Exception caught in Wait For Element Method-------"+e.getMessage());
			 statusFail(driver,"Element is not displayed in Application:" + element,elementName);
			 endReporting();
			 Assert.fail("Wait for elements");
		}
	 
		 } 


	public static void verifyMasked(WebDriver driver,String element,String text,String testCaseName) throws IOException{
		try
		{
		
			 String passwordContents = driver.findElement(By.xpath(element)).getAttribute("type");
			 statusPass("Text field contents are masked" +passwordContents); 
       	  if (passwordContents.equalsIgnoreCase("password")) {
       		 statusPass("Text field contents are masked" +text);  
       		  
       		  
       	  }
       	  }
	
	 
		
		catch(Exception e)
		{
			 System.out.println("Exception caught in Verify Masked Method-------"+e.getMessage());
			 statusFail(driver,"Text field contents are not masked" + text,testCaseName);
			 endReporting();
			 Assert.fail("Verify masked");
			
			 
		 } 
	}
	
	public static void verifyPasswordCriteriaCheck(WebDriver driver,String element,String text,String testCaseName) throws IOException{
		try
		{
		
			 String passwordContents = driver.findElement(By.xpath(element)).getAttribute("type");
			 statusPass("Text field contents are masked" +passwordContents); 
       	  if (passwordContents.equalsIgnoreCase("password")) {
       		 statusPass("Text field contents are masked" +text);  
       		  
       		  
       	  }
       	  }
	
	 
		
		catch(Exception e)
		{
			 System.out.println("Exception caught in Verify Masked Method-------"+e.getMessage());
			 statusFail(driver,"Text field contents are not masked" + text,testCaseName);
			 endReporting();
			 Assert.fail("Verify masked");
			
			 
		 } 
	}
	
	public static void checkDisabled(WebDriver driver,String element,String text,String testCaseName) throws IOException{
		try
		{
		
			
			boolean status=driver.findElement(By.xpath(element)).isEnabled();
			if(status==false)
			{
				 statusPass("Element is disabled" +text); 
			}
			else
			{
				statusFail(driver,"Element is enabled" +text,testCaseName); 
			}
       	 
       	  }
	
	 
		
		catch(Exception e)
		{
			 System.out.println("Exception caught in check disabled Method-------"+e.getMessage());
			 statusFail(driver,"Element is present in the application" + text,testCaseName);
			 endReporting();
			 Assert.fail("Verify Element is disabled");
			
			 
		 } 
	}
	
	
	public static void checkEnabled(WebDriver driver,String element,String text,String testCaseName) throws IOException{
		try
		{
		
			
			boolean status=driver.findElement(By.xpath(element)).isEnabled();
			if(status==true)
			{
				 statusPass("Element is Enabled" +text); 
			}
			else
			{
				statusFail(driver,"Element is Disabled" +text,testCaseName); 
			}
       	 
       	  }
	
	 
		
		catch(Exception e)
		{
			 System.out.println("Exception caught in check enabled Method-------"+e.getMessage());
			 statusFail(driver,"Element is not present in the application" + text,testCaseName);
			 endReporting();
			 Assert.fail("Verify Element is enabled");
			
			 
		 } 
	}
	
	
	public static void checkFontColour(WebDriver driver,String element,String expColour,String text,String testCaseName) throws IOException{
		try
		{
		
			
		String status=driver.findElement(By.xpath(element)).getCssValue("color"); 
			System.out.println("Font Colur dispalyed" +status);
			
			if(expColour.equalsIgnoreCase(status))
			{
				 statusPass("Font Colour of the Element is as expected " +text); 
			}
			else
			{
				statusFail(driver,"Font Colour of the Element is not as expected " +text,testCaseName); 
			}
		}
	
	 
		
		catch(Exception e)
		{
			 System.out.println("Exception caught in check font colour Method-------"+e.getMessage());
			 statusFail(driver,"Element is not present in the application" + text,testCaseName);
			 endReporting();
			 Assert.fail("Verify font colour");
			
			 
		 } 
	}
	
	
	public static void verifySecurityElements(WebDriver driver,String testCaseName) throws IOException{
		try
		{
		
			   CommonFunctions.verifyElement(driver, "Security Question 1", obj.getQuestion1(), testCaseName);
		       CommonFunctions.verifyElement(driver, "Security Answer 1 ", obj.getAnswer1(), testCaseName);
		       CommonFunctions.verifyElement(driver, "Security Question 2 ", obj.getQuestion2(), testCaseName);
		        
		        CommonFunctions.verifyElement(driver, "Security Answer 2 ", obj.getAnswer2(),testCaseName );
		        
		        CommonFunctions.verifyElement(driver, "Security Question 3 ", obj.getQuestion3(), testCaseName);
		        
		        CommonFunctions.verifyElement(driver, "Security Answer 3  ", obj.getAnswer3(),testCaseName );
		           
			
			
		}
	 
		
		catch(Exception e)
		{
			 System.out.println("Exception caught in verify Security Section Elements Method-------"+e.getMessage());
			 statusFail(driver,"Error in elements location in Challenge question section" ,testCaseName);
			 endReporting();
			 Assert.fail("Verify security section elements");
			
			 
		 } 
	}
	
	
	
	
	public static void setSecurityFields(WebDriver driver,int question1,String answer1,int question2,String answer2,int question3,String answer3,String testCaseName) throws IOException{
		try
		{
		
			CommonFunctions.selectByIndex(driver,question1, obj.getQuestion1(), testCaseName);
			driver.findElement(By.xpath(obj.getAnswer1())).sendKeys(answer1);
			   CommonFunctions.selectByIndex(driver,question2, obj.getQuestion2(), testCaseName);
			   driver.findElement(By.xpath(obj.getAnswer2())).sendKeys(answer2);
				
			   CommonFunctions.selectByIndex(driver,question3, obj.getQuestion3(), testCaseName);
		   driver.findElement(By.xpath(obj.getAnswer3())).sendKeys(answer3);
			  
			
			
			
		}
	 
		
		catch(Exception e)
		{
			 System.out.println("Exception caught in set Security Section Elements Method-------"+e.getMessage());
			 statusFail(driver,"Error in setting values in Challenge question section" ,testCaseName);
			 endReporting();
			 Assert.fail("Verify security section elements");
			
			 
		 } 
	}
	
	
	
	public static void resetSecurityFields(WebDriver driver) throws IOException{
		try
		{
		
			CommonFunctions.resetSelectField(driver,obj.getQuestion1(),1);
			CommonFunctions.resetSelectField(driver,obj.getQuestion2(),2);
			CommonFunctions.resetSelectField(driver,obj.getQuestion3(),3);
			driver.findElement(By.xpath(obj.getAnswer1())).clear();
			driver.findElement(By.xpath(obj.getAnswer2())).clear();
			driver.findElement(By.xpath(obj.getAnswer3())).clear();
		
		 	
		}
	 
		
		catch(Exception e)
		{
			 System.out.println("Exception caught in resetting Security Section Elements Method-------"+e.getMessage());
			 statusFail(driver,"Error in resetting values in Challenge question section" ,"Error in resetting values in Challenge question section");
			 endReporting();
			 Assert.fail("Reset security section elements");
			
			 
		 } 
	}
	
	
	
	
	public static void checkSizeofDropDown(WebDriver driver,String element,int size) throws IOException{
		try
		{
		int count=0;
		Select s1=new Select (driver.findElement(By.xpath(element)));
		List<WebElement> elementCount=s1.getOptions();
		int sizeOfOptions=elementCount.size();
		for(int i=0;i<sizeOfOptions;i++)
		{
			if(elementCount.get(i).isEnabled())
			{
				count++;
			}
			
		}
		
	
		if(count==size)
		{
			statusPass("Size of the Select drop down box is as expected. Size : "+ count ); 
		}
		else
		{
			statusFail(driver,"Size of the Select drop down box is not as expected.Size: " +count,"Size of the Select drop down box is not as expected");
			
		}
		
		 	
		}
	 
		
		
		
		catch(Exception e)
		{
			 System.out.println("Exception caught in checkSizeofDropDown Method-------"+e.getMessage());
			 statusFail(driver,"Error in checking size of the drop down box" ,"EError in checking size of the drop down box");
			 endReporting();
			 Assert.fail("Size of the drop down elements");
			
			 
		 } 
	}
	
	
	
	public static void checkSizeofDropDownoriginal(WebDriver driver,String element,int size) throws IOException{
		try
		{
		
		Select s1=new Select (driver.findElement(By.xpath(element)));
		List<WebElement> elementCount=s1.getOptions();
		int sizeOfOptions=elementCount.size();
		if(sizeOfOptions-1==size)
		{
			statusPass("Size of the Select drop down box is as expected. Size : "+ (sizeOfOptions-1) ); 
		}
		else
		{
			statusFail(driver,"Size of the Select drop down box is not as expected.Size: " +(sizeOfOptions-1),"Size of the Select drop down box is not as expected");
			
		}
		
		 	
		}
	 
		catch(Exception e)
		{
			 System.out.println("Exception caught in checkSizeofDropDown Method-------"+e.getMessage());
			 statusFail(driver,"Error in checking size of the drop down box" ,"EError in checking size of the drop down box");
			 endReporting();
			 Assert.fail("Size of the drop down elements");
			
			 
		 } 
	}
	
	
	
	public static void checkFieldLength(WebDriver driver,String element,int expectedLength) throws IOException{
		try
		{
		
	String text=driver.findElement(By.xpath(element)).getAttribute("value");
		int actLength=text.length();
		if(actLength==expectedLength)
		{
			statusPass("Text Field limits entry to "+actLength+" characters" ); 
		}
		else
		{
			statusFail(driver,"Text Field not limits entry to "+expectedLength+" characters & the actual length of text provided is "+actLength ,"Text Field not limits entry to "+expectedLength+" characters");
			
		}
		
		 	
		}
	 
		
		catch(Exception e)
		{
			 System.out.println("Exception caught in checkFieldLength Method-------"+e.getMessage());
			 statusFail(driver,"Error in checking length of the text Field" ,"Error in checking length of the text Field");
			 endReporting();
			 Assert.fail("Length limit of Text Box");
			
			 
		 } 
	}
	public static void resetSelectField(WebDriver driver,String element,int indexvalue) throws IOException{
		try
		{
		
		
			  
		   Select s1=new Select(driver.findElement(By.xpath(element)));
		  s1.deselectByIndex(indexvalue);
			
		}
	 
		
		catch(Exception e)
		{
			 System.out.println("Exception caught in resetSelectField Method-------"+e.getMessage());
			 statusFail(driver,"Error in resetting values of select box" ,"Error in resetting values of select box");
			 endReporting();
			 Assert.fail("Clear Select Text Box");
			
			 
		 } 
	}
	public static void checkElementColour(WebDriver driver,String element,String expColour,String text,String testCaseName) throws IOException{
        try
        {
        
               
        String status=driver.findElement(By.xpath(element)).getCssValue("background-color");
               System.out.println("Background Colur dispalyed*(*********" +status);
               
               if(expColour.equalsIgnoreCase(status))
               {
                     statusPass("Font Colour of the Element is as expected " +text); 
               }
               else
               {
                     statusFail(driver,"Font Colour of the Element is not as expected " +text,testCaseName); 
               }
        }
 
 
        
        catch(Exception e)
        {
               System.out.println("Exception caught in check font colour Method-------"+e.getMessage());
               statusFail(driver,"Element is not present in the application" + text,testCaseName);
               endReporting();
               Assert.fail("Verify font colour");
               
               
         } 
 }
	
	//Poorva getQuestion list for 53504964
	
	public static void getQuestionList(WebDriver driver, String element,
			String testCaseName) throws IOException {

		try {

			WebElement ele = driver.findElement(By.xpath(element));

			HashMap<Integer, String> hmap = new HashMap<Integer, String>();

			/* Adding elements to HashMap */
			hmap.put(1, "What was the name of your first childhood pet?");
			hmap.put(2,"What was the first and last name of your first boyfriend or girlfriend?");
			hmap.put(3, "What was the name of the street that you grew up on?");
			hmap.put(4, "What is the name of your favourite childhood friend?");
			hmap.put(5, " Who was your favourite teacher?");
			hmap.put(6, "What was your favorite subject in school?");
			hmap.put(7, "Who was your childhood hero?");
			hmap.put(8, "What was the make of your first car?");
			hmap.put(9, "What did you want to be when you grew up?");
			hmap.put(10, "What was your first job?");
			hmap.put(11, "Who was your favourite athlete as a child?");
			hmap.put(12, "What was the name of your first roommate?");
			hmap.put(13, "What was the name of your first manager?");
			hmap.put(14, "What was your favourite book or novel as a child?");
			hmap.put(15, "What was your favourite game as a child?");
			hmap.put(16,"What was your favourite food as a child?");
			hmap.put(17, "What was the best thing you ever won as an adult?");
			hmap.put(18, "Where was your first vacation as an adult?");
			hmap.put(19, "What was the first movie you saw in the theatre as a child?");
			hmap.put(20, "What was your favourite song as a child?");
			Set set = hmap.entrySet();
			Iterator iterator = set.iterator();
			while (iterator.hasNext()) {
				Map.Entry mentry = (Map.Entry) iterator.next();
				System.out
						.print("key is: " + mentry.getKey() + " & Value is: ");
				System.out.println(mentry.getValue());
			}
		Select selectList = new Select(ele);
			List<WebElement> options = selectList.getOptions();

			for (int i = 1; i < options.size(); i++) {

				String value = options.get(i).getText().trim();
				System.out.println(value + "option value");
				String mapvalue = hmap.get(i).trim();
				System.out.println(mapvalue + "map value");

				if (value.contains(mapvalue)
						|| value.equalsIgnoreCase(mapvalue)) {
					statusPass("The Matching Question is Present ");
					System.out.println("Ifpass");
				} else {
					statusFail(driver, "List of Matching question is Absent ",
							testCaseName);
					System.out.println("IfFailed");
				}

			}

		} catch (Exception e) {
			System.out
					.println("Exception caught in List of matchin question -------"
							+ e.getMessage());
			statusFail(driver, "Element is not present in the application"
					+ element, testCaseName);
			endReporting();
			Assert.fail("matching Question is Absent");

			throw e;
		}

	}

/*	
	public static void getQuestionList(WebDriver driver, String element,
			String testCaseName) throws IOException {

		try {

			HashMap<Integer, String> hmap = new HashMap<Integer, String>();

			/* Adding elements to HashMap */
			
		/*	//OLD ORDER
			hmap.put(1,	"What was the first movie you saw in the theatre as a child?");
			hmap.put(2, "What was the best thing you ever won as an adult?");
			hmap.put(3, "Where was your first vacation as an adult?");
			hmap.put(4, "What was your favourite game as a child?");
			hmap.put(5, "What was your favourite food as a child?");
			hmap.put(6, "What was the name of your first manager?");
			hmap.put(7, "What was your favourite book or novel as a child?");
			hmap.put(8, "Who was your favourite athlete as a child?");
			hmap.put(9, "What was the name of your first roommate?");
			hmap.put(10, "What was the name of the street that you grew up on?");
			hmap.put(11, "What was your favourite song as a child?");
			hmap.put(12, "What was the first and last name of your first boyfriend or girlfriend?");
			hmap.put(13, "What was the name of your first childhood pet?");
			hmap.put(14, "What was your first job?");
			hmap.put(15, "Who was your childhood hero?");
			hmap.put(16, "What was your favorite subject in school?");
			hmap.put(17, "Who was your favourite teacher?");
			hmap.put(18, "What is the name of your favourite childhood friend?");
			hmap.put(19, "What did you want to be when you grew up?");
			hmap.put(20, "What was the make of your first car?"); 
			
			
			//NEWORDER
			hmap.put(1,	"What was the name of your first childhood pet?");
			hmap.put(2, "What was the first and last name of your first boyfriend or girlfriend?");
			hmap.put(3, "What was the name of the street that you grew up on?");
			hmap.put(4, "What is the name of your favourite childhood friend?");
			hmap.put(5, "Who was your favourite teacher?");
			hmap.put(6, "What was your favorite subject in school?");
			hmap.put(7, "Who was your childhood hero?");
			hmap.put(8, "What was the make of your first car?");
			hmap.put(9, "What did you want to be when you grew up?");
			hmap.put(10, "What was your first job?");
			hmap.put(11, "Who was your favourite athlete as a child?");
			hmap.put(12, "What was the name of your first roommate?");
			hmap.put(13, "What was the name of your first manager?");
			hmap.put(14, "What was your favourite book or novel as a child?");
			hmap.put(15, "What was your favourite game as a child?");
			hmap.put(16, "What was your favourite food as a child?");
			hmap.put(17, "What was the best thing you ever won as an adult?");
			hmap.put(18, "Where was your first vacation as an adult?");
			hmap.put(19, "What was the first movie you saw in the theatre as a child?");
			hmap.put(20, "What was your favourite song as a child?");

			Set set = hmap.entrySet();
			Iterator iterator = set.iterator();
			while (iterator.hasNext()) {
				Map.Entry mentry = (Map.Entry) iterator.next();
				System.out
						.print("key is: " + mentry.getKey() + " & Value is: ");
				System.out.println(mentry.getValue());
			}

			Select selectList = new Select(driver.findElement(By.xpath(element)));
			List<WebElement> options = selectList.getOptions();

			for (int i = 1; i < options.size(); i++) {

				String value = options.get(i).getText().trim();
				System.out.println(value + "option value");
				String mapvalue = hmap.get(i).trim();
				System.out.println(mapvalue + "map value");

				if (value.contains(mapvalue)
						|| value.equalsIgnoreCase(mapvalue)) {
					statusPass("The Matching Question is Present " + value);
				} else {
					statusFail(driver, "List of Matching question is Absent "
							+ value, testCaseName);
				}

			}

		} catch (Exception e) {
			System.out
					.println("Exception caught in List of matchin question -------"
							+ e.getMessage());
			statusFail(driver, "Element is not present in the application"
					+ element, testCaseName);
			endReporting();
			Assert.fail("matching Question is Absent");

			throw e;
		}

	}
	*/
	
public static String uniquePassword(WebDriver driver,String TestCaseID,String Functionality, String testCaseName,String CellValue ) throws IOException{
		
		try
		{
		
			Date date = new Date();  
	    	DateFormat df = new SimpleDateFormat("dd MMMM yyyy HH-mm-ss");
	        String Date = df.format(date);
	        
	        Calendar c = Calendar.getInstance();
	        c.setTime(new Date()); 
	        int millis = c.get(Calendar.MILLISECOND);
	        String NewPassword=ReadExcelFile.getTestData(TestCaseID,Functionality,CellValue);
			String NewPassword1=Integer.toString(millis);
			String NewPasswordUpdated = NewPassword.concat(NewPassword1);
	        return NewPasswordUpdated;
	        
		}
			
	
	 
		
		catch(Exception e)
		{
			
			 statusFail(driver,"Unable to get MilliSecond for date function",testCaseName);
			 endReporting();
			 Assert.fail("Verify Element is enabled");
			return "False";
			 
		 } 
		
	}


public static void verifyQuestionList(WebDriver driver, String element,String previousSecurityQuestion,int expectedQuestions, String testCaseName) throws IOException {
		
		try {
			
			HashMap<Integer, String> hmap = new HashMap<Integer, String>();
			
			/* Adding elements to HashMap */
			hmap.put(1,	"What was the first movie you saw in the theatre as a child?");
			hmap.put(2, "What was the best thing you ever won as an adult?");
			hmap.put(3, "Where was your first vacation as an adult?");
			hmap.put(4, "What was your favourite game as a child?");
			hmap.put(5, "What was your favourite food as a child?");
			hmap.put(6, "What was the name of your first manager?");
			hmap.put(7, "What was your favourite book or novel as a child?");
			hmap.put(8, "Who was your favourite athlete as a child?");
			hmap.put(9, "What was the name of your first roommate?");
			hmap.put(10, "What was the name of the street that you grew up on?");
			hmap.put(11, "What was your favourite song as a child?");
			hmap.put(12, "What was the first and last name of your first boyfriend or girlfriend?");
			hmap.put(13, "What was the name of your first childhood pet?");
			hmap.put(14, "What was your first job?");
			hmap.put(15, "Who was your childhood hero?");
			hmap.put(16, "What was your favorite subject in school?");
			hmap.put(17, "Who was your favourite teacher?");
			hmap.put(18, "What is the name of your favourite childhood friend?");
			hmap.put(19, "What did you want to be when you grew up?");
			hmap.put(20, "What was the make of your first car?");
			Select selectList = new Select(driver.findElement(By.xpath(element)));
			List<WebElement> options = selectList.getOptions();
			int count=0;
			for (WebElement option : options) {
			      if (option.isEnabled()) {
			    	  count++;
			          String ListBoxValue = option.getText().trim();
			          if(previousSecurityQuestion.equalsIgnoreCase(ListBoxValue))
			          {
			        	  statusFail(driver, "Matching question is Present in the list box"+ ListBoxValue, testCaseName);
			        	  Assert.fail("Security Question"+ListBoxValue+"present in the drop down");
			          }
			      }
			   }
			if (count==expectedQuestions)
				statusPass("Total number of Security Questions present in the dropdown is =" + count);
			else
				statusFail(driver, "Expected security questios in the dropdown is 19 but actual secuirity question is-  "+count, testCaseName);
					

		} catch (Exception e) {
			System.out
					.println("Exception caught in List of matchin question -------"
							+ e.getMessage());
			statusFail(driver, "Element is not present in the application"
					+ element, testCaseName);
			endReporting();
			Assert.fail("matching Question is Absent");

			throw e;
		}

	}

public static void checkCapitalize(WebDriver driver,String element) throws IOException {
    try {
              String originalText=driver.findElement(By.xpath(element)).getText();
              String originalToLower = originalText.toLowerCase();
              String finalText= Character.toUpperCase(originalToLower.charAt(0)) + originalToLower.substring(1);
              if(originalText.equals(finalText))
              {
                     statusPass("Given Text is capitalized as expected " ); 
              }
              else
              {
                     statusFail(driver,"Given Text is not capitalized as expected ",""); 
              }
}
catch (Exception e) {
       System.out.println("Exception caught in checkCapitalize-------"+e.getMessage());
    statusFail(driver,"Selection of DropDown Text Failed","");
    endReporting();
       Assert.fail("Verify Text capitalization");
   }

}


public static void SwitchToChildWindow(WebDriver driver) throws IOException{
    try
    {
           
       for (String winHandle : driver.getWindowHandles()) { //Gets the new window handle
            System.out.println(winHandle);
            driver.switchTo().window(winHandle);        // switch focus of WebDriver to the next found window handle (that's your newly opened window)              
        }
           
      }
    catch (Exception e)
    {
           System.out.println("Exception caught in SwitchToWindow Method-------"+e.getMessage());
           statusFail(driver,"SwitchToWindow Operation is not performed","");
           endReporting();
           Assert.fail("SwitchToWindow");      
    }
}

public static void SwitchToParentWindow(WebDriver driver,String parentWindow) throws IOException{
    try
    {
           
       driver.close();                                 // close newly opened window when done with it
        driver.switchTo().window(parentWindow);     // switch focus of WebDriver to the next found window handle (that's your newly opened window)              
     
           
      }
    catch (Exception e)
    {
           System.out.println("Exception caught in SwitchToParentWindow Method-------"+e.getMessage());
           statusFail(driver,"SwitchToParentWindow Operation is not performed","");
           endReporting();
           Assert.fail("SwitchToParentWindow");      
    }
}

public static String Date(WebDriver driver,String TestCaseID,String Functionality, String testCaseName) throws IOException{
    
    try
    {
    
           Date date = new Date();  
    DateFormat df = new SimpleDateFormat("yy-MM-dd");
     String Date = df.format(date);
     
     return Date;
     
    }
           


    
    catch(Exception e)
    {
           
           statusFail(driver,"Unable to get Date for date function",testCaseName);
           endReporting();
           Assert.fail("Unable to get the date");
           return "False";
           
     } 
    
}

public static void eMailCheckBoxClick(WebDriver driver,String TestCaseID,String Functionality, String testCaseName) throws IOException{
	
	try
	{
		 
		Screen s=new Screen();
		Pattern image = new Pattern("C:\\GatewayPasswordReset\\Sikuli Images\\CheckBox.PNG");
		s.wait(image, 10);
		s.click(image)	;
			         
               
	}
		
	
	catch(Exception e)
	{
		
		 statusFail(driver,"Unable to select the check box",testCaseName);
		 endReporting();
		 Assert.fail("Unable to select the check box");
		
		 
	 } 
	
}


public static void checkDisplayed(WebDriver driver, String element,
		String text, String testCaseName) throws IOException {
	try {

		boolean status = driver.findElement(By.xpath(element))
				.isDisplayed();
		if (status == true) {
			statusPass("Element is Enabled" + text);
		} else {
			statusFail(driver, "Element is Disabled" + text, testCaseName);
		}

	}

	catch (Exception e) {
		System.out
				.println("Exception caught in check enabled Method-------"
						+ e.getMessage());
		statusFail(driver, "Element is not present in the application"
				+ text, testCaseName);
		endReporting();
		Assert.fail("Verify Element is enabled");

	}
}

public static void checkSelected(WebDriver driver, String element,
		String text, String testCaseName) throws IOException {
	try {

		boolean status = driver.findElement(By.xpath(element)).isSelected();
		if (status == true) {
			statusPass("Element is Enabled" + text);
		} else {
			statusFail(driver, "Element is Disabled" + text, testCaseName);
		}

	}

	catch (Exception e) {
		System.out
				.println("Exception caught in check enabled Method-------"
						+ e.getMessage());
		statusFail(driver, "Element is not present in the application"
				+ text, testCaseName);
		endReporting();
		Assert.fail("Verify Element is enabled");

	}
}


public static void verifySpellingText(WebDriver driver, String expText,
		String element, String testCaseName) throws IOException {

	try {

		CommonFunctions.waitForElement(driver, element, 40,
				"EServices Screen");

		if (driver.findElement(By.xpath(element)).getText()
				.contains(expText))

		{

			statusPass("Verification of Text Success:" + expText);
		} else {

			statusFail(driver, "Verification of Text Failed:" + expText,
					testCaseName);
		}

	} catch (Exception e) {
		System.out.println("Exception caught in VerifyText Method-------"
				+ e.getMessage());
		statusFail(driver, "Verification of Text Failed:" + expText,
				testCaseName);

	}
	// TODO Auto-generated method stub

}

public static void verifyHorizontalLocationOfElement(WebDriver driver,
		String referenceElement, String element, String testCaseName)
		throws IOException {
	try {
		WebElement reference_Element = driver.findElement(By
				.xpath(referenceElement));
		WebElement exp_element = driver.findElement(By.xpath(element));
		Point p1 = (Point) (WebElement) reference_Element.getLocation();
		int x_reference_Element = p1.getX();

		Point p2 = (Point) (WebElement) exp_element.getLocation();
		int x_exp_element = p2.getX();

		int horizontal = x_reference_Element - x_exp_element;

		if (horizontal < 0) {
			statusPass("Element is to the Right :" + element);

		} else if (horizontal > 0) {
			statusPass("Element is to the Left :" + element);
		}

		else if (horizontal == 0) {
			statusFail(driver, "Element is not relative to given Element"
					+ element, testCaseName);
		}
	} catch (Exception e) {
		System.out
				.println("Exception caught in Verifying Horizontal Location-------"
						+ e.getMessage());
		statusFail(driver, "Verification of  Horizontal Location- Failed:"
				+ element, testCaseName);

	}

}

public static void verifyVerticalLocationOfElement(WebDriver driver,
		String referenceElement, String element, String testCaseName)
		throws IOException {

	try {
		WebElement reference_Element = driver.findElement(By
				.xpath(referenceElement));
		WebElement exp_element = driver.findElement(By.xpath(element));
		Point p1 = (Point) (WebElement) reference_Element.getLocation();

		int y_reference_Element = p1.getY();

		Point p2 = (Point) (WebElement) exp_element.getLocation();

		int y_exp_element = p2.getY();

		int vertical = y_reference_Element - y_exp_element;

		if (vertical < 0) {
			statusPass("Element is below the reference Element:" + element);

		} else if (vertical > 0) {
			statusPass("Element is Above the reference Element :" + element);
		}

		else if (vertical == 0) {
			statusFail(driver, "Element is not relative to given Element"
					+ element, testCaseName);
		}
	} catch (Exception e) {
		System.out
				.println("Exception caught in Verifying Vertical Location-------"
						+ e.getMessage());
		statusFail(driver, "Verification of  Vertical Location- Failed:"
				+ element, testCaseName);

	}
}

public static void verifyButtonFont(WebDriver driver, String string,
		String textColour, String backGroundColour, String border,
		String element, String testCaseName) throws IOException {

	try {

		WebElement btn = driver.findElement(By.xpath(element));
		String borderColour = btn.getCssValue(border);
		System.out.println(borderColour);
		String txtColour = btn.getCssValue(textColour);
		System.out.println(txtColour);
		String bgColour = btn.getCssValue(backGroundColour);

		System.out.println(bgColour);

		if ((borderColour.equalsIgnoreCase(border))
				|| ((txtColour.equalsIgnoreCase(textColour)) && (bgColour
						.equalsIgnoreCase(backGroundColour)))) {

			statusPass("Element has appropriate font" + element);

			System.out.println("Colour correct ");

		} else {
			statusFail(driver, "Element has appropriate font" + element,
					testCaseName);

		}
	} catch (Exception e) {
		System.out.println("Exception caught in Verifying font ------"
				+ e.getMessage());
		statusFail(driver, "Verification of Font- Failed:" + string,
				testCaseName);

	}
}

public static void verifyBlankText(WebDriver driver, String element,
		String testCaseName) throws IOException {
	try {

		CommonFunctions.waitForElement(driver, element, 40,
				"Change a New Password Screen");

		WebElement ele = driver.findElement(By.xpath(element));
		if ((ele.getText().isEmpty()) || (ele.getText().equals(null)))

		{

			statusPass("Verification of  Blank Text Success:");
		} else {

			statusFail(driver, "Verification of Blank Text Failed:",
					testCaseName);
		}

	} catch (Exception e) {
		System.out.println("Exception caught in VerifyText Method-------"
				+ e.getMessage());
		statusFail(driver, "Verification of Text Failed:", testCaseName);

	}
}


public static String getQuestionValue(WebDriver driver, String element)
		throws Exception {
	try {
		WebElement ele = driver.findElement(By.xpath(element));
		Select s = new Select(ele);
		String originalText = s.getFirstSelectedOption().getText();

		System.out.println(originalText);

		return originalText;

	} catch (Exception e) {

		throw new Exception();
	}
}

/**
 * 17th July @Poorva
 * 
 * @param driver
 * @param profileTabChallengeQuestionDate
 * @param string
 * @throws Exception
 */

public static void verifyDateformat(WebDriver driver, String elem,
		String testCaseName) throws Exception {
	try {
		WebElement velement = driver.findElement(By.xpath(elem));
		String value = velement.getText();

		Date date = null;
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("MM/DD/YYYY");
			date = sdf.parse(value);
			if (!value.equals(sdf.format(date))) {
				date = null;
			}
		} catch (DateTimeParseException ex) {
			ex.printStackTrace();
		}
		if (date != null) {
			statusPass("Date is presernt in appropriate format of MM/DD/YYYY ="
					+ value);

		} else {
			statusFail(
					driver,
					"Expected security questios in the dropdown is 19 but actual secuirity question is-  "
							+ value, testCaseName);
		}
	} catch (Exception e) {
		System.out.println("Exception caught in Date Format-------"
				+ e.getMessage());
		endReporting();
		Assert.fail("Matching Date is Absent");

		throw e;
	}

}

public static void CheckNonEditable(WebDriver driver, String element,
		String text, String testCaseName) throws IOException {
	try {

		boolean status = driver.findElement(By.xpath(element))
				.getTagName().equals("p");

		if (status) {
			statusPass("Element is NonEditable" + text);
		} else {
			statusFail(driver, "Element is Editable" + text, testCaseName);
		}

	}

	catch (Exception e) {
		System.out
				.println("Exception caught in check NonEditable Method-------"
						+ e.getMessage());
		statusFail(driver, "Element is EDITABLE" + text,
				testCaseName);
		endReporting();
		Assert.fail("Verify Element is NonEditable");

	}
}

public static void verifyUpdatedCurrentdate(WebDriver driver, String text,
		String elem, String testCaseName) throws Exception {
	try {

		SimpleDateFormat sdf = new SimpleDateFormat("MMM-dd-yyyy");
		Calendar cal = Calendar.getInstance();
		String todayDate = cal.toString();

		WebElement velement = driver.findElement(By.xpath(elem));
		String value = velement.getText();

		Date date = null;
		Date date2 = null;

		date = sdf.parse(value);
		date2 = sdf.parse(todayDate);

		if (date.compareTo(date2) == 0) {

			statusPass("Date is same as current date =" + value);
		}

		else {
			statusFail(driver,
					" Updated date is not same as current date  " + value,
					testCaseName);
		}
	} catch (Exception e) {
		System.out.println("Exception caught in Date Format-------"
				+ e.getMessage());
		endReporting();
		Assert.fail("Matching Date is Absent");

		throw e;
	}

}

public static void resetSecurityFields(WebDriver driver, int question1,
		String answer1, int question2, String answer2, int question3,
		String answer3, String testCaseName) throws IOException {
	try {

		CommonFunctions.resetSelectField(driver, obj.getQuestion1());
		CommonFunctions.resetSelectField(driver, obj.getQuestion2());
		CommonFunctions.resetSelectField(driver, obj.getQuestion3());
		driver.findElement(By.xpath(obj.getAnswer1())).clear();
		driver.findElement(By.xpath(obj.getAnswer2())).clear();
		driver.findElement(By.xpath(obj.getAnswer3())).clear();

	}

	catch (Exception e) {
		System.out
				.println("Exception caught in resetting Security Section Elements Method-------"
						+ e.getMessage());
		statusFail(driver,
				"Error in resetting values in Challenge question section",
				testCaseName);
		endReporting();
		Assert.fail("Reset security section elements");

	}
}

public static void resetSelectField(WebDriver driver, String element)
		throws IOException {
	try {

		Select s1 = new Select(driver.findElement(By.xpath(element)));
		s1.deselectAll();

	}

	catch (Exception e) {
		System.out
				.println("Exception caught in resetSelectField Method-------"
						+ e.getMessage());
		statusFail(driver, "Error in resetting values of select box",
				"Error in resetting values of select box");
		endReporting();
		Assert.fail("Clear Select Text Box");

	}
}


public static void ClickButton(WebDriver driver,String tmpxpath) throws IOException{
    try
    {
    	
    
           
           if (driver.findElement(By.xpath(tmpxpath)).isDisplayed())
           {
        		WebElement element = driver.findElement(By.xpath(tmpxpath));
            	JavascriptExecutor executor = (JavascriptExecutor)driver;
            	executor.executeScript("arguments[0].click();", element);
        	  
        	   statusPass("Click action performed ");
           }else
           {
        	   statusFail(driver,"Click action notperformed ","");
           }
           
      }
    catch (Exception e)
    {
           System.out.println("Exception caught in ClickButton Method-------"+e.getMessage());
           statusFail(driver,"ClickButton Operation is not performed","");
           endReporting();
           Assert.fail("ClickButton");      
    }
}

public static void movemousepointer(WebDriver driver,String element) throws IOException{
	try
	{
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].scrollIntoView(true);",driver.findElement(By.xpath(element)));
		WebElement ele=driver.findElement(By.xpath(element));
		Actions builder = new Actions(driver); 
		builder.moveToElement(ele,5,15).click().build().perform();


	} 
	catch(Exception e)
	{
		 System.out.println("Exception caught in movemousepointer Method-------"+e.getMessage());
		 statusFail(driver,"Screenshot not properly Captured",element);
		 
	 } 
} 

public static void EmailValidation(WebDriver driver, String accountNumber,String testCaseName) throws IOException {
    try {

           System.out.println("Email inbox is displayed");
    //     String parentWindow = driver.getWindowHandle();
           WebElement AccountNumberElement = driver.findElement(By.xpath("(//span[contains(text(),'" + accountNumber + "')])[1]"));
    //     Thread.sleep(120000);
           AccountNumberElement.click();
           driver.findElement(By.xpath("//a[contains(text(),'Validate email')]")).click();
           // Thread.sleep(1000);
           System.out.println("Verification link is clicked");
           CommonFunctions.SwitchToChildWindow(driver);
           CommonFunctions.waitForElement(driver, obj.getEmailVerifiedTitle(),20, "Email Verified Heading");
           CommonFunctions.verifyElement(driver, "Email Verified",obj.getEmailVerifiedTitle(),  "Email Validation Screen");
  
           
           statusPassWithScreenshot(driver, "Title Verified", "Email Validation Screen");
//         CommonFunctions.SwitchToParentWindow(driver, parentWindow);

           statusPass("Email received Successfully");

    }

    catch (Exception e) {
           System.out.println("Exception caught in Email validation Function:"
                        + e.getMessage());
           statusFail(driver, "Email validation is Unsuccesful", testCaseName);
           endReporting();
           Assert.fail("Email Validation Error");

    }
}

public static void Click(WebDriver driver, String tmpxpath)
		throws IOException {
	try {

		if (driver.findElement(By.xpath(tmpxpath)).isDisplayed()) {
			driver.findElement(By.xpath(tmpxpath)).click();
			statusPass("Click action performed ");
		} else {
			statusFail(driver, "Click action notperformed ", "");
		}

	} catch (Exception e) {
		System.out.println("Exception caught in ClickButton Method-------"
				+ e.getMessage());
		statusFail(driver, "ClickButton Operation is not performed", "");
		endReporting();
		Assert.fail("ClickButton");
	}
}
public static void SetText(WebDriver driver, String tmpxpath, String strText)
		throws IOException {
	try {
		driver.findElement(By.xpath(tmpxpath)).clear();
		driver.findElement(By.xpath(tmpxpath)).sendKeys(strText);
		Thread.sleep(1000);
	} catch (Exception e) {
		System.out.println("Exception caught in setText Method-------"
				+ e.getMessage());
		statusFail(driver, "Set Text Operation is not performed", "");
		endReporting();
		Assert.fail("SetText");
	}

}

public static void getMatchingAnswerforQuestion(WebDriver driver,
		String question, String answer, String testCaseName)
		throws IOException {

	try {

		String questionvalue = driver.findElement(By.xpath(question))
				.getText();

		HashMap<String, String> hmap = new HashMap<String, String>();

		/* Adding elements to HashMap */
		hmap.put(
				"What was the first movie you saw in the theatre as a child?",
				"Pakiza");
		hmap.put("What was the best thing you ever won as an adult?",
				"Trophy");
		hmap.put("Where was your first vacation as an adult?", "Srilanka");
		hmap.put("What was your favourite game as a child?", "Tambola");
		hmap.put("What was your favourite food as a child?", "Maggie");
		hmap.put("What was the name of your first manager?", "Manish");
		hmap.put("What was your favourite book or novel as a child?",
				"babyDayOut");
		hmap.put("Who was your favourite athlete as a child?",
				"AbhinavBindra");
		hmap.put("What was the name of your first roommate?", "SudhaSingh");
		hmap.put("What was the name of the street that you grew up on?",
				"zxcvbnm");
		hmap.put("What was your favourite song as a child?", "EveryNight");
		hmap.put(
				"What was the first and last name of your first boyfriend or girlfriend?",
				"friend123");
		hmap.put("What was the name of your first childhood pet?",
				"pet123");
		hmap.put("What was your first job?", "Engineer");
		hmap.put("Who was your childhood hero?", "KenuReeves");
		hmap.put("What was your favorite subject in school?", "mathematics");
		hmap.put("Who was your favourite teacher?", "Tessyvadekel");
		hmap.put("What is the name of your favourite childhood friend?",
				"IshaTripathi");
		hmap.put("What did you want to be when you grew up?", "up1234");
		hmap.put("What was the make of your first car?", "WagoonR");

		Iterator entries = hmap.entrySet().iterator();
		while (entries.hasNext()) {
			Map.Entry entry = (Map.Entry) entries.next();
			String key = (String) entry.getKey();

			System.out.println(key);

			String value = (String) entry.getValue();
			System.out.println(value);
			if (key.contains(questionvalue)) {

				driver.findElement(By.xpath(answer)).sendKeys(value);
				System.out.println(key + value);

			}
		}
	} catch (Exception e) {
		System.out
				.println("Exception caught in getting the answer to teh question-------"
						+ e.getMessage());
		statusFail(driver, "Matching answer is not obtained", "");
		endReporting();
		Assert.fail("Answer Mismatch");
	}
}



public static void EmailLogin(WebDriver driver, String NewEmail,String password, String testCaseName) throws IOException {
    try {
           obj = new FetchingOR(fileName);
           driver.findElement(By.xpath(obj.getEmailUserName())).sendKeys(NewEmail);
           driver.findElement(By.xpath(obj.getEmailPassword())).sendKeys(password);
           driver.findElement(By.xpath(obj.getEmailSigninButton())).click();
           statusPass("Email Login Success");
    //     Thread.sleep(15000);
    }

    catch (Exception e) {
           // System.out.println("Exception caught in Login Function:"+
           // e.getMessage());
           statusFail(driver, "Email Log In Unsuccesful", testCaseName);
    
           endReporting();
           Assert.fail("Email Login Error");
    }

}


public static void EmailValidation(int rowNumber, String accountNumber,
		String testCaseName) throws IOException {
	try {

		System.out.println("Email inbox is displayed");
		String parentWindow = driver.getWindowHandle();
		WebElement AccountNumberElement = driver.findElement(By
				.xpath("//span[contains(text(),'" + accountNumber + "')]"));
		Thread.sleep(120000);
		AccountNumberElement.click();
		driver.findElement(By.xpath("//a[contains(text(),'Click Here')]"))
				.click();
		// Thread.sleep(1000);
		System.out.println("Verification link is clicked");
		CommonFunctions.SwitchToChildWindow(driver);
		CommonFunctions.waitForElement(driver, obj.getEmailVerifiedTitle(),
				20, "Email Verified Heading");
		CommonFunctions.verifyElement(driver, "Email Verified",
				obj.getEmailVerifiedTitle(), testCaseName);
		statusPassWithScreenshot(driver, "Title Verified", testCaseName);
		CommonFunctions.SwitchToParentWindow(driver, parentWindow);

		statusPass("Email received Successfully");

	}

	catch (Exception e) {
		System.out.println("Exception caught in Email validation Function:"
				+ e.getMessage());
		statusFail(driver, "Email validation is Unsuccesful", testCaseName);
		endReporting();
		Assert.fail("Email Validation Error");

	}
}
}





