package com.Gatewaytr.pages;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.Gateway.GlobalParameters.BaseClass;

public class DataBase extends BaseClass {
	
	public static String DBConnection(WebDriver driver,String preRequisite,String testRunLanguage,String testCaseName) throws ClassNotFoundException, SQLException, IOException
	{
		String myName =null;
		try{
			 System.out.println("iNSIDE database 1");
		  	String query=null;
		//Connection URL Syntax: "jdbc:mysql://ipaddress:portnumber/db_name"		
        String dbUrl = "jdbc:oracle:thin:@10.193.16.54:1521:SIRW2";		
        
        System.out.println("iNSIDE database 2");

		//Database Username		
		String username = "retail";	
        
		//Database Password		
		String password = "retail";	
		  	
			  	
	/*	    String dbUrl = "jdbc:oracle:thin:@10.193.17.33:1521:SIRW2";		
	        
	        System.out.println("iNSIDE database 2");

			//Database Username		
			String username = "craja01";	
	        
			//Database Password		
			String password = "craja0123";*/
		
		//EXISTING USER ACCOUNTS -->3.2.2 (MERIDIAN)

		if(preRequisite.equalsIgnoreCase("ACCOUNTWITHNOSECURITYQUES")&& testRunLanguage.equalsIgnoreCase("ENGLISH"))
				{
						
			query = "select WC_USERID from sirw.si_clients  where wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) AND WC_USERID IN (select CL_CLCODE from retail.client where cl_freetype='W') AND wc_lang='E' AND WC_SUSPIND='N' AND WC_PROFILEVALID='N'";
	
        System.out.println("iNSIDE database 3");
        }
		
		else if(preRequisite.equalsIgnoreCase("ACCOUNTWITHNOSECURITYQUES")&& testRunLanguage.equalsIgnoreCase("FRENCH"))
		{
				
query = "select WC_USERID from sirw.si_clients  where wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) AND WC_USERID IN (select CL_CLCODE from retail.client where cl_freetype='W') AND wc_lang='F'";
}
	//Password = aaaaaa --. 3.2.7 (NON MERIDIAN)
		else if(preRequisite.equalsIgnoreCase("ACCOUNTINACTIVEMORETHAN1YEAR")&&testRunLanguage.equalsIgnoreCase("ENGLISH"))
		{
			 query = "SELECT wc_userid FROM SIRW.SI_CLIENTS WHERE WC_LASTACCESS like '%17-%' and WC_PASSWD='EZX9deU6UJbhY' and WC_LANG='E' AND wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) AND WC_SUSPIND IS NULL";
		}
		
		
		else if(preRequisite.equalsIgnoreCase("ACCOUNTINACTIVEMORETHAN1YEAR")&&testRunLanguage.equalsIgnoreCase("FRENCH"))
		{
			 query = "SELECT wc_userid FROM SIRW.SI_CLIENTS WHERE WC_LASTACCESS like '%15-%' and WC_PASSWD='EZLWofbCL1hxw' and WC_LANG='E' AND wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) AND WC_SUSPIND='N'";
		}
	//Password = aaaaaa (INSECURE PASSWORD) --> 3.2.5 (NON MERIDIAN)
		else if(preRequisite.equalsIgnoreCase("SECQUESCUTOFFDATEEXCEEDEDNONMERIDIAN")&&testRunLanguage.equalsIgnoreCase("ENGLISH"))
		{
			query="SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE  wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) AND WC_FIRSTACCESS IS NOT NULL and WC_PASSWD='EZX9deU6UJbhY' and WC_SUSPIND = 'N'and WC_LASTACCESS > sysdate - 365 and WC_RESETPWD = 'N' AND WC_LANG='E' AND wc_passwdind='Y' and wc_setup_secqn_disabled='N' and wc_userid not in(select cl_clcode from retail.client where cl_freetype='W')";
		}
		
		
		else if(preRequisite.equalsIgnoreCase("SECQUESCUTOFFDATEEXCEEDEDNONMERIDIAN")&&testRunLanguage.equalsIgnoreCase("FRENCH"))
		{
			query =  "SELECT wc_userid FROM SIRW.SI_CLIENTS WHERE WC_LASTPWD='EZLWofbCL1hxw' and WC_PASSWD<>'EZLWofbCL1hxw' AND WC_FIRSTACCESS IS NOT NULL and wc_lastaccess between '17-01-01' and '17-05-30' and WC_LANG='F' AND WC_SUSPIND='N'  AND WC_USERID NOT IN (select CL_CLCODE from retail.client where cl_freetype='W')";
		}
		
		
		//Password = aaaaaa (INSECURE PASSWORD) --> 3.2.5 (MERIDIAN)
				else if(preRequisite.equalsIgnoreCase("SECQUESCUTOFFDATEEXCEEDEDMERIDIAN")&&testRunLanguage.equalsIgnoreCase("ENGLISH"))
				{
					 query = "SELECT wc_userid FROM SIRW.SI_CLIENTS WHERE WC_LASTPWD='EZLWofbCL1hxw' AND WC_USERID IN (select CL_CLCODE from retail.client where cl_freetype='W') AND WC_PASSWD<>'EZLWofbCL1hxw' AND WC_FIRSTACCESS IS NOT NULL and wc_lastaccess between '17-01-01' and '17-05-30' and WC_LANG='E' AND WC_SUSPIND='N'";
				}
				
				
				else if(preRequisite.equalsIgnoreCase("SECQUESCUTOFFDATEEXCEEDEDMERIDIAN")&&testRunLanguage.equalsIgnoreCase("FRENCH"))
				{
					query =  "SELECT wc_userid FROM SIRW.SI_CLIENTS WHERE WC_LASTPWD='EZLWofbCL1hxw' AND WC_USERID IN (select CL_CLCODE from retail.client where cl_freetype='W') AND WC_PASSWD<>'EZLWofbCL1hxw' AND WC_FIRSTACCESS IS NOT NULL and wc_lastaccess between '17-01-01' and '17-05-30' and WC_LANG='F' AND WC_SUSPIND='N'";
				}
		
		
		//Password = aaaaaa (INSECURE PASSWORD) --> 3.2.5 (MAIN PAGE)
				else if(preRequisite.equalsIgnoreCase("SECQUESCUTOFFDATEEXCEEDED")&&testRunLanguage.equalsIgnoreCase("ENGLISH"))
				{
				
					query="SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE  wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) AND WC_FIRSTACCESS IS NOT NULL and WC_PASSWD='EZX9deU6UJbhY' and WC_SUSPIND = 'N'and WC_LASTACCESS > sysdate - 365  AND WC_LANG='E' and wc_setup_secqn_disabled='N' and wc_profilevalid='N'";
				}
				
				
				else if(preRequisite.equalsIgnoreCase("SECQUESCUTOFFDATEEXCEEDED")&&testRunLanguage.equalsIgnoreCase("FRENCH"))
				{
					 query = "SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE  wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) AND WC_FIRSTACCESS IS NOT NULL and WC_PASSWD='EZLWofbCL1hxw' and WC_SUSPIND = 'N'and WC_LASTACCESS > sysdate - 365 and WC_RESETPWD = 'N' AND WC_LANG='F' and wc_setup_secqn_disabled='N' AND WC_PROFILEVALID='N'";	
		}
		//Password = A1aaaaaa (SECURE PASSWORD)--> 3.2.6 (NON - MERIDIAN)
		
		/*		else if(preRequisite.equalsIgnoreCase("SECQUESCUTOFFDATEEXCEEDEDSECUREPASS")&&testRunLanguage.equalsIgnoreCase("ENGLISH"))
				{
					query = "SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE  wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) and WC_USERID NOT IN (select CL_CLCODE from retail.client where cl_freetype='W') AND WC_FIRSTACCESS IS NOT NULL and WC_PASSWD='EZGD2gp80bEQQ' and WC_SUSPIND = 'N'and WC_LASTACCESS > sysdate - 365 and WC_RESETPWD = 'N' AND WC_LANG='E' and WC_LASTPWD <> 'EZLWofbCL1hxw' and wc_setup_secqn_disabled='N'";
				}
		
				
				else if(preRequisite.equalsIgnoreCase("SECQUESCUTOFFDATEEXCEEDEDSECUREPASS")&&testRunLanguage.equalsIgnoreCase("FRENCH"))
				{
					query = "SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE  wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) and WC_USERID NOT IN (select CL_CLCODE from retail.client where cl_freetype='W') AND WC_FIRSTACCESS IS NOT NULL and WC_PASSWD='EZGD2gp80bEQQ' and WC_SUSPIND = 'N'and WC_LASTACCESS > sysdate - 365 and WC_RESETPWD = 'N' AND WC_LANG='F' and WC_LASTPWD <> 'EZLWofbCL1hxw' and wc_setup_secqn_disabled='N'";
				}*/
		
				else if(preRequisite.equalsIgnoreCase("SECQUESCUTOFFDATEEXCEEDEDSECUREPASS")&&testRunLanguage.equalsIgnoreCase("ENGLISH"))
				{
				//	 query = "SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE  wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) AND WC_FIRSTACCESS IS NOT NULL and WC_PASSWD='EZLWofbCL1hxw' and WC_SUSPIND = 'N'and WC_LASTACCESS > sysdate - 365 and WC_RESETPWD = 'N' AND WC_LANG='E' and wc_setup_secqn_disabled='N'";
					//query="SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE  wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) AND WC_FIRSTACCESS IS NOT NULL and WC_PASSWD='EZLWofbCL1hxw' and WC_SUSPIND = 'N'and WC_LASTACCESS > sysdate - 365 and WC_RESETPWD = 'N' AND WC_LANG='E' AND wc_passwdind='Y' and wc_setup_secqn_disabled='N'";
				//	query="SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE  wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) AND WC_FIRSTACCESS IS NOT NULL and WC_PASSWD='EZGD2gp80bEQQ' and WC_SUSPIND = 'N'and WC_LASTACCESS > sysdate - 365 and WC_RESETPWD = 'N' AND WC_LANG='E' AND wc_passwdind='Y' and wc_setup_secqn_disabled='N'";
					query="SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE  wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge)and WC_USERID in (select CL_CLCODE from retail.client where cl_freetype='W' ) and WC_PASSWD='EZGD2gp80bEQQ' and WC_SUSPIND = 'N'and WC_LASTACCESS > sysdate - 365 and WC_RESETPWD = 'N' and wc_tradepwd is not null AND WC_LANG='E' AND wc_passwdind='Y' and wc_setup_secqn_disabled='N'";
				}
				
				
				else if(preRequisite.equalsIgnoreCase("SECQUESCUTOFFDATEEXCEEDEDSECUREPASS")&&testRunLanguage.equalsIgnoreCase("FRENCH"))
				{
					query = "SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE  wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) AND WC_FIRSTACCESS IS NOT NULL and WC_PASSWD='EZLWofbCL1hxw' and WC_SUSPIND = 'N'and WC_LASTACCESS > sysdate - 365 and WC_RESETPWD = 'N' AND WC_LANG='F' and wc_setup_secqn_disabled='N'";
				}
				
		
//Password = A1aaaaaa (SECURE PASSWORD)--> 3.2.6 (NON - MERIDIAN) -> security question set
		
				else if(preRequisite.equalsIgnoreCase("SECQUESCUTOFFDATEEXCEEDEDSECUREPASS1")&&testRunLanguage.equalsIgnoreCase("ENGLISH"))
				{
					 query = "SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE  wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) AND WC_FIRSTACCESS IS NOT NULL and WC_PASSWD='EZGD2gp80bEQQ' and WC_SUSPIND = 'N'and WC_LASTACCESS  like '%17-%'  and WC_RESETPWD = 'N' AND WC_LANG='E' and wc_profilevalid='Y'";
				}
				
				
				else if(preRequisite.equalsIgnoreCase("SECQUESCUTOFFDATEEXCEEDEDSECUREPASS1")&&testRunLanguage.equalsIgnoreCase("FRENCH"))
				{
					 query = "SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE  wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) AND WC_FIRSTACCESS IS NOT NULL and WC_PASSWD='EZGD2gp80bEQQ' and WC_SUSPIND = 'N'and WC_LASTACCESS  like '%17-%'  and WC_RESETPWD = 'N' AND WC_LANG='F' and wc_profilevalid='Y'";
				}	
		
		
		//EXISTING USER ACCOUNTS --> 3.2.3 --> UNSECURE PASSWORD = aaaaaa (NON MERIDIAN)
		//SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE  wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) AND WC_FIRSTACCESS IS NOT NULL and WC_PASSWD='EZLWofbCL1hxw' and WC_SUSPIND = 'N'and WC_LASTACCESS > sysdate - 365 and WC_RESETPWD = 'N' AND WC_LANG='E' and wc_setup_secqn_disabled='N' AND WC_PROFILEVALID='N' and wc_tradestatus ='E' and wc_passwdind ='Y'";
		else if(preRequisite.equalsIgnoreCase("COMMUNICATIONLINKUNSECURE")&&testRunLanguage.equalsIgnoreCase("ENGLISH"))
		{
		
	
			query="SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE  wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) AND WC_FIRSTACCESS IS NOT NULL and WC_PASSWD='EZX9deU6UJbhY' and WC_SUSPIND = 'N'and WC_LASTACCESS > sysdate - 365 and WC_RESETPWD = 'N' AND WC_LANG='E' AND wc_passwdind='Y' and wc_setup_secqn_disabled='N' and wc_profilevalid='N'";
			
			// commented due to no accounts in Database,Manoj
		//	query="SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE  wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) AND WC_FIRSTACCESS IS NOT NULL and WC_PASSWD='EZX9deU6UJbhY' and WC_SUSPIND = 'N'and WC_LASTACCESS > sysdate - 365 and WC_RESETPWD = 'N' AND WC_LANG='E' AND wc_passwdind='Y' and wc_setup_secqn_disabled='N' and wc_tradepwd is not null";
			
		}
		
		
		else if(preRequisite.equalsIgnoreCase("COMMUNICATIONLINKUNSECURE")&&testRunLanguage.equalsIgnoreCase("FRENCH"))
		{
			query = "SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE  wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) AND WC_FIRSTACCESS IS NOT NULL and WC_PASSWD='EZLWofbCL1hxw' and WC_SUSPIND = 'N'and WC_LASTACCESS > sysdate - 365 and WC_RESETPWD = 'N' AND WC_LANG='F' and wc_setup_secqn_disabled='N' AND WC_PROFILEVALID='N' and wc_tradestatus ='E' and wc_passwdind ='Y'";
		}
		
		
		//EXISTING USER ACCOUNTS --> 3.2.3 --> UNSECURE PASSWORD= aaaaaa (MERIDIAN)
		
		else if(preRequisite.equalsIgnoreCase("COMMUNICATIONLINKUNSECUREMERIDIAN")&&testRunLanguage.equalsIgnoreCase("ENGLISH"))
		{
			query = "SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE  wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) AND WC_FIRSTACCESS IS NOT NULL and WC_PASSWD='EZLWofbCL1hxw' and WC_SUSPIND = 'N'and WC_LASTACCESS > sysdate - 365 and WC_RESETPWD = 'N' AND WC_LANG='E' and wc_tradestatus ='E' and wc_passwdind ='Y'";
		}
		
		
		else if(preRequisite.equalsIgnoreCase("COMMUNICATIONLINKUNSECUREMERIDIAN")&&testRunLanguage.equalsIgnoreCase("FRENCH"))
		{
			query = "SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE  wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) AND WC_FIRSTACCESS IS NOT NULL and WC_PASSWD='EZLWofbCL1hxw' and WC_SUSPIND = 'N'and WC_LASTACCESS > sysdate - 365 and WC_RESETPWD = 'N' AND WC_LANG='E' and wc_tradestatus ='E' and wc_passwdind ='Y'";
			}
		
		
		
		
		//EXISTING USER ACCOUNTS --> 3.2.4 --> SECURE PASSWORD = A1aaaaaa (NON MERIDIAN)
				
		else if(preRequisite.equalsIgnoreCase("COMMUNICATIONLINKSECURE")&&testRunLanguage.equalsIgnoreCase("ENGLISH"))
		{
			//query = "SELECT WC_USERID  FROM SIRW.SI_CLIENTS WHERE  wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) AND WC_FIRSTACCESS IS NOT NULL and WC_PASSWD='EZGD2gp80bEQQ'  and WC_SUSPIND = 'N'and WC_LASTACCESS > sysdate - 365  and WC_RESETPWD = 'N' AND WC_LANG='E' AND wc_passwdind='Y' and wc_setup_secqn_disabled='N'";
			//query="SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE  wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge)and WC_USERID NOT IN (select CL_CLCODE from retail.client where cl_freetype='W' and cl_status in('A', 'R')) AND WC_FIRSTACCESS IS NOT NULL and WC_PASSWD='EZGD2gp80bEQQ' and WC_SUSPIND = 'N'and WC_LASTACCESS > sysdate - 365 and WC_RESETPWD = 'N' AND WC_LANG='E' AND wc_passwdind='Y' and wc_setup_secqn_disabled='N'";	
			//query="SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE  wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge)and WC_USERID in (select CL_CLCODE from retail.client where cl_freetype='W' ) and WC_PASSWD='EZGD2gp80bEQQ' and WC_SUSPIND = 'N'and WC_LASTACCESS > sysdate - 365 and WC_RESETPWD = 'N' and wc_tradepwd is not null AND WC_LANG='E' AND wc_passwdind='Y' and wc_setup_secqn_disabled='N'";
			query="SELECT wc_userid FROM SIRW.SI_CLIENTS WHERE  wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) and WC_USERID in (select CL_CLCODE from retail.client where cl_freetype='W' ) AND wc_passwdind='Y' and WC_PASSWD='EZGD2gp80bEQQ' and WC_SUSPIND = 'N'and WC_LASTACCESS > sysdate - 365 and WC_RESETPWD = 'N'  AND WC_LANG='E'  and wc_setup_secqn_disabled='N' and wc_profilevalid='N'";

		}
		
		
		else if(preRequisite.equalsIgnoreCase("COMMUNICATIONLINKSECURE")&&testRunLanguage.equalsIgnoreCase("FRENCH"))
		{
			query = "SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE  wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge)  AND WC_LASTPWD <> 'EZLWofbCL1hxw' and  WC_FIRSTACCESS IS NOT NULL and WC_PASSWD='EZGD2gp80bEQQ' and WC_SUSPIND = 'N'and WC_LASTACCESS > sysdate - 365 and WC_RESETPWD = 'N' AND WC_LANG='F'  and wc_setup_secqn_disabled='N' and wc_profilevalid='N' and wc_tradestatus ='E' and wc_passwdind ='Y'";
				
		}
		
		
		
		
		//EXISTING USER ACCOUNTS --> 3.2.4 --> SECURE PASSWORD = A1aaaaaa (MERIDIAN)
		
		
	
		
				else if(preRequisite.equalsIgnoreCase("COMMUNICATIONLINKSECUREMERIDIAN")&&testRunLanguage.equalsIgnoreCase("ENGLISH"))
				{
					query = "SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE  wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) AND WC_FIRSTACCESS IS NOT NULL and WC_PASSWD='EZGD2gp80bEQQ' and WC_SUSPIND = 'N'and WC_LASTACCESS > sysdate - 365 and WC_RESETPWD = 'N' and WC_USERID IN (select CL_CLCODE from retail.client where cl_freetype='W') AND WC_LANG='E' AND wc_passwdind='Y' and wc_setup_secqn_disabled='N' and WC_TRADEPWD is not null";
							}
				
				
				else if(preRequisite.equalsIgnoreCase("COMMUNICATIONLINKSECUREMERIDIAN")&&testRunLanguage.equalsIgnoreCase("FRENCH"))
				{
					query = "SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE  wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) AND WC_FIRSTACCESS IS NOT NULL and WC_PASSWD='EZGD2gp80bEQQ' and WC_SUSPIND = 'N'and WC_LASTACCESS > sysdate - 365 and WC_RESETPWD = 'N' and WC_USERID IN (select CL_CLCODE from retail.client where cl_freetype='W') AND WC_LANG='F' AND wc_passwdind='Y' and wc_setup_secqn_disabled='N' and WC_TRADEPWD is not null";
						
				}
				
		
		
		
		//NEW USER ACCOUNTS --> 3.2.1 (MERIDIAN)
		
		else if(preRequisite.equalsIgnoreCase("NEWUSERACCOUNTS")&&testRunLanguage.equalsIgnoreCase("ENGLISH"))
		{
			 query = "SELECT wc_userid FROM SIRW.SI_CLIENTS WHERE WC_FIRSTACCESS IS NULL AND WC_LANG='E' AND WC_USERID IN (select CL_CLCODE from retail.client where cl_freetype='W')";
		}
		
		
		else if(preRequisite.equalsIgnoreCase("NEWUSERACCOUNTS")&&testRunLanguage.equalsIgnoreCase("FRENCH"))
		{
			query =  "SELECT wc_userid FROM SIRW.SI_CLIENTS WHERE WC_FIRSTACCESS IS NULL AND WC_LANG='F' AND WC_USERID IN (select CL_CLCODE from retail.client where cl_freetype='W')";
		}
		
		

		else if(preRequisite.equalsIgnoreCase("NEWUSERACCOUNTSTC005")&&testRunLanguage.equalsIgnoreCase("ENGLISH"))
		{
			 query = "SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE WC_FIRSTACCESS IS NOT NULL AND wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) AND WC_TRADEPWD IS NULL AND WC_RESETPWD='N' AND WC_LANG='E' and wc_profilevalid='N' AND wc_setup_secqn_disabled='N'";
		}
		
		
		else if(preRequisite.equalsIgnoreCase("NEWUSERACCOUNTSTC005")&&testRunLanguage.equalsIgnoreCase("FRENCH"))
		{
			query =  "SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE WC_FIRSTACCESS IS NOT NULL AND wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) AND WC_TRADEPWD IS NULL AND WC_RESETPWD='N' AND WC_LANG='E' and wc_profilevalid='N' AND wc_setup_secqn_disabled='N'";
		}
		
		
		else if(preRequisite.equalsIgnoreCase("NEWUSERACCOUNTSTC006")&&testRunLanguage.equalsIgnoreCase("ENGLISH"))
		{
			 query = "SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE WC_FIRSTACCESS IS NULL AND wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) and wc_userid NOT IN (select se_userid from sirw.si_eproxy) AND WC_TRADEPWD IS NULL AND WC_RESETPWD='N' AND WC_LANG='E' and wc_profilevalid='N' AND wc_setup_secqn_disabled='N'";
		}
		
		
		else if(preRequisite.equalsIgnoreCase("NEWUSERACCOUNTSTC006")&&testRunLanguage.equalsIgnoreCase("FRENCH"))
		{
			query =  "SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE WC_FIRSTACCESS IS NULL AND wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) and wc_userid NOT IN (select se_userid from sirw.si_eproxy) AND WC_TRADEPWD IS NULL AND WC_RESETPWD='N' AND WC_LANG='F' and wc_profilevalid='N' AND wc_setup_secqn_disabled='Y'";
		}
		
		
	    //Load jdbc driver	
		//com.mysql.jdbc.Driver
   	    Class.forName("oracle.jdbc.driver.OracleDriver");
   	 
        System.out.println("iNSIDE database 5");
   		//Create Connection to DB		
    	Connection con = DriverManager.getConnection(dbUrl,username,password);
    	
  
  		//Create Statement Object		
	   Statement stmt = con.createStatement();					

			// Execute the SQL Query. Store results in ResultSet		
 		ResultSet rs= stmt.executeQuery(query);	
 	
 		//log("info", "OUTSIDE CONTENTS 1 ***"+rs.getString(1));
 		//log("info", "OUTSIDE CONTENTS 2 ***"+rs.getString(2));
 		// While Loop to iterate through all data and print results	
 		
 		 System.out.println("iNSIDE database");
 			
 			while (rs.next())
		   {
			
 				myName= rs.getString(1);								        
 				System.out.println("From&&&&&&&&&&Database&&&&&&&&&&:"+myName);
 				break;
            }	
 		
	
		return myName;	
		}

		catch(Exception e)
		{
			
			 System.out.println("Exception caught in DB Connection Method-------:"+e.getMessage());
			 statusFail(driver,"Error in getting data from Database:",testCaseName);
			 endReporting();
			 Assert.fail("Database Connectivity");
			 return myName;
			
		}
			
		
	
	}
	
	public static void DBChallengeQuesNotUpdated(WebDriver driver,String accountNumber,String testCaseName) throws ClassNotFoundException, SQLException, IOException
	{
		String myName =null;
		try{
			
		  	String query=null;
		
        String dbUrl = "jdbc:oracle:thin:@10.193.16.54:1521:SIRW2";		
   		String username = "retail";	
 		String password = "retail";				
		query = "select * from sirw.si_qa_challenge where QA_USERID='"+accountNumber+"'";
		System.out.println("Query:"+query);
	    Class.forName("oracle.jdbc.driver.OracleDriver");
   	   	Connection con = DriverManager.getConnection(dbUrl,username,password);
    	Statement stmt = con.createStatement();					
		ResultSet rs= stmt.executeQuery(query);	
		
		if(!rs.isBeforeFirst())
		{
			//No Data 
			System.out.println("Pass-No Data ");
			statusPass("Challenge Questions have not been updated SI_QA_CHALLENGE table with version V1");
		}
		else
		{
			System.out.println("Fail- Contains Data");
			 statusFail(driver,"Challenge Questions have been updated SI_QA_CHALLENGE table with version V1",testCaseName);
		}
 	/*	while (!rs.next())
	   {
			
 				myName= rs.getString(1);								        
 				System.out.println("Failed"+myName);
 				break;
       }	*/
 		
 	
 		// statusPass("Challenge Questions have not been updated SI_QA_CHALLENGE table with version V1");
	
		}

		catch(Exception e)
		{
			System.out.println("Inside Catch");
			 System.out.println("Exception caught in DB Connection Method-------:"+e.getMessage());
			 statusFail(driver,"Error in getting data from Database:",testCaseName);
			 endReporting();
			 Assert.fail("Database Connectivity");
			
			
		}
			
		
	
	}

	
	
	public static void DBChallengeQuesUpdated(WebDriver driver,String accountNumber,String testCaseName) throws ClassNotFoundException, SQLException, IOException
	{
		String myName =null;
		try{
			
		  	String query=null;
		
        String dbUrl = "jdbc:oracle:thin:@10.193.16.54:1521:SIRW2";		
   		String username = "retail";	
 		String password = "retail";				
		query = "select * from sirw.si_qa_challenge where QA_USERID='"+accountNumber+"'";
		System.out.println("Query:"+query);
	    Class.forName("oracle.jdbc.driver.OracleDriver");
   	   	Connection con = DriverManager.getConnection(dbUrl,username,password);
    	Statement stmt = con.createStatement();					
		ResultSet rs= stmt.executeQuery(query);	
		
		if(!rs.isBeforeFirst())
		{
			//No Data 
			System.out.println("Pass-No Data ");
			statusFail(driver,"Challenge Questions have not been updated SI_QA_CHALLENGE table with version V1",testCaseName);
			
			}
		else
		{
			System.out.println("Fail- Contains Data");
			statusPass("Challenge Questions have been updated SI_QA_CHALLENGE table with version V1");
			 
			}
 	/*	while (!rs.next())
	   {
			
 				myName= rs.getString(1);								        
 				System.out.println("Failed"+myName);
 				break;
       }	*/
 		
 	
 		// statusPass("Challenge Questions have not been updated SI_QA_CHALLENGE table with version V1");
	
		}

		catch(Exception e)
		{
			System.out.println("Inside Catch");
			 System.out.println("Exception caught in DB Connection Method-------:"+e.getMessage());
			 statusFail(driver,"Error in getting data from Database:",testCaseName);
			 endReporting();
			 Assert.fail("Database Connectivity");
			
			
		}
			
		
	
	}

	
	
	
	
	
	public static void DBVerifyloginPwdRequiresReset(WebDriver driver,String accountNumber,String testCaseName) throws ClassNotFoundException, SQLException, IOException
	{
		String myName =null;
		try{
			
		  	String query=null;
		
        String dbUrl = "jdbc:oracle:thin:@10.193.16.54:1521:SIRW2";		
   		String username = "retail";	
 		String password = "retail";				
		query = "SELECT WC_RESETPWD FROM SIRW.SI_CLIENTS WHERE WC_USERID='"+accountNumber+"'";
		System.out.println("Query:"+query);
	    Class.forName("oracle.jdbc.driver.OracleDriver");
   	   	Connection con = DriverManager.getConnection(dbUrl,username,password);
    	Statement stmt = con.createStatement();					
		ResultSet rs= stmt.executeQuery(query);	
		
		
		while (rs.next())
		   {
				
	 				myName= rs.getString(1);								        
	 				System.out.println("DB Contents**********"+myName);
	 				break;
	       }
		if(myName.equalsIgnoreCase("Y"))
		{
			//No Data 
			System.out.println("Pass**********");
			statusPass("WC_RESETPWD column in SI_CLIENTS table is updated with 'Y'");
		}
		else
		{
			System.out.println("Fail**********");
			 statusFail(driver,"WC_RESETPWD column in SI_CLIENTS table is updated with 'N'",testCaseName);
		}
 		}

		catch(Exception e)
		{
			System.out.println("Inside Catch");
			 System.out.println("Exception caught in DBVerifyloginPwdRequiresReset Method-------:"+e.getMessage());
			 statusFail(driver,"Error in getting details from DBVerifyloginPwdRequiresReset method from Database:",testCaseName);
			 endReporting();
			 Assert.fail("Database Connectivity");
			
			
		}
			
		
	
	}
	
	
	public static void DBVerifyNloginPwdRequiresReset(WebDriver driver,String accountNumber,String testCaseName) throws ClassNotFoundException, SQLException, IOException
	{
		String myName =null;
		try{
			
		  	String query=null;
		
        String dbUrl = "jdbc:oracle:thin:@10.193.16.54:1521:SIRW2";		
   		String username = "retail";	
 		String password = "retail";				
		query = "SELECT WC_RESETPWD FROM SIRW.SI_CLIENTS WHERE WC_USERID='"+accountNumber+"'";
		System.out.println("Query:"+query);
	    Class.forName("oracle.jdbc.driver.OracleDriver");
   	   	Connection con = DriverManager.getConnection(dbUrl,username,password);
    	Statement stmt = con.createStatement();					
		ResultSet rs= stmt.executeQuery(query);	
		
		
		while (rs.next())
		   {
				
	 				myName= rs.getString(1);								        
	 				System.out.println("DB Contents**********"+myName);
	 				break;
	       }
		if(myName.equalsIgnoreCase("N"))
		{
			//No Data 
			System.out.println("Pass**********");
			statusPass("WC_RESETPWD column in SI_CLIENTS table is updated with 'N'");
		}
		else
		{
			System.out.println("Fail**********");
			 statusFail(driver,"WC_RESETPWD column in SI_CLIENTS table is updated with 'Y'",testCaseName);
		}
 		}

		catch(Exception e)
		{
			System.out.println("Inside Catch");
			 System.out.println("Exception caught in DBVerifyloginPwdRequiresReset Method-------:"+e.getMessage());
			 statusFail(driver,"Error in getting details from DBVerifyloginPwdRequiresReset method from Database:",testCaseName);
			 endReporting();
			 Assert.fail("Database Connectivity");
			
			
		}
			
		
	
	}
	
	
	public static void DBVerifyNloginPwdRequiresReset1(WebDriver driver,String accountNumber,String testCaseName) throws ClassNotFoundException, SQLException, IOException
	{
		String myName =null;
		try{
			
		  	String query=null;
		
        String dbUrl = "jdbc:oracle:thin:@10.193.16.54:1521:SIRW2";		
   		String username = "retail";	
 		String password = "retail";				
		query = "SELECT WC_RESETPWD FROM SIRW.SI_CLIENTS WHERE WC_USERID='"+accountNumber+"'";
		System.out.println("Query:"+query);
	    Class.forName("oracle.jdbc.driver.OracleDriver");
   	   	Connection con = DriverManager.getConnection(dbUrl,username,password);
    	Statement stmt = con.createStatement();					
		ResultSet rs= stmt.executeQuery(query);	
		
		
		while (rs.next())
		   {
				
	 				myName= rs.getString(1);								        
	 				System.out.println("DB Contents**********"+myName);
	 				break;
	       }
		if(myName.equalsIgnoreCase("Y"))
		{
			//No Data 
			System.out.println("Pass**********");
			statusPass("WC_RESETPWD column in SI_CLIENTS table is updated with 'Y'");
		}
		else
		{
			System.out.println("Fail**********");
			 statusFail(driver,"WC_RESETPWD column in SI_CLIENTS table is updated with 'N'",testCaseName);
		}
 		}

		catch(Exception e)
		{
			System.out.println("Inside Catch");
			 System.out.println("Exception caught in DBVerifyloginPwdRequiresReset Method-------:"+e.getMessage());
			 statusFail(driver,"Error in getting details from DBVerifyloginPwdRequiresReset method from Database:",testCaseName);
			 endReporting();
			 Assert.fail("Database Connectivity");
			
			
		}
			
		
	
	}

	public static void DBVerifyloginPwdProfileValid(WebDriver driver,String accountNumber,String testCaseName) throws ClassNotFoundException, SQLException, IOException
	{
		String myName =null;
		try{
			
		  	String query=null;
		
        String dbUrl = "jdbc:oracle:thin:@10.193.16.54:1521:SIRW2";		
   		String username = "retail";	
 		String password = "retail";				
		query = "SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE WC_PROFILEVALID = 'N' and WC_SETUP_SECQN_DISABLED = 'Y' and WC_USERID='"+accountNumber+"'";
		System.out.println("Query:"+query);
	    Class.forName("oracle.jdbc.driver.OracleDriver");
   	   	Connection con = DriverManager.getConnection(dbUrl,username,password);
    	Statement stmt = con.createStatement();					
		ResultSet rs= stmt.executeQuery(query);	
		
		
		
		if(!rs.isBeforeFirst())
		{
			
			//No Data 
			System.out.println("Fail-No Data ");
			statusFail(driver,"WC_PROFILEVALID = 'N' and WC_SETUP_SECQN_DISABLED = 'Y' is not updated in SI_CLIENTS",testCaseName);
			
					 
				
			}
		else
		{
			

			System.out.println("Pass- Contains Data");
			statusPass("WC_PROFILEVALID = 'N' and WC_SETUP_SECQN_DISABLED = 'Y' is updated in SI_CLIENTS");
		
			
			}
		
		
	/*	if(!rs.isBeforeFirst())
		{
			//No Data 
			System.out.println("Pass-Contains Data ");
			while(rs.next()){
			myName=rs.getString(1);
			}
			if(accountNumber.equalsIgnoreCase(myName))
					{
			statusPass("WC_PROFILEVALID = 'N' and WC_SETUP_SECQN_DISABLED = 'Y' is updated in SI_CLIENTS");
					}
			else
			{
				statusFail(driver,"WC_PROFILEVALID = 'N' and WC_SETUP_SECQN_DISABLED = 'Y' is not updated in SI_CLIENTS",testCaseName);
			}
			
		}
		else
		{
			
			//No Data 
			
			System.out.println("Fail- No Data present in DB");
			 statusFail(driver,"No Data is updated in Table si_clients for the account Number: "+accountNumber,testCaseName);
		}*/
		
	/*	while (rs.next())
		   {
				
	 				myName= rs.getString(1);								        
	 				System.out.println("DB Contents**********"+myName);
	 				break;
	       }
		if(myName.equalsIgnoreCase(accountNumber))
		{
			//No Data 
			System.out.println("Pass**********");
			statusPass("WC_PROFILEVALID = 'N' and WC_SETUP_SECQN_DISABLED = 'Y' is updated in SI_CLIENTS");
		}
		else
		{
			System.out.println("Fail**********");
			 statusFail(driver,"WC_PROFILEVALID = 'N' and WC_SETUP_SECQN_DISABLED = 'Y' is not updated in SI_CLIENTS",testCaseName);
		}*/
 		}

		catch(Exception e)
		{
			System.out.println("Inside Catch");
			 System.out.println("Exception caught in DBVerifyloginPwdProfileValid Method-------:"+e.getMessage());
			 statusFail(driver,"Error in getting details from DBVerifyloginPwdProfileValid method from Database:",testCaseName);
			 endReporting();
			 Assert.fail("Database Connectivity");
			
			
		}
			
		
	
	}


	//TO VERIFY ATTRIBUTES WC_PROFILEVALID = 'N' and WC_SETUP_SECQN_DISABLED = 'Y' IN SI_CLIENTS
	
	public static void DBVerifyEmail(WebDriver driver,String accountNumber,String testCaseName) throws ClassNotFoundException, SQLException, IOException
	{
		String myName =null;
		try{
			
		  	String query=null;
		
        String dbUrl = "jdbc:oracle:thin:@10.193.16.54:1521:SIRW2";		
   		String username = "retail";	
 		String password = "retail";				
		query = "SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE WC_PROFILEVALID = 'N' and WC_SETUP_SECQN_DISABLED = 'Y' and WC_USERID='"+accountNumber+"'";
		System.out.println("Query:"+query);
	    Class.forName("oracle.jdbc.driver.OracleDriver");
   	   	Connection con = DriverManager.getConnection(dbUrl,username,password);
    	Statement stmt = con.createStatement();					
		ResultSet rs= stmt.executeQuery(query);	
		
		
		while (rs.next())
		   {
				
	 				myName= rs.getString(1);								        
	 				System.out.println("DB Contents**********"+myName);
	 				break;
	       }
		if(myName.equalsIgnoreCase(accountNumber))
		{
			//No Data 
			System.out.println("Pass**********");
			statusPass("WC_PROFILEVALID = 'N' and WC_SETUP_SECQN_DISABLED = 'Y' is updated in SI_CLIENTS");
		}
		else
		{
			System.out.println("Fail**********");
			 statusFail(driver,"WC_PROFILEVALID = 'N' and WC_SETUP_SECQN_DISABLED = 'Y' is not updated in SI_CLIENTS",testCaseName);
		}
 		}

		catch(Exception e)
		{
			System.out.println("Inside Catch");
			 System.out.println("Exception caught in DBVerifyloginPwdProfileValid Method-------:"+e.getMessage());
			 statusFail(driver,"Error in getting details from DBVerifyloginPwdProfileValid method from Database:",testCaseName);
			 endReporting();
			 Assert.fail("Database Connectivity");
			
			
		}
			
		
	
	}
	
	
	
	//TO VERIFY ATTRIBUTES WC_PROFILEVALID = 'Y' and WC_SETUP_SECQN_DISABLED = 'N' IN SI_CLIENTS
	
		public static void DBVerifyProfileValid1(WebDriver driver,String accountNumber,String testCaseName) throws ClassNotFoundException, SQLException, IOException
		{
			String myName =null;
			try{
				
			  	String query=null;
			
	        String dbUrl = "jdbc:oracle:thin:@10.193.16.54:1521:SIRW2";		
	   		String username = "retail";	
	 		String password = "retail";				
			query = "SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE WC_PROFILEVALID = 'Y' and WC_SETUP_SECQN_DISABLED = 'N' and WC_USERID='"+accountNumber+"'";
			System.out.println("Query:"+query);
		    Class.forName("oracle.jdbc.driver.OracleDriver");
	   	   	Connection con = DriverManager.getConnection(dbUrl,username,password);
	    	Statement stmt = con.createStatement();					
			ResultSet rs= stmt.executeQuery(query);	
			
			
			while (rs.next())
			   {
					
		 				myName= rs.getString(1);								        
		 				System.out.println("DB Contents**********"+myName);
		 				break;
		       }
			if(myName.equalsIgnoreCase(accountNumber))
			{
				//No Data 
				System.out.println("Pass**********");
				statusPass("WC_PROFILEVALID = 'Y' and WC_SETUP_SECQN_DISABLED = 'N' is updated in SI_CLIENTS");
			}
			else
			{
				System.out.println("Fail**********");
				 statusFail(driver,"WC_PROFILEVALID = 'Y' and WC_SETUP_SECQN_DISABLED = 'N' is not updated in SI_CLIENTS",testCaseName);
			}
	 		}

			catch(Exception e)
			{
				System.out.println("Inside Catch");
				 System.out.println("Exception caught in DBVerifyProfileValid1 Method-------:"+e.getMessage());
				 statusFail(driver,"Error in getting details from DBVerifyProfileValid1 method from Database:",testCaseName);
				 endReporting();
				 Assert.fail("Database Connectivity");
				
				
			}
				
			
		
		}
	//TO VERIFY SECURITY QUESTION UPDATED IN DB OR NOT
	
			public static void DBVerifySecurityQuestion(WebDriver driver,String accountNumber,int orderNo,String flag,int questionNo,String testCaseName) throws ClassNotFoundException, SQLException, IOException
			{		
				try{
					
				  	String query=null;
				
		        String dbUrl = "jdbc:oracle:thin:@10.193.16.54:1521:SIRW2";		
		   		String username = "retail";	
		 		String password = "retail";				
				query = "select QA_USERID from sirw.SI_QA_CHALLENGE where qa_userid='"+accountNumber+"' and QA_version='V1' and QA_ORDER="+orderNo+" and QA_MASTER_QUESTION='"+flag+"' and qa_question ="+questionNo+"";
				System.out.println("Query:"+query);
			    Class.forName("oracle.jdbc.driver.OracleDriver");
		   	   	Connection con = DriverManager.getConnection(dbUrl,username,password);
		    	Statement stmt = con.createStatement();					
				ResultSet rs= stmt.executeQuery(query);	
				
				if(!rs.isBeforeFirst())
				{
					//No Data 
					System.out.println("Fail-No Data ");
					statusFail(driver,"QA_VERSION ='V1' and QA_ORDER = "+orderNo+" and QA_MASTER_QUESTION ='"+flag+"' and QA_question='"+questionNo+"' is not updated in SI_CLIENTS",testCaseName);
				}
				else
				{
					System.out.println("Pass-Contains Data ");
					statusPass("QA_VERSION ='V1' and QA_ORDER = "+orderNo+" and QA_MASTER_QUESTION ='"+flag+"' and QA_question='"+questionNo+"' is updated in SI_QA_CHALLENGE");
					
				}
							
		 		}

				catch(Exception e)
				{
					System.out.println("Inside Catch");
					 System.out.println("Exception caught in DBVerifySecurityQuestion Method-------:"+e.getMessage());
					 statusFail(driver,"Error in getting details from DBVerifySecurityQuestion method from Database:",testCaseName);
					 endReporting();
					 Assert.fail("Database Connectivity");
									
				}
					
				
			
			}
			
			
			
			
	//Verify New User TC005		
			public static void DBVerifyloginTC005(WebDriver driver,String accountNumber,String testCaseName) throws ClassNotFoundException, SQLException, IOException
			{
				String myName =null;
				try{
					
				  	String query=null;
				
		        String dbUrl = "jdbc:oracle:thin:@10.193.16.54:1521:SIRW2";		
		   		String username = "retail";	
		 		String password = "retail";	
		 		query="SELECT * FROM SIRW.SI_CLIENTS WHERE wc_userid='"+accountNumber+"' AND WC_FIRSTACCESS IS NOT NULL AND wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) AND WC_TRADEPWD IS NULL AND WC_RESETPWD='Y' and wc_profilevalid='N' AND wc_setup_secqn_disabled='N'";
		 			
				System.out.println("Query:"+query);
			    Class.forName("oracle.jdbc.driver.OracleDriver");
		   	   	Connection con = DriverManager.getConnection(dbUrl,username,password);
		    	Statement stmt = con.createStatement();					
				ResultSet rs= stmt.executeQuery(query);	
				
				
				while (rs.next())
				   {
						
			 				myName= rs.getString(1);								        
			 				System.out.println("DB Contents**********"+myName);
			 				break;
			       }
				if(!rs.isBeforeFirst())
				{
					//No Data 
					System.out.println("Fail-No Data ");
					statusFail(driver,"DB Validation Failed for 3.2.1_Complex_TC005",testCaseName);
				}
				else
				{
					System.out.println("Pass-Contains Data ");
					statusPass("DB Validation Successful for 3.2.1_Complex_TC005");
					
				}
		 		}

				catch(Exception e)
				{
					System.out.println("Inside Catch");
					 System.out.println("Exception caught in DBVerifyloginPwdRequiresReset Method-------:"+e.getMessage());
					 statusFail(driver,"Error in getting details from DBVerifyloginPwdRequiresReset method from Database:",testCaseName);
					 endReporting();
				
					
					
				}
					
				
			
			}
			

			
			//Verify New User TC006	
			public static void DBVerifyloginTC006(WebDriver driver,String accountNumber,String testCaseName) throws ClassNotFoundException, SQLException, IOException
			{
				String myName =null;
				try{
					
				  	String query=null;
				
		        String dbUrl = "jdbc:oracle:thin:@10.193.16.54:1521:SIRW2";		
		   		String username = "retail";	
		 		String password = "retail";	
		 		query="SELECT * FROM SIRW.SI_CLIENTS WHERE wc_userid='"+accountNumber+"' AND WC_FIRSTACCESS IS NOT NULL AND wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) AND WC_TRADEPWD IS NULL AND WC_RESETPWD='Y' and wc_profilevalid='Y' AND wc_setup_secqn_disabled='N'";
		 			
				System.out.println("Query:"+query);
			    Class.forName("oracle.jdbc.driver.OracleDriver");
		   	   	Connection con = DriverManager.getConnection(dbUrl,username,password);
		    	Statement stmt = con.createStatement();					
				ResultSet rs= stmt.executeQuery(query);	
				
				
				while (rs.next())
				   {
						
			 				myName= rs.getString(1);								        
			 				System.out.println("DB Contents**********"+myName);
			 				break;
			       }
				if(!rs.isBeforeFirst())
				{
					//No Data 
					System.out.println("Fail-No Data ");
					statusFail(driver,"DB Validation Failed for 3.2.1_Complex_TC006",testCaseName);
				}
				else
				{
					System.out.println("Pass-Contains Data ");
					statusPass("DB Validation Successful for 3.2.1_Complex_TC006");
					
				}
		 		}

				catch(Exception e)
				{
					System.out.println("Inside Catch");
					 System.out.println("Exception caught in DBVerifyloginPwdRequiresReset Method-------:"+e.getMessage());
					 statusFail(driver,"Error in getting details from DBVerifyloginPwdRequiresReset method from Database:",testCaseName);
					 endReporting();
				
					
					
				}
					
				
			
			}
			
			//Verify New User TC004	
			public static void DBVerifyloginTC004(WebDriver driver,String accountNumber,String testCaseName) throws ClassNotFoundException, SQLException, IOException
			{
				String myName =null;
				try{
					
				  	String query=null;
				
		        String dbUrl = "jdbc:oracle:thin:@10.193.16.54:1521:SIRW2";		
		   		String username = "retail";	
		 		String password = "retail";	
		 		query="SELECT WC_USERID FROM SIRW.SI_CLIENTS WHERE wc_userid='"+accountNumber+"' AND WC_FIRSTACCESS IS NOT NULL AND WC_USERID NOT IN (select se_userid from sirw.si_eproxy) and wc_userid NOT IN (select QA_USERID from sirw.si_qa_challenge) AND WC_TRADEPWD IS NULL AND WC_RESETPWD='N' and wc_profilevalid='N' AND wc_setup_secqn_disabled='Y'";
		 			
				System.out.println("Query:"+query);
			    Class.forName("oracle.jdbc.driver.OracleDriver");
		   	   	Connection con = DriverManager.getConnection(dbUrl,username,password);
		    	Statement stmt = con.createStatement();					
				ResultSet rs= stmt.executeQuery(query);	
				
				
			/*	while (rs.next())
				   {
						
			 				myName= rs.getString(1);								        
			 				System.out.println("DB Contents**********"+myName);
			 				break;
			       }*/
				if(!rs.isBeforeFirst())
				{
					//No Data 
					System.out.println("Fail-No Data ");
					statusFail(driver,"DB Validation Failed for 3.2.1_Complex_TC004",testCaseName);
				}
				else
				{
					System.out.println("Pass-Contains Data ");
					statusPass("DB Validation Successful for 3.2.1_Complex_TC004");
					
				}
		 		}

				catch(Exception e)
				{
					System.out.println("Inside Catch");
					 System.out.println("Exception caught in DBVerifyloginPwdRequiresReset Method-------:"+e.getMessage());
					 statusFail(driver,"Error in getting details from DBVerifyloginPwdRequiresReset method from Database:",testCaseName);
					 endReporting();
					
					
					
				}
					
				
			
			}
			public static void DBEmailUpdated(WebDriver driver,String accountNumber,String date,String testCaseName) throws ClassNotFoundException, SQLException, IOException
            {
                  String myName =null;
            try{
                   
                   String query=null;
            System.out.println("Todays datedfkgjdklfjdfk"+date);
      String dbUrl = "jdbc:oracle:thin:@10.193.16.54:1521:SIRW2";        
            String username = "retail";      
           String password = "retail";                          
            query = "select se_hashcrtdte from sirw.si_eproxy where se_userid='"+accountNumber+"' and se_hashcrtdte like '%"+date+"%'";
            System.out.println("Query:"+query);
         Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection(dbUrl,username,password);
     Statement stmt = con.createStatement();                              
            ResultSet rs= stmt.executeQuery(query);  
            
            if(!rs.isBeforeFirst())
            {
              //No Data 
                   
                   System.out.println("Fail- No Data present in DB");
                   statusFail(driver," Table si_eproxy is not updated with the provided Date",testCaseName);
                   
            }
            else
            {
              
             
                   statusPass("Email Has been sent to the User & Table si_eproxy  is updated with the provided Date");
                                }
                                        
                  
            
    
            }

            catch(Exception e)
            {
                   System.out.println("Inside Catch");
                   System.out.println("Exception caught in DBEmailUpdated Method-------:"+e.getMessage());
                   statusFail(driver,"Error in getting data from Database DBEmailUpdated:",testCaseName);
                   endReporting();
                   Assert.fail("Database Connectivity");
                   
                   
            }

                          
                   
            
            }

	
			
			public static void DBEmailNotUpdated(WebDriver driver,String accountNumber,String date,String testCaseName) throws ClassNotFoundException, SQLException, IOException
            {
                  String myName =null;
            try{
                   
                   String query=null;
            System.out.println("Todays datedfkgjdklfjdfk"+date);
      String dbUrl = "jdbc:oracle:thin:@10.193.16.54:1521:SIRW2";        
            String username = "retail";      
           String password = "retail";                          
            query = "select se_hashcrtdte from sirw.si_eproxy where se_userid='"+accountNumber+"' and se_hashcrtdte like '%"+date+"%'";
            System.out.println("Query:"+query);
         Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection(dbUrl,username,password);
     Statement stmt = con.createStatement();                              
            ResultSet rs= stmt.executeQuery(query);  
            
            if(!rs.isBeforeFirst())
            {
              //No Data 
                   
                   System.out.println("Pass- No Data present in DB");
                   
                   statusPass("Table si_eproxy is not updated with the provided Date");
                   
                   
            }
            else
            {
            	 statusFail(driver,"Email Has been sent to the User & Table si_eproxy  is updated with the current Date",testCaseName);
                 
             
                                      }
                                        
                  
            
    
            }

            catch(Exception e)
            {
                   System.out.println("Inside Catch");
                   System.out.println("Exception caught in DBEmailUpdated Method-------:"+e.getMessage());
                   statusFail(driver,"Error in getting data from Database DBEmailUpdated:",testCaseName);
                   endReporting();
                   Assert.fail("Database Connectivity");
                   
                   
            }

                          
                   
            
            }

		
}
