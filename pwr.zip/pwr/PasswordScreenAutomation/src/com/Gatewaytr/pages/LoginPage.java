package com.Gatewaytr.pages;

//import PerfectoLabUtils;
//import io.appium.java_client.android.AndroidDriver;

import java.io.IOException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;



import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.Gateway.GlobalParameters.BaseClass;
import com.Gateway.GlobalParameters.FetchingOR;
import com.Gatewaytr.ExcelFile.ExcelJXL;
import com.Gatewaytr.Testcases.ExtentReport;
/*import com.perfecto.reportium.client.ReportiumClient;
import com.perfecto.reportium.client.ReportiumClientFactory;
import com.perfecto.reportium.model.Job;
import com.perfecto.reportium.model.PerfectoExecutionContext;
import com.perfecto.reportium.model.Project;
import com.perfecto.reportium.test.TestContext;
import com.perfecto.reportium.test.result.TestResultFactory;*/
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class LoginPage extends BaseClass
{
	public static WebDriver driver;
	public static WebDriver LaunchBrowser(String browserName) 
    {
        /*if (browserName.toLowerCase().equals("perfecto")) {
        	System.out.println("Run started");
            
            String browserNamePerfecto = "mobileOS";
            DesiredCapabilities capabilities = new DesiredCapabilities(browserNamePerfecto, "", Platform.ANY);
            String host = "demo.perfectomobile.com";
            capabilities.setCapability("user", "johnnyl@perfectomobile.com");
            capabilities.setCapability("password", "fish123");
            
            //TODO: Change your device ID
            capabilities.setCapability("deviceName", "C9EB7CE3A03D50F6F7B35132B9FF62E5369DF978");
            
            // Use the automationName capability to define the required framework - Appium (this is the default) or PerfectoMobile.
            capabilities.setCapability("automationName", "Appium");
            
          
            // Application settings examples.
            // capabilities.setCapability("app", "PRIVATE:applications/Errands.ipa");
            // For Android:
            // capabilities.setCapability("appPackage", "com.google.android.keep");
            // capabilities.setCapability("appActivity", ".activities.BrowseActivity");
            // For iOS:
            // capabilities.setCapability("bundleId", "com.yoctoville.errands");
            
            // Add a persona to your script (see https://community.perfectomobile.com/posts/1048047-available-personas)
            //capabilities.setCapability(WindTunnelUtils.WIND_TUNNEL_PERSONA_CAPABILITY, WindTunnelUtils.GEORGIA);
            
            // Name your script
            capabilities.setCapability("scriptName", "Perfecto connectivity test");
            
            //AndroidDriver driver = new AndroidDriver(new URL("https://" + host + "/nexperience/perfectomobile/wd/hub"), capabilities);
            IOSDriver driver = new IOSDriver(new URL("https://" + host + "/nexperience/perfectomobile/wd/hub"), capabilities);
            driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
            
            // Reporting client. For more details, see http://developers.perfectomobile.com/display/PD/Reporting
            PerfectoExecutionContext perfectoExecutionContext = new PerfectoExecutionContext.PerfectoExecutionContextBuilder()
            .withProject(new Project("My Project", "1.0"))
            .withJob(new Job("My Job", 45))
            .withContextTags("tag1")
            .withWebDriver(driver)
            .build();
            ReportiumClient reportiumClient = new ReportiumClientFactory().createPerfectoReportiumClient(perfectoExecutionContext);
            
            try {
                reportiumClient.testStart("My test name", new TestContext("tag2", "tag3"));
                
                // write your code here
                
                // reportiumClient.testStep("step1"); // this is a logical step for reporting
                // add commands...
                // reportiumClient.testStep("step2");
                // more commands...
                
                reportiumClient.testStop(TestResultFactory.createSuccess());
            } catch (Exception e) {
                reportiumClient.testStop(TestResultFactory.createFailure(e.getMessage(), e));
                e.printStackTrace();
            } finally {
                try {
                    driver.quit();
                    
                    // Retrieve the URL to the DigitalZoom Report (= Reportium Application) for an aggregated view over the execution
                    String reportURL = reportiumClient.getReportUrl();
                    
                    // Retrieve the URL to the Execution Summary PDF Report
                    String reportPdfUrl = (String)(driver.getCapabilities().getCapability("reportPdfUrl"));
                    // For detailed documentation on how to export the Execution Summary PDF Report, the Single Test report and other attachments such as
                    // video, images, device logs, vitals and network files - see http://developers.perfectomobile.com/display/PD/Exporting+the+Reports
                    
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }*/
		if (browserName.equalsIgnoreCase("chrome"))
           {
                  try
                  {
                        System.setProperty("webdriver.chrome.driver", "C:\\GatewayPasswordReset\\Drivers\\chromedriver.exe");
                        driver = new ChromeDriver();
                        System.out.println("Launched Browser:Chrome");  
                  }
                  catch(Exception e)
                  {
                        System.out.println("Exceptuion caught in LaunchBrowser"+e.getMessage());
                  }
           
           }else
               if(browserName.equalsIgnoreCase("ie"))
                   
               {
                     try
                     {
                            
                            //DesiredCapabilities capabilities = new DesiredCapabilities();
                            //capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
                            //System.setProperty("webdriver.ie.driver","IEDriverServer.exe");
                            //driver = new InternetExplorerDriver(capabilities);
                     System.setProperty("webdriver.ie.driver", "C:\\GatewayPasswordReset\\Drivers\\IEDriverServer.exe");
                     
                     driver = new InternetExplorerDriver();
                     System.out.println("Launched Browser:IE");      
                     }
                     catch(Exception e)
                     {
                            System.out.println("Exceptuion caught in LaunchBrowser"+e.getMessage());
                     }
               }

           else if(browserName.equalsIgnoreCase("firefox"))
               
           {
                 try
                 {
                	
                	//It create firefox profile
                	 FirefoxProfile profile=new FirefoxProfile();
                     System.out.println("Launched Browser:Firefox 1"); 
                	 // This will set the true value
                	 profile.setAcceptUntrustedCertificates(true);


                     System.out.println("Launched Browser:Firefox 2"); 
                	// WebDriver Driver = new FirefoxDriver(myProfile);
             	//	System.setProperty("webdriver.gecko.driver", "C:\\GatewayPasswordReset\\Drivers\\geckodriver.exe");
             	     System.out.println("Launched Browser:Firefox 3");  
             		driver=new FirefoxDriver(profile); 
              //  	// webdriver = new FirefoxDriver(profile); 
             	
                 System.out.println("Launched Browser:Firefox 4");      
                 }
                 catch(Exception e)
                 {
                        System.out.println("Exceptuion caught in LaunchBrowser : FireFox"+e.getMessage());
                 }
           }
           
 else if(browserName.equalsIgnoreCase("firefox1"))
               
           {
                 try
                 {
                	
                	//It create firefox profile
                // FirefoxProfile profile=new FirefoxProfile();
                //     System.out.println("Launched Browser:Firefox 1"); 
                	 // This will set the true value
              //  	 profile.setAcceptUntrustedCertificates(true);


                     System.out.println("Launched Browser:Firefox 2"); 
                	
             	System.setProperty("webdriver.gecko.driver", "C:\\GatewayPasswordReset\\Drivers\\geckodriver.exe");
             	     System.out.println("Launched Browser:Firefox 3");  
             		driver=new FirefoxDriver(); 
              //  	// webdriver = new FirefoxDriver(profile); 
             	
                 System.out.println("Launched Browser:Firefox GDGFGFDGDFGGDG");      
                 }
                 catch(Exception e)
                 {
                        System.out.println("Exceptuion caught in LaunchBrowser : FireFox"+e.getMessage());
                 }
           }
           return driver;
    }

// Launch URL 
	
	public static void LaunchURL(WebDriver driver,String URL) throws InterruptedException 
    {
           driver.get(URL);
           
           try
           {
                  Thread.sleep(5000);
           if(driver.findElement(By.linkText("Continue to this website (not recommended).")).isDisplayed()==true)
           {
                  System.out.println("Inside if");
                  driver.findElement(By.partialLinkText("(not recommended)")).click();
           

           }
  

           
           System.out.println("Launched URL");
        //   driver.manage().window().maximize();
           }
           catch (Exception e)
           {
                  System.out.println("Inside catch");
                  System.out.println("Launched URL");
                  Thread.sleep(1000);
               //   driver.manage().window().maximize();
           }
           System.out.println("clicked passed$$$$$$$$$$$$$$");
           Thread.sleep(1000);
    }
    


		
//Login to the Gateway Application
	public static void Login(int rowNumber,String userName,String password,String dropDownText,String testCaseName) throws IOException {
	try{
		obj = new FetchingOR(fileName);
		CommonFunctions.waitForElement(driver, obj.getUserName(), 20,"Username Text Field");
		System.out.println("User name from Database------"+userName);
		driver.findElement(By.xpath(obj.getUserName())).sendKeys(userName);
		driver.findElement(By.xpath(obj.getPassword())).sendKeys(password);
		CommonFunctions.select(driver, dropDownText, obj.getLoginDropDown(), testCaseName);
		driver.findElement(By.xpath(obj.getLoginButton())).click();
		statusPass("Login Success");
		
		}
	
	catch(Exception e)
	{
		//System.out.println("Exception caught in Login Function:"+ e.getMessage());
		statusFail(driver, "Log In Unsuccesful",testCaseName);
		outPut(0, 7, rowNumber, "FAIL");
		endReporting();
		Assert.fail("Login Error");
		
		
		
	}
	
		
	}
	
	public static void EmailLogin(int rowNumber,String NewEmail,String password, String testCaseName) throws IOException {
		try{
			obj = new FetchingOR(fileName);
			driver.findElement(By.xpath(obj.getEmailUserName())).sendKeys(NewEmail);
			driver.findElement(By.xpath(obj.getEmailPassword())).sendKeys(password);
			driver.findElement(By.xpath(obj.getEmailSigninButton())).click();
			statusPass("Email Login Success");
			Thread.sleep(15000);
			}
		
		catch(Exception e)
		{
			//System.out.println("Exception caught in Login Function:"+ e.getMessage());
			statusFail(driver, "Email Log In Unsuccesful",testCaseName);
			outPut(0, 7, rowNumber, "FAIL");
			endReporting();
			Assert.fail("Email Login Error");
		}
			
		}
	
	
public static void EmailValidation(int rowNumber,String accountNumber, String testCaseName) throws IOException {
		try{
			
			
			System.out.println("Email inbox is displayed");
			String parentWindow = driver.getWindowHandle();
			
			//WebElement AccountNumberElement = driver.findElement(By.xpath("//span[contains(text(),'"+accountNumber+"')]"));
			String accountElement="//span[contains(text(),'"+accountNumber+"')]";
			CommonFunctions.waitForElement(driver,accountElement ,180, "Wait for the Email to receive in Inbox");
			//Thread.sleep(120000);
			driver.findElement(By.xpath(accountElement)).click();
			driver.findElement(By.xpath("//a[contains(text(),'Click Here')]")).click();
			//Thread.sleep(1000);
			System.out.println("Verification link is clicked");
			CommonFunctions.SwitchToChildWindow(driver);
			CommonFunctions.waitForElement(driver, obj.getEmailVerifiedTitle(),20,"Email Verified Heading");           
	        CommonFunctions.verifyElement(driver, "Email Verified", obj.getEmailVerifiedTitle(),testCaseName); 
	        statusPassWithScreenshot(driver, "Title Verified", testCaseName);
	        CommonFunctions.SwitchToParentWindow(driver,parentWindow);
	        
			statusPass("Email received Successfully");
			
			}
		
		catch(Exception e)
		{
			System.out.println("Exception caught in Email validation Function:"+ e.getMessage());
			statusFail(driver, "Email validation is Unsuccesful",testCaseName);
			endReporting();
			Assert.fail("Email Validation Error");
		
		}
		}

	public static void closeDriver()
	{
		driver.close();
	}
	
	
}
