package com.Gatewaytr.ExcelFile;


import java.io.FileInputStream;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelFile {

private static XSSFSheet ExcelWSheet;

private static XSSFWorkbook ExcelWBook;

private static XSSFCell Cell;

public static void setExcelFile(String Path,String SheetName) throws Exception {
	
	try {

		// Open the Excel file

		FileInputStream ExcelFile = new FileInputStream(Path);

		// Access the required test data sheet

		ExcelWBook = new XSSFWorkbook(ExcelFile);

		ExcelWSheet = ExcelWBook.getSheet(SheetName);

	} catch (Exception e){

		throw (e);

	}

}

//This method is to read the test data from the Excel cell, in this we are passing parameters as Row num and Col num

public static int getTotalNoofRows() throws Exception{

	try{
		int totalrows=ExcelWSheet.getLastRowNum();
			return totalrows;
		}catch (Exception e){

			System.out.println("Exception Caught in Total No Of Rows Method:" +e.getMessage());	
		return 0;

		}

}
public static int getTotalNoofColumns(int RowNum) throws Exception{

	try{
		int totalcolumns=ExcelWSheet.getRow(RowNum).getLastCellNum();
		//count by person 5columns = 5
		//System.out.println(" total number of colums:" +totalcolumns);
			return totalcolumns;
		}catch (Exception e){

			System.out.println("Exception Caught in getCellData Method:" +e.getMessage());	
		return 0;

		}

}

public static void endExcelFileRead() throws Exception{

	try{
		ExcelWBook.close();
		}catch (Exception e){

			System.out.println("Exception Caught in endExcelFileRead Method:" +e.getMessage());	
	

		}

}
public static String getCellData(int RowNum, int ColNum) throws Exception{

	try{
		

		int totalrows=ExcelWSheet.getLastRowNum();
		
		final DataFormatter df = new DataFormatter();
		Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
		String cellData = df.formatCellValue(Cell);


	//System.out.println("Cell Data:"+cellData);
		
		return cellData;
		}catch (Exception e){

	
		
			
		return "";

		}

}

//This method is to write in the Excel cell, Row num and Col num are the parameters

	
	public static String getTestData(String testID,String Functionality,String TestData) throws Exception
	{
		
		int count=0;
		for(int i=1;i<=ReadExcelFile.getTotalNoofRows();i++)
		{
		String functionality=ReadExcelFile.getCellData(i ,0);
		String testCase_ID=ReadExcelFile.getCellData(i,1);
		if(testCase_ID.equals(testID)&& functionality.equals(Functionality))
		{
			count=i;
		}
	
		
		}
	
		return newFunction2(count,TestData);
		
	}
	public static String newFunction2(int rowNum,String TestData) throws Exception
	
	{
		int count1=0;
			int columnNumber=ReadExcelFile.getTotalNoofColumns(rowNum);
			//System.out.println("**************"+columnNumber);
			for(int j=0;j<columnNumber;j++)
			{
				String columnContents=ReadExcelFile.getCellData(0 ,j);
			//	System.out.println("Column Value of :"+j+" "+columnContents);
			if(columnContents.equalsIgnoreCase(TestData))
			{
			//	System.out.println("Matched column r***********");
			//	System.out.println("GetColumn Number***********:"+j);
			count1=j;
			}
			}
			
			return getCellData(rowNum,count1);
			
			
		}
		
	}




