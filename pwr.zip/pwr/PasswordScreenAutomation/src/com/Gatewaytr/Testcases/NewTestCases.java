/**
 * 
 */
package com.Gatewaytr.Testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import java.awt.Image;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.List;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import com.Gateway.GlobalParameters.BaseClass;
import com.Gateway.GlobalParameters.FetchingOR;
import com.Gatewaytr.ExcelFile.ReadExcelFile;
import com.Gatewaytr.pages.Admin;
import com.Gatewaytr.pages.CommonFunctions;
import com.Gatewaytr.pages.DataBase;
import com.Gatewaytr.pages.LoginPage;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.model.Screencast;



/**
 * @author craja01
 * TestNG Class
 *
 */
public class NewTestCases extends BaseClass {

	
	WebDriver driver;
	ExtentReports extent;
	ExtentTest logger;
	public FetchingOR obj=null;
	public String fileName="C:\\GatewayPasswordReset\\Configuration\\ConfigurationPage.property";
	public String fileName_French="C:\\GatewayPasswordReset\\Configuration\\ConfigurationPage_French.property";
	File src = new File("C:\\GatewayPasswordReset\\DriverSheet\\DriveSheetSample.xls");
	int rowNumber;
	
	@DataProvider(name="DriverSheet")
	public Object[][] driverSheetData() {
		Object[][] arrayObject = getExcelData("C:\\GatewayPasswordReset\\DriverSheet\\DriveSheetSample.xls","Sheet1");
		return arrayObject;
	}

	public String[][] getExcelData(String fileName, String sheetName) {
		String[][] arrayExcelData = null;
		try {
			FileInputStream fs = new FileInputStream(fileName);
			Workbook wb = Workbook.getWorkbook(fs);
			Sheet sh = wb.getSheet(sheetName);

			int totalNoOfCols = sh.getColumns();
			int totalNoOfRows = sh.getRows();
			
			arrayExcelData = new String[totalNoOfRows-1][totalNoOfCols];
			
			for (int i= 1 ; i < totalNoOfRows; i++) 
			{
				
				for (int j=0; j < totalNoOfCols; j++) {
					arrayExcelData[i-1][j] = sh.getCell(j, i).getContents();
					
				}

			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
			e.printStackTrace();
		} catch (BiffException e) {
			e.printStackTrace();
		}
		return arrayExcelData;
	}	

	
@BeforeSuite
public void beforeSuite() throws Exception
{
	 	     
     setReport();
    
}
String Browser,LanguageSettings;
String accountNumber;

String tempPassword;
@BeforeTest
@Parameters({ "browserName" ,"language"})
public void beforeTest(String browserName,String language) throws Exception
{
	
	Browser=browserName;
	LanguageSettings=language;
	System.out.println("*****************"+Browser);
	System.out.println("*****************"+LanguageSettings);
	if(LanguageSettings.equalsIgnoreCase("English"))
	{
	obj = new FetchingOR(fileName);
	}
	else
	{
		obj = new FetchingOR(fileName_French);
	}
	ReadExcelFile.setExcelFile(filePath, LanguageSettings);
	driver=LoginPage.LaunchBrowser(Browser);
	
}


/*----- Author - Chinnu Rajaram -----*/

@Test(dataProvider="DriverSheet")
public void test_353637_M_TC014(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
 {
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC014")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.5_3.6_3.7_Functional_Medium"))
	{

		
		startReporting("TC014_existing GW client_forgets password and security questions_helpdesk reset password_setting new challenge questions_challenge question process incomplete_stop session midway");
	
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
        
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	
   	 CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(), TestCaseDescription);
   	 
   
   	 
   	 CommonFunctions.checkSizeofDropDown(driver, obj.getQuestion3(), 17);
     CommonFunctions.selectByIndex(driver,3, obj.getQuestion3(), TestCaseDescription);
     driver.findElement(By.xpath(obj.getAnswer3())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer3")); 	
   	 
     
     CommonFunctions.checkSizeofDropDown(driver, obj.getQuestion2(), 16);
     CommonFunctions.selectByIndex(driver,2, obj.getQuestion2(), TestCaseDescription);
     driver.findElement(By.xpath(obj.getAnswer2())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer2"));    
      	
   	 CommonFunctions.checkSizeofDropDown(driver, obj.getQuestion1(), 15);
     CommonFunctions.selectByIndex(driver,1, obj.getQuestion1(), TestCaseDescription);
     driver.findElement(By.xpath(obj.getAnswer1())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer1"));    
       
     driver.close();
     
     
     driver=LoginPage.LaunchBrowser(Browser);
	 LoginPage.LaunchURL(driver,GatewayQAURL);
	 LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Username_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_NewPassword_Eng"),"Home", Functionality + TestCaseID);
  	 CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), TestCaseDescription);
 	
 	 LoginPage.LaunchURL(driver,GatewayAdminURL);
 	 System.out.println("After Admin");
 	 tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
 	 System.out.println("Before QA");
 	 LoginPage.LaunchURL(driver,GatewayQAURL);
 	 LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "TestCaseDescription"); 
    
   // DataBase.DBVerifyNloginPwdRequiresReset(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"),TestCaseDescription);
	
   // DataBase.DBVerifyProfileValid1(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), TestCaseDescription);
    BaseClass.statusPassWithScreenshot(driver,"Home Page Screen",TestCaseDescription);
	
    endReporting();
	
	}
 }
@Test(dataProvider="DriverSheet")
public void test_353637_M_TC015(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
 {
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC015")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.5_3.6_3.7_Functional_Medium"))
	{

		
		startReporting(TestCaseDescription);
	
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
        
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	
   	  	CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(), TestCaseDescription);
   	 	 
   	 CommonFunctions.checkSizeofDropDown(driver, obj.getQuestion3(), 17);
     CommonFunctions.selectByIndex(driver,3, obj.getQuestion3(), TestCaseDescription);
     driver.findElement(By.xpath(obj.getAnswer3())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer3")); 	
   	 
     
     CommonFunctions.checkSizeofDropDown(driver, obj.getQuestion2(), 16);
     CommonFunctions.selectByIndex(driver,2, obj.getQuestion2(), TestCaseDescription);
     driver.findElement(By.xpath(obj.getAnswer2())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer2"));    
      	
   	 CommonFunctions.checkSizeofDropDown(driver, obj.getQuestion1(), 15);
     CommonFunctions.selectByIndex(driver,1, obj.getQuestion1(), TestCaseDescription);
     driver.findElement(By.xpath(obj.getAnswer1())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer1"));    
       
     CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
     CommonFunctions.verifyElement(driver, "Create a new Password", obj.getHomePageLogo(), TestCaseDescription);
       BaseClass.statusPassWithScreenshot(driver,"Home Page Screen",TestCaseDescription);
	
    endReporting();
	
	}
 }
	


@Test(dataProvider="DriverSheet")
public void test_353637_M_TC016(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
 {
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC016")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.5_3.6_3.7_Functional_Medium"))
	{

		
		startReporting(TestCaseDescription);
	
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
        
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	
   	  	CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(), TestCaseDescription);
   	 	 
   		CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
   	  	CommonFunctions.setSecurityFields(driver,1, "",2, "", 6, "", TestCaseDescription);
   	 	statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);
  
   	 	
   	 CommonFunctions.setSecurityFields(driver,3, "",4, "", 5, "", TestCaseDescription);
	
	 	
	 	CommonFunctions.setSecurityFields(driver,2, "",6, "", 1, "", TestCaseDescription);
	 	statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);

	 	CommonFunctions.setSecurityFields(driver,3, "",4, "", 5, "", TestCaseDescription);
	
	 	
		CommonFunctions.setSecurityFields(driver,6, "",1, "", 2, "", TestCaseDescription);
	 	statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);

    	 
   	  	
     CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	
	
	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getHomePageLogo(), TestCaseDescription);
    
    BaseClass.statusPassWithScreenshot(driver,"Home Page Screen",TestCaseDescription);
	
    endReporting();
	
	}
 }
	
@Test(dataProvider="DriverSheet")
public void test_325_C_TC066(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC066")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Complex"))
	{
		
		startReporting(Functionality);
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	  //  CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
      //  CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
	    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
		    
	    CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
	    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
   	  	CommonFunctions.setSecurityFields(driver,1, "",2, "", 6, "", TestCaseDescription);
   	 	statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);
  
   	 	
   	 CommonFunctions.setSecurityFields(driver,3, "",4, "", 5, "", TestCaseDescription);
	
	 	
	 	CommonFunctions.setSecurityFields(driver,2, "",6, "", 1, "", TestCaseDescription);
	 	statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);

	 	CommonFunctions.setSecurityFields(driver,3, "",4, "", 5, "", TestCaseDescription);
	
	 	
		CommonFunctions.setSecurityFields(driver,6, "",1, "", 2, "", TestCaseDescription);
	 	statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);

    	 
    	 
    	 
    	 
      	endReporting();
	}
}



@Test(dataProvider="DriverSheet")
public void test_325_C_TC099(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC099")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Complex"))
	{
		
		startReporting(Functionality);
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	  //  CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
      //  CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
	    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
	    CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
	    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
   	  	CommonFunctions.setSecurityFields(driver,1, "animal",2, "porter", 6, "failure", TestCaseDescription);
   	 	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
   	 	CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
  	    driver.findElement(By.xpath(obj.getEmailAddressNewEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
     	driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
     	
     	

    	BaseClass.statusPassWithScreenshot(driver,"Email Address Screen",TestCaseDescription);
    	CommonFunctions.movemousepointer(driver,"//label[@for='terms']");
        CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
        CommonFunctions.waitForElement(driver, obj.getEmailConfirmationPageTitle(), 10, "verification");
        
        
        LoginPage.LaunchURL(driver,GatewayEmailURL);
        CommonFunctions.EmailLogin(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailUserName"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailPwd"), TestCaseDescription);
        Thread.sleep(2000);
        System.out.println("check1");
        CommonFunctions.EmailValidation(driver, accountNumber, TestCaseDescription);
        statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);
  

    	 
    	 
    	 
    	 
      	endReporting();
	}
}

	@Test(dataProvider="DriverSheet")
	public void test_325_C_TC100(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC100")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Complex"))
		{
			
			startReporting(Functionality);
			
			accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
		    CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
	        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
			      
		  //  CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
		    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
	   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
	   	  	CommonFunctions.setSecurityFields(driver,1, "animal",2, "porter", 6, "failure", TestCaseDescription);
	   	 	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	   	 	CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
	  	    driver.findElement(By.xpath(obj.getEmailAddressNewEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
	     	driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
	     	
	     	

	    	BaseClass.statusPassWithScreenshot(driver,"Email Address Screen",TestCaseDescription);
	    	CommonFunctions.movemousepointer(driver,"//label[@for='terms']");
	        CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
	        CommonFunctions.waitForElement(driver, obj.getEmailConfirmationPageTitle(), 10, "verification");
	        
	        
	        LoginPage.LaunchURL(driver,GatewayEmailURL);
	        CommonFunctions.EmailLogin(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailUserName"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailPwd"), TestCaseDescription);
	        Thread.sleep(2000);
	        System.out.println("check1");
	        CommonFunctions.EmailValidation(driver, accountNumber, TestCaseDescription);
	        statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);
	  
	
	    	 
	    	 
	    	 
	    	 
	      	endReporting();
		}
	}
	
	@Test(dataProvider="DriverSheet")
	public void test_327_M_TC026(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC026")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.7_Functional_Medium"))
		{
			
			startReporting("3.2.7_Functional_Medium_TC026_Create a new Login password screen_Password updated succesfully");
			
			accountNumber=DataBase.DBConnection(driver,"ACCOUNTINACTIVEMORETHAN1YEAR", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	        CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), TestCaseDescription);
	        CommonFunctions.checkElementColour(driver, obj.getGoToLoginPageButton(),"rgba(0, 114, 193, 1)","Go To Login Button Colour", TestCaseDescription);
	        CommonFunctions.ClickButton(driver,obj.getGoToLoginPageButton());
	        CommonFunctions.verifyElement(driver,"Login Page Displayed",obj.getUserName(),TestCaseDescription);
	        LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.checkFontColour(driver,obj.getMinimum1lowerCase(), "rgba(0, 138, 0, 1)","Minimum 1 Lower Case Check",TestCaseDescription);
	      	CommonFunctions.checkFontColour(driver,obj.getMinimum1upperCase(), "rgba(0, 138, 0, 1)","Minimum 2 Upper Case Check",TestCaseDescription);
	      	CommonFunctions.checkFontColour(driver,obj.getMinimum1Number(), "rgba(0, 138, 0, 1)","Minimum 1 Number  Check",TestCaseDescription);
	      	CommonFunctions.checkFontColour(driver,obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)","Minimum 8 Characters Check",TestCaseDescription);
	      	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	      	CommonFunctions.checkFontColour(driver,obj.getConfirmPasswords(), "rgba(0, 138, 0, 1)","Confirm Password Check",TestCaseDescription);
	      	//CommonFunctions.checkDisabled(driver,obj.getSpecialCharacterAlertError(),"Invalid Special Character Entered Error Message", TestCaseDescription);
	       	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	 	CommonFunctions.verifyElement(driver, "Set Up Challenge Question Screen", obj.getChallengeQuestionTitleNew(), TestCaseDescription);
	   	    BaseClass.statusPassWithScreenshot(driver,"Set Up Challenge Question Screen",TestCaseDescription);
	       
	      	endReporting();
		}
	}
	
	
	
	@Test(dataProvider="DriverSheet")
	public void test_321_L_TC056(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription,  String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC056")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.1_Functional_Low"))
		{
			//LoginPage.LaunchURL(driver,"https://www.yahoo.com");
			startReporting("3.2.1_Functional_Low_TC056_ErrorMessage_one Challange question is not selected");
			accountNumber=DataBase.DBConnection(driver,"NEWUSERACCOUNTS", LanguageSettings, "3.2.1_Functional_Low	");
			LoginPage.LaunchURL(driver,GatewayAdminURL);
			String tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
			LoginPage.LaunchURL(driver,GatewayQAURL);
			LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
			
			CommonFunctions.waitForElement(driver, obj.getWelcomeScreenTitle(),40, "WelcomeScreen");
			
			CommonFunctions.verifyElement(driver, "StartButton", obj.getWelcomeScreenStartButton(), TestCaseDescription);
			driver.findElement(By.xpath(obj.getWelcomeScreenStartButton())).click();
			CommonFunctions.waitForElement(driver, obj.getPasswordChangePageTitle(),40, "Create a new Password");
		
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys("B7aaaaaa");
			driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys("B7aaaaaa");
			driver.findElement(By.xpath(obj.getContinueButton())).click();
			//CommonFunctions.verifyText(driver, "Create a new Trading password", obj.getTradingpasswordtitle(), TestCaseDescription);
			CommonFunctions.waitForElement(driver, obj.getNewTradingpassword(),40, "New Trading Password");
			
			driver.findElement(By.xpath(obj.getNewTradingpassword())).sendKeys("Trade123");
			driver.findElement(By.xpath(obj.getConfirmTradingpassword())).sendKeys("Trade123");
			CommonFunctions.ClickButton(driver,obj.getTradingcontinue());
			CommonFunctions.waitForElement(driver, obj.getSecurityQuestionTitle(),40, "Title");
			CommonFunctions.verifyElement(driver, "SecurityQuestion1", obj.getQuestion1(), TestCaseDescription);
			CommonFunctions.verifyElement(driver, "SecurityQuestion2", obj.getQuestion2(), TestCaseDescription);
			CommonFunctions.verifyElement(driver, "SecurityQuestion3", obj.getQuestion3(), TestCaseDescription);
			CommonFunctions.waitForElement(driver, obj.getQuestion1(),10, "Question");
			CommonFunctions.selectByIndex(driver, 2, obj.getQuestion1(), TestCaseDescription);
			driver.findElement(By.xpath(obj.getAnswer1())).sendKeys("abcdefgh");
			CommonFunctions.selectByIndex(driver, 3, obj.getQuestion2(), TestCaseDescription);
			driver.findElement(By.xpath(obj.getAnswer2())).sendKeys("abcdefgj");
			//CommonFunctions.selectByIndex(driver, 4, obj.getQuestion3(), TestCaseDescription);
			//driver.findElement(By.xpath(obj.getAnswer3())).sendKeys("abcdefg");
			CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
			//CommonFunctions.verifyText(driver, "We're sorry, but the fields outlined in red require updating. Please review the comments in red and update the information in order to proceed.", obj.getSecurityQuestionMessage(), TestCaseDescription);
				  CommonFunctions.verifyText(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_VerifyText_Eng") , obj.getSecurityQuestionMessage(), TestCaseDescription);
				
			statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
			endReporting();
		}
	}
	
	@Test(dataProvider="DriverSheet")
	public void test_321_L_TC057(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC057")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.1_Functional_Low"))
		{
			//LoginPage.LaunchURL(driver,"https://www.yahoo.com");
			startReporting("3.2.1_Functional_Low_TC057_ErrorMessage_two  Challange question is not selected");
			accountNumber=DataBase.DBConnection(driver,"NEWUSERACCOUNTS", LanguageSettings, "3.2.1_Functional_Low	");
			LoginPage.LaunchURL(driver,GatewayAdminURL);
			String tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
			LoginPage.LaunchURL(driver,GatewayQAURL);
			LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
			
			CommonFunctions.waitForElement(driver, obj.getWelcomeScreenTitle(),40, "WelcomeScreen");
			//CommonFunctions.verifyText(driver, "Welcome to Gateway", obj.getWelcomeScreenTitle(), TestCaseDescription);		
			CommonFunctions.verifyElement(driver, "StartButton", obj.getWelcomeScreenStartButton(), TestCaseDescription);
			driver.findElement(By.xpath(obj.getWelcomeScreenStartButton())).click();
			
			//CommonFunctions.verifyText(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
			CommonFunctions.waitForElement(driver, obj.getNewPasswordField(),40, "Newpassword");
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys("B2aaaaaa");
			driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys("B2aaaaaa");
			driver.findElement(By.xpath(obj.getContinueButton())).click();
			//CommonFunctions.verifyText(driver, "Create a new Trading password", obj.getTradingpasswordtitle(), TestCaseDescription);
CommonFunctions.waitForElement(driver, obj.getNewTradingpassword(),40, "New Trading Password");
			
			driver.findElement(By.xpath(obj.getNewTradingpassword())).sendKeys("Trade123");
			driver.findElement(By.xpath(obj.getConfirmTradingpassword())).sendKeys("Trade123");
			CommonFunctions.ClickButton(driver,obj.getTradingcontinue());
			CommonFunctions.waitForElement(driver, obj.getSecurityQuestionTitle(),40, "Title");
				//Thread.sleep(2000);
			//CommonFunctions.verifyText(driver, "Set up challenge questions", obj.getSecurityQuestionTitle(), TestCaseDescription);
			
			CommonFunctions.verifyElement(driver, "SecurityQuestion1", obj.getQuestion1(), TestCaseDescription);
			CommonFunctions.verifyElement(driver, "SecurityQuestion2", obj.getQuestion2(), TestCaseDescription);
			CommonFunctions.verifyElement(driver, "SecurityQuestion3", obj.getQuestion3(), TestCaseDescription);
			
			CommonFunctions.selectByIndex(driver, 2, obj.getQuestion1(), TestCaseDescription);
			driver.findElement(By.xpath(obj.getAnswer1())).sendKeys("abcdefgh");
			//CommonFunctions.selectByIndex(driver, 3, obj.getQuestion2(), TestCaseDescription);
			//driver.findElement(By.xpath(obj.getAnswer2())).sendKeys("abcdefgj");
			//CommonFunctions.selectByIndex(driver, 4, obj.getQuestion3(), TestCaseDescription);
			//driver.findElement(By.xpath(obj.getAnswer3())).sendKeys("abcdefg");
			CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
			//CommonFunctions.verifyText(driver, "We're sorry, but the fields outlined in red require updating. Please review the comments in red and update the information in order to proceed.", obj.getSecurityQuestionMessage(), TestCaseDescription);
			  CommonFunctions.verifyText(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_VerifyText_Eng") , obj.getSecurityQuestionMessage(), TestCaseDescription);
					statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
			endReporting();
		}
	}
	
	
	@Test(dataProvider="DriverSheet")
	public void test_321_L_TC031(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription,  String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC031")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.1_Functional_Low"))
		{
			//LoginPage.LaunchURL(driver,"https://www.yahoo.com");
			startReporting(TestCaseDescription);
			accountNumber=DataBase.DBConnection(driver,"NEWUSERACCOUNTS", LanguageSettings, "3.2.1_Functional_Low	");
			LoginPage.LaunchURL(driver,GatewayAdminURL);
			String tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
			LoginPage.LaunchURL(driver,GatewayQAURL);
			LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
			CommonFunctions.waitForElement(driver, obj.getWelcomeScreenTitle(), 40, "WelcomeScreen");
			CommonFunctions.verifyElement(driver, "StartButton", obj.getWelcomeScreenStartButton(), TestCaseDescription);
			driver.findElement(By.xpath(obj.getWelcomeScreenStartButton())).click();
			CommonFunctions.waitForElement(driver, obj.getPasswordChangePageTitle(), 40, "Create a new Password");
			CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys("B8aaaaaa");
			driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys("B8aaaaaa");
			driver.findElement(By.xpath(obj.getContinueButton())).click();
	CommonFunctions.waitForElement(driver, obj.getNewTradingpassword(),40, "New Trading Password");
			
			driver.findElement(By.xpath(obj.getNewTradingpassword())).sendKeys("Trade123");
			driver.findElement(By.xpath(obj.getConfirmTradingpassword())).sendKeys("Trade123");
		
			CommonFunctions.waitForElement(driver,obj.getTradingMinimum6chracters(), 10, "Minimum 6 Characters");
			CommonFunctions.checkFontColour(driver, obj.getTradingMinimum6chracters(), "rgba(0, 138, 0, 1)", "Green", TestCaseDescription);
			//CommonFunctions.checkFontColour(driver, obj.getTradingSpecialCharacter(), "rgba(0, 138, 0, 1)", "Green", TestCaseDescription);
			CommonFunctions.checkFontColour(driver, obj.getTradingConfirmPasswordCheck(), "rgba(0, 138, 0, 1)", "Green", TestCaseDescription);
			
			statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
			endReporting();
		}
	}
	
	@Test(dataProvider="DriverSheet")
	public void test_322_M_TC122(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription,  String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC122")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Medium"))
		{
			
			startReporting(TestCaseDescription);
			accountNumber=DataBase.DBConnection(driver,"ACCOUNTWITHNOSECURITYQUES", LanguageSettings, TestCaseDescription);
			
			LoginPage.LaunchURL(driver,GatewayAdminURL);
			String tempPassword=Admin.getTemporaryPassword(driver, accountNumber);
			Admin.getTemporaryTradingPassword(driver, accountNumber);
			LoginPage.LaunchURL(driver,GatewayQAURL);

			//accountNumber=ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username",TestDataID);
			LoginPage.Login(rowNumber,accountNumber,tempPassword ,"Home",Functionality + TestCaseID);
			
			CommonFunctions.verifyText(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	  		
	  		driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	        driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	        CommonFunctions.ClickButton(driver,obj.getContinueButton());
	        
	        CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
	        //System.out.println(obj.getNewTradingpassword());
	        
	        
	        driver.findElement(By.xpath(obj.getNewTradingpassword())).sendKeys("aaaaaa");
	        driver.findElement(By.xpath(obj.getConfirmTradingpassword())).sendKeys("aaaaaa");
	        CommonFunctions.ClickButton(driver,obj.getTradingcontinue());
	    
	        CommonFunctions.verifyElement(driver, "Challenge Question Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
		    CommonFunctions.setSecurityFields(driver, 5,"porter", 7, "animal",8, "tester",TestCaseDescription);
		    CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		    CommonFunctions.verifyElement(driver, "Email address screen", obj.getEmailAddressTitle(),TestCaseDescription);        
		  
		          
		    CommonFunctions.SetText(driver, obj.getEmailAddressNewEmail(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID") );
		    CommonFunctions.SetText(driver, obj.getEmailAddressConfirmEmail(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID") );
		  CommonFunctions.movemousepointer(driver,"//label[@for='terms']"); 
		    //Thread.sleep(6000);
		    CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
		    CommonFunctions.waitForElement(driver, obj.getEmailConfirmationPageTitle(), 10, "verification");
		    BaseClass.statusPassWithScreenshot(driver, "Email Screen Dispalyed",Browser+"_"+TestCaseDescription+"_1");
		        
		 	LoginPage.LaunchURL(driver,GatewayEmailURL);
			CommonFunctions.EmailLogin(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailUserName"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailPwd"), TestCaseDescription);
			Thread.sleep(2000);
			System.out.println("check1");
			CommonFunctions.EmailValidation(driver, accountNumber, TestCaseDescription);
			statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);
			
			String CurrentDate=CommonFunctions.Date(driver,TestCaseID,Functionality, TestCaseDescription);
			DataBase.DBEmailUpdated(driver,accountNumber,CurrentDate,TestCaseDescription);
			statusPassWithScreenshot(driver,"Screenshot done",Functionality + "TC122");
		
			endReporting();
		}
	}
	
	
	@Test(dataProvider="DriverSheet")
	public void test_322_M_TC123(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC123")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Medium"))
		{
			
			startReporting(TestCaseDescription);
			accountNumber=DataBase.DBConnection(driver,"ACCOUNTWITHNOSECURITYQUES", LanguageSettings, TestCaseDescription);
			
			LoginPage.LaunchURL(driver,GatewayAdminURL);
			String tempPassword=Admin.getTemporaryPassword(driver, accountNumber);
			Admin.getTemporaryTradingPassword(driver, accountNumber);
			LoginPage.LaunchURL(driver,GatewayQAURL);

			//accountNumber=ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username",TestDataID);
			LoginPage.Login(rowNumber,accountNumber,tempPassword ,"Home",Functionality + TestCaseID);
			
			CommonFunctions.verifyText(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	  		
	  		driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	        driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	        CommonFunctions.ClickButton(driver,obj.getContinueButton());
	        
	        CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
	        //System.out.println(obj.getNewTradingpassword());
	        
	        
	        driver.findElement(By.xpath(obj.getNewTradingpassword())).sendKeys("aaaaaa");
	        driver.findElement(By.xpath(obj.getConfirmTradingpassword())).sendKeys("aaaaaa");
	        CommonFunctions.ClickButton(driver,obj.getTradingcontinue());
	    
	        CommonFunctions.verifyElement(driver, "Challenge Question Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
		    CommonFunctions.setSecurityFields(driver, 5,"porter", 7, "animal",8, "tester",TestCaseDescription);
		    CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		    CommonFunctions.verifyElement(driver, "Email address screen", obj.getEmailAddressTitle(),TestCaseDescription);        
		  
		          
		    CommonFunctions.SetText(driver, obj.getEmailAddressNewEmail(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID") );
		    CommonFunctions.SetText(driver, obj.getEmailAddressConfirmEmail(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID") );
		  CommonFunctions.movemousepointer(driver,"//label[@for='terms']"); 
		    //Thread.sleep(6000);
		    CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
		    CommonFunctions.waitForElement(driver, obj.getEmailConfirmationPageTitle(), 10, "verification");
		    BaseClass.statusPassWithScreenshot(driver, "Email Screen Dispalyed",Browser+"_"+TestCaseDescription+"_1");
		        
		 	LoginPage.LaunchURL(driver,GatewayEmailURL);
			CommonFunctions.EmailLogin(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailUserName"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailPwd"), TestCaseDescription);
			Thread.sleep(2000);
			System.out.println("check1");
			CommonFunctions.EmailValidation(driver, accountNumber, TestCaseDescription);
			statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);
			
			String CurrentDate=CommonFunctions.Date(driver,TestCaseID,Functionality, TestCaseDescription);
			DataBase.DBEmailUpdated(driver,accountNumber,CurrentDate,TestCaseDescription);
			statusPassWithScreenshot(driver,"Screenshot done",Functionality + "TC122");
		
			endReporting();
		}
	}
	
	@Test(dataProvider="DriverSheet")
	public void test_322_M_TC124(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription,String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC124")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Medium"))
		{
			
			startReporting(TestCaseDescription);
			accountNumber=DataBase.DBConnection(driver,"ACCOUNTWITHNOSECURITYQUES", LanguageSettings, TestCaseDescription);
			
			LoginPage.LaunchURL(driver,GatewayAdminURL);
			String tempPassword=Admin.getTemporaryPassword(driver, accountNumber);
			Admin.getTemporaryTradingPassword(driver, accountNumber);
			LoginPage.LaunchURL(driver,GatewayQAURL);

			//accountNumber=ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username",TestDataID);
			LoginPage.Login(rowNumber,accountNumber,tempPassword ,"Home",Functionality + TestCaseID);
			
			CommonFunctions.verifyText(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	  		
	  		driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	        driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	        CommonFunctions.ClickButton(driver,obj.getContinueButton());
	        
	        CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
	        //System.out.println(obj.getNewTradingpassword());
	        
	        
	        driver.findElement(By.xpath(obj.getNewTradingpassword())).sendKeys("aaaaaa");
	        driver.findElement(By.xpath(obj.getConfirmTradingpassword())).sendKeys("aaaaaa");
	        CommonFunctions.ClickButton(driver,obj.getTradingcontinue());
	    
	        CommonFunctions.verifyElement(driver, "Challenge Question Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
		    CommonFunctions.setSecurityFields(driver, 5,"porter", 7, "animal",8, "tester",TestCaseDescription);
		    CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		    CommonFunctions.verifyElement(driver, "Email address screen", obj.getEmailAddressTitle(),TestCaseDescription);        
		  
		          
		    CommonFunctions.SetText(driver, obj.getEmailAddressNewEmail(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID") );
		    CommonFunctions.SetText(driver, obj.getEmailAddressConfirmEmail(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID") );
		  CommonFunctions.movemousepointer(driver,"//label[@for='terms']"); 
		    //Thread.sleep(6000);
		    CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
		    CommonFunctions.waitForElement(driver, obj.getEmailConfirmationPageTitle(), 10, "verification");
		    BaseClass.statusPassWithScreenshot(driver, "Email Screen Dispalyed",Browser+"_"+TestCaseDescription+"_1");
		        
		 	LoginPage.LaunchURL(driver,GatewayEmailURL);
			CommonFunctions.EmailLogin(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailUserName"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailPwd"), TestCaseDescription);
			Thread.sleep(2000);
			System.out.println("check1");
			CommonFunctions.EmailValidation(driver, accountNumber, TestCaseDescription);
			
		    CommonFunctions.ClickButton(driver,obj.getGotoLoginButton());
	      //  LoginPage.LaunchURL(driver,GatewayQAURL);
		  //  LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
		   CommonFunctions.waitForElement(driver,obj.getUserName(), 30, "verification");
	    
		
			statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);
			
			String CurrentDate=CommonFunctions.Date(driver,TestCaseID,Functionality, TestCaseDescription);
			DataBase.DBEmailUpdated(driver,accountNumber,CurrentDate,TestCaseDescription);
			statusPassWithScreenshot(driver,"Screenshot done",Functionality + "TC122");
		
			endReporting();
		}
	}
	
	@Test(dataProvider="DriverSheet")
	public void test_322_M_TC126(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription,String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC126")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Medium"))
		{
			
			startReporting(TestCaseDescription);
			accountNumber=DataBase.DBConnection(driver,"ACCOUNTWITHNOSECURITYQUES", LanguageSettings, TestCaseDescription);
			
			LoginPage.LaunchURL(driver,GatewayAdminURL);
			String tempPassword=Admin.getTemporaryPassword(driver, accountNumber);
			Admin.getTemporaryTradingPassword(driver, accountNumber);
			LoginPage.LaunchURL(driver,GatewayQAURL);

			//accountNumber=ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username",TestDataID);
			LoginPage.Login(rowNumber,accountNumber,tempPassword ,"Home",Functionality + TestCaseID);
			
			CommonFunctions.verifyText(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	  		
	  		driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	        driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	        CommonFunctions.ClickButton(driver,obj.getContinueButton());
	        
	        CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
	        //System.out.println(obj.getNewTradingpassword());
	        
	        
	        driver.findElement(By.xpath(obj.getNewTradingpassword())).sendKeys("aaaaaa");
	        driver.findElement(By.xpath(obj.getConfirmTradingpassword())).sendKeys("aaaaaa");
	        CommonFunctions.ClickButton(driver,obj.getTradingcontinue());
	    
	        CommonFunctions.verifyElement(driver, "Challenge Question Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
		    CommonFunctions.setSecurityFields(driver, 5,"porter", 7, "animal",8, "tester",TestCaseDescription);
		    CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		    CommonFunctions.verifyElement(driver, "Email address screen", obj.getEmailAddressTitle(),TestCaseDescription);        
		  
		          
		    CommonFunctions.SetText(driver, obj.getEmailAddressNewEmail(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID") );
		    CommonFunctions.SetText(driver, obj.getEmailAddressConfirmEmail(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID") );
		    CommonFunctions.movemousepointer(driver,"//label[@for='terms']"); 
		    //Thread.sleep(6000);
		    CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
		    CommonFunctions.waitForElement(driver, obj.getEmailConfirmationPageTitle(), 10, "verification");
		    BaseClass.statusPassWithScreenshot(driver, "Email Screen Dispalyed",Browser+"_"+TestCaseDescription+"_1");
		 
			
			String CurrentDate=CommonFunctions.Date(driver,TestCaseID,Functionality, TestCaseDescription);
			DataBase.DBEmailUpdated(driver,accountNumber,CurrentDate,TestCaseDescription);
			statusPassWithScreenshot(driver,"Screenshot done",Functionality + "TC122");
			
			
			
			LoginPage.LaunchURL(driver,GatewayQAURL);

			//accountNumber=ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username",TestDataID);
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"),"Home",Functionality + TestCaseID);
		
			   CommonFunctions.verifyText(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_VerifyText_Eng") , obj.getUnSecureError(), TestCaseDescription);
				
			endReporting();
		}
	}
	
	
	@Test(dataProvider="DriverSheet")
	public void test_322_M_TC127(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription,String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC127")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Medium"))
		{
			
			startReporting(TestCaseDescription);
			accountNumber=DataBase.DBConnection(driver,"ACCOUNTWITHNOSECURITYQUES", LanguageSettings, TestCaseDescription);
			
			LoginPage.LaunchURL(driver,GatewayAdminURL);
			String tempPassword=Admin.getTemporaryPassword(driver, accountNumber);
			Admin.getTemporaryTradingPassword(driver, accountNumber);
			LoginPage.LaunchURL(driver,GatewayQAURL);

			//accountNumber=ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username",TestDataID);
			LoginPage.Login(rowNumber,accountNumber,tempPassword ,"Home",Functionality + TestCaseID);
			
			CommonFunctions.verifyText(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	  		
	  		driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	        driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	        CommonFunctions.ClickButton(driver,obj.getContinueButton());
	        
	        CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
	        //System.out.println(obj.getNewTradingpassword());
	        
	        
	        driver.findElement(By.xpath(obj.getNewTradingpassword())).sendKeys("aaaaaa");
	        driver.findElement(By.xpath(obj.getConfirmTradingpassword())).sendKeys("aaaaaa");
	        CommonFunctions.ClickButton(driver,obj.getTradingcontinue());
	    
	        CommonFunctions.verifyElement(driver, "Challenge Question Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
		    CommonFunctions.setSecurityFields(driver, 5,"porter", 7, "animal",8, "tester",TestCaseDescription);
		    CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		    CommonFunctions.verifyElement(driver, "Email address screen", obj.getEmailAddressTitle(),TestCaseDescription);        
		  
		          
		    CommonFunctions.SetText(driver, obj.getEmailAddressNewEmail(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID") );
		    CommonFunctions.SetText(driver, obj.getEmailAddressConfirmEmail(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID") );
		    CommonFunctions.movemousepointer(driver,"//label[@for='terms']"); 
		    //Thread.sleep(6000);
		    CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
		    CommonFunctions.waitForElement(driver, obj.getEmailConfirmationPageTitle(), 10, "verification");
		    BaseClass.statusPassWithScreenshot(driver, "Email Screen Dispalyed",Browser+"_"+TestCaseDescription+"_1");
		 
			
			String CurrentDate=CommonFunctions.Date(driver,TestCaseID,Functionality, TestCaseDescription);
			DataBase.DBEmailUpdated(driver,accountNumber,CurrentDate,TestCaseDescription);
			statusPassWithScreenshot(driver,"Screenshot done",Functionality + "TC122");
			
			
			
			LoginPage.LaunchURL(driver,GatewayQAURL);

			//accountNumber=ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username",TestDataID);
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"),"Home",Functionality + TestCaseID);
		
			   CommonFunctions.verifyText(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_VerifyText_Eng") , obj.getUnSecureError(), TestCaseDescription);
				
			endReporting();
		}
	}
	
	
	
	
	
	
	@Test(dataProvider = "DriverSheet")
	public void test_324_M_TC019(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC019")&& Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.4_Functional_Medium")) {

			startReporting("TC019_GUI_Set up challenge questions screen_Challenge questions dropdown");
			LoginPage.LaunchURL(driver, GatewayQAURL);
			
			
			accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
			
			//Line Added/Modified by Sakshee
			
			//accountNumber= ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng");
			
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"Home",TestCaseDescription );
		    CommonFunctions.verifyElement(driver, "Home",obj.getHomePageLogo(),TestCaseDescription);
			CommonFunctions.verifyElement(driver, "Set Up Now ButtOn on banner",obj.getCommunicationLink(),TestCaseDescription);
			CommonFunctions.verifyElement(driver, "Communication link Text",obj.getCommunicationLink_BannerText(),TestCaseDescription);
			//CommonFunctions.verifyText(driver, "Home",obj.getCommunicationLink_BannerText(),TestCaseDescription);
	        CommonFunctions.ClickButton(driver,obj.getCommunicationLink());
			
			
			CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(),TestCaseDescription );
			 CommonFunctions.verifySecurityElements(driver,TestCaseDescription);
			// CommonFunctions.setSecurityFields(driver,1, "animal",2,"animal",3,"animal", TestCaseDescription);
			 CommonFunctions.getQuestionList(driver,obj.getQuestion1(), TestCaseDescription);
			 CommonFunctions.getQuestionList(driver,obj.getQuestion2(), TestCaseDescription);
			 CommonFunctions.getQuestionList(driver,obj.getQuestion3(), TestCaseDescription);
			 
			// CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
			// CommonFunctions.verifyElement(driver,"Security question", obj.getSecurityQuestionMessage(),TestCaseDescription);

					
			BaseClass.statusPassWithScreenshot(driver, "Security Question Setup Screen",TestCaseDescription);
			endReporting();
		}

	}
	@Test(dataProvider="DriverSheet")
	public void test_325_C_TC005(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC005")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Complex"))
		{
			
			startReporting(Functionality);
			
			accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
		 //   CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
	      //  CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
		    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
		            
		   CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
		    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	    	driver.close();
	    	driver=LoginPage.LaunchBrowser(Browser);
	    	LoginPage.LaunchURL(driver,GatewayQAURL);
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
			 
			   CommonFunctions.verifyText(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_VerifyText_Eng") , obj.getUnSecureError(), TestCaseDescription);
			    
			
			LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
	      //  Admin.getTemporaryTradingPassword(driver,accountNumber);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
	        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	  	
	  /* 	 CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
	        //System.out.println(obj.getNewTradingpassword());
	        
	        
	        driver.findElement(By.xpath(obj.getNewTradingpassword())).sendKeys("aaaaaa");
	        driver.findElement(By.xpath(obj.getConfirmTradingpassword())).sendKeys("aaaaaa");
	        CommonFunctions.ClickButton(driver,obj.getTradingcontinue());*/
	        
	        
	   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
	   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
	   	  	CommonFunctions.setSecurityFields(driver,1, "animal",2, "porter", 6, "failure", TestCaseDescription);
	   	 	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	   	 	CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
	  	    driver.findElement(By.xpath(obj.getEmailAddressNewEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
	     	driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
	     	BaseClass.statusPassWithScreenshot(driver,"Email Address Screen",TestCaseDescription);
	    	CommonFunctions.movemousepointer(driver,"//label[@for='terms']");
	        CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
	        CommonFunctions.waitForElement(driver, obj.getEmailConfirmationPageTitle(), 10, "verification");
	        LoginPage.LaunchURL(driver,GatewayEmailURL);
	        CommonFunctions.EmailLogin(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailUserName"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailPwd"), TestCaseDescription);
	        Thread.sleep(2000);
	        System.out.println("check1");
	        CommonFunctions.EmailValidation(driver, accountNumber, TestCaseDescription);
	        statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);
	  
	        CommonFunctions.ClickButton(driver,obj.getGotoLoginButton());
	        LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
		 
		    CommonFunctions.waitForElement(driver, obj.getHomePageLogo(), 10, "verification");
		      
	    	 
	    	 
	    	 
	    	 
	      	endReporting();
		}
	}
	
	
	@Test(dataProvider="DriverSheet")
	public void test_325_C_TC007(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC007")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Complex"))
		{
			
			startReporting(Functionality);
			
			accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
		 //   CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
	      //  CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
		    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
		            
		   CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
		    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	    	
		    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys("A2aaaaaa");
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys("A2aaaaaa");
	   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	  	
	   		CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
	   	 
	   
		    
		    driver.close();
	    	driver=LoginPage.LaunchBrowser(Browser);
	    	LoginPage.LaunchURL(driver,GatewayQAURL);
			LoginPage.Login(rowNumber,accountNumber, "A2aaaaaa","Home",TestCaseDescription);
			 
			   CommonFunctions.verifyText(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_VerifyText_Eng") , obj.getUnSecureError(), TestCaseDescription);
			    
			
			LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
	      //  Admin.getTemporaryTradingPassword(driver,accountNumber);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
	        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	  	
	  /* 	 CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
	        //System.out.println(obj.getNewTradingpassword());
	        
	        
	        driver.findElement(By.xpath(obj.getNewTradingpassword())).sendKeys("aaaaaa");
	        driver.findElement(By.xpath(obj.getConfirmTradingpassword())).sendKeys("aaaaaa");
	        CommonFunctions.ClickButton(driver,obj.getTradingcontinue());*/
	        
	        
	   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
	   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
	   	  	CommonFunctions.setSecurityFields(driver,1, "animal",2, "porter", 6, "failure", TestCaseDescription);
	   	 	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	   	 	CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
	  	    driver.findElement(By.xpath(obj.getEmailAddressNewEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
	     	driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
	     	BaseClass.statusPassWithScreenshot(driver,"Email Address Screen",TestCaseDescription);
	    	CommonFunctions.movemousepointer(driver,"//label[@for='terms']");
	        CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
	        CommonFunctions.waitForElement(driver, obj.getEmailConfirmationPageTitle(), 10, "verification");
	        LoginPage.LaunchURL(driver,GatewayEmailURL);
	        CommonFunctions.EmailLogin(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailUserName"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailPwd"), TestCaseDescription);
	        Thread.sleep(2000);
	        System.out.println("check1");
	        CommonFunctions.EmailValidation(driver, accountNumber, TestCaseDescription);
	        statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);
	  
	        CommonFunctions.ClickButton(driver,obj.getGotoLoginButton());
	        LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
		 
		    CommonFunctions.waitForElement(driver, obj.getHomePageLogo(), 10, "verification");
		      
	    	 
	    	 
	    	 
	    	 
	      	endReporting();
		}
	}
	
	
	@Test(dataProvider="DriverSheet")
	public void test_325_C_TC008(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC008")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Complex"))
		{
			
			startReporting(Functionality);
			
			accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
		 //   CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
	      //  CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
		    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
		            
		   CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
		   
		    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	  	
	  /* 	 CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
	        //System.out.println(obj.getNewTradingpassword());
	        
	        
	        driver.findElement(By.xpath(obj.getNewTradingpassword())).sendKeys("aaaaaa");
	        driver.findElement(By.xpath(obj.getConfirmTradingpassword())).sendKeys("aaaaaa");
	        CommonFunctions.ClickButton(driver,obj.getTradingcontinue());*/
	        
	        
	   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
	   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
	   	  	CommonFunctions.setSecurityFields(driver,1, "animal",2, "porter", 6, "failure", TestCaseDescription);
	   	 	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	   	 	CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
	  	
		 
		    
		    driver.close();
	    	driver=LoginPage.LaunchBrowser(Browser);
	    	LoginPage.LaunchURL(driver,GatewayQAURL);
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"),"Home",TestCaseDescription);
			CommonFunctions.verifyText(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_VerifyText_Eng") , obj.getUnSecureError(), TestCaseDescription);
			    
			
			  	 
	    	 
	    	 
	    	 
	      	endReporting();
		}
	}
	
	
	@Test(dataProvider="DriverSheet")
	public void test_325_C_TC009(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC009")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Complex"))
		{
			
			startReporting(Functionality);
			
			accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
		 //   CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
	      //  CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
		    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
		            
		   CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
		    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	    	
		    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys("A2aaaaaa");
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys("A2aaaaaa");
	   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	  	
	   		CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
	   	 
	   		CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
	   	  	CommonFunctions.setSecurityFields(driver,1, "animal",2, "porter", 6, "failure", TestCaseDescription);
	   	 	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	   	 	CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
	  	
		    
		    driver.close();
	    	driver=LoginPage.LaunchBrowser(Browser);
	    	LoginPage.LaunchURL(driver,GatewayQAURL);
			LoginPage.Login(rowNumber,accountNumber, "A2aaaaaa","Home",TestCaseDescription);
			 
			   CommonFunctions.verifyText(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_VerifyText_Eng") , obj.getUnSecureError(), TestCaseDescription);
			    
			
			LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
	      //  Admin.getTemporaryTradingPassword(driver,accountNumber);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
	        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	  	
	  /* 	 CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
	        //System.out.println(obj.getNewTradingpassword());
	        
	        
	        driver.findElement(By.xpath(obj.getNewTradingpassword())).sendKeys("aaaaaa");
	        driver.findElement(By.xpath(obj.getConfirmTradingpassword())).sendKeys("aaaaaa");
	        CommonFunctions.ClickButton(driver,obj.getTradingcontinue());*/
	        
	        
	   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
	   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
	   	  	CommonFunctions.setSecurityFields(driver,8, "animal1",5, "porter1", 10, "failure1", TestCaseDescription);
	   	 	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	   	 	CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
	  	    driver.findElement(By.xpath(obj.getEmailAddressNewEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
	     	driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
	     	BaseClass.statusPassWithScreenshot(driver,"Email Address Screen",TestCaseDescription);
	    	CommonFunctions.movemousepointer(driver,"//label[@for='terms']");
	        CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
	        CommonFunctions.waitForElement(driver, obj.getEmailConfirmationPageTitle(), 10, "verification");
	        LoginPage.LaunchURL(driver,GatewayEmailURL);
	        CommonFunctions.EmailLogin(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailUserName"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailPwd"), TestCaseDescription);
	        Thread.sleep(2000);
	        System.out.println("check1");
	        CommonFunctions.EmailValidation(driver, accountNumber, TestCaseDescription);
	        statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);
	  
	        CommonFunctions.ClickButton(driver,obj.getGotoLoginButton());
	        LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
		 
		    CommonFunctions.waitForElement(driver, obj.getHomePageLogo(), 10, "verification");
		      
	    	 
	    	 
	    	 
	    	 
	      	endReporting();
		}
	}
	
	
	
	@Test(dataProvider="DriverSheet")
	public void test_323_M_TC076(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC076")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium"))
		{
			
			startReporting(TestCaseDescription);
			
			accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
		    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
		    CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
		    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	  	//CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
	   	 CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
	   	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
   	  	CommonFunctions.setSecurityFields(driver,8, "animal1",5, "porter1", 10, "failure1", TestCaseDescription);
   	  
	     //CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
	        statusPassWithScreenshot(driver,"Security Question Screen",TestCaseID);
	  
	       	 
	    	 
	    	 
	    	 
	      	endReporting();
		}
	}
	
	@Test(dataProvider="DriverSheet")
	public void test_323_M_TC077(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC077")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium"))
		{
			
			startReporting(TestCaseDescription);
			
			accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
		    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
		    CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
		    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	  	//CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
	   	 CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
	   	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
   	  	CommonFunctions.setSecurityFields(driver,8, "animal1",5, "porter1", 10, "failure1", TestCaseDescription);
   	  
	     //CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
	        statusPassWithScreenshot(driver,"Security Question Screen",TestCaseID);
	  
	       	 
	    	 
	    	 
	    	 
	      	endReporting();
		}
	}
	
	
	@Test(dataProvider="DriverSheet")
	public void test_323_M_TC078(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC078")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium"))
		{
			
			startReporting(TestCaseDescription);
			
			accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
		    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
		    CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
		    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	  	//CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
	   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
	   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
	   	  	CommonFunctions.setSecurityFields(driver,8, "animal1",5, "animal1", 10, "animal1", TestCaseDescription);
	   	  	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	   		CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Verifytext_Eng"), obj.getSecurityErrorMessages(),TestCaseDescription);
	   		statusPassWithScreenshot(driver,"Security Question Screen",TestCaseID);
	   		     
	      	endReporting();
		}
	}
	
	
	@Test(dataProvider="DriverSheet")
	public void test_323_M_TC087(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC087")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium"))
		{
			
			startReporting(TestCaseDescription);
			
			accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
		    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
		    CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
		    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	  	//CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
	   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
	   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
	   	  	CommonFunctions.setSecurityFields(driver,8, "animal1",5, "animal1", 10, "porter1", TestCaseDescription);
	   	  	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	   		CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Verifytext_Eng"), obj.getSecurityErrorMessages(),TestCaseDescription);
	   		statusPassWithScreenshot(driver,"Security Question Screen",TestCaseID);
	   		     
	      	endReporting();
		}
	}
	
	
	@Test(dataProvider="DriverSheet")
	public void test_323_M_TC023(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC023")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium"))
		{
			
			startReporting(TestCaseDescription);
			
			//Login to the Application	
			LoginPage.LaunchURL(driver,GatewayQAURL);
			accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
			   
			LoginPage.Login(rowNumber,accountNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng") ,"eServices",Functionality + TestCaseID);
			CommonFunctions.waitForElement(driver, obj.getLoginDropDown(),10,"LoginPage");              
			CommonFunctions.verifyElement(driver,"eServices", obj.getAccountSetting_eServicesTab(),TestCaseDescription);
		    statusPass("eServices page displayed");   
		    CommonFunctions.verifyElement(driver,"Profile", obj.getAccountSetting_ProfileTab(),TestCaseDescription);
	        driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab())).click();
	        CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Verifytext_Eng"),obj.getProfileEmailadreditbtn(),TestCaseDescription);
	     
	     
			
	   		statusPassWithScreenshot(driver,"Profile Screen",TestCaseID);
	   		     
	      	endReporting();
		}
	}
	@Test(dataProvider="DriverSheet")
	public void test_323_M_TC080(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC080")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium"))
		{
			
			startReporting(TestCaseDescription);
			
			accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
		    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
		    CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
		    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	  	//CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
	   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
	   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
	   	  	CommonFunctions.setSecurityFields(driver,8, "animal1",5, "porter1", 10, "tester12", TestCaseDescription);
	   	  	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	   		CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
		  	
	   		statusPassWithScreenshot(driver,"Email Screen",TestCaseID);
	   		     
	      	endReporting();
		}
	}
	
	
	@Test(dataProvider="DriverSheet")
	public void test_323_M_TC082(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC082")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium"))
		{
			
			startReporting(TestCaseDescription);
			
			accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
		    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
		    CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
		    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	  	//CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
	   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
	   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
	   	  	CommonFunctions.setSecurityFields(driver,5, "animal1",7, "porter1", 8, "tester12", TestCaseDescription);
	   	  	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	   		CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
		  	
	   		statusPassWithScreenshot(driver,"Email Screen",TestCaseID);
	   		     
	      	endReporting();
		}
	}
	
	@Test(dataProvider="DriverSheet")
	public void test_323_M_TC083(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC083")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium"))
		{
			
			startReporting(TestCaseDescription);
			
			accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
		    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
		    CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
		    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	  	//CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
	   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
	   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
	   	  	CommonFunctions.setSecurityFields(driver,5, "animal1",18, "porter1", 10, "tester12", TestCaseDescription);
	   	  	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	   		CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
		  	
	   		statusPassWithScreenshot(driver,"Email Screen",TestCaseID);
	   		     
	      	endReporting();
		}
	}
	
	@Test(dataProvider="DriverSheet")
	public void test_323_M_TC084(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC084")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium"))
		{
			
			startReporting(TestCaseDescription);
			
			accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
		    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
		    CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
		    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	  	//CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
	   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
	   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
	   	  	CommonFunctions.setSecurityFields(driver,10, "animal1",5, "porter1", 18, "tester12", TestCaseDescription);
	   	  	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	   		CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
		  	
	   		statusPassWithScreenshot(driver,"Email Screen",TestCaseID);
	   		     
	      	endReporting();
		}
	}
	
	
	@Test(dataProvider="DriverSheet")
	public void test_323_M_TC086(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC086")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium"))
		{
			
			startReporting(TestCaseDescription);
			
			accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
		    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
		    CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
		    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	  	//CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
	   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
	   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
	   	  	CommonFunctions.setSecurityFields(driver,10, "animal1",18, "porter1", 5, "tester12", TestCaseDescription);
	   	  	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	   		CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
		  	
	   		statusPassWithScreenshot(driver,"Email Screen",TestCaseID);
	   		     
	      	endReporting();
		}
	}

	@Test(dataProvider="DriverSheet")
	public void test_323_M_TC085(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC085")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium"))
		{
			
			startReporting(TestCaseDescription);
			
			accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
		    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
		    CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
		    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	  	//CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
	   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
	   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
	   	  	CommonFunctions.setSecurityFields(driver,18, "animal1",10, "porter1", 5, "tester12", TestCaseDescription);
	   	  	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	   		CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
		  	
	   		statusPassWithScreenshot(driver,"Email Screen",TestCaseID);
	   		     
	      	endReporting();
		}
	}
	
	
		
@AfterTest
public void afterTest() throws Exception
{
		
}
	
@AfterSuite
public void afterSuite() throws Exception
{
      closeReporting();
      LoginPage.closeDriver();
      ReadExcelFile.endExcelFileRead();
}
}
