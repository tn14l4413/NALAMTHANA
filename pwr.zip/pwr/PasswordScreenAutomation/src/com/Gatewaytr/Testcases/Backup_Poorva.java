/**
 * 
 */
package com.Gatewaytr.Testcases;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.os.WindowsUtils;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.Gateway.GlobalParameters.BaseClass;
import com.Gateway.GlobalParameters.FetchingOR;
import com.Gatewaytr.ExcelFile.ReadExcelFile;
import com.Gatewaytr.pages.Admin;
import com.Gatewaytr.pages.CommonFunctions;
import com.Gatewaytr.pages.DataBase;
import com.Gatewaytr.pages.LoginPage;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

/**
 * @author craja01 TestNG Class
 * 
 */
public class Backup_Poorva extends BaseClass {
	WebDriver driver;
	String Browser,LanguageSettings;
	String accountNumber;
	ExtentReports extent;
	ExtentTest logger;
	public FetchingOR obj = null;
	public String fileName = "C:\\GatewayPasswordReset\\Configuration\\ConfigurationPage.property";
	File src = new File(
			"C:\\GatewayPasswordReset\\DriverSheet\\DriveSheetSample.xls");
	int rowNumber;

	@DataProvider(name = "DriverSheet")
	public Object[][] driverSheetData() {
		Object[][] arrayObject = getExcelData(
				"C:\\GatewayPasswordReset\\DriverSheet\\DriveSheetSample.xls",
				"Sheet1");
		return arrayObject;
	}

	public String[][] getExcelData(String fileName, String sheetName) {
		String[][] arrayExcelData = null;
		try {
			FileInputStream fs = new FileInputStream(fileName);
			Workbook wb = Workbook.getWorkbook(fs);
			Sheet sh = wb.getSheet(sheetName);

			int totalNoOfCols = sh.getColumns();
			int totalNoOfRows = sh.getRows();

			arrayExcelData = new String[totalNoOfRows - 1][totalNoOfCols];

			for (int i = 1; i < totalNoOfRows; i++) {

				for (int j = 0; j < totalNoOfCols; j++) {
					arrayExcelData[i - 1][j] = sh.getCell(j, i).getContents();

				}

			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
			e.printStackTrace();
		} catch (BiffException e) {
			e.printStackTrace();
		}
		return arrayExcelData;
	}

	@BeforeSuite
	public void beforeSuite() throws Exception {

		setReport();

	}

	@BeforeTest
	@Parameters({ "browserName", "language" })
	public void beforeTest(String browserName, String language)
			throws Exception {
		String Browser, LanguageSettings;
		Browser = browserName;
		LanguageSettings = language;
		System.out.println("*****************" + Browser);
		System.out.println("*****************" + LanguageSettings);
		obj = new FetchingOR(fileName);
		ReadExcelFile.setExcelFile(filePath, LanguageSettings);
		driver = LoginPage.LaunchBrowser(Browser);

	}

	
	
	/*
	 * @author=Poorva Dixit
	 */

	@Test(dataProvider = "DriverSheet")
	public void test_322_TC081(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC081")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.2_Functional_Low")) {

			startReporting("3.2.2_Functional_Low_TC081_GUI_Set up challenge questions screen");

			// Launching the admin url
			LoginPage.LaunchURL(driver, GatewayAdminURL);
			// Storing temporary password from admin Url
			String tempPassword = Admin.getTemporaryPassword(driver,
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			// Storing the trading password

			Admin.getTemporaryTradingPassword(driver, ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Username_Eng"));

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));
			// Logging in using temporary password
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), tempPassword, "Home",
					Functionality + TestCaseID);
			// verifying the screen of create a new password
			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(),
					"3.2.2_Functional_Low_TC081");
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					"3.2.2_Functional_Low_TC081");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					"3.2.2_Functional_Low_TC081");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					"3.2.2_Functional_Low_TC081");
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", "3.2.2_Functional_Low_TC081");

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_ConfirmPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					"3.2.2_Functional_Low_TC081");
			
			
			
			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			/*
			 * Moving to Trading screen verifyElement
			 */CommonFunctions.verifyText(driver,
					"Create a new Trading password", obj.getTradingTitle(),
					"3.2.2_Functional_Low_TC081");

			driver.findElement(By.xpath(obj.getTradingNewPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_TradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingMinimum6chracters(), "rgba(0, 138, 0, 1)",
					"Minimum 6 characters", "3.2.2_Functional_Low_TC081");

			driver.findElement(By.xpath(obj.getTradingConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality,
									"p_ConfirmTradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingConfirmPasswordCheck(), "rgba(0, 138, 0, 1)",
					"Confirmed, your Trading passwords match",
					"3.2.2_Functional_Low_TC081");

			driver.findElement(By.xpath(obj.getTradingContinueButton()))
					.click();

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.2_Functional_Low_TC081");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC081",
					"3.2.2_Functional_Low_TC081");

			endReporting();

		}
	}

	/*
	 * @author=Poorva Dixit
	 */

	@Test(dataProvider = "DriverSheet")
	public void test_322_TC082(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC082")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.2_Functional_Low")) {

			startReporting("3.2.2_Functional_Low_TC082_GUI_Set up challenge questions screen");

			// Launching the admin url
			LoginPage.LaunchURL(driver, GatewayAdminURL);
			// Storing temporary password from admin Url
			String tempPassword = Admin.getTemporaryPassword(driver,
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			// Storing the trading password

			Admin.getTemporaryTradingPassword(driver, ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Username_Eng"));

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));
			// Logging in using temporary password
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), tempPassword, "Home",
					Functionality + TestCaseID);
			// verifying the screen of create a new password
			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(),
					"3.2.2_Functional_Low_TC082");
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					"3.2.2_Functional_Low_TC082");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					"3.2.2_Functional_Low_TC082");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					"3.2.2_Functional_Low_TC082");
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", "3.2.2_Functional_Low_TC082");

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_ConfirmPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					"3.2.2_Functional_Low_TC082");
			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			/*
			 * Moving to Trading screen verifyElement
			 */CommonFunctions.verifyText(driver,
					"Create a new Trading password", obj.getTradingTitle(),
					"3.2.2_Functional_Low_TC082");

			driver.findElement(By.xpath(obj.getTradingNewPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_TradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingMinimum6chracters(), "rgba(0, 138, 0, 1)",
					"Minimum 6 characters", "3.2.2_Functional_Low_TC082");

			driver.findElement(By.xpath(obj.getTradingConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality,
									"p_ConfirmTradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingConfirmPasswordCheck(), "rgba(0, 138, 0, 1)",
					"Confirmed, your Trading passwords match",
					"3.2.2_Functional_Low_TC082");

			driver.findElement(By.xpath(obj.getTradingContinueButton()))
					.click();

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.2_Functional_Low_TC082");
			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getQuestion1(), "3.2.2_Functional_Low_TC082");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getQuestion2(), "3.2.2_Functional_Low_TC082");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getQuestion3(), "3.2.2_Functional_Low_TC082");

			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_322_TC083(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC083")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.2_Functional_Low")) {

			startReporting("3.2.2_Functional_Low_TC083_GUI_Set up challenge questions screen_Challenge questions dropdown");

			// Launching the admin url
			LoginPage.LaunchURL(driver, GatewayAdminURL);
			// Storing temporary password from admin Url
			String tempPassword = Admin.getTemporaryPassword(driver,
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			// Storing the trading password

			Admin.getTemporaryTradingPassword(driver, ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Username_Eng"));

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));
			// Logging in using temporary password
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), tempPassword, "Home",
					Functionality + TestCaseID);
			// verifying the screen of create a new password
			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(),
					"3.2.2_Functional_Low_TC083");
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					"3.2.2_Functional_Low_TC083");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					"3.2.2_Functional_Low_TC083");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					"3.2.2_Functional_Low_TC083");
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", "3.2.2_Functional_Low_TC083");

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_ConfirmPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					"3.2.2_Functional_Low_TC083");
			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			/*
			 * Moving to Trading screen verifyElement
			 */CommonFunctions.verifyText(driver,
					"Create a new Trading password", obj.getTradingTitle(),
					"3.2.2_Functional_Low_TC083");

			driver.findElement(By.xpath(obj.getTradingNewPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_TradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingMinimum6chracters(), "rgba(0, 138, 0, 1)",
					"Minimum 6 characters", "3.2.2_Functional_Low_TC083");

			driver.findElement(By.xpath(obj.getTradingConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality,
									"p_ConfirmTradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingConfirmPasswordCheck(), "rgba(0, 138, 0, 1)",
					"Confirmed, your Trading passwords match",
					"3.2.2_Functional_Low_TC083");

			driver.findElement(By.xpath(obj.getTradingContinueButton()))
					.click();

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.2_Functional_Low_TC083");
			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getQuestion1(), "3.2.2_Functional_Low_TC083");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getQuestion2(), "3.2.2_Functional_Low_TC083");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getQuestion3(), "3.2.2_Functional_Low_TC083");
			// Clicking on First question dropdown
			driver.findElement(By.xpath(obj.getQuestion1())).click();

		//	CommonFunctions.getQuestionList(driver, obj.getQuestion1(),"3.2.2_Functional_Low_TC083");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_322_TC084(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC084")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.2_Functional_Low")) {

			startReporting("3.2.2_Functional_Low_TC084_GUI_Set up challenge questions screen_Challenge questions dropdow");
			/*------------  Pre-requisites---------- */
			LoginPage.LaunchURL(driver, GatewayAdminURL);

			String tempPassword = Admin.getTemporaryPassword(driver,
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			// Storing the trading password

			Admin.getTemporaryTradingPassword(driver, ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Username_Eng"));
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));
			// Logging in using temporary password

			/*------------  Step2 and Step3 and Step4 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), tempPassword, "Home",
					Functionality + TestCaseID);

			/*------------  Step5---------- */

			// verifying the screen of create a new password
			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(),
					"3.2.2_Functional_Low_TC084");

			/*------------  Step6---------- */
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					"3.2.2_Functional_Low_TC084");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					"3.2.2_Functional_Low_TC084");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					"3.2.2_Functional_Low_TC084");
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", "3.2.2_Functional_Low_TC084");

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_ConfirmPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					"3.2.2_Functional_Low_TC084");
			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			/*------------  Step7---------- */

			/*
			 * Moving to Trading screen verifyElement
			 */CommonFunctions.verifyText(driver,
					"Create a new Trading password", obj.getTradingTitle(),
					"3.2.2_Functional_Low_TC084");

			driver.findElement(By.xpath(obj.getTradingNewPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_TradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingMinimum6chracters(), "rgba(0, 138, 0, 1)",
					"Minimum 6 characters", "3.2.2_Functional_Low_TC084");

			driver.findElement(By.xpath(obj.getTradingConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality,
									"p_ConfirmTradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingConfirmPasswordCheck(), "rgba(0, 138, 0, 1)",
					"Confirmed, your Trading passwords match",
					"3.2.2_Functional_Low_TC084");

			driver.findElement(By.xpath(obj.getTradingContinueButton()))
					.click();

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.2_Functional_Low_TC084");

			/*------------  Step8---------- */

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getQuestion1(), "3.2.2_Functional_Low_TC084");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getQuestion2(), "3.2.2_Functional_Low_TC084");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getQuestion3(), "3.2.2_Functional_Low_TC084");

			/*------------  Step9---------- */

			// Clicking on First question dropdown
			driver.findElement(By.xpath(obj.getQuestion2())).click();

			//CommonFunctions.getQuestionList(driver, obj.getQuestion2(),					"3.2.2_Functional_Low_TC084");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_322_TC085(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC085")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.2_Functional_Low")) {

			startReporting("3.2.2_Functional_Low_TC085_GUI_Set up challenge questions screen_Challenge questions dropdow");

			/*------------  Pre-requisites---------- */
			LoginPage.LaunchURL(driver, GatewayAdminURL);

			String tempPassword = Admin.getTemporaryPassword(driver,
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			// Storing the trading password

			Admin.getTemporaryTradingPassword(driver, ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Username_Eng"));
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));
			// Logging in using temporary password

			/*------------  Step2 and Step3 and Step4 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), tempPassword, "Home",
					Functionality + TestCaseID);

			/*------------  Step5---------- */

			// verifying the screen of create a new password
			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(),
					"3.2.2_Functional_Low_TC085");

			/*------------  Step6---------- */
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					"3.2.2_Functional_Low_TC085");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					"3.2.2_Functional_Low_TC085");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					"3.2.2_Functional_Low_TC085");
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", "3.2.2_Functional_Low_TC085");

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_ConfirmPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					"3.2.2_Functional_Low_TC085");
			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			/*------------  Step7---------- */

			/*
			 * Moving to Trading screen verifyElement
			 */CommonFunctions.verifyText(driver,
					"Create a new Trading password", obj.getTradingTitle(),
					"3.2.2_Functional_Low_TC085");

			driver.findElement(By.xpath(obj.getTradingNewPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_TradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingMinimum6chracters(), "rgba(0, 138, 0, 1)",
					"Minimum 6 characters", "3.2.2_Functional_Low_TC085");

			driver.findElement(By.xpath(obj.getTradingConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality,
									"p_ConfirmTradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingConfirmPasswordCheck(), "rgba(0, 138, 0, 1)",
					"Confirmed, your Trading passwords match",
					"3.2.2_Functional_Low_TC085");

			driver.findElement(By.xpath(obj.getTradingContinueButton()))
					.click();

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.2_Functional_Low_TC085");

			/*------------  Step8---------- */

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getQuestion1(), "3.2.2_Functional_Low_TC085");

			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getQuestion2(), "3.2.2_Functional_Low_TC085");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getQuestion3(), "3.2.2_Functional_Low_TC085");

			/*------------  Step9---------- */

			// Clicking on First question dropdown
			driver.findElement(By.xpath(obj.getQuestion3())).click();

			CommonFunctions.getQuestionList(driver, obj.getQuestion3(),
					"3.2.2_Functional_Low_TC085");

			//BaseClass.statusPassWithScreenshot(driver, "Screen For TC085",					"3.2.2_Functional_Low_TC085");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC001_ UI_ Challenge Questions
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC001(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC001")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

			startReporting("3.3.1_Functional_Low_TC001_ UI_ Challenge Questions");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC001");

			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// verifying the Challenge Questions

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getAccountSetting_ProfileTab_SecurityQuesHeading(),
					"3.3.1_Functional_Low_TC001");

			/*------------  Step5 ---------- */

			// verify Spelling of Challenge Question

			CommonFunctions.verifySpellingText(driver, "Challenge questions",
					obj.getAccountSetting_ProfileTab_SecurityQuesHeading(),
					"3.3.1_Functional_Low_TC001");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC001",
					"3.3.1_Functional_Low_TC001");

			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC002_ UI_ Edit button
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC002(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		try {
			int rowNumber = Integer.parseInt(RowNumber);
			if (TestCaseID.equalsIgnoreCase("TC002")
					&& Execution.equalsIgnoreCase("Y")
					&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

				startReporting("3.3.1_Functional_Low_TC002_ UI_ Edit button");

				/*------------  Step1---------- */

				// Launching QA Gateway
				LoginPage.LaunchURL(driver, GatewayQAURL);
				System.out.println("*****************"
						+ ReadExcelFile.getTestData(TestCaseID, Functionality,
								"p_Password_Eng"));

				// Logging in using password and Navigating to the eServices tab
				// page

				/*------------  Step2 ---------- */
				LoginPage.Login(rowNumber, ReadExcelFile.getTestData(
						TestCaseID, Functionality, "p_Username_Eng"),
						ReadExcelFile.getTestData(TestCaseID, Functionality,
								"p_Password_Eng"), "eServices", Functionality
								+ TestCaseID);

				CommonFunctions.verifyText(driver, "Profile",
						obj.getAccountSetting_ProfileTab(),
						"3.3.1_Functional_Low_TC002");
				/*------------  Step3 ---------- */

				driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
						.click();

				/*------------  Step4---------- */

				// verifying the Edit button

				CommonFunctions.waitForElement(driver,
						obj.getEditChallengeqtnbtn(), 40,
						"3.3.1_Functional_Low_TC002");

				CommonFunctions.verifyText(driver, "Edit",
						obj.getEditChallengeqtnbtn(),
						"3.3.1_Functional_Low_TC002");

				/*
				 * CommonFunctions.verifyHorizontalLocationOfElement(driver,
				 * obj.getAccountSetting_ProfileTab_SecurityQuesHeading(),
				 * obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC002");
				 */

				System.out.println("Step4 done");

				/*------------  Step5 ---------- */

				// verify Font Of Edit Button

				/*
				 * CommonFunctions.verifyButtonFont(driver, "#0079c1", "#fff",
				 * "#CCCCCC", "Grey", obj.getEditChallengeqtnbtn(),
				 * "3.3.1_Functional_Low_TC002");
				 * System.out.println("Step5 done");
				 */
				BaseClass.statusPassWithScreenshot(driver, "Screen For TC002",
						"3.3.1_Functional_Low_TC002");

				endReporting();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw e;
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC003_functionality_ Edit button
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC003(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC003")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

			startReporting("3.3.1_Functional_Low_TC003_functionality_ Edit button");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC003");

			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC003");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC003");
			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			CommonFunctions.waitForElement(driver,
					obj.getProfileChallengeqtncontinuebtn(), 40,
					"3.3.1_Functional_Low_TC003");

			CommonFunctions.checkEnabled(driver,
					obj.getProfileChallengeqtncontinuebtn(), "Continue Button",
					"3.3.1_Functional_Low_TC003");

			CommonFunctions.waitForElement(driver,
					obj.getProfileChallengeqtncancelbtn(), 40,
					"3.3.1_Functional_Low_TC003");
			CommonFunctions.checkEnabled(driver,
					obj.getProfileChallengeqtncancelbtn(), "Cancel Button",
					"3.3.1_Functional_Low_TC003");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC003",
					"3.3.1_Functional_Low_TC003");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC005_ UI_ Save Button
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC005(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC005")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

			startReporting("3.3.1_Functional_Low_TC005_ UI_ Save Button");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC005");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab())).click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			CommonFunctions.checkEnabled(driver,
					obj.getProfileChallengeqtnonetextbox(), "TextBox Area",
					"3.3.1_Functional_Low_TC005");

			/*------------  Step5---------- */

			// "Verify the availabilty of save  Button for challange questions section "

			CommonFunctions.checkEnabled(driver,
					obj.getProfileChallengeqtnonetextbox(), "Continue Button",
					"3.3.1_Functional_Low_TC005");

			/*------------  Step6---------- */
			// Verify if the save Button

			/*
			 * CommonFunctions.verifyButtonFont(driver, "Save", "White", "Blue",
			 * "NULL", obj.getEditChallengeqtnbtn(),
			 * "3.3.1_Functional_Low_TC005");
			 */

			CommonFunctions.verifySpellingText(driver, "Save",
					obj.getProfileChallengeqtncontinuebtn(),
					"3.3.1_Functional_Low_TC005");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC005",
					"3.3.1_Functional_Low_TC005");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC007_ UI_ Cancel button
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC007(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC007")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

			startReporting("3.3.1_Functional_Low_TC007_ UI_ Cancel  button");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC007");

			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */
			/*
			 * CommonFunctions.verifyElement(driver, "Edit",
			 * obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC007");
			 * 
			 * CommonFunctions.verifyHorizontalLocationOfElement(driver,
			 * obj.getAccountSetting_ProfileTab_SecurityQuesHeading(),
			 * obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC007");
			 */

			/*------------  Step5---------- */
			// click on Edit Button of Challenge question Section

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();
			CommonFunctions.checkEnabled(driver,
					obj.getProfileChallengeqtnonetextbox(), "TextBox Area",
					"3.3.1_Functional_Low_TC007");

			/*------------  Step5---------- */

			// "Verify the availabilty of save  Button for challange questions section "

			CommonFunctions.checkEnabled(driver,
					obj.getProfileChallengeqtnonetextbox(), "Continue Button",
					"3.3.1_Functional_Low_TC007");

			/*------------  Step6---------- */
			// Verify if the Cancel Button

			// Verification Of Cancel Button Font is Pending as per discussion

			CommonFunctions.verifySpellingText(driver, "Cancel",
					obj.getProfileChallengeqtncancelbtn(),
					"3.3.1_Functional_Low_TC007");

			/*
			 * CommonFunctions.verifyButtonFont(driver, "CancelButton", "Blue",
			 * "White", "Grey", obj.getProfileChallengeqtncancelbtn(),
			 * "3.3.1_Functional_Low_TC007");
			 */

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC007",
					"3.3.1_Functional_Low_TC007");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC009_ UI_Question _Text Fields
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC009(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC009")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

			startReporting("3.3.1_Functional_Low_TC009_ UI_Question _Text Fields");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC009");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Low_TC009");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Low_TC009");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Low_TC009");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC009",
					"3.3.1_Functional_Low_TC009");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC010_ UI_Answer_Text Fields
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC010(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC010")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

			startReporting("3.3.1_Functional_Low_TC010_ UI_Answer_Text Fields");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC010");

			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Low_TC010");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getProfileChallengeansonetextbox(),
					"3.3.1_Functional_Low_TC010");
			CommonFunctions.verifyElement(driver, "Answer 2",
					obj.getProfileChallengeanstwotextbox(),
					"3.3.1_Functional_Low_TC010");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getProfileChallengeansthreetextbox(),
					"3.3.1_Functional_Low_TC010");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC010",
					"3.3.1_Functional_Low_TC010");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC011_ UI_Login password
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC011(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC011")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

			startReporting("3.3.1_Functional_Low_TC011_ UI_Login password");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC010");

			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step5---------- */

			CommonFunctions.verifyText(driver, "Login Password",
					obj.getProfiletextboxloginheader(),
					"3.3.1_Functional_Low_TC011");

			CommonFunctions.checkCapitalize(driver,
					obj.getProfiletextboxloginheader());

			/*------------  Step6---------- */

			driver.findElement(By.xpath(obj.getProfiletextboxlogin())).click();

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC011",
					"3.3.1_Functional_Low_TC011");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC012_functional_Navigates without saving
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC012(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC012")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC012_functional_Navigates without saving");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "eServices",
					obj.getAccountSetting_eServicesTab(),
					"3.3.1_Functional_Medium_TC012");

			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step5---------- */

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC012");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC012");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC012");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step6---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_eServicesTab()))
					.click();

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC012",
					"3.3.1_Functional_Medium_TC012");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC006_ Functionality _ Save Button
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC006(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC006")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC006_Functionality_Save Button");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC006");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC006");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC006");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC006");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step6---------- */

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();

			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC006");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC006",
					"3.3.1_Functional_Medium_TC006");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC008_ Functionality _ Cancel button
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC008(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC008")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC008_Functionality_Cancel button");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC008");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC008");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC008");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC008");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step6---------- */
			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"));
			driver.findElement(By.xpath(obj.getProfileChallengeqtncancelbtn()))
					.click();

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC008",
					"3.3.1_Functional_Medium_TC008");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC015_Error message_ same answer for two security question
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC015(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC015")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC015_Error message_ same answer for two security question");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC015");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC015");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC015");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC015");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step6---------- */
			/*
			 * Here Continue button is present instead of save Button
			 */

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();

			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC015");
			/*
			 * Here answers defect is there as answers aresaved asthe cancel
			 * button is clicked
			 */

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC015",
					"3.3.1_Functional_Medium_TC015");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC016_Error message_ same answer already on file
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC016(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC016")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC016_Error message_ same answer already on file");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC015");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC015");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC015");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC015");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step6---------- */
			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC016");

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();

			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC016");
			/*
			 * Here answers defect is there as answers aresaved asthe cancel
			 * button is clicked
			 */

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC016",
					"3.3.1_Functional_Medium_TC016");
			endReporting();
		}

	}

	/**
	 * TC017_ Change challenge question 1
	 * 
	 * @throws Exception
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC017(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC017")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC017_ Change challenge question 1");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC017");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			String s1 = CommonFunctions.getQuestionValue(driver,
					obj.getProfileChallengeqtnonetextbox());

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnonetextbox(), s1, 17,
					"3.3.1_Functional_Medium_TC017");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC016",
					"3.3.1_Functional_Medium_TC016");
			endReporting();
		}

	}

	/**
	 * TC018_ Change challenge question 2
	 * 
	 * @throws Exception
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC018(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC018")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC018_ Change challenge question 2");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC018");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			String s2 = CommonFunctions.getQuestionValue(driver,
					obj.getProfileChallengeqtntwotextbox());

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtntwotextbox(), s2, 18,
					"3.3.1_Functional_Medium_TC018");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC018",
					"3.3.1_Functional_Medium_TC018");
			endReporting();
		}

	}

	/**
	 * TC019_ Change challenge question 3
	 * 
	 * @throws Exception
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC019(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC019")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_3.3.1_Functional_Medium_TC019 3");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC019");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step5---------- */

			String s3 = CommonFunctions.getQuestionValue(driver,
					obj.getProfileChallengeqtnthreetextbox());

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnthreetextbox(), s3, 18,
					"3.3.1_Functional_Medium_TC019");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC019",
					"3.3.1_Functional_Medium_TC019");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC020_error _Change challenge question _answer not given
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC020(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC005")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC020_error _Change challenge question _answer not given");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC020");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC020");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC020");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, ""));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC020");

			/*------------  Step6---------- */
			// Click on Save button with success text

			/*
			 * Here Continue button is present instead of save Button
			 */

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC020");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC020",
					"3.3.1_Functional_Medium_TC020");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC021_error _Change challenge question _Incorrect Login password
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC021(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC005")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC021_error _Change challenge question _Incorrect Login password");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC021");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC021");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC021");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC021");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step6---------- */
			// Click on Save button with success text

			/*
			 * Here Continue button is present instead of save Button And Login
			 * password Field is absent
			 */

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC021");
			;

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC021");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC021",
					"3.3.1_Functional_Medium_TC021");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC022_error _Change challenge question _and answer for different question
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC022(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC022")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC022_error _Change challenge question _and answer for different question");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC022");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC022");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC022");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, ""));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC022");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step6---------- */

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC022");
			;

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC022");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC022",
					"3.3.1_Functional_Medium_TC022");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC023_error _Change challenge question _and answer for different question
	 * with incorrect password error message
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC023(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC023")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC023_error _Change challenge question _and answer for different question with incorrect password error message");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC023");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers
			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC023");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC023");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, ""));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC023");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step6---------- */
			// Click on Save button with success text
			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC022");
			;

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC023");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC023",
					"3.3.1_Functional_Medium_TC023");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC024_error _Change challenge question _blank Login password
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC024(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC024")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC024_error _Change challenge question _blank  Login password");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC024");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC024");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC024");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC024");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step6---------- */
			// Click on Save button with success text

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys("");
			;

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC024");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC024",
					"3.3.1_Functional_Medium_TC024");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC025_error _Change answer to challenge question _Incorrect Login
	 * password
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC025(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC025")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC025_error _Change answer to challenge question _Incorrect Login password");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC025");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC024");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC024");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC024");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();
			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_UpdatedSecurityQuestion1"),
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC024");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_UpdatedAnswer1");

			/*------------  Step6---------- */
			// Click on Save button with success text
			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC025");
			;

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC025");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC025",
					"3.3.1_Functional_Medium_TC025");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC026_error _Change answer to challenge question _blank Login password
	 * password
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC026(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC026")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC026_error _Change answer to challenge question _blank  Login password");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC026");
			/*------------  Step3 ---------- */

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC020");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC026");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC026");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC026");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			// Click on Save button with success text
			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys("");
			;

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC026");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			/*------------  Step6---------- */
			// Click on Save button with success text

			/*
			 * Here Continue button is present instead of save Button And Login
			 * password Field is absent
			 */

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC026");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC026",
					"3.3.1_Functional_Medium_TC026");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC027_error _challange answer less than 6 characters
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC027(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC027")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC027_error _challange answer less than 6 characters");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC027");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC020");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers
			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC027");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC027");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC027");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_UpdatedSecurityQuestion1"),
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC027");

			// Answer less than 6 letter
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_UpdatedAnswer1");

			/*------------  Step6---------- */
			// Click on Save button with success text

			// Click on Save button with success text
			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC025");
			;
			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC027");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC027",
					"3.3.1_Functional_Medium_TC027");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC028_error _challange answer with special character at beginning of
	 * answer
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC028(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC028")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC028_error _challange answer with special character at beginning of answer");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC028");
			/*------------  Step3 ---------- */

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC020");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers
			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC028");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC028");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC028");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();
			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_UpdatedSecurityQuestion1"),
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC028");

			// Answer Special Character in Begining
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_UpdatedAnswer1");

			/*------------  Step6---------- */
			// Click on Save button with success text

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC025");

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC028");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC028",
					"3.3.1_Functional_Medium_TC028");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit TC029_error _challange answer with special character
	 * in middle of answer
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC029(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC029")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC029_error _challange answer with special character in middle of answer");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC029");
			/*------------  Step3 ---------- */
			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC020");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers
			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC029");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC029");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC029");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_UpdatedSecurityQuestion1"),
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC029");

			// Answer Special Character in Middle
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "P_UpdatedAnswer1"));

			/*------------  Step6---------- */
			// Click on Save button with success text

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC025");
			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC029");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC029",
					"3.3.1_Functional_Medium_TC029");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit TC030_error _challange answer with special character
	 * at end of answer
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC030(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC030")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC030_error _challange answer with special character at end of answer");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC030");
			/*------------  Step3 ---------- */

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC020");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			// Select Challenge question and corresponding answers
			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC030");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC030");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC030");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_UpdatedSecurityQuestion1"),
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC030");

			// Answer Special Characterat the end
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_UpdatedAnswer1"));

			/*------------  Step6---------- */
			// Click on Save button with success text
			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC025");

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC030");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC030",
					"3.3.1_Functional_Medium_TC030");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit TC031_error _challange answer beginning with a space
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC031(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC031")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC031_error _challange answer beginning with a space");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC031");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC031");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC031");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC031");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_UpdatedSecurityQuestion1"),
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC031");

			// Answer with More than 20 characters
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_UpdatedAnswer1"));

			/*------------  Step6---------- */
			// Click on Save button with success text

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC025");
			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC031");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC031",
					"3.3.1_Functional_Medium_TC031");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC032_error _challange answer ending with a space
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC032(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC032")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC032_error _challange answer ending with a space");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC032");
			/*------------  Step3 ---------- */

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC032");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC032");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC032");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_UpdatedSecurityQuestion1"),
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC032");

			// Answer with More than 20 characters
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_UpdatedAnswer1"));

			/*------------  Step6---------- */
			// Click on Save button with success text

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC025");

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC032");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC032",
					"3.3.1_Functional_Medium_TC032");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC033_challange answer with a space in between two characters
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC033(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC033")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC033_challange answer  with a space in between two characters");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC033");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC033");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC033");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC033");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_UpdatedSecurityQuestion1"),
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC033");

			// Answer with space in between
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_UpdatedAnswer1"));

			/*------------  Step6---------- */
			// Click on Save button with success text

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC025");

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC033");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC033",
					"3.3.1_Functional_Medium_TC033");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC034_error _challange answer is 20 characters
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC034a(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC034a")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC034_error _challange answer is 20 characters");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC034a");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC034a");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC034a");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC034a");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_UpdatedSecurityQuestion1"),
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC034a");

			// Answer with More than 20 characters
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_UpdatedAnswer1"));

			/*------------  Step6---------- */
			// Click on Save button with success text
			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC025");
			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC034a");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC034a",
					"3.3.1_Functional_Medium_TC034a");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC034_error _challange answer more than 20 characters
	 */

	@Test(dataProvider = "DriverSheet")
	public void test_331_TC034b(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC034b")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC034b_error _challange answer more  than 20 characters");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC034b");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();
			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC034b");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC034b");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC034b");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_UpdatedSecurityQuestion1"),
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC034b");

			// Answer with More than 20 characters
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_UpdatedAnswer1"));
			/*------------  Step6---------- */
			// Click on Save button with success text

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC025");
			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC034b");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC034b",
					"3.3.1_Functional_Medium_TC034b");
			endReporting();
		}
	}

	//
	/*
	 * @author=Poorva Dixit
	 * 
	 * TC035_error _challange answer is 6 characters
	 */

	@Test(dataProvider = "DriverSheet")
	public void test_331_TC035(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC035")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC035_error _challange answer is 6 characters");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC035");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();
			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC035");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC035");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC035");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_UpdatedSecurityQuestion1"),
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC035");

			// Answer with 6 character
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_UpdatedAnswer1"));

			/*------------  Step6---------- */
			// Click on Save button with success text

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC025");

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC035");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC035",
					"3.3.1_Functional_Medium_TC035");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC013_UI_Updated Date_Collapsed
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC013(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC013")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

			startReporting("3.3.1_Functional_Low_TC013_UI_Updated Date_Collapsed");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC013");
			/*------------  Step3 ---------- */

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step4---------- */
			// Check Date Element and see if its disabled

			CommonFunctions.verifyElement(driver, "Date",
					obj.getProfileTabChallengeQuestionDate(),
					"3.3.1_Functional_Low_TC013");

			CommonFunctions.CheckNonEditable(driver, "Date",
					obj.getProfileTabChallengeQuestionDate(),
					"3.3.1_Functional_Low_TC013");
			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.verifyDateformat(driver,
					obj.getProfileTabChallengeQuestionDate(),
					"3.3.1_Functional_Low_TC013");

			/*------------  Step6---------- */
			// Verify DB Date as Updated Date

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC013",
					"3.3.1_Functional_Low_TC013");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC014_UI_Updated Date_expanded
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC014(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC014")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

			startReporting("3.3.1_Functional_Low_TC014_UI_Updated Date_expanded");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC014");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step5---------- */

			// Check Date Element and see if its Non Editable

			CommonFunctions.verifyElement(driver, "Date",
					obj.getProfileTabChallengeQuestionDate(),
					"3.3.1_Functional_Low_TC014");

			CommonFunctions.CheckNonEditable(driver, "Date",
					obj.getProfileTabChallengeQuestionDate(),
					"3.3.1_Functional_Low_TC014");
			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.verifyDateformat(driver,
					obj.getProfileTabChallengeQuestionDate(),
					"3.3.1_Functional_Low_TC014");

			/*------------  Step6---------- */

			// Verify DB Date as Updated Date waiting for DB method

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC014",
					"3.3.1_Functional_Low_TC014");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC038_UI_Updated Date_after changing challenge questions password
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC038(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC038")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC038_UI_Updated Date_after changing challenge questions");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC038");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();
			/*------------  Step5---------- */

			// Check Date Element and see if its Non Editable

			CommonFunctions.verifyElement(driver, "Date",
					obj.getProfileTabChallengeQuestionDate(),
					"3.3.1_Functional_Low_TC038");

			CommonFunctions.CheckNonEditable(driver, "Date",
					obj.getProfileTabChallengeQuestionDate(),
					"3.3.1_Functional_Low_TC038");

			/*------------  Step6---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.selectByIndex(driver, 3,
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Low_TC038");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng" + "1122"));

			CommonFunctions.selectByIndex(driver, 12,
					obj.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Low_TC038");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys("");

			CommonFunctions.selectByIndex(driver, 13,
					obj.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Low_TC038");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng" + "1112"));

			/*------------  Step7---------- */
			// Click on Save button with success text

			/*
			 * Here Continue button is present instead of save Button And Login
			 * password Field is absent
			 */

			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Low_TC038");

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();

			/*------------  Step8---------- */

			CommonFunctions.verifyUpdatedCurrentdate(driver, "Date",
					obj.getProfileTabChallengeQuestionDate(),
					"3.3.1_Functional_Low_TC038");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC038",
					"3.3.1_Functional_Low_TC038");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC040_Functional_Challenge questions and answers can be entered in any
	 * order
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC040(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC040")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC040_Functional_Challenge questions and answers can be entered in any order");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC040");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();
			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.selectByIndex(driver, 3,
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Low_TC040");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng" + "1122"));

			CommonFunctions.selectByIndex(driver, 12,
					obj.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Low_TC040");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys("");

			CommonFunctions.selectByIndex(driver, 13,
					obj.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Low_TC040");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng" + "1102"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			CommonFunctions.selectByIndex(driver, 4,
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Low_TC040");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng" + "11227"));

			CommonFunctions.selectByIndex(driver, 16,
					obj.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Low_TC040");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys("");

			CommonFunctions.selectByIndex(driver, 10,
					obj.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Low_TC040");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng" + "112"));
			/*------------  Step6---------- */
			// Click on Save button with success text

			/*
			 * Here Continue button is present instead of save Button And Login
			 * password Field is absent
			 */

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();

			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Low_TC040");

			/*------------  Step8---------- */

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC040",
					"3.3.1_Functional_Low_TC040");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC039_UI_Updated Date_after changing challenge questions password
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC039(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC039")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC039_UI_Updated Date_after changing challenge questions");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC039");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();
			/*------------  Step5---------- */

			// Check Date Element and see if its Non Editable

			CommonFunctions.verifyElement(driver, "Date",
					obj.getProfileTabChallengeQuestionDate(),
					"3.3.1_Functional_Low_TC039");

			CommonFunctions.CheckNonEditable(driver, "Date",
					obj.getProfileTabChallengeQuestionDate(),
					"3.3.1_Functional_Low_TC039");

			/*------------  Step6---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.selectByIndex(driver, 3,
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Low_TC039");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng" + "1122"));

			CommonFunctions.selectByIndex(driver, 12,
					obj.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Low_TC039");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys("");

			CommonFunctions.selectByIndex(driver, 13,
					obj.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Low_TC039");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng" + "1112"));

			/*------------  Step7---------- */
			// Click on Save button with success text

			/*
			 * Here Continue button is present instead of save Button And Login
			 * password Field is absent
			 */

			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Low_TC039");

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();

			/*------------  Step8---------- */

			CommonFunctions.verifyUpdatedCurrentdate(driver, "Date",
					obj.getProfileTabChallengeQuestionDate(),
					"3.3.1_Functional_Low_TC039");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC039",
					"3.3.1_Functional_Low_TC039");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC044_UI_ set up challenge Questions
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC044(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC044")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC044_UI_ set up challenge Questions");
			/*------------  Pre-requisites---------- */
			LoginPage.LaunchURL(driver, GatewayAdminURL);

			String tempPassword = Admin.getTemporaryPassword(driver,
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			// Storing the trading password

			Admin.getTemporaryTradingPassword(driver, ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Username_Eng"));
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));
			// Logging in using temporary password

			/*------------  Step2 and Step3  ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), tempPassword, "Home",
					Functionality + TestCaseID);

			// verifying the screen of create a new password
			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(),
					"3.3.1_Functional_Medium_TC044");

			/*------------  Step 4-------- */
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					"3.3.1_Functional_Medium_TC044");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					"3.3.1_Functional_Medium_TC044");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					"3.3.1_Functional_Medium_TC044");
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check",
					"3.3.1_Functional_Medium_TC044");

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					"3.3.1_Functional_Medium_TC044");
			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			/*
			 * Moving to Trading screen verifyElement
			 */CommonFunctions.verifyText(driver,
					"Create a new Trading password", obj.getTradingTitle(),
					"3.3.1_Functional_Medium_TC044");

			/*------------  Step5-------- */

			driver.findElement(By.xpath(obj.getTradingNewPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_TradingPassword"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingMinimum6chracters(), "rgba(0, 138, 0, 1)",
					"Minimum 6 characters", "3.3.1_Functional_Medium_TC044");

			driver.findElement(By.xpath(obj.getTradingConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality,
									"p_ConfirmTradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingConfirmPasswordCheck(), "rgba(0, 138, 0, 1)",
					"Confirmed, your Trading passwords match",
					"3.3.1_Functional_Medium_TC044");

			driver.findElement(By.xpath(obj.getTradingContinueButton()))
					.click();

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.3.1_Functional_Medium_TC044");

			/*------------  Step6--------- */

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getQuestion1(), "3.3.1_Functional_Medium_TC044");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getQuestion2(), "3.3.1_Functional_Medium_TC044");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getQuestion3(), "3.3.1_Functional_Medium_TC044");

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getAnswer1(), "3.3.1_Functional_Medium_TC044");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getAnswer2(), "3.3.1_Functional_Medium_TC044");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getAnswer3(), "3.3.1_Functional_Medium_TC044");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC044",
					"3.3.1_Functional_Medium_TC044");

			endReporting();
		}

	}

	/**
	 * TC041_Functional_Challenge questions _master Question
	 * TC042_Functional_Master question _ question changed seperately
	 * TC045_Functional_Change challenge questions screen_ DB verification
	 * TC046_Functional_Change challenge questions screen_ Cancel without saving
	 * 
	 * @param RowNumber
	 * @param Functionality
	 * @param TestCaseID
	 * @param TestCaseDescription
	 * @param Execution
	 * @param Status
	 * @throws Exception
	 */

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC041_Functional_Challenge questions _master Question
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC041(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC041")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Complex")) {

			startReporting("3.3.1_Functional_Complex_TC041_Functional_Challenge questions _master Question");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Complex_TC041");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			// Select Challenge question and corresponding answers
			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Complex_TC041");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Complex_TC041");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Complex_TC041");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_ErrorMsg"), obj
					.getProfiletabchallengequestionmsg(),
					"3.3.1_Functional_Complex_TC041");

			/*------------  Step6---------- */

			// verify the Db - QA_MASTER_QUESTION column under SI_QA_CHALLENGE

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC041",
					"3.3.1_Functional_Complex_TC041");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC042_Functional_Master question _ question changed seperately
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC042(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC042")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Complex")) {

			startReporting("3.3.1_Functional_Complex_TC042_Functional_Master question _ question changed seperately");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Complex_TC042");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			// Select Challenge question and corresponding answers
			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Complex_TC042");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Complex_TC042");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Complex_TC042");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Complex_TC042");

			/*------------  Step6---------- */

			// verify the Db - QA_MASTER_QUESTION column under SI_QA_CHALLENGE

			/*-------------Step7--------*/

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_UpdatedSecurityQuestion2"),
					obj.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Complex_TC042");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_UpdatedAnswer2"));

			// Password field is absent from the screen

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Complex_TC042");

			/** -------------Step 8-------------- */

			// verify the Db - QA_MASTER_QUESTION column under SI_QA_CHALLENGE

			/** -------------Step 9-------------- */

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_UpdatedSecurityQuestion1"),
					obj.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Complex_TC042");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_UpdatedAnswer1"));

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_ErrorMsg"), obj
					.getProfiletabchallengequestionmsg(),
					"3.3.1_Functional_Complex_TC042");
			/** -------------Step 10-------------- */
			// verify the Db - QA_MASTER_QUESTION column under SI_QA_CHALLENGE

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC042",
					"3.3.1_Functional_Complex_TC042");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC046_Functional_Change challenge questions screen_ Cancel without saving
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC046(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC046")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Complex")) {

			startReporting("3.3.1_Functional_Complex_TC046_Functional_Change challenge questions screen_ Cancel without saving");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Complex_TC046");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();

			/*------------  Step4---------- */
			/*
			 * CommonFunctions.verifyElement(driver, "Challenge  Question 1",
			 * obj.getProfileChallengeqtnonetextbox(),
			 * "3.3.1_Functional_Complex_TC046");
			 * CommonFunctions.verifyElement(driver, "Challenge  Question 2",
			 * obj.getProfileChallengeqtntwotextbox(),
			 * "3.3.1_Functional_Complex_TC046");
			 * CommonFunctions.verifyElement(driver, "Challenge  Question 3",
			 * obj.getProfileChallengeqtnthreetextbox(),
			 * "3.3.1_Functional_Complex_TC046");
			 */

			String s1 = CommonFunctions.getQuestionValue(driver,
					obj.getProfileChallengeqtnonetextbox());

			String s2 = CommonFunctions.getQuestionValue(driver,
					obj.getProfileChallengeqtntwotextbox());

			String s3 = CommonFunctions.getQuestionValue(driver,
					obj.getProfileChallengeqtnthreetextbox());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers
			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Complex_TC046");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Complex_TC046");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Complex_TC046");

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();

			CommonFunctions.verifyText(driver, s1,
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Complex_TC046");

			CommonFunctions.verifyText(driver, s2,
					obj.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Complex_TC046");

			CommonFunctions.verifyText(driver, s3,
					obj.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Complex_TC046");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC046",
					"3.3.1_Functional_Complex_TC046");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC045_Functional_Change challenge questions screen_ DB verification
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC045(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC041")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Complex")) {

			startReporting("3.3.1_Functional_Complex_TC045_Functional_Change challenge questions screen_ DB verification");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Complex_TC045");
			/*------------  Step3 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			driver.findElement(By.xpath(obj.getEditChallengeqtnbtn())).click();
			/*------------  Step4---------- */
			/*
			 * CommonFunctions.verifyElement(driver, "Challenge  Question 1",
			 * obj.getProfileChallengeqtnonetextbox(),
			 * "3.3.1_Functional_Complex_TC045");
			 * CommonFunctions.verifyElement(driver, "Challenge  Question 2",
			 * obj.getProfileChallengeqtntwotextbox(),
			 * "3.3.1_Functional_Complex_TC045");
			 * CommonFunctions.verifyElement(driver, "Challenge  Question 3",
			 * obj.getProfileChallengeqtnthreetextbox(),
			 * "3.3.1_Functional_Complex_TC045");
			 */

			String s1 = CommonFunctions.getQuestionValue(driver,
					obj.getProfileChallengeqtnonetextbox());

			String s2 = CommonFunctions.getQuestionValue(driver,
					obj.getProfileChallengeqtntwotextbox());

			String s3 = CommonFunctions.getQuestionValue(driver,
					obj.getProfileChallengeqtnthreetextbox());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnonetextbox(), s1, 17,
					"3.3.1_Functional_Complex_TC045");

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnonetextbox(), s2, 16,
					"3.3.1_Functional_Complex_TC045");

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnonetextbox(), s3, 15,
					"3.3.1_Functional_Complex_TC045");

			/*------------  Step6---------- */
			// Selecting question 5 in Dropdown
			CommonFunctions.selectByIndex(driver, 5,
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Complex_TC045");

			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			/*------------  Step7---------- */
			// Selecting question 18 in Dropdown
			CommonFunctions.selectByIndex(driver, 18,
					obj.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Complex_TC045");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			/*------------  Step8---------- */
			// Selecting question 10 in Dropdown
			CommonFunctions.selectByIndex(driver, 10,
					obj.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Complex_TC045");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*-----Step10------*/

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_ErrorMsg"), obj
					.getProfiletabchallengequestionmsg(),
					"3.3.1_Functional_Complex_TC045");

			/*------Step11---------------*/
			// /Verify in DB that challenge questions have been updated

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC045",
					"3.3.1_Functional_Complex_TC045");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC005_ 323_Account not activated_closed the browser without setting 3
	 * challenge questions
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_323_TC005(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC005")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.3_Functional_Medium")) {

			startReporting("3.2.3_Functional_Medium_TC005_ 323_Account not activated_closed the browser without setting 3 challenge questions");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2,3,4 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			/*------------  Step5 ---------- */

			CommonFunctions.verifyElement(driver, "Home",
					obj.getHomePageLogo(), "3.2.3_Functional_Medium_TC005");

			/*------------  Step6 ---------- */

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getCommunicationLink_BannerText(),
					"3.2.3_Functional_Medium_TC005");

			CommonFunctions
					.verifyText(driver, "Set up now",
							obj.getCommunicationLink(),
							"3.2.3_Functional_Medium_TC005");

			/*--------------Step 7---*/

			driver.findElement(By.xpath(obj.getCommunicationLink())).click();

			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(),
					"3.2.3_Functional_Medium_TC005");

			/*------------  Step8 ---------- */
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.3_Functional_Medium_TC005");

			/*------------  Step 9 ---------- */

			// Closes the Currently handled window

			driver.close();

			/*------------  Step 10---------- */

			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);
			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_ErrorMsg"), obj
					.getProfiletabchallengequestionmsg(),
					"3.2.3_Functional_Medium_TC005");

			/*------------  Step 11 ---------- */

			LoginPage.LaunchURL(driver, GatewayAdminURL);
			// Storing temporary password from admin Url
			String tempPassword = Admin.getTemporaryPassword(driver,
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			// Storing the trading password

			Admin.getTemporaryTradingPassword(driver, ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Username_Eng"));

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));
			// Logging in using temporary password
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), tempPassword, "Home",
					Functionality + TestCaseID);
			// verifying the screen of create a new password
			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(),
					"3.2.3_Functional_Medium_TC005");
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			/*
			 * Moving to Trading screen verifyElement
			 */CommonFunctions.verifyText(driver,
					"Create a new Trading password", obj.getTradingTitle(),
					"3.2.3_Functional_Medium_TC005");

			driver.findElement(By.xpath(obj.getTradingNewPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_TradingNewPassword"));

			driver.findElement(By.xpath(obj.getTradingConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_TradingConfirmPassword"));

			driver.findElement(By.xpath(obj.getTradingContinueButton()))
					.click();

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.3_Functional_Medium_TC005");

			// Verify Mail Text

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC005",
					"3.2.3_Functional_Medium_TC005");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC007_ 323_Account not activated_closed the browser without updating
	 * Email address screen challenge questions
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_323_TC007(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC007")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.3_Functional_Medium")) {

			startReporting("3.2.3_Functional_Medium_TC007_ 323_Account not activated_closed the browser without updating Email address screen");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			CommonFunctions.verifyElement(driver, "Home",
					obj.getHomePageLogo(), "3.2.3_Functional_Medium_TC007");
			/*------------  Step6 ---------- */

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getCommunicationLink_BannerText(),
					"3.2.3_Functional_Medium_TC007");

			CommonFunctions
					.verifyText(driver, "Set up now",
							obj.getCommunicationLink(),
							"3.2.3_Functional_Medium_TC007");

			/*--------------Step 7---*/

			driver.findElement(By.xpath(obj.getCommunicationLink())).click();

			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(),
					"3.2.3_Functional_Medium_TC007");

			/*------------  Step8 ---------- */
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.3_Functional_Medium_TC007");

			/*------------  Step 9 ---------- */

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.2.3_Functional_Medium_TC007");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.2.3_Functional_Medium_TC007");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.2.3_Functional_Medium_TC007");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			// Verify Email Page
			// Closes the Currently handled window

			/*------------  Step 10---------- */

			driver.close();

			/*-----------Step11 -------*/
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);
			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_ErrorMsg"), obj
					.getProfiletabchallengequestionmsg(),
					"3.2.3_Functional_Medium_TC007");

			// Step12 and 13 require DB and IA access

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC007",
					"3.2.3_Functional_Medium_TC007");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC011_ 323_view communication link in Home page_less than 6 chars
	 * password
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_323_TC011(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC011")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.3_Functional_Medium")) {

			startReporting("3.2.3_Functional_Medium_TC011_ 323_view communication link in Home page_less than 6 chars password");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			CommonFunctions.verifyElement(driver, "Home",
					obj.getHomePageLogo(), "3.2.3_Functional_Medium_TC011");/*------------  Step6 ---------- */

			/*
			 * CommonFunctions.verifyElement(driver, "Banner Message",
			 * obj.getCommunicationLink_BannerText(),
			 * "3.2.3_Functional_Medium_TC011");
			 */
			CommonFunctions.waitForElement(driver,
					obj.getCommunicationLink_BannerText(), 30,
					"3.2.3_Functional_Medium_TC011");

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getCommunicationLink_BannerText(),
					"3.2.3_Functional_Medium_TC011");

			System.out.println("Sucess");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC011",
					"3.2.3_Functional_Medium_TC011");

			System.out.println("Suces334s");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC019_ 323_click on set up now button from home page_account is locked
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_323_TC019(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC019")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.3_Functional_Medium")) {

			startReporting("3.2.3_Functional_Medium_TC019_ 323_click on set up now button from home page_account is locked");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			/*------------  Step6 ---------- */

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getCommunicationLink_BannerText(),
					"3.2.3_Functional_Medium_TC019");

			/*--------------Step 7---*/

			CommonFunctions
					.verifyText(driver, "Set up now",
							obj.getCommunicationLink(),
							"3.2.3_Functional_Medium_TC019");

			// driver.findElement(By.xpath(obj.getCommunicationLink())).click();

			String parentWindow = driver.getWindowHandle(); // get the current
															// window handle

			/*--------------Step 8--*/
			driver.findElement(By.xpath(obj.getCommunicationLink())).click();

			CommonFunctions.SwitchToChildWindow(driver);

			CommonFunctions.waitForElement(driver, obj.getSetUpNowLoginPwd(),
					20, "Profile button");
			Thread.sleep(5000);
			// Setup Now Button scenarios for

			/*--------------Step 9--------*/

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_ErrorMsg"), obj
					.getCommunicationLink_BannerText(),
					"3.2.3_Functional_Medium_TC019");

			/*--------------Step 10--------*/

			boolean val = driver.findElement(By.xpath(obj.getHomePageLogo()))
					.isDisplayed();

			if (val == false) {
				BaseClass.statusPassWithScreenshot(driver, "Screen For TC019",
						"3.2.3_Functional_Medium_TC019");
				endReporting();
			}
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC020_ 323_for creating complex login password_click on set up now button
	 * from Account setting page
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_323_TC020(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC020")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.3_Functional_Medium")) {

			startReporting("3.2.3_Functional_Medium_TC020_ 323_for creating complex login password_click on set up now button from Account setting page");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			/*------------  Step6 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_Tab()));

			CommonFunctions.verifyText(driver, "eServices",
					obj.getAccountSetting_eServicesTab(),
					"3.2.3_Functional_Medium_TC020");

			/*------------  Step7---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step8 ---------- */

			CommonFunctions.verifyElement(driver, "Set up now",
					obj.getSetUpNowLoginPwd(), "3.2.3_Functional_Medium_TC020");

			/*------------  Step9	 ---------- */

			CommonFunctions.verifyElement(driver, "Old password",
					obj.getPassword(), "3.2.3_Functional_Medium_TC022");
			CommonFunctions.verifyElement(driver, "New password",
					obj.getNewPasswordField(), "3.2.3_Functional_Medium_TC020");
			CommonFunctions.verifyElement(driver, "Confirm Password",
					obj.getConfirmPasswordField(),
					"3.2.3_Functional_Medium_TC020");

			driver.findElement(By.xpath(obj.getPassword())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_ConfirmPassword_Eng"));

			driver.findElement(By.xpath(obj.getContinueButton()));

			/*------------  Step10	 ---------- */

			driver.findElement(By.xpath(obj.getSignOutButton())).click();

			/*------------  Step11---------- */
			driver.findElement(By.xpath(obj.getSignInButton())).click();

			/*------------  Step12---------- */

			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"),
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"), "Home", Functionality
							+ TestCaseID);

			// Verify DB Values

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC020",
					"3.2.3_Functional_Medium_TC020");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC021_ 323_for updating email address_click on set up now button from
	 * Account setting page
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_323_TC021(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC021")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.3_Functional_Medium")) {

			startReporting("3.2.3_Functional_Medium_TC021_ 323_for updating email address_click on set up now button from Account setting page");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			/*------------  Step3 ---------- */

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC021",
					"3.2.3_Functional_Medium_TC021");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC022_ 323_for setting of challenge question_click on set up now button
	 * from Account setting page
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_323_TC022(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC022")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.3_Functional_Medium")) {

			startReporting("3.2.3_Functional_Medium_TC022_323_for setting of challenge question_click on set up now button from Account setting page");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			/*------------  Step6 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_Tab()));

			CommonFunctions.verifyText(driver, "eServices",
					obj.getAccountSetting_eServicesTab(),
					"3.2.3_Functional_Medium_TC022");

			/*------------  Step7---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step8 ---------- */

			CommonFunctions.verifyElement(driver, "Set up now",
					obj.getSetUpNowSecurityQues(),
					"3.2.3_Functional_Medium_TC022");

			/*------------  Step9	 ---------- */
			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getProfileChallengeqtnonetextbox(),
					"3.2.3_Functional_Medium_TC022");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getProfileChallengeqtntwotextbox(),
					"3.2.3_Functional_Medium_TC022");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getProfileChallengeqtnthreetextbox(),
					"3.2.3_Functional_Medium_TC022");

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.2.3_Functional_Medium_TC022");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.2.3_Functional_Medium_TC022");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.2.3_Functional_Medium_TC022");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(By.xpath(obj.getProfileChallengeqtncontinuebtn()));

			/*------------  Step10	 ---------- */

			driver.findElement(By.xpath(obj.getSignOutButton())).click();

			/*------------  Step11---------- */
			driver.findElement(By.xpath(obj.getSignInButton())).click();

			/*------------  Step12---------- */

			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			// Verify DB Values

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC022",
					"3.2.3_Functional_Medium_TC022");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC023_ 323_set up now button in Account setting page
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_323_TC023(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC023")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.3_Functional_Medium")) {

			startReporting("3.2.3_Functional_Medium_TC023_ 323_set up now button in Account setting page");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			/*------------  Step6 ---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_Tab()));

			CommonFunctions.verifyText(driver, "eServices",
					obj.getAccountSetting_eServicesTab(),
					"3.2.3_Functional_Medium_TC023");

			/*------------  Step7---------- */

			driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab()))
					.click();

			/*------------  Step8 ---------- */

			CommonFunctions.verifyElement(driver, "Set up now",
					obj.getSetUpNowLoginPwd(), "3.2.3_Functional_Medium_TC023");

			CommonFunctions.verifyElement(driver, "Set up now",
					obj.getSetUpNowEmail(), "3.2.3_Functional_Medium_TC023");

			CommonFunctions.verifyElement(driver, "Set up now",
					obj.getSetUpNowSecurityQues(),
					"3.2.3_Functional_Medium_TC023");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC023",
					"3.2.3_Functional_Medium_TC023");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC020_ 323_for creating complex login password_click on set up now button
	 * from Account setting page
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_323_TC074(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC074")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.3_Functional_Medium")) {

			startReporting("3.2.3_Functional_Medium_TC074_Set up challenge questions screen_setting up of first challenge question");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			/*------------  Step6 ---------- */

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getCommunicationLink_BannerText(),
					"3.2.3_Functional_Medium_TC074");

			CommonFunctions
					.verifyText(driver, "Set up now",
							obj.getCommunicationLink(),
							"3.2.3_Functional_Medium_TC074");

			/*--------------Step 7---*/

			// driver.findElement(By.xpath(obj.getCommunicationLink())).click();

			String parentWindow = driver.getWindowHandle(); // get the current
															// window handle
			driver.findElement(By.xpath(obj.getCommunicationLink())).click();

			CommonFunctions.SwitchToChildWindow(driver);

			CommonFunctions.waitForElement(driver, obj.getSetUpNowLoginPwd(),
					20, "Profile button");
			Thread.sleep(5000);

			// driver.findElement(By.xpath(obj.getSetUpNowLoginPwd())).click();
			CommonFunctions.ClickButton(driver, obj.getSetUpNowLoginPwd());

			/*---------------Step8---------*/

			CommonFunctions.waitForElement(driver, obj.getNewPasswordField(),
					20, "Profile button");
			Thread.sleep(5000);

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.waitForElement(driver,
					obj.getSecurityQuestionTitle(), 20, "Profile button");
			Thread.sleep(5000);

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.3_Functional_Medium_TC074");

			/*---------------Step9---------*/

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getProfileChallengeqtnonetextbox(),
					"3.2.3_Functional_Medium_TC074");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getProfileChallengeqtntwotextbox(),
					"3.2.3_Functional_Medium_TC074");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getProfileChallengeqtnthreetextbox(),
					"3.2.3_Functional_Medium_TC074");
			/*-----------------Step10----------*/

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnonetextbox(), "Select", 20,
					"3.2.3_Functional_Medium_TC074");
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC074",
					"3.2.3_Functional_Medium_TC074");

			/*----------Step for TC075------------*/

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.2.3_Functional_Medium_TC075");
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC075",
					"3.2.3_Functional_Medium_TC075");

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtntwotextbox(), "Select", 19,
					"3.2.3_Functional_Medium_TC075");

			/*----------Step for TC076------------*/

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.2.3_Functional_Medium_TC076");
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC076",
					"3.2.3_Functional_Medium_TC076");

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnthreetextbox(), "Select", 18,
					"3.2.3_Functional_Medium_TC076");

			/*----------Step for TC077------------*/

			CommonFunctions.verifyElement(driver, "",
					obj.getProfileChallengeansonetextbox(),
					"3.2.3_Functional_Medium_TC077");
			CommonFunctions.verifyElement(driver, "",
					obj.getProfileChallengeanstwotextbox(),
					"3.2.3_Functional_Medium_TC077");
			CommonFunctions.verifyElement(driver, "",
					obj.getProfileChallengeansthreetextbox(),
					"3.2.3_Functional_Medium_TC077");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC077",
					"3.2.3_Functional_Medium_TC077");

			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC078",
					"3.2.3_Functional_Medium_TC078");

			CommonFunctions.SwitchToParentWindow(driver, parentWindow);

			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC020_ 323_for creating complex login password_click on set up now button
	 * from Account setting page
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_323_TC075(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC075")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.3_Functional_Medium")) {

			startReporting("3.2.3_Functional_Medium_TC075_Set up challenge questions screen_setting up of second challenge question");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			/*------------  Step6 ---------- */

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getCommunicationLink_BannerText(),
					"3.2.3_Functional_Medium_TC075");

			CommonFunctions
					.verifyText(driver, "Set up now",
							obj.getCommunicationLink(),
							"3.2.3_Functional_Medium_TC075");

			/*--------------Step 7---*/

			driver.findElement(By.xpath(obj.getCommunicationLink())).click();

			/*---------------Step8---------*/

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.3_Functional_Medium_TC075");

			/*---------------Step9---------*/

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getProfileChallengeqtnonetextbox(),
					"3.2.3_Functional_Medium_TC075");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getProfileChallengeqtntwotextbox(),
					"3.2.3_Functional_Medium_TC075");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getProfileChallengeqtnthreetextbox(),
					"3.2.3_Functional_Medium_TC075");
			/*-----------------Step10----------*/

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnonetextbox(), "Select", 20,
					"3.2.3_Functional_Medium_TC075");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.2.3_Functional_Medium_TC075");
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC075",
					"3.2.3_Functional_Medium_TC075");

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtntwotextbox(), "Select", 19,
					"3.2.3_Functional_Medium_TC075");
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC076_Set up challenge questions screen_setting up of third challenge
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_323_TC076(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC076")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.3_Functional_Medium")) {

			startReporting("3.2.3_Functional_Medium_ TC076_Set up challenge questions screen_setting up of third challenge");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			/*------------  Step6 ---------- */

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getCommunicationLink_BannerText(),
					"3.2.3_Functional_Medium_TC076");

			CommonFunctions
					.verifyText(driver, "Set up now",
							obj.getCommunicationLink(),
							"3.2.3_Functional_Medium_TC076");

			/*--------------Step 7---*/

			driver.findElement(By.xpath(obj.getCommunicationLink())).click();

			/*---------------Step8---------*/

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.3_Functional_Medium_TC076");

			/*---------------Step9---------*/

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getProfileChallengeqtnonetextbox(),
					"3.2.3_Functional_Medium_TC076");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getProfileChallengeqtntwotextbox(),
					"3.2.3_Functional_Medium_TC076");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getProfileChallengeqtnthreetextbox(),
					"3.2.3_Functional_Medium_TC076");
			/*-----------------Step10----------*/

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnonetextbox(), "Select", 20,
					"3.2.3_Functional_Medium_TC076");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.2.3_Functional_Medium_TC076");
			/*----------Step 11------------*/

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtntwotextbox(), "Select", 19,
					"3.2.3_Functional_Medium_TC076");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.2.3_Functional_Medium_TC076");

			/*----------Step 12------------*/

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnthreetextbox(), "Select", 18,
					"3.2.3_Functional_Medium_TC076");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC076",
					"3.2.3_Functional_Medium_TC076");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC077_Set up challenge questions screen_challenge answer field
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_323_TC077(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC077")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.3_Functional_Medium")) {

			startReporting("3.2.3_Functional_Medium_TC077_Set up challenge questions screen_challenge answer field");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			/*------------  Step6 ---------- */

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getCommunicationLink_BannerText(),
					"3.2.3_Functional_Medium_TC077");

			CommonFunctions
					.verifyText(driver, "Set up now",
							obj.getCommunicationLink(),
							"3.2.3_Functional_Medium_TC077");

			/*--------------Step 7---*/

			driver.findElement(By.xpath(obj.getCommunicationLink())).click();

			/*---------------Step8---------*/

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.3_Functional_Medium_TC077");

			/*---------------Step9---------*/

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getProfileChallengeqtnonetextbox(),
					"3.2.3_Functional_Medium_TC077");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getProfileChallengeqtntwotextbox(),
					"3.2.3_Functional_Medium_TC077");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getProfileChallengeqtnthreetextbox(),
					"3.2.3_Functional_Medium_TC077");
			/*-----------------Step10----------*/

			CommonFunctions.verifyElement(driver, "Answer 1",
					obj.getProfileChallengeansonetextbox(),
					"3.2.3_Functional_Medium_TC077");
			CommonFunctions.verifyElement(driver, "Answer 2",
					obj.getProfileChallengeanstwotextbox(),
					"3.2.3_Functional_Medium_TC077");
			CommonFunctions.verifyElement(driver, "Answer 3",
					obj.getProfileChallengeansthreetextbox(),
					"3.2.3_Functional_Medium_TC077");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC077",
					"3.2.3_Functional_Medium_TC077");

			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC077",
					"3.2.3_Functional_Medium_TC077");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC078_Set up challenge questions screen_ setting up of challenge answer
	 * fields
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_323_TC078(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC078")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.3_Functional_Medium")) {

			startReporting("3.2.3_Functional_Medium_TC078_Set up challenge questions screen_ setting up of challenge answer fields");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			/*------------  Step5 ---------- */

			CommonFunctions.verifyElement(driver, "Home",
					obj.getHomePageLogo(), "3.2.3_Functional_Medium_TC078");

			/*------------  Step6 ---------- */

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getCommunicationLink_BannerText(),
					"3.2.3_Functional_Medium_TC078");

			CommonFunctions
					.verifyText(driver, "Set up now",
							obj.getCommunicationLink(),
							"3.2.3_Functional_Medium_TC078");

			/*--------------Step 7---*/

			driver.findElement(By.xpath(obj.getCommunicationLink())).click();

			/*---------------Step8---------*/

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.3_Functional_Medium_TC078");

			/*---------------Step9---------*/

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getProfileChallengeqtnonetextbox(),
					"3.2.3_Functional_Medium_TC078");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getProfileChallengeqtntwotextbox(),
					"3.2.3_Functional_Medium_TC078");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getProfileChallengeqtnthreetextbox(),
					"3.2.3_Functional_Medium_TC078");
			/*-----------------Step10----------*/

			CommonFunctions.verifyElement(driver, "Answer 1",
					obj.getProfileChallengeansonetextbox(),
					"3.2.3_Functional_Medium_TC078");
			CommonFunctions.verifyElement(driver, "Answer 2",
					obj.getProfileChallengeanstwotextbox(),
					"3.2.3_Functional_Medium_TC078");
			CommonFunctions.verifyElement(driver, "Answer 3",
					obj.getProfileChallengeansthreetextbox(),
					"3.2.3_Functional_Medium_TC078");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC077",
					"3.2.3_Functional_Medium_TC078");

			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC078",
					"3.2.3_Functional_Medium_TC078");

			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC080_Functional_Set up challenge questions screen_ Continue button
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_323_TC080(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC080")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.3_Functional_Medium")) {

			startReporting("3.2.3_Functional_Medium_TC080_Functional_Set up challenge questions screen_ Continue button");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			/*------------  Step5 ---------- */

			CommonFunctions.verifyElement(driver, "Home",
					obj.getHomePageLogo(), "3.2.3_Functional_Medium_TC080");

			/*------------  Step6 ---------- */

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getCommunicationLink_BannerText(),
					"3.2.3_Functional_Medium_TC080");

			CommonFunctions
					.verifyText(driver, "Set up now",
							obj.getCommunicationLink(),
							"3.2.3_Functional_Medium_TC080");

			/*--------------Step 7---*/

			driver.findElement(By.xpath(obj.getCommunicationLink())).click();

			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(),
					"3.2.3_Functional_Medium_TC080");

			/*------------  Step8 ---------- */
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.3_Functional_Medium_TC080");
			/*------------  Step 9 ---------- */

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getProfileChallengeqtnonetextbox(),
					"3.2.3_Functional_Medium_TC080");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getProfileChallengeqtntwotextbox(),
					"3.2.3_Functional_Medium_TC080");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getProfileChallengeqtnthreetextbox(),
					"3.2.3_Functional_Medium_TC080");

			/*------------  Step 10 ,11,12,--------------------*/
			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.2.3_Functional_Medium_TC080");

			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.2.3_Functional_Medium_TC080");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.2.3_Functional_Medium_TC080");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(By.xpath(obj.getProfileChallengeqtncontinuebtn()));

			// DB Validation Required
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC080",
					"3.2.3_Functional_Medium_TC080");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC082_Functional_Set up challenge questions screen_ Continue button
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_323_TC082(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC082")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.3_Functional_Medium")) {

			startReporting("3.2.3_Functional_Medium_TC082_Functional_Set up challenge questions screen_ Continue button");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			/*------------  Step5 ---------- */

			CommonFunctions.verifyElement(driver, "Home",
					obj.getHomePageLogo(), "3.2.3_Functional_Medium_TC082");

			/*------------  Step6 ---------- */

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getCommunicationLink_BannerText(),
					"3.2.3_Functional_Medium_TC082");

			CommonFunctions
					.verifyText(driver, "Set up now",
							obj.getCommunicationLink(),
							"3.2.3_Functional_Medium_TC082");

			/*--------------Step 7---*/

			driver.findElement(By.xpath(obj.getCommunicationLink())).click();

			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(),
					"3.2.3_Functional_Medium_TC082");

			/*------------  Step8 ---------- */
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.3_Functional_Medium_TC082");
			/*------------  Step 9 ---------- */

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getProfileChallengeqtnonetextbox(),
					"3.2.3_Functional_Medium_TC082");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getProfileChallengeqtntwotextbox(),
					"3.2.3_Functional_Medium_TC082");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getProfileChallengeqtnthreetextbox(),
					"3.2.3_Functional_Medium_TC082");

			/*------------  Step 10 ,11,12,13,14---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnonetextbox(), "Select", 20,
					"3.2.3_Functional_Medium_TC082");
			CommonFunctions.selectByIndex(driver, 5,
					obj.getProfileChallengeqtnonetextbox(),
					"3.2.3_Functional_Medium_TC082");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnthreetextbox(), "Select", 19,
					"3.2.3_Functional_Medium_TC082");
			CommonFunctions.selectByIndex(driver, 18,
					obj.getProfileChallengeqtnthreetextbox(),
					"3.2.3_Functional_Medium_TC082");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtntwotextbox(), "Select", 18,
					"3.2.3_Functional_Medium_TC082");

			CommonFunctions.selectByIndex(driver, 10,
					obj.getProfileChallengeqtntwotextbox(),
					"3.2.3_Functional_Medium_TC082");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			/*------------  Step 15---------- */

			driver.findElement(By.xpath(obj.getProfileChallengeqtncontinuebtn()));

			/*------------Step16-----------*/

			// DB Validation Required

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC082",
					"3.2.3_Functional_Medium_TC082");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC083_Functional_Set up challenge questions screen_ Continue button
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_323_TC083(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC083")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.3_Functional_Medium")) {

			startReporting("3.2.3_Functional_Medium_TC083_Functional_Set up challenge questions screen_ Continue button");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			/*------------  Step5 ---------- */

			CommonFunctions.verifyElement(driver, "Home",
					obj.getHomePageLogo(), "3.2.3_Functional_Medium_TC083");

			/*------------  Step6 ---------- */

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getCommunicationLink_BannerText(),
					"3.2.3_Functional_Medium_TC083");

			CommonFunctions
					.verifyText(driver, "Set up now",
							obj.getCommunicationLink(),
							"3.2.3_Functional_Medium_TC083");

			/*--------------Step 7---*/

			driver.findElement(By.xpath(obj.getCommunicationLink())).click();

			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(),
					"3.2.3_Functional_Medium_TC083");

			/*------------  Step8 ---------- */
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.3_Functional_Medium_TC083");
			/*------------  Step 9 ---------- */

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getProfileChallengeqtnonetextbox(),
					"3.2.3_Functional_Medium_TC083");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getProfileChallengeqtntwotextbox(),
					"3.2.3_Functional_Medium_TC083");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getProfileChallengeqtnthreetextbox(),
					"3.2.3_Functional_Medium_TC083");

			/*------------  Step 10 ,11,12,13,14---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtntwotextbox(), "Select", 20,
					"3.2.3_Functional_Medium_TC083");

			CommonFunctions.selectByIndex(driver, 5,
					obj.getProfileChallengeqtntwotextbox(),
					"3.2.3_Functional_Medium_TC083");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnonetextbox(), "Select", 19,
					"3.2.3_Functional_Medium_TC083");
			CommonFunctions.selectByIndex(driver, 18,
					obj.getProfileChallengeqtnonetextbox(),
					"3.2.3_Functional_Medium_TC083");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnthreetextbox(), "Select", 18,
					"3.2.3_Functional_Medium_TC083");
			CommonFunctions.selectByIndex(driver, 10,
					obj.getProfileChallengeqtnthreetextbox(),
					"3.2.3_Functional_Medium_TC083");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step 15---------- */

			driver.findElement(By.xpath(obj.getProfileChallengeqtncontinuebtn()));

			/*------------Step16-----------*/

			// DB Validation Required

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC083",
					"3.2.3_Functional_Medium_TC083");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC084Functional_Set up challenge questions screen_ Continue button
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_323_TC084(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC084")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.3_Functional_Medium")) {

			startReporting("3.2.3_Functional_Medium_TC084Functional_Set up challenge questions screen_ Continue button");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			/*------------  Step5 ---------- */

			CommonFunctions.verifyElement(driver, "Home",
					obj.getHomePageLogo(), "3.2.3_Functional_Medium_TC084");
			/*------------  Step6 ---------- */

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getCommunicationLink_BannerText(),
					"3.2.3_Functional_Medium_TC084");

			CommonFunctions
					.verifyText(driver, "Set up now",
							obj.getCommunicationLink(),
							"3.2.3_Functional_Medium_TC084");

			/*--------------Step 7---*/

			driver.findElement(By.xpath(obj.getCommunicationLink())).click();

			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(),
					"3.2.3_Functional_Medium_TC084");

			/*------------  Step8 ---------- */
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.3_Functional_Medium_TC084");
			/*------------  Step 9 ---------- */

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getProfileChallengeqtnonetextbox(),
					"3.2.3_Functional_Medium_TC084");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getProfileChallengeqtntwotextbox(),
					"3.2.3_Functional_Medium_TC084");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getProfileChallengeqtnthreetextbox(),
					"3.2.3_Functional_Medium_TC084");

			/*------------  Step 10 ,11,12,13,14---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtntwotextbox(), "Select", 20,
					"3.2.3_Functional_Medium_TC084");

			CommonFunctions.selectByIndex(driver, 5,
					obj.getProfileChallengeqtntwotextbox(),
					"3.2.3_Functional_Medium_TC084");

			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(ReadExcelFile.getTestData(TestCaseID,

					Functionality, "p_Answer2"));

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnthreetextbox(), "Select", 19,
					"3.2.3_Functional_Medium_TC084");
			CommonFunctions.selectByIndex(driver, 18,
					obj.getProfileChallengeqtnthreetextbox(),
					"3.2.3_Functional_Medium_TC084");

			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnonetextbox(), "Select", 18,
					"3.2.3_Functional_Medium_TC084");
			CommonFunctions.selectByIndex(driver, 10,
					obj.getProfileChallengeqtnonetextbox(),
					"3.2.3_Functional_Medium_TC084");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			/*------------  Step 15---------- */

			driver.findElement(By.xpath(obj.getProfileChallengeqtncontinuebtn()));

			/*------------Step16-----------*/

			// DB Validation Required

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC084",
					"3.2.3_Functional_Medium_TC084");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC085_Functional_Set up challenge questions screen_ Continue button
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_323_TC085(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC085")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.3_Functional_Medium")) {

			startReporting("3.2.3_Functional_Medium_TC085_Functional_Set up challenge questions screen_ Continue button");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);
			/*------------  Step5 ---------- */

			CommonFunctions.verifyElement(driver, "Home",
					obj.getHomePageLogo(), "3.2.3_Functional_Medium_TC085");

			/*------------  Step6 ---------- */

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getCommunicationLink_BannerText(),
					"3.2.3_Functional_Medium_TC085");

			CommonFunctions
					.verifyText(driver, "Set up now",
							obj.getCommunicationLink(),
							"3.2.3_Functional_Medium_TC085");

			/*--------------Step 7---*/

			driver.findElement(By.xpath(obj.getCommunicationLink())).click();

			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(),
					"3.2.3_Functional_Medium_TC085");

			/*------------  Step8 ---------- */
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.3_Functional_Medium_TC085");
			/*------------  Step 9 ---------- */

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getProfileChallengeqtnonetextbox(),
					"3.2.3_Functional_Medium_TC085");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getProfileChallengeqtntwotextbox(),
					"3.2.3_Functional_Medium_TC085");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getProfileChallengeqtnthreetextbox(),
					"3.2.3_Functional_Medium_TC085");

			/*------------  Step 10 ,11,12,13,14---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnthreetextbox(), "Select", 20,
					"3.2.3_Functional_Medium_TC085");

			CommonFunctions.selectByIndex(driver, 5,
					obj.getProfileChallengeqtnthreetextbox(),
					"3.2.3_Functional_Medium_TC085");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnonetextbox(), "Select", 19,
					"3.2.3_Functional_Medium_TC085");
			CommonFunctions.selectByIndex(driver, 18,
					obj.getProfileChallengeqtnonetextbox(),
					"3.2.3_Functional_Medium_TC085");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtntwotextbox(), "Select", 18,
					"3.2.3_Functional_Medium_TC085");
			CommonFunctions.selectByIndex(driver, 10,
					obj.getProfileChallengeqtntwotextbox(),
					"3.2.3_Functional_Medium_TC085");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(ReadExcelFile.getTestData(TestCaseID,

					Functionality, "p_Answer2"));

			/*------------  Step 15---------- */

			driver.findElement(By.xpath(obj.getProfileChallengeqtncontinuebtn()));

			/*------------Step16-----------*/

			// DB Validation Required

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC085",
					"3.2.3_Functional_Medium_TC085");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC086_Functional_Set up challenge questions screen_ Continue button
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_323_TC086(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC086")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.3_Functional_Medium")) {

			startReporting("3.2.3_Functional_Medium_TC086_Functional_Set up challenge questions screen_ Continue button");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			/*------------  Step5 ---------- */

			CommonFunctions.verifyElement(driver, "Home",
					obj.getHomePageLogo(), "3.2.3_Functional_Medium_TC086");

			/*------------  Step6 ---------- */

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getCommunicationLink_BannerText(),
					"3.2.3_Functional_Medium_TC086");

			CommonFunctions
					.verifyText(driver, "Set up now",
							obj.getCommunicationLink(),
							"3.2.3_Functional_Medium_TC086");

			/*--------------Step 7---*/

			driver.findElement(By.xpath(obj.getCommunicationLink())).click();

			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(),
					"3.2.3_Functional_Medium_TC086");

			/*------------  Step8 ---------- */
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.3_Functional_Medium_TC086");
			/*------------  Step 9 ---------- */

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getProfileChallengeqtnonetextbox(),
					"3.2.3_Functional_Medium_TC086");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getProfileChallengeqtntwotextbox(),
					"3.2.3_Functional_Medium_TC086");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getProfileChallengeqtnthreetextbox(),
					"3.2.3_Functional_Medium_TC086");

			/*------------  Step 10 ,11,12,13,14---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnthreetextbox(), "Select", 20,
					"3.2.3_Functional_Medium_TC086");

			CommonFunctions.selectByIndex(driver, 5,
					obj.getProfileChallengeqtnthreetextbox(),
					"3.2.3_Functional_Medium_TC086");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtntwotextbox(), "Select", 19,
					"3.2.3_Functional_Medium_TC086");
			CommonFunctions.selectByIndex(driver, 18,
					obj.getProfileChallengeqtntwotextbox(),
					"3.2.3_Functional_Medium_TC086");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(ReadExcelFile.getTestData(TestCaseID,

					Functionality, "p_Answer2"));

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnonetextbox(), "Select", 18,
					"3.2.3_Functional_Medium_TC086");
			CommonFunctions.selectByIndex(driver, 10,
					obj.getProfileChallengeqtnonetextbox(),
					"3.2.3_Functional_Medium_TC086");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			/*------------  Step 15---------- */

			driver.findElement(By.xpath(obj.getProfileChallengeqtncontinuebtn()));

			/*------------Step16-----------*/

			// DB Validation Required
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC086",
					"3.2.3_Functional_Medium_TC086");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC087_Set up challenge questions screen_Error message
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_323_TC087(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC020")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.3_Functional_Medium")) {

			startReporting("3.2.3_Functional_Medium_TC087_Set up challenge questions screen_Error message");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			/*------------  Step5 ---------- */

			CommonFunctions.verifyElement(driver, "Home",
					obj.getHomePageLogo(), "3.2.3_Functional_Medium_TC087");

			/*------------  Step6 ---------- */

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getCommunicationLink_BannerText(),
					"3.2.3_Functional_Medium_TC087");

			CommonFunctions
					.verifyText(driver, "Set up now",
							obj.getCommunicationLink(),
							"3.2.3_Functional_Medium_TC087");

			/*--------------Step 7-------*/

			driver.findElement(By.xpath(obj.getCommunicationLink())).click();

			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(),
					"3.2.3_Functional_Medium_TC087");

			/*------------  Step8 ---------- */

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.3_Functional_Medium_TC087");
			/*------------  Step 9 ---------- */

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getProfileChallengeqtnonetextbox(),
					"3.2.3_Functional_Medium_TC087");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getProfileChallengeqtntwotextbox(),
					"3.2.3_Functional_Medium_TC087");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getProfileChallengeqtnthreetextbox(),
					"3.2.3_Functional_Medium_TC087");

			/*------------  Step 10 ---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.2.3_Functional_Medium_TC087");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.2.3_Functional_Medium_TC087");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.2.3_Functional_Medium_TC087");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(By.xpath(obj.getProfileChallengeqtncontinuebtn()));
			/*------------  Step 11---------- */

			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.2.3_Functional_Medium_TC087");

			/*------------  Step 12---------- */

			// Verification From DB is Left

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC087",
					"3.2.3_Functional_Medium_TC087");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC028_existing GW client_reset login password_special character
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_34_TC028(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		String testCaseName = "3.4_Functional_Low_TC028";

		if (TestCaseID.equalsIgnoreCase("TC028")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.4_Functional_Low")) {

			/*-----------Step1----------*/

			startReporting("3.4_Functional_Low_TC028_existing GW client_reset login password_special character");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/* _--------------Step2---- */

			CommonFunctions.ClickButton(driver,obj.getForgotPwdLink());

			/* _--------------Step3---- */

			CommonFunctions.verifyElement(driver, "BMO icon",
					obj.getForgotPwdBMoLogo(), testCaseName);
			CommonFunctions.verifyElement(driver, "Client Sign In Button",
					obj.getForgotPwdClientSignIn(), testCaseName);
			CommonFunctions.verifyElement(driver, "FAQ Link",
					obj.getForgotPwdFAQLink(), testCaseName);

			/* _--------------Step4---- */

			CommonFunctions.verifyElement(driver, "Footer Text",
					obj.getForgotPwdFooter(), testCaseName);

			/*
			 * CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
			 * TestCaseID, Functionality, "p_ErrorMsg"), obj
			 * .getForgotPwdFooter(), "3.4_Functional_Low_TC028");
			 */

			/* _--------------Step5---- */

			CommonFunctions.verifyElement(driver, "Header Text",
					obj.getForgotPwdScreenTitle(), testCaseName);

			CommonFunctions.verifyElement(driver, "Header Sub Text",
					obj.getForgotPwdSubTitle(), testCaseName);

			/* _--------------Step6 ---- */

			driver.findElement(By.xpath(obj.getForgotPwdUserId())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/* _--------------Step7 ---- */
			/*
			 * CommonFunctions.verifyElement(driver, "Question 1",
			 * obj.getForgotPwdSecurityQuestion1(), testCaseName);
			 * CommonFunctions.verifyElement(driver, "Question 2",
			 * obj.getForgotPwdSecurityQuestion2(), testCaseName);
			 */
			/* _--------------Step8 ---- */
			/*
			 * CommonFunctions.DBVerifyForgotPwdSecurityQuestion(driver,
			 * ReadExcelFile.getTestData(TestCaseID, Functionality,
			 * "p_Username_Eng"), testCaseName);
			 */
			/* _--------------Step9 ---- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion1(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion1(),
					obj.getForgotPwdAnswer1(), testCaseName);

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion2(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion2(),
					obj.getForgotPwdAnswer2(), testCaseName);

			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/*--------------Step10------- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdNewSubTitle(), 50, testCaseName);

			CommonFunctions.verifyElement(driver, "Forgot your password?",
					obj.getForgotPwdNewSubTitle(), testCaseName);

			/*--------------Step11------- */

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", testCaseName);

			/*--------------Step13------- */

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					testCaseName);

			/*--------------Step14------- */
			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_ErrorMsg"), obj
					.getPasswordValidationText(), testCaseName);

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC028",
					testCaseName);
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC029_existing GW client_reset login password_special character
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_34_TC029(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		String testCaseName = "3.4_Functional_Low_TC029";

		if (TestCaseID.equalsIgnoreCase("TC029")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.4_Functional_Low")) {

			/*-----------Step1----------*/

			startReporting("3.4_Functional_Low_TC029_existing GW client_reset login password_special character");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/* _--------------Step2---- */

			CommonFunctions.ClickButton(driver,obj.getForgotPwdLink());

			/* _--------------Step3---- */

			CommonFunctions.verifyElement(driver, "BMO icon",
					obj.getForgotPwdBMoLogo(), testCaseName);
			CommonFunctions.verifyElement(driver, "Client Sign In Button",
					obj.getForgotPwdClientSignIn(), testCaseName);
			CommonFunctions.verifyElement(driver, "FAQ Link",
					obj.getForgotPwdFAQLink(), testCaseName);

			/* _--------------Step4---- */

			CommonFunctions.verifyElement(driver, "Footer Text",
					obj.getForgotPwdFooter(), testCaseName);

			/*
			 * CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
			 * TestCaseID, Functionality, "p_ErrorMsg"), obj
			 * .getForgotPwdFooter(), "3.4_Functional_Low_TC028");
			 */

			/* _--------------Step5---- */

			CommonFunctions.verifyElement(driver, "Header Text",
					obj.getForgotPwdScreenTitle(), testCaseName);

			CommonFunctions.verifyElement(driver, "Header Sub Text",
					obj.getForgotPwdSubTitle(), testCaseName);

			/* _--------------Step6 ---- */

			driver.findElement(By.xpath(obj.getForgotPwdUserId())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/* _--------------Step7 ---- */

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getForgotPwdSecurityQuestion1(), testCaseName);
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getForgotPwdSecurityQuestion2(), testCaseName);

			/* _--------------Step8 ---- */
			/*
			 * CommonFunctions.DBVerifyForgotPwdSecurityQuestion(driver,
			 * ReadExcelFile.getTestData(TestCaseID, Functionality,
			 * "p_Username_Eng"), testCaseName);
			 */
			/* _--------------Step9 ---- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion1(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion1(),
					obj.getForgotPwdAnswer1(), testCaseName);

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion2(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion2(),
					obj.getForgotPwdAnswer2(), testCaseName);

			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/*--------------Step10------- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdNewSubTitle(), 50, testCaseName);

			CommonFunctions.verifyElement(driver, "Forgot your password?",
					obj.getForgotPwdNewSubTitle(), testCaseName);

			/*--------------Step11------- */

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", testCaseName);

			/*--------------Step13------- */

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					testCaseName);

			/*--------------Step14------- */
			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_ErrorMsg"), obj
					.getPasswordValidationText(), testCaseName);
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC029",
					testCaseName);
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC030_existing GW client_reset login password_special character
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_34_TC030(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		String testCaseName = "3.4_Functional_Low_TC030";

		if (TestCaseID.equalsIgnoreCase("TC030")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.4_Functional_Low")) {

			/*-----------Step1----------*/

			startReporting("3.4_Functional_Low_TC030_existing GW client_reset login password_special character");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/* _--------------Step2---- */

			CommonFunctions.ClickButton(driver,obj.getForgotPwdLink());

			/* _--------------Step3---- */

			CommonFunctions.verifyElement(driver, "BMO icon",
					obj.getForgotPwdBMoLogo(), testCaseName);
			CommonFunctions.verifyElement(driver, "Client Sign In Button",
					obj.getForgotPwdClientSignIn(), testCaseName);
			CommonFunctions.verifyElement(driver, "FAQ Link",
					obj.getForgotPwdFAQLink(), testCaseName);

			/* _--------------Step4---- */

			CommonFunctions.verifyElement(driver, "Footer Text",
					obj.getForgotPwdFooter(), testCaseName);

			/*
			 * CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
			 * TestCaseID, Functionality, "p_ErrorMsg"), obj
			 * .getForgotPwdFooter(), "3.4_Functional_Low_TC028");
			 */

			/* _--------------Step5---- */

			CommonFunctions.verifyElement(driver, "Header Text",
					obj.getForgotPwdScreenTitle(), testCaseName);

			CommonFunctions.verifyElement(driver, "Header Sub Text",
					obj.getForgotPwdSubTitle(), testCaseName);

			/* _--------------Step6 ---- */

			driver.findElement(By.xpath(obj.getForgotPwdUserId())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/* _--------------Step7 ---- */

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getForgotPwdSecurityQuestion1(), testCaseName);
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getForgotPwdSecurityQuestion2(), testCaseName);

			/* _--------------Step8 ---- */
			/*
			 * CommonFunctions.DBVerifyForgotPwdSecurityQuestion(driver,
			 * ReadExcelFile.getTestData(TestCaseID, Functionality,
			 * "p_Username_Eng"), testCaseName);
			 */
			/* _--------------Step9 ---- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion1(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion1(),
					obj.getForgotPwdAnswer1(), testCaseName);

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion2(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion2(),
					obj.getForgotPwdAnswer2(), testCaseName);

			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/*--------------Step10------- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdNewSubTitle(), 50, testCaseName);

			CommonFunctions.verifyElement(driver, "Forgot your password?",
					obj.getForgotPwdNewSubTitle(), testCaseName);

			/*--------------Step11------- */

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", testCaseName);

			/*--------------Step13------- */

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					testCaseName);

			/*--------------Step14------- */
			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_ErrorMsg"), obj
					.getPasswordValidationText(), testCaseName);

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC030",
					testCaseName);
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC028_existing GW client_reset login password_special character
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_34_TC031(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		String testCaseName = "3.4_Functional_Low_TC031";
		if (TestCaseID.equalsIgnoreCase("TC031")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.4_Functional_Low")) {

			/*-----------Step1----------*/

			startReporting("3.4_Functional_Low_TC031_existing GW client_reset login password_special character");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/* _--------------Step2---- */

			CommonFunctions.ClickButton(driver,obj.getForgotPwdLink());

			/* _--------------Step3---- */

			CommonFunctions.verifyElement(driver, "BMO icon",
					obj.getForgotPwdBMoLogo(), testCaseName);
			CommonFunctions.verifyElement(driver, "Client Sign In Button",
					obj.getForgotPwdClientSignIn(), testCaseName);
			CommonFunctions.verifyElement(driver, "FAQ Link",
					obj.getForgotPwdFAQLink(), testCaseName);

			/* _--------------Step4---- */

			CommonFunctions.verifyElement(driver, "Footer Text",
					obj.getForgotPwdFooter(), testCaseName);

			/*
			 * CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
			 * TestCaseID, Functionality, "p_ErrorMsg"), obj
			 * .getForgotPwdFooter(), "3.4_Functional_Low_TC028");
			 */

			/* _--------------Step5---- */

			CommonFunctions.verifyElement(driver, "Header Text",
					obj.getForgotPwdScreenTitle(), testCaseName);

			CommonFunctions.verifyElement(driver, "Header Sub Text",
					obj.getForgotPwdSubTitle(), testCaseName);

			/* _--------------Step6 ---- */

			driver.findElement(By.xpath(obj.getForgotPwdUserId())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/* _--------------Step7 ---- */

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getForgotPwdSecurityQuestion1(), testCaseName);
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getForgotPwdSecurityQuestion2(), testCaseName);

			/* _--------------Step8 ---- */
			/*
			 * CommonFunctions.DBVerifyForgotPwdSecurityQuestion(driver,
			 * ReadExcelFile.getTestData(TestCaseID, Functionality,
			 * "p_Username_Eng"), testCaseName);
			 */
			/* _--------------Step9 ---- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion1(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion1(),
					obj.getForgotPwdAnswer1(), testCaseName);

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion2(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion2(),
					obj.getForgotPwdAnswer2(), testCaseName);

			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/*--------------Step10------- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdNewSubTitle(), 50, testCaseName);

			CommonFunctions.verifyElement(driver, "Forgot your password?",
					obj.getForgotPwdNewSubTitle(), testCaseName);

			/*--------------Step11------- */

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", testCaseName);

			/*--------------Step13------- */

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					testCaseName);

			/*--------------Step14------- */
			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_ErrorMsg"), obj
					.getPasswordValidationText(), testCaseName);

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC031",
					testCaseName);
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC032_existing GW client_reset login password_special character
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_34_TC032(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		String testCaseName = "3.4_Functional_Low_TC032";
		if (TestCaseID.equalsIgnoreCase("TC032")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.4_Functional_Low")) {

			/*-----------Step1----------*/

			startReporting("3.4_Functional_Low_TC032_existing GW client_reset login password_special character");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/* _--------------Step2---- */

			CommonFunctions.ClickButton(driver,obj.getForgotPwdLink());

			/* _--------------Step3---- */

			CommonFunctions.verifyElement(driver, "BMO icon",
					obj.getForgotPwdBMoLogo(), testCaseName);
			CommonFunctions.verifyElement(driver, "Client Sign In Button",
					obj.getForgotPwdClientSignIn(), testCaseName);
			CommonFunctions.verifyElement(driver, "FAQ Link",
					obj.getForgotPwdFAQLink(), testCaseName);

			/* _--------------Step4---- */

			CommonFunctions.verifyElement(driver, "Footer Text",
					obj.getForgotPwdFooter(), testCaseName);

			/*
			 * CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
			 * TestCaseID, Functionality, "p_ErrorMsg"), obj
			 * .getForgotPwdFooter(), "3.4_Functional_Low_TC028");
			 */

			/* _--------------Step5---- */

			CommonFunctions.verifyElement(driver, "Header Text",
					obj.getForgotPwdScreenTitle(), testCaseName);

			CommonFunctions.verifyElement(driver, "Header Sub Text",
					obj.getForgotPwdSubTitle(), testCaseName);

			/* _--------------Step6 ---- */

			driver.findElement(By.xpath(obj.getForgotPwdUserId())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/* _--------------Step7 ---- */

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getForgotPwdSecurityQuestion1(), testCaseName);
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getForgotPwdSecurityQuestion2(), testCaseName);

			/* _--------------Step8 ---- */
			/*
			 * CommonFunctions.DBVerifyForgotPwdSecurityQuestion(driver,
			 * ReadExcelFile.getTestData(TestCaseID, Functionality,
			 * "p_Username_Eng"), testCaseName);
			 */
			/* _--------------Step9 ---- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion1(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion1(),
					obj.getForgotPwdAnswer1(), testCaseName);

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion2(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion2(),
					obj.getForgotPwdAnswer2(), testCaseName);

			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/*--------------Step10------- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdNewSubTitle(), 50, testCaseName);

			CommonFunctions.verifyElement(driver, "Forgot your password?",
					obj.getForgotPwdNewSubTitle(), testCaseName);

			/*--------------Step11------- */

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", testCaseName);

			/*--------------Step13------- */

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					testCaseName);

			/*--------------Step14------- */
			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_ErrorMsg"), obj
					.getPasswordValidationText(), testCaseName);
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC032",
					testCaseName);
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC033_existing GW client_reset login password_special character in
	 * between
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_34_TC033(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		String testCaseName = "3.4_Functional_Low_TC033";
		if (TestCaseID.equalsIgnoreCase("TC033")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.4_Functional_Low")) {

			/*-----------Step1----------*/

			startReporting("3.4_Functional_Low_TC033_existing GW client_reset login password_special character in between");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/* _--------------Step2---- */

			CommonFunctions.ClickButton(driver,obj.getForgotPwdLink());

			/* _--------------Step3---- */

			CommonFunctions.verifyElement(driver, "BMO icon",
					obj.getForgotPwdBMoLogo(), testCaseName);
			CommonFunctions.verifyElement(driver, "Client Sign In Button",
					obj.getForgotPwdClientSignIn(), testCaseName);
			CommonFunctions.verifyElement(driver, "FAQ Link",
					obj.getForgotPwdFAQLink(), testCaseName);

			/* _--------------Step4---- */

			CommonFunctions.verifyElement(driver, "Footer Text",
					obj.getForgotPwdFooter(), testCaseName);

			/*
			 * CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
			 * TestCaseID, Functionality, "p_ErrorMsg"), obj
			 * .getForgotPwdFooter(), "3.4_Functional_Low_TC028");
			 */

			/* _--------------Step5---- */

			CommonFunctions.verifyElement(driver, "Header Text",
					obj.getForgotPwdScreenTitle(), testCaseName);

			CommonFunctions.verifyElement(driver, "Header Sub Text",
					obj.getForgotPwdSubTitle(), testCaseName);

			/* _--------------Step6 ---- */

			driver.findElement(By.xpath(obj.getForgotPwdUserId())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/* _--------------Step7 ---- */

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getForgotPwdSecurityQuestion1(), testCaseName);
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getForgotPwdSecurityQuestion2(), testCaseName);

			/* _--------------Step8 ---- */
			/*
			 * CommonFunctions.DBVerifyForgotPwdSecurityQuestion(driver,
			 * ReadExcelFile.getTestData(TestCaseID, Functionality,
			 * "p_Username_Eng"), testCaseName);
			 */
			/* _--------------Step9 ---- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion1(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion1(),
					obj.getForgotPwdAnswer1(), testCaseName);

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion2(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion2(),
					obj.getForgotPwdAnswer2(), testCaseName);

			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/*--------------Step10------- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdNewSubTitle(), 50, testCaseName);

			CommonFunctions.verifyElement(driver, "Forgot your password?",
					obj.getForgotPwdNewSubTitle(), testCaseName);

			/*--------------Step11------- */

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", testCaseName);

			/*--------------Step13------- */

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					testCaseName);

			/*--------------Step14------- */
			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_ErrorMsg"), obj
					.getPasswordValidationText(), testCaseName);
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC033",
					testCaseName);
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit TC034_existing GW client_reset login
	 * password_special character at beginning
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_34_TC034(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		String testCaseName = "3.4_Functional_Low_TC034";
		if (TestCaseID.equalsIgnoreCase("TC034")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.4_Functional_Low")) {

			/*-----------Step1----------*/

			startReporting("3.4_Functional_Low_TC034_existing GW client_reset login password_special character at beginning");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/* _--------------Step2---- */

			CommonFunctions.ClickButton(driver,obj.getForgotPwdLink());

			/* _--------------Step3---- */

			CommonFunctions.verifyElement(driver, "BMO icon",
					obj.getForgotPwdBMoLogo(), testCaseName);
			CommonFunctions.verifyElement(driver, "Client Sign In Button",
					obj.getForgotPwdClientSignIn(), testCaseName);
			CommonFunctions.verifyElement(driver, "FAQ Link",
					obj.getForgotPwdFAQLink(), testCaseName);

			/* _--------------Step4---- */

			CommonFunctions.verifyElement(driver, "Footer Text",
					obj.getForgotPwdFooter(), testCaseName);

			/*
			 * CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
			 * TestCaseID, Functionality, "p_ErrorMsg"), obj
			 * .getForgotPwdFooter(), "3.4_Functional_Low_TC028");
			 */

			/* _--------------Step5---- */

			CommonFunctions.verifyElement(driver, "Header Text",
					obj.getForgotPwdScreenTitle(), testCaseName);

			CommonFunctions.verifyElement(driver, "Header Sub Text",
					obj.getForgotPwdSubTitle(), testCaseName);

			/* _--------------Step6 ---- */

			driver.findElement(By.xpath(obj.getForgotPwdUserId())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/* _--------------Step7 ---- */

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getForgotPwdSecurityQuestion1(), testCaseName);
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getForgotPwdSecurityQuestion2(), testCaseName);

			/* _--------------Step8 ---- */
			/*
			 * CommonFunctions.DBVerifyForgotPwdSecurityQuestion(driver,
			 * ReadExcelFile.getTestData(TestCaseID, Functionality,
			 * "p_Username_Eng"), testCaseName);
			 */
			/* _--------------Step9 ---- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion1(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion1(),
					obj.getForgotPwdAnswer1(), testCaseName);

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion2(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion2(),
					obj.getForgotPwdAnswer2(), testCaseName);

			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/*--------------Step10------- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdNewSubTitle(), 50, testCaseName);

			CommonFunctions.verifyElement(driver, "Forgot your password?",
					obj.getForgotPwdNewSubTitle(), testCaseName);

			/*--------------Step11------- */

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", testCaseName);

			/*--------------Step13------- */

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					testCaseName);

			/*--------------Step14------- */
			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_ErrorMsg"), obj
					.getPasswordValidationText(), testCaseName);

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC034",
					testCaseName);
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC035_existing GW client_reset login password_special character at end
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_34_TC035(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		String testCaseName = "3.4_Functional_Low_TC035";
		if (TestCaseID.equalsIgnoreCase("TC035")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.4_Functional_Low")) {

			/*-----------Step1----------*/

			startReporting("3.4_Functional_Low_TC035_existing GW client_reset login password_special character at end");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/* _--------------Step2---- */

			CommonFunctions.ClickButton(driver,obj.getForgotPwdLink());

			/* _--------------Step3---- */

			CommonFunctions.verifyElement(driver, "BMO icon",
					obj.getForgotPwdBMoLogo(), testCaseName);
			CommonFunctions.verifyElement(driver, "Client Sign In Button",
					obj.getForgotPwdClientSignIn(), testCaseName);
			CommonFunctions.verifyElement(driver, "FAQ Link",
					obj.getForgotPwdFAQLink(), testCaseName);

			/* _--------------Step4---- */

			CommonFunctions.verifyElement(driver, "Footer Text",
					obj.getForgotPwdFooter(), testCaseName);

			/*
			 * CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
			 * TestCaseID, Functionality, "p_ErrorMsg"), obj
			 * .getForgotPwdFooter(), "3.4_Functional_Low_TC028");
			 */

			/* _--------------Step5---- */

			CommonFunctions.verifyElement(driver, "Header Text",
					obj.getForgotPwdScreenTitle(), testCaseName);

			CommonFunctions.verifyElement(driver, "Header Sub Text",
					obj.getForgotPwdSubTitle(), testCaseName);

			/* _--------------Step6 ---- */

			driver.findElement(By.xpath(obj.getForgotPwdUserId())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/* _--------------Step7 ---- */

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getForgotPwdSecurityQuestion1(), testCaseName);
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getForgotPwdSecurityQuestion2(), testCaseName);

			/* _--------------Step8 ---- */
			/*
			 * CommonFunctions.DBVerifyForgotPwdSecurityQuestion(driver,
			 * ReadExcelFile.getTestData(TestCaseID, Functionality,
			 * "p_Username_Eng"), testCaseName);
			 */
			/* _--------------Step9 ---- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion1(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion1(),
					obj.getForgotPwdAnswer1(), testCaseName);

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion2(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion2(),
					obj.getForgotPwdAnswer2(), testCaseName);

			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/*--------------Step10------- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdNewSubTitle(), 50, testCaseName);

			CommonFunctions.verifyElement(driver, "Forgot your password?",
					obj.getForgotPwdNewSubTitle(), testCaseName);

			/*--------------Step11------- */

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", testCaseName);

			/*--------------Step13------- */

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					testCaseName);

			/*--------------Step14------- */
			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_ErrorMsg"), obj
					.getPasswordValidationText(), testCaseName);

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC035",
					testCaseName);
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC038_existing GW client_reset login password_new login password matchs
	 * old login password
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_34_TC038(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		String testCaseName = "3.4_Functional_Low_TC038";
		if (TestCaseID.equalsIgnoreCase("TC038")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.4_Functional_Low")) {

			/*-----------Step1----------*/

			startReporting("3.4_Functional_Low_TC038_existing GW client_reset login password_new login password matchs old login password");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/* _--------------Step2---- */

			CommonFunctions.ClickButton(driver,obj.getForgotPwdLink());

			/* _--------------Step3---- */

			CommonFunctions.verifyElement(driver, "BMO icon",
					obj.getForgotPwdBMoLogo(), testCaseName);
			CommonFunctions.verifyElement(driver, "Client Sign In Button",
					obj.getForgotPwdClientSignIn(), testCaseName);
			CommonFunctions.verifyElement(driver, "FAQ Link",
					obj.getForgotPwdFAQLink(), testCaseName);

			/* _--------------Step4---- */

			CommonFunctions.verifyElement(driver, "Footer Text",
					obj.getForgotPwdFooter(), testCaseName);

			/*
			 * CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
			 * TestCaseID, Functionality, "p_ErrorMsg"), obj
			 * .getForgotPwdFooter(), "3.4_Functional_Low_TC028");
			 */

			/* _--------------Step5---- */

			CommonFunctions.verifyElement(driver, "Header Text",
					obj.getForgotPwdScreenTitle(), testCaseName);

			CommonFunctions.verifyElement(driver, "Header Sub Text",
					obj.getForgotPwdSubTitle(), testCaseName);

			/* _--------------Step6 ---- */

			driver.findElement(By.xpath(obj.getForgotPwdUserId())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/* _--------------Step7 ---- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion1(), 60, testCaseName);

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getForgotPwdSecurityQuestion1(), testCaseName);

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion2(), 60, testCaseName);
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getForgotPwdSecurityQuestion2(), testCaseName);

			/* _--------------Step8 ---- */
			/*
			 * CommonFunctions.DBVerifyForgotPwdSecurityQuestion(driver,
			 * ReadExcelFile.getTestData(TestCaseID, Functionality,
			 * "p_Username_Eng"), testCaseName);
			 */
			/* _--------------Step9 ---- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion1(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion1(),
					obj.getForgotPwdAnswer1(), testCaseName);

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion2(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion2(),
					obj.getForgotPwdAnswer2(), testCaseName);

			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/*--------------Step10------- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdNewSubTitle(), 50, testCaseName);

			CommonFunctions.verifyElement(driver, "Forgot your password?",
					obj.getForgotPwdNewSubTitle(), testCaseName);

			/*--------------Step11------- */

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", testCaseName);

			/*--------------Step13------- */

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					testCaseName);

			/*--------------Step14------- */
			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_ErrorMsg"), obj
					.getSecurityErrorMessages(), testCaseName);
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC038",
					testCaseName);
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC002_Req Id_325 old login password
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_325_TC002(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution, String Status) throws Exception {
		String testCaseName = "3.2.5_Functional_Medium_TC002";
		if (TestCaseID.equalsIgnoreCase("TC002")&& Execution.equalsIgnoreCase("Y")&& Functionality.equalsIgnoreCase("3.2.5_Functional_Complex")) {

			/*-----------Step1----------*/

			startReporting("3.2.5_Functional_Complex_TC002_Req Id_325");
			System.out.println(LanguageSettings);
			
			accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
			
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, accountNumber, ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			/*-------Step 6-----------*/

			CommonFunctions.verifyText(driver, "Set up now",
					obj.getCommunicationLink(), testCaseName);

			/*-------Step 7----------*/
			driver.findElement(By.xpath(obj.getCommunicationLink())).click();

			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(), testCaseName);

			/*------------  Step8 ---------- */

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(), testCaseName);
			/*------------  Step 9 ---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(), testCaseName);
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(), testCaseName);
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(), testCaseName);
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			;

			CommonFunctions.verifyText(driver, "Email Verification",
					obj.getEmailAddressTitle(), testCaseName);

			/*------------  Step 10---------- */

			driver.findElement(By.xpath(obj.getEmailAddressNewEmail()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewEmailID"));

			driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewEmailID"));
			CommonFunctions.eMailCheckBoxClick(driver, TestCaseID, Functionality, TestCaseDescription);


			driver.findElement(By.xpath(obj.getEmailAddressSubmitButton()))
					.click();

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getChallengeQuestionTitle(), testCaseName);

		/*	// Steps from 10 to 12 should be designed

			driver = LoginPage.LaunchBrowser(Browser);
			LoginPage.LaunchURL(driver, GatewayEmailURL);
			CommonFunctions.SwitchToChildWindow(driver);
			LoginPage.EmailLogin(rowNumber, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_EmailUserName"),
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_EmailPwd"), TestCaseID);
			Thread.sleep(2000);
			LoginPage.EmailValidation(rowNumber, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Username_Eng"), testCaseName);
			statusPassWithScreenshot(driver, "Screenshot done", Functionality
					+ TestCaseID);

			// Close child window and activate parent window

	

			CommonFunctions.verifyElement(driver, "Go to login page",
					obj.getEmailConfirmationPageGoToLoginPageButton(),
					testCaseName);

		

			driver.findElement(
					By.xpath(obj.getEmailConfirmationPageGoToLoginPageButton()))
					.click();
			;

	
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"),
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"), "Home", Functionality
							+ TestCaseID);*/
			DataBase.DBEmailUpdated(driver,accountNumber, CommonFunctions.Date(driver, TestCaseID, Functionality, TestCaseDescription), TestCaseDescription);
			
			

			// Verify IN DB

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC002",
					testCaseName);
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC103_Email verification link clicked before 8 hours_success message
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_325_TC103(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription,  String Execution, String Status) throws Exception {
		String testCaseName = "3.2.5_Functional_Medium_TC103";
		if (TestCaseID.equalsIgnoreCase("TC103")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.5_Functional_Complex")) {

			/*-----------Step1----------*/

			startReporting("3.2.5_Functional_Complex_TC103_Email verification link clicked before 8 hours_success message");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			/*-------Step 6-----------*/

			CommonFunctions.verifyText(driver, "Set up now",
					obj.getCommunicationLink(), testCaseName);

			/*-------Step 7----------*/
			driver.findElement(By.xpath(obj.getCommunicationLink())).click();

			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(), testCaseName);

			/*------------  Step8 ---------- */

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(), testCaseName);
			/*------------  Step 9 &10 &11 ---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(), testCaseName);
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(), testCaseName);
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(), testCaseName);
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			;

			CommonFunctions.verifyText(driver, "Email Verification",
					obj.getEmailAddressTitle(), testCaseName);

			/*------------  Step 12--------- */

			driver.findElement(By.xpath(obj.getEmailAddressNewEmail()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewEmailID"));

			driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewEmailID"));

			driver.findElement(By.xpath(obj.getEmailAddressTermsCheckBox()))
					.click();

			driver.findElement(By.xpath(obj.getEmailAddressSubmitButton()))
					.click();

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getChallengeQuestionTitle(), testCaseName);

			// Steps from 13 to 14 should be designed
			String parentWindow = driver.getWindowHandle();

			driver = LoginPage.LaunchBrowser(Browser);
			LoginPage.LaunchURL(driver, GatewayEmailURL);
			CommonFunctions.SwitchToChildWindow(driver);
			LoginPage.EmailLogin(rowNumber, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_EmailUserName"),
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_EmailPwd"), TestCaseID);
			Thread.sleep(2000);
			LoginPage.EmailValidation(rowNumber, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Username_Eng"), testCaseName);
			statusPassWithScreenshot(driver, "Screenshot done", Functionality
					+ TestCaseID);

			CommonFunctions.verifyText(driver, "",
					obj.getEmailVerificationClickHereLink(), testCaseName);

			CommonFunctions.verifyElement(driver, "Go to login page",
					obj.getEmailConfirmationPageGoToLoginPageButton(),
					testCaseName);

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC002",
					testCaseName);
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC104_Email verification link clicked before 8 hours_Go to Login page
	 * button
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_325_TC104(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription,  String Execution, String Status) throws Exception {
		String testCaseName = "3.2.5_Functional_Medium_TC104";
		if (TestCaseID.equalsIgnoreCase("TC104")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.5_Functional_Complex")) {

			/*-----------Step1----------*/

			startReporting("3.2.5_Functional_Complex_TC104_Email verification link clicked before 8 hours_Go to Login page button");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			/*-------Step 6-----------*/

			CommonFunctions.verifyText(driver, "Set up now",
					obj.getCommunicationLink(), testCaseName);

			/*-------Step 7----------*/
			driver.findElement(By.xpath(obj.getCommunicationLink())).click();

			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(), testCaseName);

			/*------------  Step8 ---------- */

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(), testCaseName);
			/*------------  Step 9 ---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(), testCaseName);
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(), testCaseName);
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(), testCaseName);
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			;

			CommonFunctions.verifyText(driver, "Email Verification",
					obj.getEmailAddressTitle(), testCaseName);

			/*------------  Step 10---------- */

			driver.findElement(By.xpath(obj.getEmailAddressNewEmail()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewEmailID"));

			driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewEmailID"));

			driver.findElement(By.xpath(obj.getEmailAddressTermsCheckBox()))
					.click();

			driver.findElement(By.xpath(obj.getEmailAddressSubmitButton()))
					.click();

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getChallengeQuestionTitle(), testCaseName);

			// Steps from 10 to 12 should be designed

			driver = LoginPage.LaunchBrowser(Browser);
			LoginPage.LaunchURL(driver, GatewayEmailURL);
			CommonFunctions.SwitchToChildWindow(driver);
			LoginPage.EmailLogin(rowNumber, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_EmailUserName"),
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_EmailPwd"), TestCaseID);
			Thread.sleep(2000);
			LoginPage.EmailValidation(rowNumber, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Username_Eng"), testCaseName);
			statusPassWithScreenshot(driver, "Screenshot done", Functionality
					+ TestCaseID);

			// Close child window and activate parent window

			/*------------  Step 13--------- */

			CommonFunctions.verifyElement(driver, "Go to login page",
					obj.getEmailConfirmationPageGoToLoginPageButton(),
					testCaseName);

			/*------------  Step 14--------- */

			driver.findElement(
					By.xpath(obj.getEmailConfirmationPageGoToLoginPageButton()))
					.click();
			;

			/*------------  Step 15--------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"),
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"), "Home", Functionality
							+ TestCaseID);

			// Verify IN DB

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC104",
					testCaseName);
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC100_Email verification link_clicked before 8 hours button
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_325_TC100(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription,  String Execution, String Status) throws Exception {
		String testCaseName = "3.2.5_Functional_Medium_TC100";
		if (TestCaseID.equalsIgnoreCase("TC100")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.5_Functional_Complex")) {

			/*-----------Step1----------*/

			startReporting("3.2.5_Functional_Complex_TC100_Email verification link_clicked before 8 hours");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			/*-------Step 6-----------*/

			CommonFunctions.verifyText(driver, "Set up now",
					obj.getCommunicationLink(), testCaseName);

			/*-------Step 7----------*/
			driver.findElement(By.xpath(obj.getCommunicationLink())).click();

			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(), testCaseName);

			/*------------  Step8 ---------- */

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(), testCaseName);
			/*------------  Step 9 ---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(), testCaseName);
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(), testCaseName);
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(), testCaseName);
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			;

			CommonFunctions.verifyText(driver, "Email Verification",
					obj.getEmailAddressTitle(), testCaseName);

			/*------------  Step 10---------- */

			driver.findElement(By.xpath(obj.getEmailAddressNewEmail()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewEmailID"));

			driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewEmailID"));

			driver.findElement(By.xpath(obj.getEmailAddressTermsCheckBox()))
					.click();

			driver.findElement(By.xpath(obj.getEmailAddressSubmitButton()))
					.click();

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getChallengeQuestionTitle(), testCaseName);

			// Steps from 10 to 12 should be designed

			driver = LoginPage.LaunchBrowser(Browser);
			LoginPage.LaunchURL(driver, GatewayEmailURL);
			CommonFunctions.SwitchToChildWindow(driver);
			LoginPage.EmailLogin(rowNumber, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_EmailUserName"),
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_EmailPwd"), TestCaseID);
			Thread.sleep(2000);
			LoginPage.EmailValidation(rowNumber, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Username_Eng"), testCaseName);
			statusPassWithScreenshot(driver, "Screenshot done", Functionality
					+ TestCaseID);

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC100",
					testCaseName);
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC066_Set up challenge questions screen_setting up of challenge question
	 * in any order
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_325_TC066(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription,  String Execution, String Status) throws Exception {
		String testCaseName = "3.2.5_Functional_Medium_TC101";
		if (TestCaseID.equalsIgnoreCase("TC066")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.5_Functional_Complex")) {

			/*-----------Step1----------*/

			startReporting("3.2.5_Functional_Complex_TC066_Set up challenge questions screen_setting up of challenge question in any order");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			/*-------Step 6-----------*/

			CommonFunctions.verifyText(driver, "Set up now",
					obj.getCommunicationLink(), testCaseName);

			/*-------Step 7----------*/
			driver.findElement(By.xpath(obj.getCommunicationLink())).click();

			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(), testCaseName);

			/*------------  Step8 ---------- */

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(), testCaseName);
			/*------------  Step 9 ---------- */

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getProfileChallengeqtnonetextbox(), "testCaseName");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getProfileChallengeqtntwotextbox(), "testCaseName");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getProfileChallengeqtnthreetextbox(), "testCaseName");
			/*-----------------Step10----------*/

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnonetextbox(), "Select", 20,
					"testCaseNameTC074");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(), "testCaseName");

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtntwotextbox(), "Select", 19,
					"testCaseName");

			/*----------Step for TC076------------*/

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtnonetextbox(), "testCaseName");
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC076",
					"testCaseName");

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnthreetextbox(), "Select", 18,
					"testCaseName");

			/*----------Step for TC077------------*/

			CommonFunctions.verifyElement(driver, "",
					obj.getProfileChallengeansonetextbox(), "testCaseName");
			CommonFunctions.verifyElement(driver, "",
					obj.getProfileChallengeanstwotextbox(), "testCaseName");
			CommonFunctions.verifyElement(driver, "",
					obj.getProfileChallengeansthreetextbox(), "testCaseName");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC077",
					"3.2.3_Functional_Medium_TC077");

			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC078",
					"3.2.3_Functional_Medium_TC078");

			endReporting();
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC100",
					testCaseName);
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC099_Email verification link_clicked after 8 hours button
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_325_TC099(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution, String Status) throws Exception {
		String testCaseName = "3.2.5_Functional_Medium_TC099";
		if (TestCaseID.equalsIgnoreCase("TC099")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.5_Functional_Complex")) {

			/*-----------Step1----------*/

			startReporting("3.2.5_Functional_Complex_TC099_EmailAddress screen_Store new valid email id");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			/*-------Step 6-----------*/

			CommonFunctions.verifyText(driver, "Set up now",
					obj.getCommunicationLink(), testCaseName);

			/*-------Step 7----------*/
			driver.findElement(By.xpath(obj.getCommunicationLink())).click();

			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(), testCaseName);

			/*------------  Step8 ---------- */

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(), testCaseName);
			/*------------  Step 9 ---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(), testCaseName);
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(), testCaseName);
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(), testCaseName);
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			;

			CommonFunctions.verifyText(driver, "Email Verification",
					obj.getEmailAddressTitle(), testCaseName);

			/*------------  Step 10---------- */

			driver.findElement(By.xpath(obj.getEmailAddressNewEmail()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewEmailID"));

			driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewEmailID"));

			driver.findElement(By.xpath(obj.getEmailAddressTermsCheckBox()))
					.click();

			driver.findElement(By.xpath(obj.getEmailAddressSubmitButton()))
					.click();

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getChallengeQuestionTitle(), testCaseName);

			// DataBase Verification is pending

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC100",
					testCaseName);
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC009_Req Id_325_Re-login into GW after closing Email address screen
	 * using new temporary password_update setting up fo 3 challenge
	 * question_Account reactivates
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_325_TC009(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution, String Status) throws Exception {
		String testCaseName = "3.2.5_Functional_Medium_TC009";
		if (TestCaseID.equalsIgnoreCase("TC009")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.5_Functional_Complex")) {

			/*-----------Step1----------*/

			startReporting("3.2.5_Functional_Complex_TC009_Req Id_325_Re-login into GW after closing Email address screen using new temporary password_update setting up fo 3 challenge question_Account reactivates");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			/*-------Step 6-----------*/

			CommonFunctions.verifyText(driver, "Set up now",
					obj.getCommunicationLink(), testCaseName);

			/*-------Step 7----------*/
			driver.findElement(By.xpath(obj.getCommunicationLink())).click();

			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(), testCaseName);

			/*------------  Step8 ---------- */

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(), testCaseName);
			/*------------  Step 9 ---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(), testCaseName);
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(), testCaseName);
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(), testCaseName);
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			;

			CommonFunctions.verifyText(driver, "Email Verification",
					obj.getEmailAddressTitle(), testCaseName);

			// Close the browser without updating Email

			/*------------  Step 10 ---------- */

			driver.close();

			/*------------  Step 11---------- */
			LoginPage.LaunchURL(driver, GatewayQAURL);

			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"),
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"), "Home", Functionality
							+ TestCaseID);

			CommonFunctions.verifyText(driver, "error Text",
					obj.getEmailAddressTitle(), testCaseName);

			// Launching the admin url
			LoginPage.LaunchURL(driver, GatewayAdminURL);

			String tempPassword = Admin.getTemporaryPassword(driver,
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));

			/*------------  Step 12---------- */

			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng")); // Logging in using temporary
												// password
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), tempPassword, "Home",
					Functionality + TestCaseID);

			/*------------  Step 13---------- */

			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(),
					"3.2.2_Functional_Low_TC081");
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"));

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			/*------------  Step 14 ---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(), testCaseName);
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(), testCaseName);
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(), testCaseName);
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			;

			CommonFunctions.verifyText(driver, "Email Verification",
					obj.getEmailAddressTitle(), testCaseName);

			/*------------  Step 15---------- */
			driver.findElement(By.xpath(obj.getEmailAddressNewEmail()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewEmailID"));

			driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewEmailID"));

			driver.findElement(By.xpath(obj.getEmailAddressTermsCheckBox()))
					.click();

			driver.findElement(By.xpath(obj.getEmailAddressSubmitButton()))
					.click();

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getChallengeQuestionTitle(), testCaseName);

			/*------------  Step 16,17---------- */

			driver = LoginPage.LaunchBrowser(Browser);
			LoginPage.LaunchURL(driver, GatewayEmailURL);

			LoginPage.EmailLogin(rowNumber, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_EmailUserName"),
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_EmailPwd"), TestCaseID);
			Thread.sleep(2000);
			LoginPage.EmailValidation(rowNumber, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Username_Eng"), testCaseName);
			statusPassWithScreenshot(driver, "Screenshot done", Functionality
					+ TestCaseID);

			/*------------  Step 13--------- */

			CommonFunctions.verifyElement(driver, "Go to login page",
					obj.getEmailConfirmationPageGoToLoginPageButton(),
					testCaseName);

			/*------------  Step 14--------- */

			driver.findElement(
					By.xpath(obj.getEmailConfirmationPageGoToLoginPageButton()))
					.click();
			;

			/*------------  Step 15--------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			CommonFunctions.verifyElement(driver, "Home",
					obj.getHomePageLogo(), testCaseName);

			// Verify IN DB

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC100",
					testCaseName);
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC008_Req Id_325_Account not activated_closed the browser without
	 * updating Email address screen
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_325_TC008(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription,  String Execution, String Status) throws Exception {
		String testCaseName = "3.2.5_Functional_Medium_TC008";
		if (TestCaseID.equalsIgnoreCase("TC008")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.5_Functional_Complex")) {

			/*-----------Step1----------*/

			startReporting("3.2.5_Functional_Complex_TC008_Req Id_325_Account not activated_closed the browser without updating Email address screen");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			/*-------Step 6-----------*/

			CommonFunctions.verifyText(driver, "Set up now",
					obj.getCommunicationLink(), testCaseName);

			/*-------Step 7----------*/
			driver.findElement(By.xpath(obj.getCommunicationLink())).click();

			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(), testCaseName);

			/*------------  Step8 ---------- */

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(), testCaseName);
			/*------------  Step 9 ---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(), testCaseName);
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(), testCaseName);
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(), testCaseName);
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			;

			CommonFunctions.verifyText(driver, "Email Verification",
					obj.getEmailAddressTitle(), testCaseName);

			// Close the browser without updating Email

			/*------------  Step 10 ---------- */

			driver.close();

			/*------------  Step 11---------- */
			LoginPage.LaunchURL(driver, GatewayQAURL);

			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"),
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"), "Home", Functionality
							+ TestCaseID);

			CommonFunctions.verifyText(driver, "error Text",
					obj.getEmailAddressTitle(), testCaseName);

			// Verify IN DB

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC008",
					testCaseName);
			endReporting();
		}
	}

	/*
	 * TC005_Req Id_325_Re-login into GW after closing login password
	 * screen_update setting up fo 3 challenge question_Account reactivates
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_325_TC005(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription,  String Execution, String Status) throws Exception {
		String testCaseName = "3.2.5_Functional_Medium_TC005";
		if (TestCaseID.equalsIgnoreCase("TC005")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.5_Functional_Complex")) {

			/*-----------Step1----------*/

			startReporting("3.2.5_Functional_Complex_TC005_Req Id_325_Re-login into GW after closing login password screen_update setting up fo 3 challenge question_Account reactivates");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			/*-------Step 6-----------*/

			CommonFunctions.verifyText(driver, "Set up now",
					obj.getCommunicationLink(), testCaseName);

			/*-------Step 7----------*/
			driver.findElement(By.xpath(obj.getCommunicationLink())).click();

			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(), testCaseName);

			/*------------  Step8 ---------- */

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(), testCaseName);
			/*------------  Step 9 ---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(), testCaseName);
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(), testCaseName);
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(), testCaseName);
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			;

			CommonFunctions.verifyText(driver, "Email Verification",
					obj.getEmailAddressTitle(), testCaseName);

			/*------------  Step 10---------- */

			driver.findElement(By.xpath(obj.getEmailAddressNewEmail()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewEmailID"));

			driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewEmailID"));

			driver.findElement(By.xpath(obj.getEmailAddressTermsCheckBox()))
					.click();

			driver.findElement(By.xpath(obj.getEmailAddressSubmitButton()))
					.click();

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getChallengeQuestionTitle(), testCaseName);

			// Steps from 10 to 12 should be designed

			driver = LoginPage.LaunchBrowser(Browser);
			LoginPage.LaunchURL(driver, GatewayEmailURL);
			CommonFunctions.SwitchToChildWindow(driver);
			LoginPage.EmailLogin(rowNumber, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_EmailUserName"),
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_EmailPwd"), TestCaseID);
			Thread.sleep(2000);
			LoginPage.EmailValidation(rowNumber, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Username_Eng"), testCaseName);
			statusPassWithScreenshot(driver, "Screenshot done", Functionality
					+ TestCaseID);

			// Close child window and activate parent window

			/*------------  Step 13--------- */

			CommonFunctions.verifyElement(driver, "Go to login page",
					obj.getEmailConfirmationPageGoToLoginPageButton(),
					testCaseName);

			/*------------  Step 14--------- */

			driver.findElement(
					By.xpath(obj.getEmailConfirmationPageGoToLoginPageButton()))
					.click();
			;

			/*------------  Step 15--------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"),
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"), "Home", Functionality
							+ TestCaseID);

			// Verify IN DB

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC002",
					testCaseName);
			endReporting();
		}
	}

	/*
	 * TC007_Req Id_325_Re-login into GW after closing challenge questions
	 * screen using new temporary password_update setting up fo 3 challenge
	 * question_Account reactivates
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_325_TC007(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription,String Execution, String Status) throws Exception {
		String testCaseName = "3.2.5_Functional_Medium_TC007";
		if (TestCaseID.equalsIgnoreCase("TC007")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.5_Functional_Complex")) {

			/*-----------Step1----------*/

			startReporting("3.2.5_Functional_Complex_TC007_Req Id_325_Re-login into GW after closing challenge questions screen using new temporary password_update setting up fo 3 challenge question_Account reactivates");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/*------------  Step2,3,4,5 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"Home", Functionality + TestCaseID);

			/*-------Step 6-----------*/

			CommonFunctions.verifyText(driver, "Set up now",
					obj.getCommunicationLink(), testCaseName);

			/*-------Step 7----------*/
			driver.findElement(By.xpath(obj.getCommunicationLink())).click();

			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(), testCaseName);

			/*------------  Step8 ---------- */

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(), testCaseName);
			/*------------  Step 9 ---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(), testCaseName);
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(), testCaseName);
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(), testCaseName);
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(
					By.xpath(obj.getProfileChallengeqtncontinuebtn())).click();
			;

			CommonFunctions.verifyText(driver, "Email Verification",
					obj.getEmailAddressTitle(), testCaseName);

			/*------------  Step 10---------- */

			driver.findElement(By.xpath(obj.getEmailAddressNewEmail()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewEmailID"));

			driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewEmailID"));

			driver.findElement(By.xpath(obj.getEmailAddressTermsCheckBox()))
					.click();

			driver.findElement(By.xpath(obj.getEmailAddressSubmitButton()))
					.click();

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getChallengeQuestionTitle(), testCaseName);

			// Steps from 10 to 12 should be designed

			driver = LoginPage.LaunchBrowser(Browser);
			LoginPage.LaunchURL(driver, GatewayEmailURL);
			CommonFunctions.SwitchToChildWindow(driver);
			LoginPage.EmailLogin(rowNumber, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_EmailUserName"),
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_EmailPwd"), TestCaseID);
			Thread.sleep(2000);
			LoginPage.EmailValidation(rowNumber, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Username_Eng"), testCaseName);
			statusPassWithScreenshot(driver, "Screenshot done", Functionality
					+ TestCaseID);

			// Close child window and activate parent window

			/*------------  Step 13--------- */

			CommonFunctions.verifyElement(driver, "Go to login page",
					obj.getEmailConfirmationPageGoToLoginPageButton(),
					testCaseName);

			/*------------  Step 14--------- */

			driver.findElement(
					By.xpath(obj.getEmailConfirmationPageGoToLoginPageButton()))
					.click();
			;

			/*------------  Step 15--------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"),
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"), "Home", Functionality
							+ TestCaseID);

			// Verify IN DB

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC002",
					testCaseName);
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC001_existing GW client_reset login password online
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_34_TC001(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		String testCaseName = "3.4_Functional_Complex_TC001";

		if (TestCaseID.equalsIgnoreCase("TC001")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.4_Functional_Complex")) {

			/*-----------Step1----------*/

			startReporting("3.4_Functional_Complex_TC001_existing GW client_reset login password online");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/* _--------------Step2---- */

			CommonFunctions.ClickButton(driver,obj.getForgotPwdLink());

			/* _--------------Step3---- */

			CommonFunctions.verifyElement(driver, "BMO icon",
					obj.getForgotPwdBMoLogo(), testCaseName);
			CommonFunctions.verifyElement(driver, "Client Sign In Button",
					obj.getForgotPwdClientSignIn(), testCaseName);
			CommonFunctions.verifyElement(driver, "FAQ Link",
					obj.getForgotPwdFAQLink(), testCaseName);

			/* _--------------Step4---- */

			CommonFunctions.verifyElement(driver, "Footer Text",
					obj.getForgotPwdFooter(), testCaseName);

			/*
			 * CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
			 * TestCaseID, Functionality, "p_ErrorMsg"), obj
			 * .getForgotPwdFooter(), "3.4_Functional_Low_TC028");
			 */

			/* _--------------Step5---- */

			CommonFunctions.verifyElement(driver, "Header Text",
					obj.getForgotPwdScreenTitle(), testCaseName);

			CommonFunctions.verifyElement(driver, "Header Sub Text",
					obj.getForgotPwdSubTitle(), testCaseName);

			/* _--------------Step6 ---- */

			driver.findElement(By.xpath(obj.getForgotPwdUserId())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/* _--------------Step7 ---- */
			/*
			 * CommonFunctions.verifyElement(driver, "Question 1",
			 * obj.getForgotPwdSecurityQuestion1(), testCaseName);
			 * CommonFunctions.verifyElement(driver, "Question 2",
			 * obj.getForgotPwdSecurityQuestion2(), testCaseName);
			 */
			/* _--------------Step8 ---- */



			/* _--------------Step9 ---- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion1(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion1(),
					obj.getForgotPwdAnswer1(), testCaseName);

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion2(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion2(),
					obj.getForgotPwdAnswer2(), testCaseName);

			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/*--------------Step10------- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdNewSubTitle(), 50, testCaseName);

			CommonFunctions.verifyElement(driver, "Forgot your password?",
					obj.getForgotPwdNewSubTitle(), testCaseName);

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", testCaseName);

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					testCaseName);

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_ErrorMsg"), obj
					.getPasswordValidationText(), testCaseName);

			// Step 11

			LoginPage.LaunchURL(driver, GatewayEmailURL);
			CommonFunctions.SwitchToChildWindow(driver);
			LoginPage.EmailLogin(rowNumber, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_EmailUserName"),
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_EmailPwd"), TestCaseID);
			Thread.sleep(2000);
			LoginPage.EmailValidation(rowNumber, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Username_Eng"), testCaseName);
			statusPassWithScreenshot(driver, "Screenshot done", Functionality
					+ TestCaseID);

			// Step12
			// Verify new login password is saved in the DB
			// step13
			// Verify the forgot password flow is completed in the DB
			//
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC028",
					testCaseName);
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC005_existing GW client_reset login password online_client closes window
	 * without completing process
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_34_TC005(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		String testCaseName = "3.4_Functional_Complex_TC005";

		if (TestCaseID.equalsIgnoreCase("TC005")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.4_Functional_Complex")) {

			/*-----------Step1----------*/

			startReporting("3.4_Functional_Complex_TC005_existing GW client_reset login password online_client closes window without completing process");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/* _--------------Step2---- */

			CommonFunctions.ClickButton(driver,obj.getForgotPwdLink());

			/* _--------------Step3---- */

			CommonFunctions.verifyElement(driver, "Footer Text",
					obj.getForgotPwdFooter(), testCaseName);

			/* _--------------Step4 ---- */

			driver.findElement(By.xpath(obj.getForgotPwdUserId())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/* _--------------Step5 ---- */
			/*
			 * CommonFunctions.verifyElement(driver, "Question 1",
			 * obj.getForgotPwdSecurityQuestion1(), testCaseName);
			 * CommonFunctions.verifyElement(driver, "Question 2",
			 * obj.getForgotPwdSecurityQuestion2(), testCaseName);
			 */
			/* _--------------Step6 ---- */

			/* _--------------Step7---- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion1(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion1(),
					obj.getForgotPwdAnswer1(), testCaseName);

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion2(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion2(),
					obj.getForgotPwdAnswer2(), testCaseName);

			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/*--------------Step8------ */

			driver.close();
			/*--------------Step9------ */

			// Verify in DB that challenge questions have been deleted from
			// table, and new questions have not been setup
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC028",
					testCaseName);
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC008_existing GW client_reset login password online_ cancel button
	 * challenge question
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_34_TC008(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		String testCaseName = "3.4_Functional_Complex_TC008";

		if (TestCaseID.equalsIgnoreCase("TC008")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.4_Functional_Complex")) {

			/*-----------Step1----------*/

			startReporting("3.4_Functional_Complex_TC008_existing GW client_reset login password online_ cancel button challenge question");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/* _--------------Step2---- */

			CommonFunctions.ClickButton(driver,obj.getForgotPwdLink());

			/* _--------------Step3---- */

			CommonFunctions.verifyElement(driver, "BMO icon",
					obj.getForgotPwdBMoLogo(), testCaseName);
			CommonFunctions.verifyElement(driver, "Client Sign In Button",
					obj.getForgotPwdClientSignIn(), testCaseName);
			CommonFunctions.verifyElement(driver, "FAQ Link",
					obj.getForgotPwdFAQLink(), testCaseName);

			/* _--------------Step4---- */

			CommonFunctions.verifyElement(driver, "Footer Text",
					obj.getForgotPwdFooter(), testCaseName);

			/*
			 * CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
			 * TestCaseID, Functionality, "p_ErrorMsg"), obj
			 * .getForgotPwdFooter(), "3.4_Functional_Low_TC028");
			 */

			driver.findElement(By.xpath(obj.getForgotPwdUserId())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/* _--------------Step6 ---- */
			/*
			 * CommonFunctions.verifyElement(driver, "Question 1",
			 * obj.getForgotPwdSecurityQuestion1(), testCaseName);
			 * CommonFunctions.verifyElement(driver, "Question 2",
			 * obj.getForgotPwdSecurityQuestion2(), testCaseName);
			 */
			/* _--------------Step7 ---- */

			/* _--------------Step8 ---- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion1(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion1(),
					obj.getForgotPwdAnswer1(), testCaseName);

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion2(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion2(),
					obj.getForgotPwdAnswer2(), testCaseName);

			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/*--------------Step10------- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdNewSubTitle(), 50, testCaseName);

			CommonFunctions.verifyElement(driver, "Forgot your password?",
					obj.getForgotPwdNewSubTitle(), testCaseName);

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getForgotPwdCancelBtn())).click();

			// Verify in DB that login password has not been updated

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC028",
					testCaseName);
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC020_existing GW client_reset login password_successful reset
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_34_TC020(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		String testCaseName = "3.4_Functional_Complex_TC020";

		if (TestCaseID.equalsIgnoreCase("TC020")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.4_Functional_Complex")) {

			/*-----------Step1----------*/

			startReporting("3.4_Functional_Complex_TC020_existing GW client_reset login password_successful reset");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/* _--------------Step2---- */

			CommonFunctions.ClickButton(driver,obj.getForgotPwdLink());

			/* _--------------Step3---- */

			CommonFunctions.verifyElement(driver, "BMO icon",
					obj.getForgotPwdBMoLogo(), testCaseName);
			CommonFunctions.verifyElement(driver, "Client Sign In Button",
					obj.getForgotPwdClientSignIn(), testCaseName);
			CommonFunctions.verifyElement(driver, "FAQ Link",
					obj.getForgotPwdFAQLink(), testCaseName);

			/* _--------------Step4---- */

			CommonFunctions.verifyElement(driver, "Footer Text",
					obj.getForgotPwdFooter(), testCaseName);

			/*
			 * CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
			 * TestCaseID, Functionality, "p_ErrorMsg"), obj
			 * .getForgotPwdFooter(), "3.4_Functional_Low_TC028");
			 */

			/* _--------------Step5---- */

			CommonFunctions.verifyElement(driver, "Header Text",
					obj.getForgotPwdScreenTitle(), testCaseName);

			CommonFunctions.verifyElement(driver, "Header Sub Text",
					obj.getForgotPwdSubTitle(), testCaseName);

			/* _--------------Step6 ---- */

			driver.findElement(By.xpath(obj.getForgotPwdUserId())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/* _--------------Step7 ---- */
			/*
			 * CommonFunctions.verifyElement(driver, "Question 1",
			 * obj.getForgotPwdSecurityQuestion1(), testCaseName);
			 * CommonFunctions.verifyElement(driver, "Question 2",
			 * obj.getForgotPwdSecurityQuestion2(), testCaseName);
			 */
			/* _--------------Step8 ---- */

			
			/* _--------------Step9 ---- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion1(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion1(),
					obj.getForgotPwdAnswer1(), testCaseName);

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion2(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion2(),
					obj.getForgotPwdAnswer2(), testCaseName);

			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/*--------------Step10------- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdNewSubTitle(), 50, testCaseName);

			CommonFunctions.verifyElement(driver, "Forgot your password?",
					obj.getForgotPwdNewSubTitle(), testCaseName);

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			/*--------------Step11------- */

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", testCaseName);

			/*--------------Step12------- */

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					testCaseName);

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getChallengeQuestionTitle(), testCaseName);

			CommonFunctions.verifyElement(driver, "Go to login page",
					obj.getEmailConfirmationPageGoToLoginPageButton(),
					testCaseName);

			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"),
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"), "Home", Functionality
							+ TestCaseID);

			// Verify IN DB

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC028",
					testCaseName);
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC023_existing GW client_reset login password_cancel_closes browser
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_34_TC023(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		String testCaseName = "3.4_Functional_Complex_TC023";

		if (TestCaseID.equalsIgnoreCase("TC023")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.4_Functional_Complex")) {

			/*-----------Step1----------*/

			startReporting("3.4_Functional_Complex_TC023_existing GW client_reset login password_cancel_closes browser");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/* _--------------Step2---- */

			CommonFunctions.ClickButton(driver,obj.getForgotPwdLink());

			/* _--------------Step3---- */

			CommonFunctions.verifyElement(driver, "BMO icon",
					obj.getForgotPwdBMoLogo(), testCaseName);
			CommonFunctions.verifyElement(driver, "Client Sign In Button",
					obj.getForgotPwdClientSignIn(), testCaseName);
			CommonFunctions.verifyElement(driver, "FAQ Link",
					obj.getForgotPwdFAQLink(), testCaseName);

			/* _--------------Step4---- */

			CommonFunctions.verifyElement(driver, "Footer Text",
					obj.getForgotPwdFooter(), testCaseName);

			/*
			 * CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
			 * TestCaseID, Functionality, "p_ErrorMsg"), obj
			 * .getForgotPwdFooter(), "3.4_Functional_Low_TC028");
			 */

			/* _--------------Step5---- */

			CommonFunctions.verifyElement(driver, "Header Text",
					obj.getForgotPwdScreenTitle(), testCaseName);

			CommonFunctions.verifyElement(driver, "Header Sub Text",
					obj.getForgotPwdSubTitle(), testCaseName);

			/* _--------------Step6 ---- */

			driver.findElement(By.xpath(obj.getForgotPwdUserId())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/* _--------------Step7 ---- */
			/*
			 * CommonFunctions.verifyElement(driver, "Question 1",
			 * obj.getForgotPwdSecurityQuestion1(), testCaseName);
			 * CommonFunctions.verifyElement(driver, "Question 2",
			 * obj.getForgotPwdSecurityQuestion2(), testCaseName);
			 */
			/* _--------------Step8 ---- */


			/* _--------------Step9 ---- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion1(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion1(),
					obj.getForgotPwdAnswer1(), testCaseName);

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion2(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion2(),
					obj.getForgotPwdAnswer2(), testCaseName);

			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/*--------------Step10------- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdNewSubTitle(), 50, testCaseName);

			CommonFunctions.verifyElement(driver, "Forgot your password?",
					obj.getForgotPwdNewSubTitle(), testCaseName);

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			/*--------------Step11------- */

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", testCaseName);

			/*--------------Step12------- */

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					testCaseName);

			/*--------------Step13------ */
			driver.close();

			// Step 14

			// Step12
			// Verify new login password is saved in the DB// Verify the forgot
			// password flow is completed in the DB
			//
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC028",
					testCaseName);
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC021_existing GW client_reset login password_cancel
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_34_TC021(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		String testCaseName = "3.4_Functional_Complex_TC021";

		if (TestCaseID.equalsIgnoreCase("TC021")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.4_Functional_Complex")) {

			/*-----------Step1----------*/

			startReporting("3.4_Functional_Complex_TC021_existing GW client_reset login password_cancel");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/* _--------------Step2---- */

			CommonFunctions.ClickButton(driver,obj.getForgotPwdLink());

			/* _--------------Step3---- */

			CommonFunctions.verifyElement(driver, "BMO icon",
					obj.getForgotPwdBMoLogo(), testCaseName);
			CommonFunctions.verifyElement(driver, "Client Sign In Button",
					obj.getForgotPwdClientSignIn(), testCaseName);
			CommonFunctions.verifyElement(driver, "FAQ Link",
					obj.getForgotPwdFAQLink(), testCaseName);

			/* _--------------Step4---- */

			CommonFunctions.verifyElement(driver, "Footer Text",
					obj.getForgotPwdFooter(), testCaseName);

			/*
			 * CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
			 * TestCaseID, Functionality, "p_ErrorMsg"), obj
			 * .getForgotPwdFooter(), "3.4_Functional_Low_TC028");
			 */

			/* _--------------Step5---- */

			CommonFunctions.verifyElement(driver, "Header Text",
					obj.getForgotPwdScreenTitle(), testCaseName);

			CommonFunctions.verifyElement(driver, "Header Sub Text",
					obj.getForgotPwdSubTitle(), testCaseName);

			/* _--------------Step6 ---- */

			driver.findElement(By.xpath(obj.getForgotPwdUserId())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/* _--------------Step7 ---- */
			/*
			 * CommonFunctions.verifyElement(driver, "Question 1",
			 * obj.getForgotPwdSecurityQuestion1(), testCaseName);
			 * CommonFunctions.verifyElement(driver, "Question 2",
			 * obj.getForgotPwdSecurityQuestion2(), testCaseName);
			 */
			/* _--------------Step8 ---- */

			/* _--------------Step9 ---- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion1(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion1(),
					obj.getForgotPwdAnswer1(), testCaseName);

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion2(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion2(),
					obj.getForgotPwdAnswer2(), testCaseName);

			driver.findElement(By.xpath(obj.getForgotPwdContinueBtn())).click();

			/*--------------Step10------- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdNewSubTitle(), 50, testCaseName);

			CommonFunctions.verifyElement(driver, "Forgot your password?",
					obj.getForgotPwdNewSubTitle(), testCaseName);

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", testCaseName);

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					testCaseName);

			driver.findElement(By.xpath(obj.getForgotPwdCancelBtn())).click();
			CommonFunctions.verifyElement(driver, "UserName",
					obj.getUserName(), testCaseName);

			// Verify in DB that the login password IS NOT updated
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC028",
					testCaseName);
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * //TC003_existing GW client_reset login password online_client forgets
	 * userID
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_34_TC003(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		String testCaseName = "3.4_Functional_Medium_TC003";

		if (TestCaseID.equalsIgnoreCase("TC003")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.4_Functional_Medium")) {

			/*-----------Step1----------*/

			startReporting("3.4_Functional_Medium_TC003_existing GW client_reset login password online_client forgets userID");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/* _--------------Step2---- */

			CommonFunctions.ClickButton(driver,obj.getForgotPwdLink());

			/* --------------Step3---- */

			CommonFunctions.ClickButton(driver,obj.getForgotPWDforgotUserIdLink());

			CommonFunctions.waitForElement(driver,
					obj.getForgotPWDforgotUserIdHelpDeskText(), 50,
					testCaseName);

			CommonFunctions.verifyText(driver, "Help Desk",
					obj.getForgotPWDforgotUserIdHelpDeskText(), testCaseName);

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC003",
					testCaseName);
			endReporting();
		}

	}

	/**
	 * 
	 * @throws Exception
	 */
	@AfterTest
	public void afterTest() throws Exception {

	}

	@AfterSuite
	public void afterSuite() throws Exception {
		closeReporting();
		LoginPage.closeDriver();
		WindowsUtils.killByName("IEDriverServer.exe");
	}
}
