/**
 * 
 */
package com.Gatewaytr.Testcases;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.os.WindowsUtils;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.Gateway.GlobalParameters.BaseClass;
import com.Gateway.GlobalParameters.FetchingOR;
import com.Gatewaytr.ExcelFile.ReadExcelFile;
import com.Gatewaytr.pages.Admin;
import com.Gatewaytr.pages.CommonFunctions;
import com.Gatewaytr.pages.DataBase;
import com.Gatewaytr.pages.LoginPage;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

/**
 * @author craja01 TestNG Class
 * 
 */
public class MainClass_Poorva extends BaseClass {
	WebDriver driver;
	String Browser,LanguageSettings;
	String accountNumber;
	ExtentReports extent;
	ExtentTest logger;
	public FetchingOR obj = null;
	public String fileName = "C:\\GatewayPasswordReset\\Configuration\\ConfigurationPage.property";
	File src = new File(
			"C:\\GatewayPasswordReset\\DriverSheet\\DriveSheetSample.xls");
	int rowNumber;

	@DataProvider(name = "DriverSheet")
	public Object[][] driverSheetData() {
		Object[][] arrayObject = getExcelData(
				"C:\\GatewayPasswordReset\\DriverSheet\\DriveSheetSample.xls",
				"Sheet1");
		return arrayObject;
	}

	public String[][] getExcelData(String fileName, String sheetName) {
		String[][] arrayExcelData = null;
		try {
			FileInputStream fs = new FileInputStream(fileName);
			Workbook wb = Workbook.getWorkbook(fs);
			Sheet sh = wb.getSheet(sheetName);

			int totalNoOfCols = sh.getColumns();
			int totalNoOfRows = sh.getRows();

			arrayExcelData = new String[totalNoOfRows - 1][totalNoOfCols];

			for (int i = 1; i < totalNoOfRows; i++) {

				for (int j = 0; j < totalNoOfCols; j++) {
					arrayExcelData[i - 1][j] = sh.getCell(j, i).getContents();

				}

			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
			e.printStackTrace();
		} catch (BiffException e) {
			e.printStackTrace();
		}
		return arrayExcelData;
	}

	@BeforeSuite
	public void beforeSuite() throws Exception {

		setReport();

	}

	@BeforeTest
	@Parameters({ "browserName", "language" })
	public void beforeTest(String browserName, String language)
			throws Exception {
		String Browser, LanguageSettings;
		Browser = browserName;
		LanguageSettings = language;
		System.out.println("*****************" + Browser);
		System.out.println("*****************" + LanguageSettings);
		obj = new FetchingOR(fileName);
		ReadExcelFile.setExcelFile(filePath, LanguageSettings);
		driver = LoginPage.LaunchBrowser(Browser);

	}

	
	
	/*
	 * @author=Poorva Dixit
	 */

	@Test(dataProvider = "DriverSheet")
	public void test_322_TC081(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC081")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.2_Functional_Low")) {

			startReporting("3.2.2_Functional_Low_TC081_GUI_Set up challenge questions screen");

			// Launching the admin url
			LoginPage.LaunchURL(driver, GatewayAdminURL);
			// Storing temporary password from admin Url
			String tempPassword = Admin.getTemporaryPassword(driver,
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			// Storing the trading password

			Admin.getTemporaryTradingPassword(driver, ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Username_Eng"));

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));
			// Logging in using temporary password
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), tempPassword, "Home",
					Functionality + TestCaseID);
			// verifying the screen of create a new password
			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(),
					"3.2.2_Functional_Low_TC081");
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					"3.2.2_Functional_Low_TC081");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					"3.2.2_Functional_Low_TC081");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					"3.2.2_Functional_Low_TC081");
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", "3.2.2_Functional_Low_TC081");

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_ConfirmPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					"3.2.2_Functional_Low_TC081");
			
			
			
			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			/*
			 * Moving to Trading screen verifyElement
			 */CommonFunctions.verifyText(driver,
					"Create a new Trading password", obj.getTradingTitle(),
					"3.2.2_Functional_Low_TC081");

			driver.findElement(By.xpath(obj.getTradingNewPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_TradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingMinimum6chracters(), "rgba(0, 138, 0, 1)",
					"Minimum 6 characters", "3.2.2_Functional_Low_TC081");

			driver.findElement(By.xpath(obj.getTradingConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality,
									"p_ConfirmTradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingConfirmPasswordCheck(), "rgba(0, 138, 0, 1)",
					"Confirmed, your Trading passwords match",
					"3.2.2_Functional_Low_TC081");

			
			CommonFunctions.ClickButton(driver,obj.getTradingContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.2_Functional_Low_TC081");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC081",
					"3.2.2_Functional_Low_TC081");

			endReporting();

		}
	}

	/*
	 * @author=Poorva Dixit
	 */

	@Test(dataProvider = "DriverSheet")
	public void test_322_TC082(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC082")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.2_Functional_Low")) {

			startReporting("3.2.2_Functional_Low_TC082_GUI_Set up challenge questions screen");

			// Launching the admin url
			LoginPage.LaunchURL(driver, GatewayAdminURL);
			// Storing temporary password from admin Url
			String tempPassword = Admin.getTemporaryPassword(driver,
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			// Storing the trading password

			Admin.getTemporaryTradingPassword(driver, ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Username_Eng"));

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));
			// Logging in using temporary password
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), tempPassword, "Home",
					Functionality + TestCaseID);
			// verifying the screen of create a new password
			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(),
					"3.2.2_Functional_Low_TC082");
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					"3.2.2_Functional_Low_TC082");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					"3.2.2_Functional_Low_TC082");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					"3.2.2_Functional_Low_TC082");
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", "3.2.2_Functional_Low_TC082");

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_ConfirmPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					"3.2.2_Functional_Low_TC082");
			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			/*
			 * Moving to Trading screen verifyElement
			 */CommonFunctions.verifyText(driver,
					"Create a new Trading password", obj.getTradingTitle(),
					"3.2.2_Functional_Low_TC082");

			driver.findElement(By.xpath(obj.getTradingNewPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_TradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingMinimum6chracters(), "rgba(0, 138, 0, 1)",
					"Minimum 6 characters", "3.2.2_Functional_Low_TC082");

			driver.findElement(By.xpath(obj.getTradingConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality,
									"p_ConfirmTradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingConfirmPasswordCheck(), "rgba(0, 138, 0, 1)",
					"Confirmed, your Trading passwords match",
					"3.2.2_Functional_Low_TC082");

			CommonFunctions.ClickButton(driver,obj.getTradingContinueButton());
			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.2_Functional_Low_TC082");
			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getQuestion1(), "3.2.2_Functional_Low_TC082");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getQuestion2(), "3.2.2_Functional_Low_TC082");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getQuestion3(), "3.2.2_Functional_Low_TC082");

			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_322_TC083(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC083")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.2_Functional_Low")) {

			startReporting("3.2.2_Functional_Low_TC083_GUI_Set up challenge questions screen_Challenge questions dropdown");

			// Launching the admin url
			LoginPage.LaunchURL(driver, GatewayAdminURL);
			// Storing temporary password from admin Url
			String tempPassword = Admin.getTemporaryPassword(driver,
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			// Storing the trading password

			Admin.getTemporaryTradingPassword(driver, ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Username_Eng"));

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));
			// Logging in using temporary password
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), tempPassword, "Home",
					Functionality + TestCaseID);
			// verifying the screen of create a new password
			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(),
					"3.2.2_Functional_Low_TC083");
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					"3.2.2_Functional_Low_TC083");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					"3.2.2_Functional_Low_TC083");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					"3.2.2_Functional_Low_TC083");
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", "3.2.2_Functional_Low_TC083");

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_ConfirmPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					"3.2.2_Functional_Low_TC083");
			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			/*
			 * Moving to Trading screen verifyElement
			 */CommonFunctions.verifyText(driver,
					"Create a new Trading password", obj.getTradingTitle(),
					"3.2.2_Functional_Low_TC083");

			driver.findElement(By.xpath(obj.getTradingNewPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_TradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingMinimum6chracters(), "rgba(0, 138, 0, 1)",
					"Minimum 6 characters", "3.2.2_Functional_Low_TC083");

			driver.findElement(By.xpath(obj.getTradingConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality,
									"p_ConfirmTradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingConfirmPasswordCheck(), "rgba(0, 138, 0, 1)",
					"Confirmed, your Trading passwords match",
					"3.2.2_Functional_Low_TC083");

			CommonFunctions.ClickButton(driver,obj.getTradingContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.2_Functional_Low_TC083");
			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getQuestion1(), "3.2.2_Functional_Low_TC083");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getQuestion2(), "3.2.2_Functional_Low_TC083");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getQuestion3(), "3.2.2_Functional_Low_TC083");
			// Clicking on First question dropdown
			
			CommonFunctions.ClickButton(driver,obj.getQuestion1());

		//	CommonFunctions.getQuestionList(driver, obj.getQuestion1(),"3.2.2_Functional_Low_TC083");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_322_TC084(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC084")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.2_Functional_Low")) {

			startReporting("3.2.2_Functional_Low_TC084_GUI_Set up challenge questions screen_Challenge questions dropdow");
			/*------------  Pre-requisites---------- */
			LoginPage.LaunchURL(driver, GatewayAdminURL);

			String tempPassword = Admin.getTemporaryPassword(driver,
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			// Storing the trading password

			Admin.getTemporaryTradingPassword(driver, ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Username_Eng"));
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));
			// Logging in using temporary password

			/*------------  Step2 and Step3 and Step4 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), tempPassword, "Home",
					Functionality + TestCaseID);

			/*------------  Step5---------- */

			// verifying the screen of create a new password
			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(),
					"3.2.2_Functional_Low_TC084");

			/*------------  Step6---------- */
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					"3.2.2_Functional_Low_TC084");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					"3.2.2_Functional_Low_TC084");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					"3.2.2_Functional_Low_TC084");
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", "3.2.2_Functional_Low_TC084");

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_ConfirmPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					"3.2.2_Functional_Low_TC084");
			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			/*------------  Step7---------- */

			/*
			 * Moving to Trading screen verifyElement
			 */CommonFunctions.verifyText(driver,
					"Create a new Trading password", obj.getTradingTitle(),
					"3.2.2_Functional_Low_TC084");

			driver.findElement(By.xpath(obj.getTradingNewPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_TradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingMinimum6chracters(), "rgba(0, 138, 0, 1)",
					"Minimum 6 characters", "3.2.2_Functional_Low_TC084");

			driver.findElement(By.xpath(obj.getTradingConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality,
									"p_ConfirmTradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingConfirmPasswordCheck(), "rgba(0, 138, 0, 1)",
					"Confirmed, your Trading passwords match",
					"3.2.2_Functional_Low_TC084");

			CommonFunctions.ClickButton(driver,obj.getTradingContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.2_Functional_Low_TC084");

			/*------------  Step8---------- */

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getQuestion1(), "3.2.2_Functional_Low_TC084");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getQuestion2(), "3.2.2_Functional_Low_TC084");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getQuestion3(), "3.2.2_Functional_Low_TC084");

			/*------------  Step9---------- */

			// Clicking on First question dropdown
			
			CommonFunctions.ClickButton(driver,obj.getQuestion2());
			

			//CommonFunctions.getQuestionList(driver, obj.getQuestion2(),					"3.2.2_Functional_Low_TC084");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_322_TC085(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC085")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.2_Functional_Low")) {

			startReporting("3.2.2_Functional_Low_TC085_GUI_Set up challenge questions screen_Challenge questions dropdow");

			/*------------  Pre-requisites---------- */
			LoginPage.LaunchURL(driver, GatewayAdminURL);

			String tempPassword = Admin.getTemporaryPassword(driver,
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			// Storing the trading password

			Admin.getTemporaryTradingPassword(driver, ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Username_Eng"));
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));
			// Logging in using temporary password

			/*------------  Step2 and Step3 and Step4 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), tempPassword, "Home",
					Functionality + TestCaseID);

			/*------------  Step5---------- */

			// verifying the screen of create a new password
			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(),
					"3.2.2_Functional_Low_TC085");

			/*------------  Step6---------- */
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					"3.2.2_Functional_Low_TC085");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					"3.2.2_Functional_Low_TC085");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					"3.2.2_Functional_Low_TC085");
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", "3.2.2_Functional_Low_TC085");

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_ConfirmPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					"3.2.2_Functional_Low_TC085");
			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			/*------------  Step7---------- */

			/*
			 * Moving to Trading screen verifyElement
			 */CommonFunctions.verifyText(driver,
					"Create a new Trading password", obj.getTradingTitle(),
					"3.2.2_Functional_Low_TC085");

			driver.findElement(By.xpath(obj.getTradingNewPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_TradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingMinimum6chracters(), "rgba(0, 138, 0, 1)",
					"Minimum 6 characters", "3.2.2_Functional_Low_TC085");

			driver.findElement(By.xpath(obj.getTradingConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality,
									"p_ConfirmTradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingConfirmPasswordCheck(), "rgba(0, 138, 0, 1)",
					"Confirmed, your Trading passwords match",
					"3.2.2_Functional_Low_TC085");
			CommonFunctions.ClickButton(driver,obj.getTradingContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.2_Functional_Low_TC085");

			/*------------  Step8---------- */

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getQuestion1(), "3.2.2_Functional_Low_TC085");

			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getQuestion2(), "3.2.2_Functional_Low_TC085");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getQuestion3(), "3.2.2_Functional_Low_TC085");

			/*------------  Step9---------- */

			// Clicking on First question dropdown
			
			CommonFunctions.ClickButton(driver,obj.getQuestion3());
			

		//	CommonFunctions.getQuestionList(driver, obj.getQuestion3(),	"3.2.2_Functional_Low_TC085");

			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC001_ UI_ Challenge Questions
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC001(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC001")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

			startReporting("3.3.1_Functional_Low_TC001_ UI_ Challenge Questions");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC001");

			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// verifying the Challenge Questions

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getAccountSetting_ProfileTab_SecurityQuesHeading(),
					"3.3.1_Functional_Low_TC001");

			/*------------  Step5 ---------- */

			// verify Spelling of Challenge Question

			CommonFunctions.verifySpellingText(driver, "Challenge questions",
					obj.getAccountSetting_ProfileTab_SecurityQuesHeading(),
					"3.3.1_Functional_Low_TC001");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC001",
					"3.3.1_Functional_Low_TC001");

			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC002_ UI_ Edit button
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC002(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		try {
			int rowNumber = Integer.parseInt(RowNumber);
			if (TestCaseID.equalsIgnoreCase("TC002")
					&& Execution.equalsIgnoreCase("Y")
					&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

				startReporting("3.3.1_Functional_Low_TC002_ UI_ Edit button");

				/*------------  Step1---------- */

				// Launching QA Gateway
				LoginPage.LaunchURL(driver, GatewayQAURL);
				System.out.println("*****************"
						+ ReadExcelFile.getTestData(TestCaseID, Functionality,
								"p_Password_Eng"));

				// Logging in using password and Navigating to the eServices tab
				// page

				/*------------  Step2 ---------- */
				LoginPage.Login(rowNumber, ReadExcelFile.getTestData(
						TestCaseID, Functionality, "p_Username_Eng"),
						ReadExcelFile.getTestData(TestCaseID, Functionality,
								"p_Password_Eng"), "eServices", Functionality
								+ TestCaseID);

				CommonFunctions.verifyText(driver, "Profile",
						obj.getAccountSetting_ProfileTab(),
						"3.3.1_Functional_Low_TC002");
				/*------------  Step3 ---------- */

				CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

				/*------------  Step4---------- */

				// verifying the Edit button

				CommonFunctions.waitForElement(driver,
						obj.getEditChallengeqtnbtn(), 40,
						"3.3.1_Functional_Low_TC002");

				CommonFunctions.verifyText(driver, "Edit",
						obj.getEditChallengeqtnbtn(),
						"3.3.1_Functional_Low_TC002");

				/*
				 * CommonFunctions.verifyHorizontalLocationOfElement(driver,
				 * obj.getAccountSetting_ProfileTab_SecurityQuesHeading(),
				 * obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC002");
				 */

				System.out.println("Step4 done");

				/*------------  Step5 ---------- */

				// verify Font Of Edit Button

				/*
				 * CommonFunctions.verifyButtonFont(driver, "#0079c1", "#fff",
				 * "#CCCCCC", "Grey", obj.getEditChallengeqtnbtn(),
				 * "3.3.1_Functional_Low_TC002");
				 * System.out.println("Step5 done");
				 */
				BaseClass.statusPassWithScreenshot(driver, "Screen For TC002",
						"3.3.1_Functional_Low_TC002");

				endReporting();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw e;
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC003_functionality_ Edit button
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC003(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC003")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

			startReporting("3.3.1_Functional_Low_TC003_functionality_ Edit button");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC003");

			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC003");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC003");
			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			CommonFunctions.waitForElement(driver,
					obj.getProfileChallengeqtncontinuebtn(), 40,
					"3.3.1_Functional_Low_TC003");

			CommonFunctions.checkEnabled(driver,
					obj.getProfileChallengeqtncontinuebtn(), "Continue Button",
					"3.3.1_Functional_Low_TC003");

			CommonFunctions.waitForElement(driver,
					obj.getProfileChallengeqtncancelbtn(), 40,
					"3.3.1_Functional_Low_TC003");
			CommonFunctions.checkEnabled(driver,
					obj.getProfileChallengeqtncancelbtn(), "Cancel Button",
					"3.3.1_Functional_Low_TC003");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC003",
					"3.3.1_Functional_Low_TC003");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC005_ UI_ Save Button
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC005(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC005")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

			startReporting("3.3.1_Functional_Low_TC005_ UI_ Save Button");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC005");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			CommonFunctions.checkEnabled(driver,
					obj.getProfileChallengeqtnonetextbox(), "TextBox Area",
					"3.3.1_Functional_Low_TC005");

			/*------------  Step5---------- */

			// "Verify the availabilty of save  Button for challange questions section "

			CommonFunctions.checkEnabled(driver,
					obj.getProfileChallengeqtnonetextbox(), "Continue Button",
					"3.3.1_Functional_Low_TC005");

			/*------------  Step6---------- */
			// Verify if the save Button

			/*
			 * CommonFunctions.verifyButtonFont(driver, "Save", "White", "Blue",
			 * "NULL", obj.getEditChallengeqtnbtn(),
			 * "3.3.1_Functional_Low_TC005");
			 */

			CommonFunctions.verifySpellingText(driver, "Save",
					obj.getProfileChallengeqtncontinuebtn(),
					"3.3.1_Functional_Low_TC005");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC005",
					"3.3.1_Functional_Low_TC005");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC007_ UI_ Cancel button
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC007(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC007")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

			startReporting("3.3.1_Functional_Low_TC007_ UI_ Cancel  button");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC007");

			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */
			/*
			 * CommonFunctions.verifyElement(driver, "Edit",
			 * obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC007");
			 * 
			 * CommonFunctions.verifyHorizontalLocationOfElement(driver,
			 * obj.getAccountSetting_ProfileTab_SecurityQuesHeading(),
			 * obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC007");
			 */

			/*------------  Step5---------- */
			// click on Edit Button of Challenge question Section

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());
			CommonFunctions.checkEnabled(driver,
					obj.getProfileChallengeqtnonetextbox(), "TextBox Area",
					"3.3.1_Functional_Low_TC007");

			/*------------  Step5---------- */

			// "Verify the availabilty of save  Button for challange questions section "

			CommonFunctions.checkEnabled(driver,
					obj.getProfileChallengeqtnonetextbox(), "Continue Button",
					"3.3.1_Functional_Low_TC007");

			/*------------  Step6---------- */
			// Verify if the Cancel Button

			// Verification Of Cancel Button Font is Pending as per discussion

			CommonFunctions.verifySpellingText(driver, "Cancel",
					obj.getProfileChallengeqtncancelbtn(),
					"3.3.1_Functional_Low_TC007");

			/*
			 * CommonFunctions.verifyButtonFont(driver, "CancelButton", "Blue",
			 * "White", "Grey", obj.getProfileChallengeqtncancelbtn(),
			 * "3.3.1_Functional_Low_TC007");
			 */

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC007",
					"3.3.1_Functional_Low_TC007");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC009_ UI_Question _Text Fields
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC009(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC009")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

			startReporting("3.3.1_Functional_Low_TC009_ UI_Question _Text Fields");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC009");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Low_TC009");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Low_TC009");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Low_TC009");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC009",
					"3.3.1_Functional_Low_TC009");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC010_ UI_Answer_Text Fields
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC010(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC010")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

			startReporting("3.3.1_Functional_Low_TC010_ UI_Answer_Text Fields");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC010");

			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Low_TC010");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getProfileChallengeansonetextbox(),
					"3.3.1_Functional_Low_TC010");
			CommonFunctions.verifyElement(driver, "Answer 2",
					obj.getProfileChallengeanstwotextbox(),
					"3.3.1_Functional_Low_TC010");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getProfileChallengeansthreetextbox(),
					"3.3.1_Functional_Low_TC010");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC010",
					"3.3.1_Functional_Low_TC010");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC011_ UI_Login password
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC011(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC011")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

			startReporting("3.3.1_Functional_Low_TC011_ UI_Login password");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC010");

			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			CommonFunctions.verifyText(driver, "Login Password",
					obj.getProfiletextboxloginheader(),
					"3.3.1_Functional_Low_TC011");

			CommonFunctions.checkCapitalize(driver,
					obj.getProfiletextboxloginheader());

			/*------------  Step6---------- */

			
			CommonFunctions.ClickButton(driver,obj.getProfiletextboxlogin());

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC011",
					"3.3.1_Functional_Low_TC011");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC012_functional_Navigates without saving
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC012(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC012")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC012_functional_Navigates without saving");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "eServices",
					obj.getAccountSetting_eServicesTab(),
					"3.3.1_Functional_Medium_TC012");

			/*------------  Step3 ---------- */
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC012");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC012");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC012");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step6---------- */

			
			
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_eServicesTab());

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC012",
					"3.3.1_Functional_Medium_TC012");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC006_ Functionality _ Save Button
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC006(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC006")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC006_Functionality_Save Button");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC006");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC006");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC006");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC006");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step6---------- */

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"));

			
			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());

			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC006");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC006",
					"3.3.1_Functional_Medium_TC006");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC008_ Functionality _ Cancel button
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC008(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC008")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC008_Functionality_Cancel button");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC008");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC008");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC008");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC008");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step6---------- */
			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"));
		
			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncancelbtn());

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC008",
					"3.3.1_Functional_Medium_TC008");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC015_Error message_ same answer for two security question
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC015(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC015")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC015_Error message_ same answer for two security question");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC015");
			/*------------  Step3 ---------- */
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC015");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC015");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC015");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step6---------- */
			/*
			 * Here Continue button is present instead of save Button
			 */

		
			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());

			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC015");
			/*
			 * Here answers defect is there as answers aresaved asthe cancel
			 * button is clicked
			 */

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC015",
					"3.3.1_Functional_Medium_TC015");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC016_Error message_ same answer already on file
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC016(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC016")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC016_Error message_ same answer already on file");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC015");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC015");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC015");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC015");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step6---------- */
			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC016");

		
			
			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());

			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC016");
			/*
			 * Here answers defect is there as answers aresaved asthe cancel
			 * button is clicked
			 */

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC016",
					"3.3.1_Functional_Medium_TC016");
			endReporting();
		}

	}

	/**
	 * TC017_ Change challenge question 1
	 * 
	 * @throws Exception
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC017(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC017")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC017_ Change challenge question 1");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC017");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			String s1 = CommonFunctions.getQuestionValue(driver,
					obj.getProfileChallengeqtnonetextbox());

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnonetextbox(), s1, 17,
					"3.3.1_Functional_Medium_TC017");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC016",
					"3.3.1_Functional_Medium_TC016");
			endReporting();
		}

	}

	/**
	 * TC018_ Change challenge question 2
	 * 
	 * @throws Exception
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC018(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC018")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC018_ Change challenge question 2");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC018");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			String s2 = CommonFunctions.getQuestionValue(driver,
					obj.getProfileChallengeqtntwotextbox());

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtntwotextbox(), s2, 18,
					"3.3.1_Functional_Medium_TC018");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC018",
					"3.3.1_Functional_Medium_TC018");
			endReporting();
		}

	}

	/**
	 * TC019_ Change challenge question 3
	 * 
	 * @throws Exception
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC019(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC019")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_3.3.1_Functional_Medium_TC019 3");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC019");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			String s3 = CommonFunctions.getQuestionValue(driver,
					obj.getProfileChallengeqtnthreetextbox());

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnthreetextbox(), s3, 18,
					"3.3.1_Functional_Medium_TC019");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC019",
					"3.3.1_Functional_Medium_TC019");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC020_error _Change challenge question _answer not given
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC020(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC005")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC020_error _Change challenge question _answer not given");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC020");
			/*------------  Step3 ---------- */
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC020");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC020");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, ""));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC020");

			/*------------  Step6---------- */
			// Click on Save button with success text

			/*
			 * Here Continue button is present instead of save Button
			 */

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC020");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC020",
					"3.3.1_Functional_Medium_TC020");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC021_error _Change challenge question _Incorrect Login password
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC021(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC005")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC021_error _Change challenge question _Incorrect Login password");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC021");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC021");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC021");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC021");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step6---------- */
			// Click on Save button with success text

			/*
			 * Here Continue button is present instead of save Button And Login
			 * password Field is absent
			 */

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC021");
			;

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC021");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC021",
					"3.3.1_Functional_Medium_TC021");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC022_error _Change challenge question _and answer for different question
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC022(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC022")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC022_error _Change challenge question _and answer for different question");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC022");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC022");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC022");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, ""));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC022");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step6---------- */

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC022");
			;

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC022");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC022",
					"3.3.1_Functional_Medium_TC022");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC023_error _Change challenge question _and answer for different question
	 * with incorrect password error message
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC023(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC023")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC023_error _Change challenge question _and answer for different question with incorrect password error message");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC023");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers
			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC023");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC023");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, ""));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC023");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step6---------- */
			// Click on Save button with success text
			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC022");
			;

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC023");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC023",
					"3.3.1_Functional_Medium_TC023");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC024_error _Change challenge question _blank Login password
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC024(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC024")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC024_error _Change challenge question _blank  Login password");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC024");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC024");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC024");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC024");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step6---------- */
			// Click on Save button with success text

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys("");
			;

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC024");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC024",
					"3.3.1_Functional_Medium_TC024");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC025_error _Change answer to challenge question _Incorrect Login
	 * password
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC025(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC025")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC025_error _Change answer to challenge question _Incorrect Login password");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC025");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC024");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC024");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC024");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());
			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_UpdatedSecurityQuestion1"),
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC024");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_UpdatedAnswer1");

			/*------------  Step6---------- */
			// Click on Save button with success text
			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC025");
			;

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC025");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC025",
					"3.3.1_Functional_Medium_TC025");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC026_error _Change answer to challenge question _blank Login password
	 * password
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC026(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC026")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC026_error _Change answer to challenge question _blank  Login password");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC026");
			/*------------  Step3 ---------- */

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC020");
			/*------------  Step3 ---------- */
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC026");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC026");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC026");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			// Click on Save button with success text
			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys("");
			;

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC026");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			/*------------  Step6---------- */
			// Click on Save button with success text

			/*
			 * Here Continue button is present instead of save Button And Login
			 * password Field is absent
			 */

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC026");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC026",
					"3.3.1_Functional_Medium_TC026");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC027_error _challange answer less than 6 characters
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC027(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC027")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC027_error _challange answer less than 6 characters");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC027");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());
			/*------------  Step4---------- */

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC020");
			/*------------  Step3 ---------- */
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers
			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC027");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC027");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC027");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_UpdatedSecurityQuestion1"),
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC027");

			// Answer less than 6 letter
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_UpdatedAnswer1");

			/*------------  Step6---------- */
			// Click on Save button with success text

			// Click on Save button with success text
			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC025");
			;
			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC027");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC027",
					"3.3.1_Functional_Medium_TC027");
			endReporting();
		}
	}

	
	/*
	 * @author=Poorva Dixit
	 * 
	 * TC013_UI_Updated Date_Collapsed
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC013(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC013")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

			startReporting("3.3.1_Functional_Low_TC013_UI_Updated Date_Collapsed");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC013");
			/*------------  Step3 ---------- */

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step4---------- */
			// Check Date Element and see if its disabled

			CommonFunctions.verifyElement(driver, "Date",
					obj.getProfileTabChallengeQuestionDate(),
					"3.3.1_Functional_Low_TC013");

			CommonFunctions.CheckNonEditable(driver, "Date",
					obj.getProfileTabChallengeQuestionDate(),
					"3.3.1_Functional_Low_TC013");
			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.verifyDateformat(driver,
					obj.getProfileTabChallengeQuestionDate(),
					"3.3.1_Functional_Low_TC013");

			/*------------  Step6---------- */
			// Verify DB Date as Updated Date

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC013",
					"3.3.1_Functional_Low_TC013");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC014_UI_Updated Date_expanded
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC014(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC014")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

			startReporting("3.3.1_Functional_Low_TC014_UI_Updated Date_expanded");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC014");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Check Date Element and see if its Non Editable

			CommonFunctions.verifyElement(driver, "Date",
					obj.getProfileTabChallengeQuestionDate(),
					"3.3.1_Functional_Low_TC014");

			CommonFunctions.CheckNonEditable(driver, "Date",
					obj.getProfileTabChallengeQuestionDate(),
					"3.3.1_Functional_Low_TC014");
			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.verifyDateformat(driver,
					obj.getProfileTabChallengeQuestionDate(),
					"3.3.1_Functional_Low_TC014");

			/*------------  Step6---------- */

			// Verify DB Date as Updated Date waiting for DB method

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC014",
					"3.3.1_Functional_Low_TC014");
			endReporting();
		}

	}

	
	

	/**
	 * TC041_Functional_Challenge questions _master Question
	 * TC042_Functional_Master question _ question changed seperately
	 * TC045_Functional_Change challenge questions screen_ DB verification
	 * TC046_Functional_Change challenge questions screen_ Cancel without saving
	 * 
	 * @param RowNumber
	 * @param Functionality
	 * @param TestCaseID
	 * @param TestCaseDescription
	 * @param Execution
	 * @param Status
	 * @throws Exception
	 */

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC041_Functional_Challenge questions _master Question
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC041(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC041")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Complex")) {

			startReporting("3.3.1_Functional_Complex_TC041_Functional_Challenge questions _master Question");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Complex_TC041");
			/*------------  Step3 ---------- */

			
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			// Select Challenge question and corresponding answers
			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Complex_TC041");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Complex_TC041");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Complex_TC041");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"));

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_ErrorMsg"), obj
					.getProfiletabchallengequestionmsg(),
					"3.3.1_Functional_Complex_TC041");

			/*------------  Step6---------- */

			// verify the Db - QA_MASTER_QUESTION column under SI_QA_CHALLENGE

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC041",
					"3.3.1_Functional_Complex_TC041");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC042_Functional_Master question _ question changed seperately
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC042(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC042")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Complex")) {

			startReporting("3.3.1_Functional_Complex_TC042_Functional_Master question _ question changed seperately");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Complex_TC042");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			// Select Challenge question and corresponding answers
			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Complex_TC042");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Complex_TC042");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Complex_TC042");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"));

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Complex_TC042");

			/*------------  Step6---------- */

			// verify the Db - QA_MASTER_QUESTION column under SI_QA_CHALLENGE

			/*-------------Step7--------*/

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_UpdatedSecurityQuestion2"),
					obj.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Complex_TC042");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_UpdatedAnswer2"));

			// Password field is absent from the screen

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Complex_TC042");

			/** -------------Step 8-------------- */

			// verify the Db - QA_MASTER_QUESTION column under SI_QA_CHALLENGE

			/** -------------Step 9-------------- */

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_UpdatedSecurityQuestion1"),
					obj.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Complex_TC042");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_UpdatedAnswer1"));

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"));

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_ErrorMsg"), obj
					.getProfiletabchallengequestionmsg(),
					"3.3.1_Functional_Complex_TC042");
			/** -------------Step 10-------------- */
			// verify the Db - QA_MASTER_QUESTION column under SI_QA_CHALLENGE

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC042",
					"3.3.1_Functional_Complex_TC042");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC046_Functional_Change challenge questions screen_ Cancel without saving
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC046(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC046")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Complex")) {

			startReporting("3.3.1_Functional_Complex_TC046_Functional_Change challenge questions screen_ Cancel without saving");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Complex_TC046");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step4---------- */
			/*
			 * CommonFunctions.verifyElement(driver, "Challenge  Question 1",
			 * obj.getProfileChallengeqtnonetextbox(),
			 * "3.3.1_Functional_Complex_TC046");
			 * CommonFunctions.verifyElement(driver, "Challenge  Question 2",
			 * obj.getProfileChallengeqtntwotextbox(),
			 * "3.3.1_Functional_Complex_TC046");
			 * CommonFunctions.verifyElement(driver, "Challenge  Question 3",
			 * obj.getProfileChallengeqtnthreetextbox(),
			 * "3.3.1_Functional_Complex_TC046");
			 */

			String s1 = CommonFunctions.getQuestionValue(driver,
					obj.getProfileChallengeqtnonetextbox());

			String s2 = CommonFunctions.getQuestionValue(driver,
					obj.getProfileChallengeqtntwotextbox());

			String s3 = CommonFunctions.getQuestionValue(driver,
					obj.getProfileChallengeqtnthreetextbox());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers
			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Complex_TC046");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Complex_TC046");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Complex_TC046");

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"));

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());

			CommonFunctions.verifyText(driver, s1,
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Complex_TC046");

			CommonFunctions.verifyText(driver, s2,
					obj.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Complex_TC046");

			CommonFunctions.verifyText(driver, s3,
					obj.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Complex_TC046");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC046",
					"3.3.1_Functional_Complex_TC046");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC045_Functional_Change challenge questions screen_ DB verification
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC045(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC041")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Complex")) {

			startReporting("3.3.1_Functional_Complex_TC045_Functional_Change challenge questions screen_ DB verification");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Complex_TC045");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());
			/*------------  Step4---------- */
			/*
			 * CommonFunctions.verifyElement(driver, "Challenge  Question 1",
			 * obj.getProfileChallengeqtnonetextbox(),
			 * "3.3.1_Functional_Complex_TC045");
			 * CommonFunctions.verifyElement(driver, "Challenge  Question 2",
			 * obj.getProfileChallengeqtntwotextbox(),
			 * "3.3.1_Functional_Complex_TC045");
			 * CommonFunctions.verifyElement(driver, "Challenge  Question 3",
			 * obj.getProfileChallengeqtnthreetextbox(),
			 * "3.3.1_Functional_Complex_TC045");
			 */

			String s1 = CommonFunctions.getQuestionValue(driver,
					obj.getProfileChallengeqtnonetextbox());

			String s2 = CommonFunctions.getQuestionValue(driver,
					obj.getProfileChallengeqtntwotextbox());

			String s3 = CommonFunctions.getQuestionValue(driver,
					obj.getProfileChallengeqtnthreetextbox());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnonetextbox(), s1, 17,
					"3.3.1_Functional_Complex_TC045");

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnonetextbox(), s2, 16,
					"3.3.1_Functional_Complex_TC045");

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnonetextbox(), s3, 15,
					"3.3.1_Functional_Complex_TC045");

			/*------------  Step6---------- */
			// Selecting question 5 in Dropdown
			CommonFunctions.selectByIndex(driver, 5,
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Complex_TC045");

			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			/*------------  Step7---------- */
			// Selecting question 18 in Dropdown
			CommonFunctions.selectByIndex(driver, 18,
					obj.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Complex_TC045");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			/*------------  Step8---------- */
			// Selecting question 10 in Dropdown
			CommonFunctions.selectByIndex(driver, 10,
					obj.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Complex_TC045");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*-----Step10------*/

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"));

			
			
			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_ErrorMsg"), obj
					.getProfiletabchallengequestionmsg(),
					"3.3.1_Functional_Complex_TC045");

			/*------Step11---------------*/
			// /Verify in DB that challenge questions have been updated

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC045",
					"3.3.1_Functional_Complex_TC045");
			endReporting();
		}

	}

	

	
	

	


	

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC002_Req Id_325 old login password
	 */
	
	/*
	 * @author=Poorva Dixit
	 * 
	 * TC001_existing GW client_reset login password online
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_34_TC001(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		String testCaseName = "3.4_Functional_Complex_TC001";

		if (TestCaseID.equalsIgnoreCase("TC001")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.4_Functional_Complex")) {

			/*-----------Step1----------*/

			startReporting("3.4_Functional_Complex_TC001_existing GW client_reset login password online");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/* _--------------Step2---- */

			CommonFunctions.ClickButton(driver,obj.getForgotPwdLink());

			/* _--------------Step3---- */

			CommonFunctions.verifyElement(driver, "BMO icon",
					obj.getForgotPwdBMoLogo(), testCaseName);
			CommonFunctions.verifyElement(driver, "Client Sign In Button",
					obj.getForgotPwdClientSignIn(), testCaseName);
			CommonFunctions.verifyElement(driver, "FAQ Link",
					obj.getForgotPwdFAQLink(), testCaseName);

			/* _--------------Step4---- */

			CommonFunctions.verifyElement(driver, "Footer Text",
					obj.getForgotPwdFooter(), testCaseName);

			/*
			 * CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
			 * TestCaseID, Functionality, "p_ErrorMsg"), obj
			 * .getForgotPwdFooter(), "3.4_Functional_Low_TC028");
			 */

			/* _--------------Step5---- */

			CommonFunctions.verifyElement(driver, "Header Text",
					obj.getForgotPwdScreenTitle(), testCaseName);

			CommonFunctions.verifyElement(driver, "Header Sub Text",
					obj.getForgotPwdSubTitle(), testCaseName);

			/* _--------------Step6 ---- */

			driver.findElement(By.xpath(obj.getForgotPwdUserId())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			CommonFunctions.ClickButton(driver,obj.getForgotPwdContinueBtn());

			/* _--------------Step7 ---- */
			/*
			 * CommonFunctions.verifyElement(driver, "Question 1",
			 * obj.getForgotPwdSecurityQuestion1(), testCaseName);
			 * CommonFunctions.verifyElement(driver, "Question 2",
			 * obj.getForgotPwdSecurityQuestion2(), testCaseName);
			 */
			/* _--------------Step8 ---- */



			/* _--------------Step9 ---- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion1(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion1(),
					obj.getForgotPwdAnswer1(), testCaseName);

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion2(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion2(),
					obj.getForgotPwdAnswer2(), testCaseName);

			CommonFunctions.ClickButton(driver,obj.getForgotPwdContinueBtn());

			/*--------------Step10------- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdNewSubTitle(), 50, testCaseName);

			CommonFunctions.verifyElement(driver, "Forgot your password?",
					obj.getForgotPwdNewSubTitle(), testCaseName);

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", testCaseName);

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					testCaseName);

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_ErrorMsg"), obj
					.getPasswordValidationText(), testCaseName);

			// Step 11

			LoginPage.LaunchURL(driver, GatewayEmailURL);
			CommonFunctions.SwitchToChildWindow(driver);
			LoginPage.EmailLogin(rowNumber, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_EmailUserName"),
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_EmailPwd"), TestCaseID);
			Thread.sleep(2000);
			LoginPage.EmailValidation(rowNumber, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Username_Eng"), testCaseName);
			statusPassWithScreenshot(driver, "Screenshot done", Functionality
					+ TestCaseID);

			// Step12
			// Verify new login password is saved in the DB
			// step13
			// Verify the forgot password flow is completed in the DB
			//
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC028",
					testCaseName);
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC005_existing GW client_reset login password online_client closes window
	 * without completing process
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_34_TC005(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		String testCaseName = "3.4_Functional_Complex_TC005";

		if (TestCaseID.equalsIgnoreCase("TC005")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.4_Functional_Complex")) {

			/*-----------Step1----------*/

			startReporting("3.4_Functional_Complex_TC005_existing GW client_reset login password online_client closes window without completing process");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/* _--------------Step2---- */

			CommonFunctions.ClickButton(driver,obj.getForgotPwdLink());

			/* _--------------Step3---- */

			CommonFunctions.verifyElement(driver, "Footer Text",
					obj.getForgotPwdFooter(), testCaseName);

			/* _--------------Step4 ---- */

			driver.findElement(By.xpath(obj.getForgotPwdUserId())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			CommonFunctions.ClickButton(driver,obj.getForgotPwdContinueBtn());

			/* _--------------Step5 ---- */
			/*
			 * CommonFunctions.verifyElement(driver, "Question 1",
			 * obj.getForgotPwdSecurityQuestion1(), testCaseName);
			 * CommonFunctions.verifyElement(driver, "Question 2",
			 * obj.getForgotPwdSecurityQuestion2(), testCaseName);
			 */
			/* _--------------Step6 ---- */

			/* _--------------Step7---- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion1(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion1(),
					obj.getForgotPwdAnswer1(), testCaseName);

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion2(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion2(),
					obj.getForgotPwdAnswer2(), testCaseName);

			CommonFunctions.ClickButton(driver,obj.getForgotPwdContinueBtn());

			/*--------------Step8------ */

			driver.close();
			/*--------------Step9------ */

			// Verify in DB that challenge questions have been deleted from
			// table, and new questions have not been setup
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC028",
					testCaseName);
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC008_existing GW client_reset login password online_ cancel button
	 * challenge question
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_34_TC008(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		String testCaseName = "3.4_Functional_Complex_TC008";

		if (TestCaseID.equalsIgnoreCase("TC008")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.4_Functional_Complex")) {

			/*-----------Step1----------*/

			startReporting("3.4_Functional_Complex_TC008_existing GW client_reset login password online_ cancel button challenge question");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/* _--------------Step2---- */

			CommonFunctions.ClickButton(driver,obj.getForgotPwdLink());

			/* _--------------Step3---- */

			CommonFunctions.verifyElement(driver, "BMO icon",
					obj.getForgotPwdBMoLogo(), testCaseName);
			CommonFunctions.verifyElement(driver, "Client Sign In Button",
					obj.getForgotPwdClientSignIn(), testCaseName);
			CommonFunctions.verifyElement(driver, "FAQ Link",
					obj.getForgotPwdFAQLink(), testCaseName);

			/* _--------------Step4---- */

			CommonFunctions.verifyElement(driver, "Footer Text",
					obj.getForgotPwdFooter(), testCaseName);

			/*
			 * CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
			 * TestCaseID, Functionality, "p_ErrorMsg"), obj
			 * .getForgotPwdFooter(), "3.4_Functional_Low_TC028");
			 */

			driver.findElement(By.xpath(obj.getForgotPwdUserId())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			CommonFunctions.ClickButton(driver,obj.getForgotPwdContinueBtn());

			/* _--------------Step6 ---- */
			/*
			 * CommonFunctions.verifyElement(driver, "Question 1",
			 * obj.getForgotPwdSecurityQuestion1(), testCaseName);
			 * CommonFunctions.verifyElement(driver, "Question 2",
			 * obj.getForgotPwdSecurityQuestion2(), testCaseName);
			 */
			/* _--------------Step7 ---- */

			/* _--------------Step8 ---- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion1(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion1(),
					obj.getForgotPwdAnswer1(), testCaseName);

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion2(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion2(),
					obj.getForgotPwdAnswer2(), testCaseName);

			CommonFunctions.ClickButton(driver,obj.getForgotPwdContinueBtn());

			/*--------------Step10------- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdNewSubTitle(), 50, testCaseName);

			CommonFunctions.verifyElement(driver, "Forgot your password?",
					obj.getForgotPwdNewSubTitle(), testCaseName);

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));

			CommonFunctions.ClickButton(driver,obj.getForgotPwdCancelBtn());

			// Verify in DB that login password has not been updated

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC028",
					testCaseName);
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC020_existing GW client_reset login password_successful reset
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_34_TC020(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		String testCaseName = "3.4_Functional_Complex_TC020";

		if (TestCaseID.equalsIgnoreCase("TC020")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.4_Functional_Complex")) {

			/*-----------Step1----------*/

			startReporting("3.4_Functional_Complex_TC020_existing GW client_reset login password_successful reset");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/* _--------------Step2---- */

			CommonFunctions.ClickButton(driver,obj.getForgotPwdLink());

			/* _--------------Step3---- */

			CommonFunctions.verifyElement(driver, "BMO icon",
					obj.getForgotPwdBMoLogo(), testCaseName);
			CommonFunctions.verifyElement(driver, "Client Sign In Button",
					obj.getForgotPwdClientSignIn(), testCaseName);
			CommonFunctions.verifyElement(driver, "FAQ Link",
					obj.getForgotPwdFAQLink(), testCaseName);

			/* _--------------Step4---- */

			CommonFunctions.verifyElement(driver, "Footer Text",
					obj.getForgotPwdFooter(), testCaseName);

			/*
			 * CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
			 * TestCaseID, Functionality, "p_ErrorMsg"), obj
			 * .getForgotPwdFooter(), "3.4_Functional_Low_TC028");
			 */

			/* _--------------Step5---- */

			CommonFunctions.verifyElement(driver, "Header Text",
					obj.getForgotPwdScreenTitle(), testCaseName);

			CommonFunctions.verifyElement(driver, "Header Sub Text",
					obj.getForgotPwdSubTitle(), testCaseName);

			/* _--------------Step6 ---- */

			driver.findElement(By.xpath(obj.getForgotPwdUserId())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			CommonFunctions.ClickButton(driver,obj.getForgotPwdContinueBtn());

			/* _--------------Step7 ---- */
			/*
			 * CommonFunctions.verifyElement(driver, "Question 1",
			 * obj.getForgotPwdSecurityQuestion1(), testCaseName);
			 * CommonFunctions.verifyElement(driver, "Question 2",
			 * obj.getForgotPwdSecurityQuestion2(), testCaseName);
			 */
			/* _--------------Step8 ---- */

			
			/* _--------------Step9 ---- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion1(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion1(),
					obj.getForgotPwdAnswer1(), testCaseName);

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion2(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion2(),
					obj.getForgotPwdAnswer2(), testCaseName);

			CommonFunctions.ClickButton(driver,obj.getForgotPwdContinueBtn());

			/*--------------Step10------- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdNewSubTitle(), 50, testCaseName);

			CommonFunctions.verifyElement(driver, "Forgot your password?",
					obj.getForgotPwdNewSubTitle(), testCaseName);

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			/*--------------Step11------- */

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", testCaseName);

			/*--------------Step12------- */

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					testCaseName);

			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getChallengeQuestionTitle(), testCaseName);

			CommonFunctions.verifyElement(driver, "Go to login page",
					obj.getEmailConfirmationPageGoToLoginPageButton(),
					testCaseName);

			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"),
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"), "Home", Functionality
							+ TestCaseID);

			// Verify IN DB

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC028",
					testCaseName);
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC023_existing GW client_reset login password_cancel_closes browser
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_34_TC023(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		String testCaseName = "3.4_Functional_Complex_TC023";

		if (TestCaseID.equalsIgnoreCase("TC023")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.4_Functional_Complex")) {

			/*-----------Step1----------*/

			startReporting("3.4_Functional_Complex_TC023_existing GW client_reset login password_cancel_closes browser");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/* _--------------Step2---- */

			CommonFunctions.ClickButton(driver,obj.getForgotPwdLink());

			/* _--------------Step3---- */

			CommonFunctions.verifyElement(driver, "BMO icon",
					obj.getForgotPwdBMoLogo(), testCaseName);
			CommonFunctions.verifyElement(driver, "Client Sign In Button",
					obj.getForgotPwdClientSignIn(), testCaseName);
			CommonFunctions.verifyElement(driver, "FAQ Link",
					obj.getForgotPwdFAQLink(), testCaseName);

			/* _--------------Step4---- */

			CommonFunctions.verifyElement(driver, "Footer Text",
					obj.getForgotPwdFooter(), testCaseName);

			/*
			 * CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
			 * TestCaseID, Functionality, "p_ErrorMsg"), obj
			 * .getForgotPwdFooter(), "3.4_Functional_Low_TC028");
			 */

			/* _--------------Step5---- */

			CommonFunctions.verifyElement(driver, "Header Text",
					obj.getForgotPwdScreenTitle(), testCaseName);

			CommonFunctions.verifyElement(driver, "Header Sub Text",
					obj.getForgotPwdSubTitle(), testCaseName);

			/* _--------------Step6 ---- */

			driver.findElement(By.xpath(obj.getForgotPwdUserId())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			CommonFunctions.ClickButton(driver,obj.getForgotPwdContinueBtn());

			/* _--------------Step7 ---- */
			/*
			 * CommonFunctions.verifyElement(driver, "Question 1",
			 * obj.getForgotPwdSecurityQuestion1(), testCaseName);
			 * CommonFunctions.verifyElement(driver, "Question 2",
			 * obj.getForgotPwdSecurityQuestion2(), testCaseName);
			 */
			/* _--------------Step8 ---- */


			/* _--------------Step9 ---- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion1(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion1(),
					obj.getForgotPwdAnswer1(), testCaseName);

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion2(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion2(),
					obj.getForgotPwdAnswer2(), testCaseName);

			CommonFunctions.ClickButton(driver,obj.getForgotPwdContinueBtn());

			/*--------------Step10------- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdNewSubTitle(), 50, testCaseName);

			CommonFunctions.verifyElement(driver, "Forgot your password?",
					obj.getForgotPwdNewSubTitle(), testCaseName);

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			/*--------------Step11------- */

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", testCaseName);

			/*--------------Step12------- */

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					testCaseName);

			/*--------------Step13------ */
			driver.close();

			// Step 14

			// Step12
			// Verify new login password is saved in the DB// Verify the forgot
			// password flow is completed in the DB
			//
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC028",
					testCaseName);
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC021_existing GW client_reset login password_cancel
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_34_TC021(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		String testCaseName = "3.4_Functional_Complex_TC021";

		if (TestCaseID.equalsIgnoreCase("TC021")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.4_Functional_Complex")) {

			/*-----------Step1----------*/

			startReporting("3.4_Functional_Complex_TC021_existing GW client_reset login password_cancel");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);

			/* _--------------Step2---- */

			CommonFunctions.ClickButton(driver,obj.getForgotPwdLink());

			/* _--------------Step3---- */

			CommonFunctions.verifyElement(driver, "BMO icon",
					obj.getForgotPwdBMoLogo(), testCaseName);
			CommonFunctions.verifyElement(driver, "Client Sign In Button",
					obj.getForgotPwdClientSignIn(), testCaseName);
			CommonFunctions.verifyElement(driver, "FAQ Link",
					obj.getForgotPwdFAQLink(), testCaseName);

			/* _--------------Step4---- */

			CommonFunctions.verifyElement(driver, "Footer Text",
					obj.getForgotPwdFooter(), testCaseName);

			/*
			 * CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
			 * TestCaseID, Functionality, "p_ErrorMsg"), obj
			 * .getForgotPwdFooter(), "3.4_Functional_Low_TC028");
			 */

			/* _--------------Step5---- */

			CommonFunctions.verifyElement(driver, "Header Text",
					obj.getForgotPwdScreenTitle(), testCaseName);

			CommonFunctions.verifyElement(driver, "Header Sub Text",
					obj.getForgotPwdSubTitle(), testCaseName);

			/* _--------------Step6 ---- */

			driver.findElement(By.xpath(obj.getForgotPwdUserId())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			CommonFunctions.ClickButton(driver,obj.getForgotPwdContinueBtn());

			/* _--------------Step7 ---- */
			/*
			 * CommonFunctions.verifyElement(driver, "Question 1",
			 * obj.getForgotPwdSecurityQuestion1(), testCaseName);
			 * CommonFunctions.verifyElement(driver, "Question 2",
			 * obj.getForgotPwdSecurityQuestion2(), testCaseName);
			 */
			/* _--------------Step8 ---- */

			/* _--------------Step9 ---- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion1(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion1(),
					obj.getForgotPwdAnswer1(), testCaseName);

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdSecurityQuestion2(), 50, testCaseName);

			CommonFunctions.getMatchingAnswerforQuestion(driver,
					obj.getForgotPwdSecurityQuestion2(),
					obj.getForgotPwdAnswer2(), testCaseName);

			CommonFunctions.ClickButton(driver,obj.getForgotPwdContinueBtn());

			/*--------------Step10------- */

			CommonFunctions.waitForElement(driver,
					obj.getForgotPwdNewSubTitle(), 50, testCaseName);

			CommonFunctions.verifyElement(driver, "Forgot your password?",
					obj.getForgotPwdNewSubTitle(), testCaseName);

			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					testCaseName);
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", testCaseName);

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_NewPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					testCaseName);

			
			CommonFunctions.ClickButton(driver,obj.getForgotPwdCancelBtn());
			CommonFunctions.verifyElement(driver, "UserName",
					obj.getUserName(), testCaseName);

			// Verify in DB that the login password IS NOT updated
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC028",
					testCaseName);
			endReporting();
		}

	}
	
	
	//NEWLY UPDATED SCRIPTS 
	
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC028(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC028")&& Execution.equalsIgnoreCase("Y")&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting(TestCaseDescription);
			accountNumber=ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Username_Eng");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			LoginPage.Login(rowNumber, accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"eServices", Functionality + TestCaseID);
			CommonFunctions.verifyText(driver, "Profile",obj.getAccountSetting_ProfileTab(),"3.3.1_Functional_Medium_TC028");
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());
			//click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,obj.getEditChallengeqtnbtn(), 40,	"3.3.1_Functional_Low_TC005");
			CommonFunctions.verifyText(driver, "Edit",obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");
			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());
/*		CommonFunctions.selectByIndex(driver, 8, obj.getProfileChallengeqtntwotextbox(), TestCaseDescription);
			
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Answer2"));
		//	CommonFunctions.select(driver, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_SecurityQuestion3"), obj.getProfileChallengeqtnthreetextbox(),"3.3.1_Functional_Medium_TC028");
			CommonFunctions.selectByIndex(driver, 15, obj.getProfileChallengeqtnthreetextbox(), TestCaseDescription);
			
			driver.findElement(By.xpath(obj.getProfileChallengeansthreetextbox())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Answer3"));
			
			driver.findElement(By.xpath("//input[@id='login-password']")).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Password_Eng"));

			
			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());*/
			CommonFunctions.selectByIndex(driver, 10, obj.getProfileChallengeqtnonetextbox(), TestCaseDescription);
			System.out.println("check 1");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox())).sendKeys("p_UpdatedAnswer1");
			System.out.println("check 2");
			CommonFunctions.SetText(driver, "//input[@id='login-password']", "A1aaaaaa");
			//driver.findElement(By.xpath()).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Password_Eng"));
			System.out.println("check 3:"+ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Password_Eng"));
			CommonFunctions.Click(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyElement(driver,  ReadExcelFile.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),obj.getProfiletabchallengequestionmsg(),"3.3.1_Functional_Medium_TC028");
			CommonFunctions.scrolltoElement(driver, obj.getProfiletabchallengequestionmsg());
			BaseClass.statusPassWithScreenshot(driver, "Screen ",TestCaseDescription);
				endReporting();
		}
	}	

	
	
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC029(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC029")&& Execution.equalsIgnoreCase("Y")&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting(TestCaseDescription);
			accountNumber=ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Username_Eng");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			LoginPage.Login(rowNumber, accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"eServices", Functionality + TestCaseID);
			CommonFunctions.verifyText(driver, "Profile",obj.getAccountSetting_ProfileTab(),"3.3.1_Functional_Medium_TC028");
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());
			//click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,obj.getEditChallengeqtnbtn(), 40,	"3.3.1_Functional_Low_TC005");
			CommonFunctions.verifyText(driver, "Edit",obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");
			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());
	CommonFunctions.selectByIndex(driver, 10, obj.getProfileChallengeqtnonetextbox(), TestCaseDescription);
			System.out.println("check 1");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox())).sendKeys("p_UpdatedAnswer1");
			System.out.println("check 2");
			CommonFunctions.SetText(driver, "//input[@id='login-password']", "A1aaaaaa");
			//driver.findElement(By.xpath()).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Password_Eng"));
			System.out.println("check 3:"+ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Password_Eng"));
			CommonFunctions.Click(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyElement(driver,  ReadExcelFile.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),obj.getProfiletabchallengequestionmsg(),"3.3.1_Functional_Medium_TC028");
			CommonFunctions.scrolltoElement(driver, obj.getProfiletabchallengequestionmsg());
			BaseClass.statusPassWithScreenshot(driver, "Screen ",TestCaseDescription);
				endReporting();
		}
	}	

	@Test(dataProvider = "DriverSheet")
	public void test_331_TC030(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC030")&& Execution.equalsIgnoreCase("Y")&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting(TestCaseDescription);
			accountNumber=ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Username_Eng");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			LoginPage.Login(rowNumber, accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"eServices", Functionality + TestCaseID);
			CommonFunctions.verifyText(driver, "Profile",obj.getAccountSetting_ProfileTab(),"3.3.1_Functional_Medium_TC028");
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());
			//click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,obj.getEditChallengeqtnbtn(), 40,	"3.3.1_Functional_Low_TC005");
			CommonFunctions.verifyText(driver, "Edit",obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");
			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());
		CommonFunctions.selectByIndex(driver, 10, obj.getProfileChallengeqtnonetextbox(), TestCaseDescription);
			System.out.println("check 1");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox())).sendKeys("p_UpdatedAnswer1");
			System.out.println("check 2");
			CommonFunctions.SetText(driver, "//input[@id='login-password']", "A1aaaaaa");
			//driver.findElement(By.xpath()).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Password_Eng"));
			System.out.println("check 3:"+ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Password_Eng"));
			CommonFunctions.Click(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyElement(driver,  ReadExcelFile.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),obj.getProfiletabchallengequestionmsg(),"3.3.1_Functional_Medium_TC028");
			CommonFunctions.scrolltoElement(driver, obj.getProfiletabchallengequestionmsg());
			BaseClass.statusPassWithScreenshot(driver, "Screen ",TestCaseDescription);
				endReporting();
		}
	}	

	@Test(dataProvider = "DriverSheet")
	public void test_331_TC031(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC031")&& Execution.equalsIgnoreCase("Y")&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting(TestCaseDescription);
			accountNumber=ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Username_Eng");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			LoginPage.Login(rowNumber, accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"eServices", Functionality + TestCaseID);
			CommonFunctions.verifyText(driver, "Profile",obj.getAccountSetting_ProfileTab(),"3.3.1_Functional_Medium_TC028");
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());
			//click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,obj.getEditChallengeqtnbtn(), 40,	"3.3.1_Functional_Low_TC005");
			CommonFunctions.verifyText(driver, "Edit",obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");
			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());
		CommonFunctions.selectByIndex(driver, 10, obj.getProfileChallengeqtnonetextbox(), TestCaseDescription);
			System.out.println("check 1");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox())).sendKeys("p_UpdatedAnswer1");
			System.out.println("check 2");
			CommonFunctions.SetText(driver, "//input[@id='login-password']", "A1aaaaaa");
			//driver.findElement(By.xpath()).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Password_Eng"));
			System.out.println("check 3:"+ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Password_Eng"));
			CommonFunctions.Click(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyElement(driver,  ReadExcelFile.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),obj.getProfiletabchallengequestionmsg(),"3.3.1_Functional_Medium_TC028");
			CommonFunctions.scrolltoElement(driver, obj.getProfiletabchallengequestionmsg());
			BaseClass.statusPassWithScreenshot(driver, "Screen ",TestCaseDescription);
				endReporting();
		}
	}	

	@Test(dataProvider = "DriverSheet")
	public void test_331_TC032(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC032")&& Execution.equalsIgnoreCase("Y")&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting(TestCaseDescription);
			accountNumber=ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Username_Eng");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			LoginPage.Login(rowNumber, accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"eServices", Functionality + TestCaseID);
			CommonFunctions.verifyText(driver, "Profile",obj.getAccountSetting_ProfileTab(),"3.3.1_Functional_Medium_TC028");
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());
			//click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,obj.getEditChallengeqtnbtn(), 40,	"3.3.1_Functional_Low_TC005");
			CommonFunctions.verifyText(driver, "Edit",obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");
			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			CommonFunctions.selectByIndex(driver, 10, obj.getProfileChallengeqtnonetextbox(), TestCaseDescription);
			System.out.println("check 1");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox())).sendKeys("p_UpdatedAnswer1");
			System.out.println("check 2");
			CommonFunctions.SetText(driver, "//input[@id='login-password']", "A1aaaaaa");
			//driver.findElement(By.xpath()).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Password_Eng"));
			System.out.println("check 3:"+ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Password_Eng"));
			CommonFunctions.Click(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyElement(driver,  ReadExcelFile.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),obj.getProfiletabchallengequestionmsg(),"3.3.1_Functional_Medium_TC028");
			CommonFunctions.scrolltoElement(driver, obj.getProfiletabchallengequestionmsg());
			BaseClass.statusPassWithScreenshot(driver, "Screen",TestCaseDescription);
				endReporting();
		}
	}	

	
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC033(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC033")&& Execution.equalsIgnoreCase("Y")&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting(TestCaseDescription);
			accountNumber=ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Username_Eng");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			LoginPage.Login(rowNumber, accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"eServices", Functionality + TestCaseID);
			CommonFunctions.verifyText(driver, "Profile",obj.getAccountSetting_ProfileTab(),"3.3.1_Functional_Medium_TC028");
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());
			//click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,obj.getEditChallengeqtnbtn(), 40,	"3.3.1_Functional_Low_TC005");
			CommonFunctions.verifyText(driver, "Edit",obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");
			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			CommonFunctions.selectByIndex(driver, 10, obj.getProfileChallengeqtnonetextbox(), TestCaseDescription);
			System.out.println("check 1");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox())).sendKeys("p_UpdatedAnswer1");
			System.out.println("check 2");
			CommonFunctions.SetText(driver, "//input[@id='login-password']", "A1aaaaaa");
			//driver.findElement(By.xpath()).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Password_Eng"));
			System.out.println("check 3:"+ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Password_Eng"));
			CommonFunctions.Click(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyElement(driver,  ReadExcelFile.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),obj.getProfiletabchallengequestionmsg(),"3.3.1_Functional_Medium_TC028");
			CommonFunctions.scrolltoElement(driver, obj.getProfiletabchallengequestionmsg());
			BaseClass.statusPassWithScreenshot(driver, "Screen",TestCaseDescription);
					endReporting();
		}
	}
	
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC034a(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC034a")&& Execution.equalsIgnoreCase("Y")&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting(TestCaseDescription);
			accountNumber=ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Username_Eng");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			LoginPage.Login(rowNumber, accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"eServices", Functionality + TestCaseID);
			CommonFunctions.verifyText(driver, "Profile",obj.getAccountSetting_ProfileTab(),"3.3.1_Functional_Medium_TC028");
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());
			//click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,obj.getEditChallengeqtnbtn(), 40,	"3.3.1_Functional_Low_TC005");
			CommonFunctions.verifyText(driver, "Edit",obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");
			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			CommonFunctions.selectByIndex(driver, 10, obj.getProfileChallengeqtnonetextbox(), TestCaseDescription);
			System.out.println("check 1");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox())).sendKeys("p_UpdatedAnswer1");
			System.out.println("check 2");
			CommonFunctions.SetText(driver, "//input[@id='login-password']", "A1aaaaaa");
			//driver.findElement(By.xpath()).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Password_Eng"));
			System.out.println("check 3:"+ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Password_Eng"));
			CommonFunctions.Click(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyElement(driver,  ReadExcelFile.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),obj.getProfiletabchallengequestionmsg(),"3.3.1_Functional_Medium_TC028");
			CommonFunctions.scrolltoElement(driver, obj.getProfiletabchallengequestionmsg());
			BaseClass.statusPassWithScreenshot(driver, "Screen",TestCaseDescription);
				endReporting();
		}
	}
	
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC034b(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC034b")&& Execution.equalsIgnoreCase("Y")&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting(TestCaseDescription);
			accountNumber=ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Username_Eng");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			LoginPage.Login(rowNumber, accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"eServices", Functionality + TestCaseID);
			CommonFunctions.verifyText(driver, "Profile",obj.getAccountSetting_ProfileTab(),"3.3.1_Functional_Medium_TC028");
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());
			//click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,obj.getEditChallengeqtnbtn(), 40,	"3.3.1_Functional_Low_TC005");
			CommonFunctions.verifyText(driver, "Edit",obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");
			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			CommonFunctions.selectByIndex(driver, 10, obj.getProfileChallengeqtnonetextbox(), TestCaseDescription);
			System.out.println("check 1");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox())).sendKeys("p_UpdatedAnswer1");
			System.out.println("check 2");
			CommonFunctions.SetText(driver, "//input[@id='login-password']", "A1aaaaaa");
			//driver.findElement(By.xpath()).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Password_Eng"));
			System.out.println("check 3:"+ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Password_Eng"));
			CommonFunctions.Click(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyElement(driver,  ReadExcelFile.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),obj.getProfiletabchallengequestionmsg(),"3.3.1_Functional_Medium_TC028");
			CommonFunctions.scrolltoElement(driver, obj.getProfiletabchallengequestionmsg());
			BaseClass.statusPassWithScreenshot(driver, "Screen",TestCaseDescription);
				endReporting();
		}

	}
	
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC035(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC035")&& Execution.equalsIgnoreCase("Y")&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting(TestCaseDescription);
			accountNumber=ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Username_Eng");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			LoginPage.Login(rowNumber, accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"eServices", Functionality + TestCaseID);
			CommonFunctions.verifyText(driver, "Profile",obj.getAccountSetting_ProfileTab(),"3.3.1_Functional_Medium_TC028");
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());
			//click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,obj.getEditChallengeqtnbtn(), 40,	"3.3.1_Functional_Low_TC005");
			CommonFunctions.verifyText(driver, "Edit",obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");
			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			CommonFunctions.selectByIndex(driver, 10, obj.getProfileChallengeqtnonetextbox(), TestCaseDescription);
			System.out.println("check 1");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox())).sendKeys("p_UpdatedAnswer1");
			System.out.println("check 2");
			CommonFunctions.SetText(driver, "//input[@id='login-password']", "A1aaaaaa");
			//driver.findElement(By.xpath()).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Password_Eng"));
			System.out.println("check 3:"+ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Password_Eng"));
			CommonFunctions.Click(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyElement(driver,  ReadExcelFile.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),obj.getProfiletabchallengequestionmsg(),"3.3.1_Functional_Medium_TC028");
			CommonFunctions.scrolltoElement(driver, obj.getProfiletabchallengequestionmsg());
			BaseClass.statusPassWithScreenshot(driver, "Screen ",TestCaseDescription);
			endReporting();
		}
	}
	
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC038(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC038")&& Execution.equalsIgnoreCase("Y")&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting(TestCaseDescription);
			accountNumber=ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Username_Eng");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			LoginPage.Login(rowNumber, accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"eServices", Functionality + TestCaseID);
			CommonFunctions.verifyText(driver, "Profile",obj.getAccountSetting_ProfileTab(),"3.3.1_Functional_Medium_TC028");
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());
			//click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,obj.getEditChallengeqtnbtn(), 40,	"3.3.1_Functional_Low_TC005");
			CommonFunctions.verifyText(driver, "Edit",obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");
			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());
			
			CommonFunctions.selectByIndex(driver, 10, obj.getProfileChallengeqtnonetextbox(), TestCaseDescription);
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Answer1"));
			
			CommonFunctions.selectByIndex(driver, 8, obj.getProfileChallengeqtntwotextbox(), TestCaseDescription);
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Answer2"));
			
			CommonFunctions.selectByIndex(driver, 15, obj.getProfileChallengeqtnthreetextbox(), TestCaseDescription);
			driver.findElement(By.xpath(obj.getProfileChallengeansthreetextbox())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Answer3"));
			
			driver.findElement(By.xpath("//input[@id='login-password']")).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Password_Eng"));
			
			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());
		
			CommonFunctions.verifyText(driver,  ReadExcelFile.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),obj.getProfiletabchallengequestionmsg(),"3.3.1_Functional_Medium_TC028");
			CommonFunctions.scrolltoElement(driver, obj.getProfiletabchallengequestionmsg());
			BaseClass.statusPassWithScreenshot(driver, "Screen ",TestCaseDescription);
				endReporting();
		}
	}	
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC039(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC039")&& Execution.equalsIgnoreCase("Y")&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting(TestCaseDescription);
			accountNumber=ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Username_Eng");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			LoginPage.Login(rowNumber, accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"eServices", Functionality + TestCaseID);
			CommonFunctions.verifyText(driver, "Profile",obj.getAccountSetting_ProfileTab(),"3.3.1_Functional_Medium_TC028");
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());
			//click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,obj.getEditChallengeqtnbtn(), 40,	"3.3.1_Functional_Low_TC005");
			CommonFunctions.verifyText(driver, "Edit",obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");
			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());
			
			CommonFunctions.selectByIndex(driver,15, obj.getProfileChallengeqtnonetextbox(), TestCaseDescription);
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Answer1"));
			
			CommonFunctions.selectByIndex(driver, 9, obj.getProfileChallengeqtntwotextbox(), TestCaseDescription);
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Answer2"));
			
			CommonFunctions.selectByIndex(driver, 11, obj.getProfileChallengeqtnthreetextbox(), TestCaseDescription);
			driver.findElement(By.xpath(obj.getProfileChallengeansthreetextbox())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Answer3"));
			
			driver.findElement(By.xpath("//input[@id='login-password']")).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Password_Eng"));
			
			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());
		
			CommonFunctions.verifyText(driver,  ReadExcelFile.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),obj.getProfiletabchallengequestionmsg(),"3.3.1_Functional_Medium_TC028");
			CommonFunctions.scrolltoElement(driver, obj.getProfiletabchallengequestionmsg());
			BaseClass.statusPassWithScreenshot(driver, "Screen ",TestCaseDescription);
				endReporting();
		}
	}	

	
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC040(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC040")&& Execution.equalsIgnoreCase("Y")&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting(TestCaseDescription);
			accountNumber=ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Username_Eng");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			LoginPage.Login(rowNumber, accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"eServices", Functionality + TestCaseID);
			CommonFunctions.verifyText(driver, "Profile",obj.getAccountSetting_ProfileTab(),"3.3.1_Functional_Medium_TC028");
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());
			//click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,obj.getEditChallengeqtnbtn(), 40,	"3.3.1_Functional_Low_TC005");
			CommonFunctions.verifyText(driver, "Edit",obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");
			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());
			
			CommonFunctions.selectByIndex(driver,15, obj.getProfileChallengeqtnonetextbox(), TestCaseDescription);
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Answer1"));
			
			CommonFunctions.selectByIndex(driver, 9, obj.getProfileChallengeqtntwotextbox(), TestCaseDescription);
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Answer2"));
			
			CommonFunctions.selectByIndex(driver, 11, obj.getProfileChallengeqtnthreetextbox(), TestCaseDescription);
			driver.findElement(By.xpath(obj.getProfileChallengeansthreetextbox())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Answer3"));
			
			driver.findElement(By.xpath("//input[@id='login-password']")).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Password_Eng"));
			
			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());
		
			CommonFunctions.verifyText(driver,  ReadExcelFile.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),obj.getProfiletabchallengequestionmsg(),"3.3.1_Functional_Medium_TC028");
			CommonFunctions.scrolltoElement(driver, obj.getProfiletabchallengequestionmsg());
			BaseClass.statusPassWithScreenshot(driver, "Screen ",TestCaseDescription);
				endReporting();
		}
	}	

	
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC044(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC044")&& Execution.equalsIgnoreCase("Y")&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting(TestCaseDescription);
			accountNumber=ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Username_Eng");
			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			LoginPage.Login(rowNumber, accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"eServices", Functionality + TestCaseID);
			CommonFunctions.verifyText(driver, "Profile",obj.getAccountSetting_ProfileTab(),"3.3.1_Functional_Medium_TC028");
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());
			//click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,obj.getEditChallengeqtnbtn(), 40,	"3.3.1_Functional_Low_TC005");
			CommonFunctions.verifyText(driver, "Edit",obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");
			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());
			
			CommonFunctions.selectByIndex(driver,15, obj.getProfileChallengeqtnonetextbox(), TestCaseDescription);
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Answer1"));
			
			CommonFunctions.selectByIndex(driver, 9, obj.getProfileChallengeqtntwotextbox(), TestCaseDescription);
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Answer2"));
			
			CommonFunctions.selectByIndex(driver, 11, obj.getProfileChallengeqtnthreetextbox(), TestCaseDescription);
			driver.findElement(By.xpath(obj.getProfileChallengeansthreetextbox())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Answer3"));
			
			driver.findElement(By.xpath("//input[@id='login-password']")).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Password_Eng"));
			
			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());
		
			CommonFunctions.verifyText(driver,  ReadExcelFile.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),obj.getProfiletabchallengequestionmsg(),"3.3.1_Functional_Medium_TC028");
			CommonFunctions.scrolltoElement(driver, obj.getProfiletabchallengequestionmsg());
			BaseClass.statusPassWithScreenshot(driver, "Screen ",TestCaseDescription);
				endReporting();
		}
	}	

	/**
	 * 
	 * @throws Exception
	 */
	@AfterTest
	public void afterTest() throws Exception {

	}

	@AfterSuite
	public void afterSuite() throws Exception {
		closeReporting();
		LoginPage.closeDriver();
		WindowsUtils.killByName("IEDriverServer.exe");
	}
}
