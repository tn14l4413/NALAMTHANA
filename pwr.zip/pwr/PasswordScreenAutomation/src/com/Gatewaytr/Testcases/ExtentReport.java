/**
 * 
 */
package com.Gatewaytr.Testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import java.awt.Image;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.List;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import com.Gateway.GlobalParameters.BaseClass;
import com.Gateway.GlobalParameters.FetchingOR;
import com.Gatewaytr.ExcelFile.ReadExcelFile;
import com.Gatewaytr.pages.Admin;
import com.Gatewaytr.pages.CommonFunctions;
import com.Gatewaytr.pages.DataBase;
import com.Gatewaytr.pages.LoginPage;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.model.Screencast;



/**
 * @author craja01
 * TestNG Class
 *
 */
public class ExtentReport extends BaseClass {

	
	WebDriver driver;
	ExtentReports extent;
	ExtentTest logger;
	public FetchingOR obj=null;
	public String fileName="C:\\GatewayPasswordReset\\Configuration\\ConfigurationPage.property";
	public String fileName_French="C:\\GatewayPasswordReset\\Configuration\\ConfigurationPage_French.property";
	File src = new File("C:\\GatewayPasswordReset\\DriverSheet\\DriveSheetSample.xls");
	int rowNumber;
	
	@DataProvider(name="DriverSheet")
	public Object[][] driverSheetData() {
		Object[][] arrayObject = getExcelData("C:\\GatewayPasswordReset\\DriverSheet\\DriveSheetSample.xls","Sheet1");
		return arrayObject;
	}

	public String[][] getExcelData(String fileName, String sheetName) {
		String[][] arrayExcelData = null;
		try {
			FileInputStream fs = new FileInputStream(fileName);
			Workbook wb = Workbook.getWorkbook(fs);
			Sheet sh = wb.getSheet(sheetName);

			int totalNoOfCols = sh.getColumns();
			int totalNoOfRows = sh.getRows();
			
			arrayExcelData = new String[totalNoOfRows-1][totalNoOfCols];
			
			for (int i= 1 ; i < totalNoOfRows; i++) 
			{
				
				for (int j=0; j < totalNoOfCols; j++) {
					arrayExcelData[i-1][j] = sh.getCell(j, i).getContents();
					
				}

			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
			e.printStackTrace();
		} catch (BiffException e) {
			e.printStackTrace();
		}
		return arrayExcelData;
	}	

	
@BeforeSuite
public void beforeSuite() throws Exception
{
	 	     
     setReport();
    
}
String Browser,LanguageSettings;
String accountNumber;

String tempPassword;
@BeforeTest
@Parameters({ "browserName" ,"language"})
public void beforeTest(String browserName,String language) throws Exception
{
	
	Browser=browserName;
	LanguageSettings=language;
	System.out.println("*****************"+Browser);
	System.out.println("*****************"+LanguageSettings);
	if(LanguageSettings.equalsIgnoreCase("English"))
	{
	obj = new FetchingOR(fileName);
	}
	else
	{
		obj = new FetchingOR(fileName_French);
	}
	ReadExcelFile.setExcelFile(filePath, LanguageSettings);
	driver=LoginPage.LaunchBrowser(Browser);
	
}


/*----- Author - Chinnu Rajaram -----*/

@Test(dataProvider="DriverSheet")
public void test_322_TC025(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC025")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC025_Create a new Login password screen_Password updated succesfully");
		
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        String tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
        LoginPage.LaunchURL(driver,GatewayQAURL);
        System.out.println("*****************"+ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyText(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC025");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	   	CommonFunctions.checkFontColour(driver,obj.getMinimum1lowerCase(), "rgba(0, 138, 0, 1)","Minimum 1 Lower Case Check","3.2.2_Functional_Low_TC025");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1upperCase(), "rgba(0, 138, 0, 1)","Minimum 2 Upper Case Check","3.2.2_Functional_Low_TC025");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1Number(), "rgba(0, 138, 0, 1)","Minimum 1 Number  Check","3.2.2_Functional_Low_TC025");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)","Minimum 8 Characters Check","3.2.2_Functional_Low_TC025");
       	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
      	CommonFunctions.checkFontColour(driver,obj.getConfirmPasswords(), "rgba(0, 138, 0, 1)","Confirm Password Check","3.2.2_Functional_Low_TC025");
    //   Thread.sleep(6000);
  
      	
      	CommonFunctions.ClickButton(driver,obj.getContinueButton());
        //CommonFunctions.verifyElement(driver,"Challenge Questions Page Displayed", obj.getChallengeQuestionTitle(),"3.2.2_Functional_Low_TC025" );
        BaseClass.statusPassWithScreenshot(driver, "Security Question Screen",TestCaseDescription);

        endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_322_TC026(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC026")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC026_Create a new Login password screen_Password updated succesfully");
		
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        String tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyText(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC026");
      	System.out.println("my conetnst from test data:"+ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys("Aaaaaaa12");
   	   	CommonFunctions.checkFontColour(driver,obj.getMinimum1lowerCase(), "rgba(0, 138, 0, 1)","Minimum 1 Lower Case Check","3.2.2_Functional_Low_TC026");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1upperCase(), "rgba(0, 138, 0, 1)","Minimum 2 Upper Case Check","3.2.2_Functional_Low_TC026");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1Number(), "rgba(0, 138, 0, 1)","Minimum 1 Number  Check","3.2.2_Functional_Low_TC026");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)","Minimum 8 Characters Check","3.2.2_Functional_Low_TC026");
       	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys("Aaaaaaa12");
      	CommonFunctions.checkFontColour(driver,obj.getConfirmPasswords(), "rgba(0, 138, 0, 1)","Confirm Password Check","3.2.2_Functional_Low_TC026");
      CommonFunctions.ClickButton(driver,obj.getContinueButton());
 //   CommonFunctions.verifyElement(driver,"Challenge Questions Page Displayed", obj.getChallengeQuestionTitle(), );
        BaseClass.statusPassWithScreenshot(driver, "Security Question Screen",TestCaseDescription);

        endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_322_TC027(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC027")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC027_Create a new Login password screen_Password updated succesfully");
		
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        String tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyText(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC025");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	   	CommonFunctions.checkFontColour(driver,obj.getMinimum1lowerCase(), "rgba(0, 138, 0, 1)","Minimum 1 Lower Case Check","3.2.2_Functional_Low_TC027");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1upperCase(), "rgba(0, 138, 0, 1)","Minimum 2 Upper Case Check","3.2.2_Functional_Low_TC027");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1Number(), "rgba(0, 138, 0, 1)","Minimum 1 Number  Check","3.2.2_Functional_Low_TC027");
      		CommonFunctions.checkFontColour(driver,obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)","Minimum 8 Characters Check","3.2.2_Functional_Low_TC027");
      	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
      	CommonFunctions.checkFontColour(driver,obj.getConfirmPasswords(), "rgba(0, 138, 0, 1)","Confirm Password Check","3.2.2_Functional_Low_TC027");
        CommonFunctions.ClickButton(driver,obj.getContinueButton());
        BaseClass.statusPassWithScreenshot(driver, "Security Question Screen",TestCaseDescription);
       
      //  CommonFunctions.verifyElement(driver,"Challenge Questions Page Displayed", obj.getChallengeQuestionTitle(),"3.2.2_Functional_Low_TC025" );
		endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_322_TC028(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription,  String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC028")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC028_Create a new Login password screen_Password updated succesfully");
		
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        String tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyText(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC028");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	   	CommonFunctions.checkFontColour(driver,obj.getMinimum1lowerCase(), "rgba(0, 138, 0, 1)","Minimum 1 Lower Case Check","3.2.2_Functional_Low_TC028");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1upperCase(), "rgba(0, 138, 0, 1)","Minimum 2 Upper Case Check","3.2.2_Functional_Low_TC028");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1Number(), "rgba(0, 138, 0, 1)","Minimum 1 Number  Check","3.2.2_Functional_Low_TC028");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)","Minimum 8 Characters Check","3.2.2_Functional_Low_TC028");
      	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
      	CommonFunctions.checkFontColour(driver,obj.getConfirmPasswords(), "rgba(0, 138, 0, 1)","Confirm Password Check","3.2.2_Functional_Low_TC028");
        CommonFunctions.ClickButton(driver,obj.getContinueButton());
        BaseClass.statusPassWithScreenshot(driver, "Security Question Screen",TestCaseDescription);
       
      //  CommonFunctions.verifyElement(driver,"Challenge Questions Page Displayed", obj.getChallengeQuestionTitle(),"3.2.2_Functional_Low_TC025" );
		endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_322_TC029(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription,  String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC029")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC029_Create a new Login password screen_Password updated succesfully");
		
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        String tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyText(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC029");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	   	CommonFunctions.checkFontColour(driver,obj.getMinimum1lowerCase(), "rgba(0, 138, 0, 1)","Minimum 1 Lower Case Check","3.2.2_Functional_Low_TC029");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1upperCase(), "rgba(0, 138, 0, 1)","Minimum 2 Upper Case Check","3.2.2_Functional_Low_TC029");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1Number(), "rgba(0, 138, 0, 1)","Minimum 1 Number  Check","3.2.2_Functional_Low_TC029");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)","Minimum 8 Characters Check","3.2.2_Functional_Low_TC029");
      	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
      	CommonFunctions.checkFontColour(driver,obj.getConfirmPasswords(), "rgba(0, 138, 0, 1)","Confirm Password Check","3.2.2_Functional_Low_TC029");
        CommonFunctions.ClickButton(driver,obj.getContinueButton());
        BaseClass.statusPassWithScreenshot(driver, "Security Question Screen",TestCaseDescription);
       
      //  CommonFunctions.verifyElement(driver,"Challenge Questions Page Displayed", obj.getChallengeQuestionTitle(),"3.2.2_Functional_Low_TC025" );
		endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_322_TC030(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC030")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC030_Create a new Login password screen_Password updated succesfully");
		
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        String tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyText(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC030");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	   	CommonFunctions.checkFontColour(driver,obj.getMinimum1lowerCase(), "rgba(0, 138, 0, 1)","Minimum 1 Lower Case Check","3.2.2_Functional_Low_TC030");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1upperCase(), "rgba(0, 138, 0, 1)","Minimum 2 Upper Case Check","3.2.2_Functional_Low_TC030");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1Number(), "rgba(0, 138, 0, 1)","Minimum 1 Number  Check","3.2.2_Functional_Low_TC030");
      		CommonFunctions.checkFontColour(driver,obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)","Minimum 8 Characters Check","3.2.2_Functional_Low_TC030");
      	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
      	CommonFunctions.checkFontColour(driver,obj.getConfirmPasswords(), "rgba(0, 138, 0, 1)","Confirm Password Check","3.2.2_Functional_Low_TC030");
        CommonFunctions.ClickButton(driver,obj.getContinueButton());
        BaseClass.statusPassWithScreenshot(driver, "Security Question Screen",TestCaseDescription);
       
      //  CommonFunctions.verifyElement(driver,"Challenge Questions Page Displayed", obj.getChallengeQuestionTitle(),"3.2.2_Functional_Low_TC025" );
		endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_322_TC031(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC031")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC031_Create a new Login password screen_Password updated succesfully");
		
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        String tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyText(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC031");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	   	CommonFunctions.checkFontColour(driver,obj.getMinimum1lowerCase(), "rgba(0, 138, 0, 1)","Minimum 1 Lower Case Check","3.2.2_Functional_Low_TC031");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1upperCase(), "rgba(0, 138, 0, 1)","Minimum 2 Upper Case Check","3.2.2_Functional_Low_TC031");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1Number(), "rgba(0, 138, 0, 1)","Minimum 1 Number  Check","3.2.2_Functional_Low_TC031");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)","Minimum 8 Characters Check","3.2.2_Functional_Low_TC031");
      	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
      	CommonFunctions.checkFontColour(driver,obj.getConfirmPasswords(), "rgba(0, 138, 0, 1)","Confirm Password Check","3.2.2_Functional_Low_TC031");
        CommonFunctions.ClickButton(driver,obj.getContinueButton());
        BaseClass.statusPassWithScreenshot(driver, "Security Question Screen",TestCaseDescription);
       
      //  CommonFunctions.verifyElement(driver,"Challenge Questions Page Displayed", obj.getChallengeQuestionTitle(),"3.2.2_Functional_Low_TC025" );
		endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_322_TC032(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC032")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC032_Create a new Login password screen_Password updated succesfully");
		
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        String tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyText(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC032");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	   	CommonFunctions.checkFontColour(driver,obj.getMinimum1lowerCase(), "rgba(0, 138, 0, 1)","Minimum 1 Lower Case Check","3.2.2_Functional_Low_TC032");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1upperCase(), "rgba(0, 138, 0, 1)","Minimum 2 Upper Case Check","3.2.2_Functional_Low_TC032");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1Number(), "rgba(0, 138, 0, 1)","Minimum 1 Number  Check","3.2.2_Functional_Low_TC032");
      		CommonFunctions.checkFontColour(driver,obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)","Minimum 8 Characters Check","3.2.2_Functional_Low_TC032");
      	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
      	CommonFunctions.checkFontColour(driver,obj.getConfirmPasswords(), "rgba(0, 138, 0, 1)","Confirm Password Check","3.2.2_Functional_Low_TC032");
        CommonFunctions.ClickButton(driver,obj.getContinueButton());
        BaseClass.statusPassWithScreenshot(driver, "Security Question Screen",TestCaseDescription);
       
      //  CommonFunctions.verifyElement(driver,"Challenge Questions Page Displayed", obj.getChallengeQuestionTitle(),"3.2.2_Functional_Low_TC025" );
		endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_322_TC033(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription,  String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC033")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC033_Create a new Login password screen_Password updated succesfully");
		
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        String tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyText(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC033");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	   	CommonFunctions.checkFontColour(driver,obj.getMinimum1lowerCase(), "rgba(0, 138, 0, 1)","Minimum 1 Lower Case Check","3.2.2_Functional_Low_TC033");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1upperCase(), "rgba(0, 138, 0, 1)","Minimum 2 Upper Case Check","3.2.2_Functional_Low_TC033");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1Number(), "rgba(0, 138, 0, 1)","Minimum 1 Number  Check","3.2.2_Functional_Low_TC033");
      		CommonFunctions.checkFontColour(driver,obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)","Minimum 8 Characters Check","3.2.2_Functional_Low_TC033");
      	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
      	CommonFunctions.checkFontColour(driver,obj.getConfirmPasswords(), "rgba(0, 138, 0, 1)","Confirm Password Check","3.2.2_Functional_Low_TC033");
        CommonFunctions.ClickButton(driver,obj.getContinueButton());
        BaseClass.statusPassWithScreenshot(driver, "Security Question Screen",TestCaseDescription);
       
      //  CommonFunctions.verifyElement(driver,"Challenge Questions Page Displayed", obj.getChallengeQuestionTitle(),"3.2.2_Functional_Low_TC025" );
		endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_322_TC034(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription,  String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC034")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC034_Create a new Login password screen_Password updated succesfully");
		
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        String tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC034");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	   	CommonFunctions.checkFontColour(driver,obj.getMinimum1lowerCase(), "rgba(0, 138, 0, 1)","Minimum 1 Lower Case Check","3.2.2_Functional_Low_TC034");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1upperCase(), "rgba(0, 138, 0, 1)","Minimum 2 Upper Case Check","3.2.2_Functional_Low_TC034");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1Number(), "rgba(0, 138, 0, 1)","Minimum 1 Number  Check","3.2.2_Functional_Low_TC034");
      		CommonFunctions.checkFontColour(driver,obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)","Minimum 8 Characters Check","3.2.2_Functional_Low_TC034");
      	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
      	CommonFunctions.checkFontColour(driver,obj.getConfirmPasswords(), "rgba(0, 138, 0, 1)","Confirm Password Check","3.2.2_Functional_Low_TC034");
        CommonFunctions.ClickButton(driver,obj.getContinueButton());
        BaseClass.statusPassWithScreenshot(driver, "Security Question Screen",TestCaseDescription);
       
      //  CommonFunctions.verifyElement(driver,"Challenge Questions Page Displayed", obj.getChallengeQuestionTitle(),"3.2.2_Functional_Low_TC025" );
		endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_322_TC035(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC035")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC035_Create a new Login password screen_Password updated succesfully");
		
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        String tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyText(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC035");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	   	CommonFunctions.checkFontColour(driver,obj.getMinimum1lowerCase(), "rgba(0, 138, 0, 1)","Minimum 1 Lower Case Check","3.2.2_Functional_Low_TC035");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1upperCase(), "rgba(0, 138, 0, 1)","Minimum 2 Upper Case Check","3.2.2_Functional_Low_TC035");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1Number(), "rgba(0, 138, 0, 1)","Minimum 1 Number  Check","3.2.2_Functional_Low_TC035");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)","Minimum 8 Characters Check","3.2.2_Functional_Low_TC035");
      	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
      	CommonFunctions.checkFontColour(driver,obj.getConfirmPasswords(), "rgba(0, 138, 0, 1)","Confirm Password Check","3.2.2_Functional_Low_TC035");
        CommonFunctions.ClickButton(driver,obj.getContinueButton());
        BaseClass.statusPassWithScreenshot(driver, "Security Question Screen",TestCaseDescription);
       
      //  CommonFunctions.verifyElement(driver,"Challenge Questions Page Displayed", obj.getChallengeQuestionTitle(),"3.2.2_Functional_Low_TC025" );
		endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_322_TC036(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription,  String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC036")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC036_Create a new Login password screen_Password updated succesfully");
		
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        String tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC036");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	   	CommonFunctions.checkFontColour(driver,obj.getMinimum1lowerCase(), "rgba(0, 138, 0, 1)","Minimum 1 Lower Case Check","3.2.2_Functional_Low_TC036");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1upperCase(), "rgba(0, 138, 0, 1)","Minimum 2 Upper Case Check","3.2.2_Functional_Low_TC036");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1Number(), "rgba(0, 138, 0, 1)","Minimum 1 Number  Check","3.2.2_Functional_Low_TC036");
      		CommonFunctions.checkFontColour(driver,obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)","Minimum 8 Characters Check","3.2.2_Functional_Low_TC036");
      	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
      	CommonFunctions.checkFontColour(driver,obj.getConfirmPasswords(), "rgba(0, 138, 0, 1)","Confirm Password Check","3.2.2_Functional_Low_TC036");
        CommonFunctions.ClickButton(driver,obj.getContinueButton());
        BaseClass.statusPassWithScreenshot(driver, "Security Question Screen",TestCaseDescription);
       
      //  CommonFunctions.verifyElement(driver,"Challenge Questions Page Displayed", obj.getChallengeQuestionTitle(),"3.2.2_Functional_Low_TC025" );
		endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_322_TC037(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC037")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC037_Create a new Login password screen_Password updated succesfully");
		
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        String tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyText(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC037");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	   	CommonFunctions.checkFontColour(driver,obj.getMinimum1lowerCase(), "rgba(0, 138, 0, 1)","Minimum 1 Lower Case Check","3.2.2_Functional_Low_TC037");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1upperCase(), "rgba(0, 138, 0, 1)","Minimum 2 Upper Case Check","3.2.2_Functional_Low_TC037");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1Number(), "rgba(0, 138, 0, 1)","Minimum 1 Number  Check","3.2.2_Functional_Low_TC037");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)","Minimum 8 Characters Check","3.2.2_Functional_Low_TC037");
      	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
      	CommonFunctions.checkFontColour(driver,obj.getConfirmPasswords(), "rgba(0, 138, 0, 1)","Confirm Password Check","3.2.2_Functional_Low_TC037");
        CommonFunctions.ClickButton(driver,obj.getContinueButton());
        BaseClass.statusPassWithScreenshot(driver, "Security Question Screen",TestCaseDescription);
       
      //  CommonFunctions.verifyElement(driver,"Challenge Questions Page Displayed", obj.getChallengeQuestionTitle(),"3.2.2_Functional_Low_TC025" );
		endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_322_TC038(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription,  String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC038")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC038_Create a new Login password screen_Password updated succesfully");
		
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        String tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC038");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	   	CommonFunctions.checkFontColour(driver,obj.getMinimum1lowerCase(), "rgba(0, 138, 0, 1)","Minimum 1 Lower Case Check","3.2.2_Functional_Low_TC038");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1upperCase(), "rgba(0, 138, 0, 1)","Minimum 2 Upper Case Check","3.2.2_Functional_Low_TC038");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1Number(), "rgba(0, 138, 0, 1)","Minimum 1 Number  Check","3.2.2_Functional_Low_TC038");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)","Minimum 8 Characters Check","3.2.2_Functional_Low_TC038");
      	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
      	CommonFunctions.checkFontColour(driver,obj.getConfirmPasswords(), "rgba(0, 138, 0, 1)","Confirm Password Check","3.2.2_Functional_Low_TC038");
        CommonFunctions.ClickButton(driver,obj.getContinueButton());
        BaseClass.statusPassWithScreenshot(driver, "Security Question Screen",TestCaseDescription);
       
      //  CommonFunctions.verifyElement(driver,"Challenge Questions Page Displayed", obj.getChallengeQuestionTitle(),"3.2.2_Functional_Low_TC025" );
		endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_322_TC039(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC039")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC039_Create a new Login password screen_Password updated succesfully");
		
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        String tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC039");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	   	CommonFunctions.checkFontColour(driver,obj.getMinimum1lowerCase(), "rgba(0, 138, 0, 1)","Minimum 1 Lower Case Check","3.2.2_Functional_Low_TC039");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1upperCase(), "rgba(0, 138, 0, 1)","Minimum 2 Upper Case Check","3.2.2_Functional_Low_TC039");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1Number(), "rgba(0, 138, 0, 1)","Minimum 1 Number  Check","3.2.2_Functional_Low_TC039");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)","Minimum 8 Characters Check","3.2.2_Functional_Low_TC039");
      	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
      	CommonFunctions.checkFontColour(driver,obj.getConfirmPasswords(), "rgba(0, 138, 0, 1)","Confirm Password Check","3.2.2_Functional_Low_TC039");
        CommonFunctions.ClickButton(driver,obj.getContinueButton());
        BaseClass.statusPassWithScreenshot(driver, "Security Question Screen",TestCaseDescription);
       
      //  CommonFunctions.verifyElement(driver,"Challenge Questions Page Displayed", obj.getChallengeQuestionTitle(),"3.2.2_Functional_Low_TC025" );
		endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_322_TC040(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription,  String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC040")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC040_Create a new Login password screen_Password updated succesfully");
		
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        String tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC040");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	   	CommonFunctions.checkFontColour(driver,obj.getMinimum1lowerCase(), "rgba(0, 138, 0, 1)","Minimum 1 Lower Case Check","3.2.2_Functional_Low_TC040");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1upperCase(), "rgba(0, 138, 0, 1)","Minimum 2 Upper Case Check","3.2.2_Functional_Low_TC040");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1Number(), "rgba(0, 138, 0, 1)","Minimum 1 Number  Check","3.2.2_Functional_Low_TC040");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)","Minimum 8 Characters Check","3.2.2_Functional_Low_TC040");
      	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
      	CommonFunctions.checkFontColour(driver,obj.getConfirmPasswords(), "rgba(0, 138, 0, 1)","Confirm Password Check","3.2.2_Functional_Low_TC040");
        CommonFunctions.ClickButton(driver,obj.getContinueButton());
        BaseClass.statusPassWithScreenshot(driver, "Security Question Screen",TestCaseDescription);
       
      //  CommonFunctions.verifyElement(driver,"Challenge Questions Page Displayed", obj.getChallengeQuestionTitle(),"3.2.2_Functional_Low_TC025" );
		endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_322_TC041(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription,  String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC041")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC041_Create a new Login password screen_Password updated succesfully");
		
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        String tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC041");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	   	CommonFunctions.checkFontColour(driver,obj.getMinimum1lowerCase(), "rgba(0, 138, 0, 1)","Minimum 1 Lower Case Check","3.2.2_Functional_Low_TC041");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1upperCase(), "rgba(0, 138, 0, 1)","Minimum 2 Upper Case Check","3.2.2_Functional_Low_TC041");
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1Number(), "rgba(0, 138, 0, 1)","Minimum 1 Number  Check","3.2.2_Functional_Low_TC041");
      		CommonFunctions.checkFontColour(driver,obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)","Minimum 8 Characters Check","3.2.2_Functional_Low_TC041");
      	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
      	CommonFunctions.checkFontColour(driver,obj.getConfirmPasswords(), "rgba(0, 138, 0, 1)","Confirm Password Check","3.2.2_Functional_Low_TC041");
        CommonFunctions.ClickButton(driver,obj.getContinueButton());
        BaseClass.statusPassWithScreenshot(driver, "Security Question Screen",TestCaseDescription);
       
      //  CommonFunctions.verifyElement(driver,"Challenge Questions Page Displayed", obj.getChallengeQuestionTitle(),"3.2.2_Functional_Low_TC025" );
		endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_322_L_TC100(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC100")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting(TestCaseDescription);
		accountNumber=DataBase.DBConnection(driver,"ACCOUNTWITHNOSECURITYQUES", LanguageSettings, "TC100");
		
		LoginPage.LaunchURL(driver,GatewayAdminURL);
         tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
        Admin.getTemporaryTradingPassword(driver,accountNumber);
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC100");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
       CommonFunctions.ClickButton(driver,obj.getContinueButton());
      CommonFunctions.verifyElement(driver, "Trading Password Title", obj.getTradingTitle(), "3.2.2_Functional_Low_TC100");
       driver.findElement(By.xpath(obj.getTradingNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TradingPassword_Eng"));
    driver.findElement(By.xpath(obj.getTradingConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TradingPassword_Eng"));
    
    
    CommonFunctions.ClickButton(driver,obj.getTradingContinueButton());
  
 CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitle(), "3.2.2_Functional_Low_TC100");
  CommonFunctions.verifySecurityElements(driver,"3.2.2_Functional_Low_TC100");
 CommonFunctions.setSecurityFields(driver,1, "anim",2,"tesret3736220103hdgdb20173hs",3,"&&****anitester ", "3.2.2_Functional_Low_TC100");
 
 
 CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
 CommonFunctions.verifyElement(driver,"Security question", obj.getSecurityQuestionMessage(), "3.2.2_Functional_Low_TC100");

 BaseClass.statusPassWithScreenshot(driver,"Error Message Security Question Scenario ","3.2.2_Functional_Low_TC100");
 
 
 
       
      	endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_322_L_TC101(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC101")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC101_Set up challenge questions screen_Error message");
		accountNumber=DataBase.DBConnection(driver,"ACCOUNTWITHNOSECURITYQUES", LanguageSettings, "TC101");
		
		LoginPage.LaunchURL(driver,GatewayAdminURL);
         tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
        Admin.getTemporaryTradingPassword(driver,accountNumber);
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC101");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
       CommonFunctions.ClickButton(driver,obj.getContinueButton());
      CommonFunctions.verifyElement(driver, "Trading Password Title", obj.getTradingTitle(), "3.2.2_Functional_Low_TC101");
       driver.findElement(By.xpath(obj.getTradingNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TradingPassword_Eng"));
    driver.findElement(By.xpath(obj.getTradingConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TradingPassword_Eng"));
    
    CommonFunctions.ClickButton(driver,obj.getTradingContinueButton());
  
 CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(), "3.2.2_Functional_Low_TC101");
  CommonFunctions.verifySecurityElements(driver,"3.2.2_Functional_Low_TC101");
 CommonFunctions.setSecurityFields(driver,1, "animal",2,"animal",3,"animal", "3.2.2_Functional_Low_TC100");
 
 
 CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
 CommonFunctions.verifyElement(driver,"Security question", obj.getSecurityQuestionMessage(), "3.2.2_Functional_Low_TC101");

 BaseClass.statusPassWithScreenshot(driver,"Error Message Security Question Scenario ","3.2.2_Functional_Low_TC101");
 DataBase.DBChallengeQuesNotUpdated(driver,accountNumber, "3.2.2_Functional_Low_TC101"); 
 
 
 
       
      	endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_322_L_TC102(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC102")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC102_Set up challenge questions screen_Error message");
		accountNumber=DataBase.DBConnection(driver,"ACCOUNTWITHNOSECURITYQUES", LanguageSettings, "TC102");
		
		LoginPage.LaunchURL(driver,GatewayAdminURL);
         tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
        Admin.getTemporaryTradingPassword(driver,accountNumber);
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC102");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
       CommonFunctions.ClickButton(driver,obj.getContinueButton());
      CommonFunctions.verifyElement(driver, "Trading Password Title", obj.getTradingTitle(), "3.2.2_Functional_Low_TC102");
       driver.findElement(By.xpath(obj.getTradingNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TradingPassword_Eng"));
    driver.findElement(By.xpath(obj.getTradingConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TradingPassword_Eng"));
    
    CommonFunctions.ClickButton(driver,obj.getTradingContinueButton());
  
 CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(), "3.2.2_Functional_Low_TC102");
  CommonFunctions.verifySecurityElements(driver,"3.2.2_Functional_Low_TC102");
	
		
	 CommonFunctions.selectByIndex(driver,3, obj.getQuestion3(), "3.2.2_Functional_Low_TC102");
   driver.findElement(By.xpath(obj.getAnswer3())).sendKeys("answer");
  
   CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
   CommonFunctions.verifyElement(driver,"Security question", obj.getSecurityQuestionMessage(), "3.2.2_Functional_Low_TC101");

  BaseClass.statusPassWithScreenshot(driver,"Continue Button Disabled in Security Questions","3.2.2_Functional_Low_TC102");
 
 
 DataBase.DBChallengeQuesNotUpdated(driver,accountNumber, "3.2.2_Functional_Low_TC102"); 
    
      	endReporting();
	}
}




@Test(dataProvider="DriverSheet")
public void test_322_L_TC103(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC103")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC103_Set up challenge questions screen_Error message");
		accountNumber=DataBase.DBConnection(driver,"ACCOUNTWITHNOSECURITYQUES", LanguageSettings, "TC103");
		
		LoginPage.LaunchURL(driver,GatewayAdminURL);
         tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
        Admin.getTemporaryTradingPassword(driver,accountNumber);
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC103");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
       CommonFunctions.ClickButton(driver,obj.getContinueButton());
      CommonFunctions.verifyElement(driver, "Trading Password Title", obj.getTradingTitle(), "3.2.2_Functional_Low_TC103");
       driver.findElement(By.xpath(obj.getTradingNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TradingPassword_Eng"));
    driver.findElement(By.xpath(obj.getTradingConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TradingPassword_Eng"));
    
    CommonFunctions.ClickButton(driver,obj.getTradingContinueButton());
  
 CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(), "3.2.2_Functional_Low_TC103");
  CommonFunctions.verifySecurityElements(driver,"3.2.2_Functional_Low_TC103");
  CommonFunctions.setSecurityFields(driver,1, "anim",2,"turn",3,"flow", "3.2.2_Functional_Low_TC103");

  CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
  CommonFunctions.verifyElement(driver,"Email Screen", obj.getEmailAddressTitle(), "3.2.2_Functional_Low_TC101");

 
  BaseClass.statusPassWithScreenshot(driver,"Continue Button Disabled in Security Questions","3.2.2_Functional_Low_TC103");
  
 //DataBase.DBChallengeQuesNotUpdated(driver,accountNumber, "3.2.2_Functional_Low_TC103"); 
       
      	endReporting();
	}
}





@Test(dataProvider="DriverSheet")
public void test_322_L_TC104(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC104")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC104_Set up challenge questions screen_Error message");
		accountNumber=DataBase.DBConnection(driver,"ACCOUNTWITHNOSECURITYQUES", LanguageSettings, "TC104");
		
		LoginPage.LaunchURL(driver,GatewayAdminURL);
         tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
        Admin.getTemporaryTradingPassword(driver,accountNumber);
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC104");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
       CommonFunctions.ClickButton(driver,obj.getContinueButton());
      CommonFunctions.verifyElement(driver, "Trading Password Title", obj.getTradingTitle(), "3.2.2_Functional_Low_TC104");
       driver.findElement(By.xpath(obj.getTradingNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TradingPassword_Eng"));
    driver.findElement(By.xpath(obj.getTradingConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TradingPassword_Eng"));
    
    CommonFunctions.ClickButton(driver,obj.getTradingContinueButton());
  
 CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(), "3.2.2_Functional_Low_TC104");
  CommonFunctions.verifySecurityElements(driver,"3.2.2_Functional_Low_TC104");
 CommonFunctions.setSecurityFields(driver,1, ",!@#$%^&*",2,"animal",3,"returns", "3.2.2_Functional_Low_TC104");
 
 CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
 CommonFunctions.verifyElement(driver,"Security question", obj.getSecurityQuestionMessage(), "3.2.2_Functional_Low_TC101");

 BaseClass.statusPassWithScreenshot(driver,"Continue Button Disabled in Security Questions","3.2.2_Functional_Low_TC104");
 
 DataBase.DBChallengeQuesNotUpdated(driver,accountNumber, "3.2.2_Functional_Low_TC104"); 
 
 
 
       
      	endReporting();
	}
}





@Test(dataProvider="DriverSheet")
public void test_322_L_TC105(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC105")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC105_Set up challenge questions screen_Error message");
		accountNumber=DataBase.DBConnection(driver,"ACCOUNTWITHNOSECURITYQUES", LanguageSettings, "TC105");
		
		LoginPage.LaunchURL(driver,GatewayAdminURL);
         tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
        Admin.getTemporaryTradingPassword(driver,accountNumber);
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC105");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
       CommonFunctions.ClickButton(driver,obj.getContinueButton());
      CommonFunctions.verifyElement(driver, "Trading Password Title", obj.getTradingTitle(), "3.2.2_Functional_Low_TC105");
       driver.findElement(By.xpath(obj.getTradingNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TradingPassword_Eng"));
    driver.findElement(By.xpath(obj.getTradingConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TradingPassword_Eng"));
    
    CommonFunctions.ClickButton(driver,obj.getTradingContinueButton());
  
 CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(), "3.2.2_Functional_Low_TC105");
  CommonFunctions.verifySecurityElements(driver,"3.2.2_Functional_Low_TC105");
 CommonFunctions.setSecurityFields(driver,1, "animal",2,"ani!@#$%^mal",3,"return", "3.2.2_Functional_Low_TC105");
 
 CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
 CommonFunctions.verifyElement(driver,"Security question", obj.getSecurityQuestionMessage(), "3.2.2_Functional_Low_TC101");

  
 BaseClass.statusPassWithScreenshot(driver,"Continue Button Disabled in Security Questions","3.2.2_Functional_Low_TC105");
 
 DataBase.DBChallengeQuesNotUpdated(driver,accountNumber, "3.2.2_Functional_Low_TC105"); 
 
 

       
      	endReporting();
	}
}




@Test(dataProvider="DriverSheet")
public void test_322_L_TC106(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC106")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC106_Set up challenge questions screen_Error message");
		accountNumber=DataBase.DBConnection(driver,"ACCOUNTWITHNOSECURITYQUES", LanguageSettings, "TC106");
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
        Admin.getTemporaryTradingPassword(driver,accountNumber);
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC106");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
       CommonFunctions.ClickButton(driver,obj.getContinueButton());
      CommonFunctions.verifyElement(driver, "Trading Password Title", obj.getTradingTitle(), "3.2.2_Functional_Low_TC106");
       driver.findElement(By.xpath(obj.getTradingNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TradingPassword_Eng"));
    driver.findElement(By.xpath(obj.getTradingConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TradingPassword_Eng"));
    CommonFunctions.ClickButton(driver,obj.getTradingContinueButton());
  CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(), "3.2.2_Functional_Low_TC106");
 CommonFunctions.verifySecurityElements(driver,"3.2.2_Functional_Low_TC106");
 CommonFunctions.setSecurityFields(driver,1, "animal",2,"animal,!@#$%^&*)",3,"return", "3.2.2_Functional_Low_TC106");
 CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
 CommonFunctions.verifyElement(driver,"Security question", obj.getSecurityQuestionMessage(), "3.2.2_Functional_Low_TC101");

 
 BaseClass.statusPassWithScreenshot(driver,"Continue Button Disabled in Security Questions","3.2.2_Functional_Low_TC106");
 
 DataBase.DBChallengeQuesNotUpdated(driver,accountNumber, "3.2.2_Functional_Low_TC106"); 
      
      	endReporting();
	}
}



@Test(dataProvider="DriverSheet")
public void test_322_L_TC107(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC107")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC107_Set up challenge questions screen_Error message");
		accountNumber=DataBase.DBConnection(driver,"ACCOUNTWITHNOSECURITYQUES", LanguageSettings, "TC107");
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
        Admin.getTemporaryTradingPassword(driver,accountNumber);
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC107");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
       CommonFunctions.ClickButton(driver,obj.getContinueButton());
      CommonFunctions.verifyElement(driver, "Trading Password Title", obj.getTradingTitle(), "3.2.2_Functional_Low_TC107");
       driver.findElement(By.xpath(obj.getTradingNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TradingPassword_Eng"));
    driver.findElement(By.xpath(obj.getTradingConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TradingPassword_Eng"));
    CommonFunctions.ClickButton(driver,obj.getTradingContinueButton());
  CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(), "3.2.2_Functional_Low_TC107");
 CommonFunctions.verifySecurityElements(driver,"3.2.2_Functional_Low_TC107");
 CommonFunctions.setSecurityFields(driver,1, "flower",2," animal",3,"return", "3.2.2_Functional_Low_TC107");
 CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
 CommonFunctions.verifyElement(driver,"Security question", obj.getSecurityQuestionMessage(), "3.2.2_Functional_Low_TC101");

 BaseClass.statusPassWithScreenshot(driver,"Continue Button Disabled in Security Questions","3.2.2_Functional_Low_TC107");
 
 DataBase.DBChallengeQuesNotUpdated(driver,accountNumber, "3.2.2_Functional_Low_TC107"); 
      
      	endReporting();
	}
}



@Test(dataProvider="DriverSheet")
public void test_322_L_TC108(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC108")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC108_Set up challenge questions screen_Error message");
		accountNumber=DataBase.DBConnection(driver,"ACCOUNTWITHNOSECURITYQUES", LanguageSettings, "TC108");
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
        Admin.getTemporaryTradingPassword(driver,accountNumber);
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC108");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
       CommonFunctions.ClickButton(driver,obj.getContinueButton());
      CommonFunctions.verifyElement(driver, "Trading Password Title", obj.getTradingTitle(), "3.2.2_Functional_Low_TC108");
       driver.findElement(By.xpath(obj.getTradingNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TradingPassword_Eng"));
    driver.findElement(By.xpath(obj.getTradingConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TradingPassword_Eng"));
    CommonFunctions.ClickButton(driver,obj.getTradingContinueButton());
  CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(), "3.2.2_Functional_Low_TC108");
 CommonFunctions.verifySecurityElements(driver,"3.2.2_Functional_Low_TC108");
 CommonFunctions.setSecurityFields(driver,1, "flower",2,"animal ",3,"return", "3.2.2_Functional_Low_TC108");
 CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
 CommonFunctions.verifyElement(driver,"Security question", obj.getSecurityQuestionMessage(), "3.2.2_Functional_Low_TC101");

 BaseClass.statusPassWithScreenshot(driver,"Continue Button Disabled in Security Questions","3.2.2_Functional_Low_TC108");
 
 DataBase.DBChallengeQuesNotUpdated(driver,accountNumber, "3.2.2_Functional_Low_TC108"); 
      
      	endReporting();
	}
}




@Test(dataProvider="DriverSheet")
public void test_322_L_TC109(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC109")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC109_Set up challenge questions screen_Error message");
		accountNumber=DataBase.DBConnection(driver,"ACCOUNTWITHNOSECURITYQUES", LanguageSettings, "TC109");
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
        Admin.getTemporaryTradingPassword(driver,accountNumber);
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC109");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
       CommonFunctions.ClickButton(driver,obj.getContinueButton());
      CommonFunctions.verifyElement(driver, "Trading Password Title", obj.getTradingTitle(), "3.2.2_Functional_Low_TC109");
       driver.findElement(By.xpath(obj.getTradingNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TradingPassword_Eng"));
    driver.findElement(By.xpath(obj.getTradingConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TradingPassword_Eng"));
    CommonFunctions.ClickButton(driver,obj.getTradingContinueButton());
  CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(), "3.2.2_Functional_Low_TC109");
 CommonFunctions.verifySecurityElements(driver,"3.2.2_Functional_Low_TC109");
 CommonFunctions.setSecurityFields(driver,1, "animal",2,"animal,!@#$%^&*)",3,"return", "3.2.2_Functional_Low_TC109");
 CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
 CommonFunctions.verifyElement(driver,"Security question", obj.getSecurityQuestionMessage(), "3.2.2_Functional_Low_TC101");

 BaseClass.statusPassWithScreenshot(driver,"Continue Button Disabled in Security Questions","3.2.2_Functional_Low_TC109");
  
 DataBase.DBChallengeQuesNotUpdated(driver,accountNumber, "3.2.2_Functional_Low_TC109"); 
      
      	endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_322_L_TC110(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC110")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC110_Set up challenge questions screen_Error message");
		accountNumber=DataBase.DBConnection(driver,"ACCOUNTWITHNOSECURITYQUES", LanguageSettings, "TC110");
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
        Admin.getTemporaryTradingPassword(driver,accountNumber);
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC110");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
       CommonFunctions.ClickButton(driver,obj.getContinueButton());
      CommonFunctions.verifyElement(driver, "Trading Password Title", obj.getTradingTitle(), "3.2.2_Functional_Low_TC110");
       driver.findElement(By.xpath(obj.getTradingNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TradingPassword_Eng"));
    driver.findElement(By.xpath(obj.getTradingConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TradingPassword_Eng"));
    CommonFunctions.ClickButton(driver,obj.getTradingContinueButton());
  CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(), "3.2.2_Functional_Low_TC110");
 CommonFunctions.verifySecurityElements(driver,"3.2.2_Functional_Low_TC110");
 CommonFunctions.setSecurityFields(driver,1, "flower",2,"animal0123325545animal12345678",3,"return", "3.2.2_Functional_Low_TC110");
 CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
 CommonFunctions.verifyElement(driver,"Email Address Page", obj.getEmailAddressTitle(), "3.2.2_Functional_Low_TC110");

 BaseClass.statusPassWithScreenshot(driver,"Successfully displayed Email Address Page ","3.2.2_Functional_Low_TC110");
 
// DataBase.DBChallengeQuesNotUpdated(driver,accountNumber, "3.2.2_Functional_Low_TC110"); 
      
      	endReporting();
	}
}



@Test(dataProvider="DriverSheet")
public void test_322_L_TC111(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC111")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Medium"))
	{
		
		startReporting("3.2.2_Functional_Medium_TC111_Set up challenge questions screen_Error message");
		accountNumber=DataBase.DBConnection(driver,"ACCOUNTWITHNOSECURITYQUES", LanguageSettings, "TC111");
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
        Admin.getTemporaryTradingPassword(driver,accountNumber);
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Medium_TC111");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
       CommonFunctions.ClickButton(driver,obj.getContinueButton());
      CommonFunctions.verifyElement(driver, "Trading Password Title", obj.getTradingTitle(), "3.2.2_Functional_Medium_TC111");
       driver.findElement(By.xpath(obj.getTradingNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TradingPassword_Eng"));
    driver.findElement(By.xpath(obj.getTradingConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TradingPassword_Eng"));
    CommonFunctions.ClickButton(driver,obj.getTradingContinueButton());
  CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(), "3.2.2_Functional_Medium_TC111");
 CommonFunctions.verifySecurityElements(driver,"3.2.2_Functional_Medium_TC111");
 CommonFunctions.setSecurityFields(driver,1, "flower",2,"",3,"", "3.2.2_Functional_Medium_TC111");
 
 CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
 CommonFunctions.verifyElement(driver,"Security question", obj.getSecurityQuestionMessage(), "3.2.2_Functional_Low_TC101");

 BaseClass.statusPassWithScreenshot(driver,"Security Question Sections","3.2.2_Functional_Medium_TC111");

 DataBase.DBChallengeQuesNotUpdated(driver,accountNumber, "3.2.2_Functional_Medium_TC111"); 
      
      	endReporting();
	}
}


@Test(dataProvider="DriverSheet")
public void test_322_L_TC117(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC117")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC117_EmailAddress screen_Error scenario");
		accountNumber=DataBase.DBConnection(driver,"ACCOUNTWITHNOSECURITYQUES", LanguageSettings, "TC117");
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
        Admin.getTemporaryTradingPassword(driver,accountNumber);
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Low_TC117");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
       CommonFunctions.ClickButton(driver,obj.getContinueButton());
      CommonFunctions.verifyElement(driver, "Trading Password Title", obj.getTradingTitle(), "3.2.2_Functional_Low_TC117");
       driver.findElement(By.xpath(obj.getTradingNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TradingPassword_Eng"));
    driver.findElement(By.xpath(obj.getTradingConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TradingPassword_Eng"));
    CommonFunctions.ClickButton(driver,obj.getTradingContinueButton());
  CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitle(), "3.2.2_Functional_Low_TC117");
 CommonFunctions.verifySecurityElements(driver,"3.2.2_Functional_Low_TC117");
 CommonFunctions.setSecurityFields(driver,1,"flower",2,"animal",3,"tester", "3.2.2_Functional_Low_TC117");
 CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getSecurityQuestionContinueBtn(), "3.2.2_Functional_Low_TC117");
 
 
 CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
 CommonFunctions.verifyElement(driver, "Email Address Section Title", obj.getEmailAddressTitle(), "3.2.2_Functional_Low_TC117");
  CommonFunctions.checkDisabled(driver,obj.getEmailAddressSubmitButton(),"Save Button in Email Password Screen", "3.2.2_Functional_Low_TC117");

 
 BaseClass.statusPassWithScreenshot(driver,"Security Question Sections","3.2.2_Functional_Low_TC117");

 //DataBase.DBChallengeQuesNotUpdated(driver,accountNumber, "3.2.2_Functional_Low_TC117"); 
      
      	endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_322_M_TC003(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC003")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Medium"))
	{
		
		startReporting("3.2.2_Functional_Medium_TC003_Existing client logging in with temporary password provided by Help deskORIA_Account not activated_closed the browser without updating login password");
		accountNumber=ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng");
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Medium_TC003");
      	 driver.close();
      driver=	LoginPage.LaunchBrowser(Browser);
      	LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
     //   CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Medium_TC003");
        
 
 
 
 BaseClass.statusPassWithScreenshot(driver,"Login Password Section after login","3.2.2_Functional_Medium_TC003");

 DataBase.DBVerifyloginPwdRequiresReset(driver,accountNumber,"3.2.2_Functional_Medium_TC003");
 DataBase.DBVerifyloginPwdProfileValid(driver, accountNumber,"3.2.2_Functional_Medium_TC003");
    
      	endReporting();
	}
}


@Test(dataProvider="DriverSheet")
public void test_322_M_TC005(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC005")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Medium"))
	{
		
		startReporting("3.2.2_Functional_Medium_TC005_Existing client logging in with temporary password provided by Help deskORIA_Account not activated_closed the browser without updating login password");
		accountNumber=ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng");	LoginPage.LaunchURL(driver,GatewayAdminURL);
        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
        Admin.getTemporaryTradingPassword(driver,accountNumber);
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Medium_TC005");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
       CommonFunctions.ClickButton(driver,obj.getContinueButton());
      CommonFunctions.verifyElement(driver, "Trading Password Title", obj.getTradingTitle(), "3.2.2_Functional_Medium_TC005");
      driver.close();
      driver=	LoginPage.LaunchBrowser(Browser);
      	LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
       // CommonFunctions.verifyElement(driver, "Error Screen after Logging", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Medium_TC005");
        
  BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login","3.2.2_Functional_Medium_TC005");

  DataBase.DBVerifyNloginPwdRequiresReset(driver,accountNumber,"3.2.2_Functional_Medium_TC005");
  DataBase.DBVerifyloginPwdProfileValid(driver, accountNumber,"3.2.2_Functional_Medium_TC005");
   
      	endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_322_M_TC006(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC006")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Medium"))
	{
		
		startReporting("3.2.2_Functional_Medium_TC006_Existing client logging in with updated Login Password_Displayed with error message");
		accountNumber=ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng");
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
        Admin.getTemporaryTradingPassword(driver,accountNumber);
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Medium_TC006");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
       CommonFunctions.ClickButton(driver,obj.getContinueButton());
      CommonFunctions.verifyElement(driver, "Trading Password Title", obj.getTradingTitle(), "3.2.2_Functional_Medium_TC006");
      driver.close();
      driver=	LoginPage.LaunchBrowser(Browser);
      	LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
     //   CommonFunctions.verifyElement(driver, "Error Screen after Logging", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Medium_TC006");
        
  BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login","3.2.2_Functional_Medium_TC006");
  DataBase.DBVerifyNloginPwdRequiresReset(driver,accountNumber,"3.2.2_Functional_Medium_TC006");
  DataBase.DBVerifyloginPwdProfileValid(driver, accountNumber,"3.2.2_Functional_Medium_TC006");
      
      	endReporting();
	}
}


@Test(dataProvider="DriverSheet")
public void test_322_M_TC007(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC007")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Medium"))
	{
		
		startReporting("3.2.2_Functional_Medium_TC007_Existing client logging in with updated Login Password_Displayed with error message");
		accountNumber=ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng");
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
         LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Medium_TC007");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
       CommonFunctions.ClickButton(driver,obj.getContinueButton());
      CommonFunctions.verifyElement(driver, "Security Question Page", obj.getSecurityQuestionTitle(), "3.2.2_Functional_Medium_TC007");
      driver.close();
      driver=	LoginPage.LaunchBrowser(Browser);
      	LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
        CommonFunctions.verifyElement(driver, "Error Screen after Logging", obj.getLoginErrorMessage(), "3.2.2_Functional_Medium_TC007");
        
  BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login","3.2.2_Functional_Medium_TC007");
  DataBase.DBVerifyNloginPwdRequiresReset(driver,accountNumber,"3.2.2_Functional_Medium_TC007");
  DataBase.DBVerifyloginPwdProfileValid(driver, accountNumber,"3.2.2_Functional_Medium_TC007");
      
      	endReporting();
	}
}


@Test(dataProvider="DriverSheet")
public void test_322_M_TC009(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC009")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Medium"))
	{
		
		startReporting("3.2.2_Functional_Medium_TC009_Existing client logging in with temporary password provided by Help deskORIA_Re-login into GW after closing the browser without updating 3 challenge question_Error message_Account not activated");
		accountNumber=ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng");
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
         LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Medium_TC009");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
       CommonFunctions.ClickButton(driver,obj.getContinueButton());
      CommonFunctions.verifyElement(driver, "Security Question Page", obj.getSecurityQuestionTitle(), "3.2.2_Functional_Medium_TC009");
      driver.close();
      driver=	LoginPage.LaunchBrowser(Browser);
      	LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
        CommonFunctions.verifyElement(driver, "Error Screen after Logging", obj.getLoginErrorMessage(), "3.2.2_Functional_Medium_TC009");
        
  BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login","3.2.2_Functional_Medium_TC009");
  DataBase.DBVerifyNloginPwdRequiresReset(driver,accountNumber,"3.2.2_Functional_Medium_TC009");
  DataBase.DBVerifyloginPwdProfileValid(driver, accountNumber,"3.2.2_Functional_Medium_TC009");
    
      	endReporting();
	}
}


@Test(dataProvider="DriverSheet")
public void test_322_M_TC011(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC011")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Medium"))
	{
		
		startReporting("3.2.2_Functional_Medium_TC011_Existing client logging in with temporary password provided by Help deskORIA_Re-login into GW after closing the browser without updating Email address screen_Error message_Account not activated");
		accountNumber=ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng");
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
         LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.2_Functional_Medium_TC011");
      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"));
       CommonFunctions.ClickButton(driver,obj.getContinueButton());
      CommonFunctions.verifyElement(driver, "Security Question Page", obj.getSecurityQuestionTitle(), "3.2.2_Functional_Medium_TC011");
     CommonFunctions.setSecurityFields(driver, 1,"animal",2, "flower",5, "return","3.2.2_Functional_Medium_TC011" );
      CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
      CommonFunctions.verifyElement(driver, "Email Adddress Page", obj.getEmailAddressTitle(), "3.2.2_Functional_Medium_TC011");
      
      driver.close();
      driver=	LoginPage.LaunchBrowser(Browser);
      	LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
       CommonFunctions.verifyElement(driver, "Error Screen after Logging", obj.getLoginErrorMessage(), "3.2.2_Functional_Medium_TC011");
        
  BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login","3.2.2_Functional_Medium_TC011");
DataBase.DBVerifyNloginPwdRequiresReset(driver,accountNumber,"3.2.2_Functional_Medium_TC011");
DataBase.DBVerifyloginPwdProfileValid(driver, accountNumber,"3.2.2_Functional_Medium_TC011");
 //DataBase.DBChallengeQuesNotUpdated(driver,accountNumber, "3.2.2_Functional_Low_TC117"); 
      
      	endReporting();
	}
}



//july 15 2017


@Test(dataProvider="DriverSheet")
public void test_325_M_TC045(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC045")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("3.2.5_Functional_Medium_TC045_Create a new Login password screen_Error scenario");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	     CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys("");
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys("");
   	    CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
        BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}


@Test(dataProvider="DriverSheet")
public void test_325_M_TC046(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC046")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("3.2.5_Functional_Medium_TC046_Create a new Login password screen_Error scenario");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys("");
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	    CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
        BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}


@Test(dataProvider="DriverSheet")
public void test_325_M_TC047(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC047")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("3.2.5_Functional_Medium_TC047_Create a new Login password screen_Error scenario");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys();
   	    CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
        BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}


@Test(dataProvider="DriverSheet")
public void test_325_M_TC048(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC048")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("3.2.5_Functional_Medium_TC048_Create a new Login password screen_Error scenario");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	    CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
        BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}


@Test(dataProvider="DriverSheet")
public void test_325_M_TC049(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC049")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("3.2.5_Functional_Medium_TC049_Create a new Login password screen_Error scenario");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	    CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
        BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_325_M_TC050(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC050")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("3.2.5_Functional_Medium_TC050_Create a new Login password screen_Error scenario");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	    CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
        BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}


@Test(dataProvider="DriverSheet")
public void test_325_M_TC051(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC051")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("3.2.5_Functional_Medium_TC051_Create a new Login password screen_Error scenario");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	    CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
        BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}


@Test(dataProvider="DriverSheet")
public void test_325_M_TC052(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC052")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("3.2.5_Functional_Medium_TC052_Create a new Login password screen_Error scenario");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	    CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
        BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_325_M_TC053(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC053")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("3.2.5_Functional_Medium_TC053_Create a new Login password screen_Error scenario");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	    CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
        BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}


@Test(dataProvider="DriverSheet")
public void test_325_M_TC054(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC054")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("3.2.5_Functional_Medium_TC054_Create a new Login password screen_Error scenario");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	    CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
        BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}


@Test(dataProvider="DriverSheet")
public void test_325_M_TC055(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC055")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("3.2.5_Functional_Medium_TC055_Create a new Login password screen_Error scenario");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	    CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
        BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}


@Test(dataProvider="DriverSheet")
public void test_325_M_TC056(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC056")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("3.2.5_Functional_Medium_TC056_Create a new Login password screen_Error scenario");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	    CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
        BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_325_M_TC057(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC057")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("3.2.5_Functional_Medium_TC057_Create a new Login password screen_Error scenario");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	    CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
        BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}
@Test(dataProvider="DriverSheet")
public void test_325_M_TC058(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC058")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("3.2.5_Functional_Medium_TC058_Create a new Login password screen_Error scenario");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	    CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
        BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}
@Test(dataProvider="DriverSheet")
public void test_325_M_TC059(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC059")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("3.2.5_Functional_Medium_TC059_Create a new Login password screen_Error scenario");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	    CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
        BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_325_M_TC033(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC033")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("TC033_Create a new Login password screen_Password updated succesfully");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	  //CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitle(),TestCaseDescription);
   	    
   	    BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}
@Test(dataProvider="DriverSheet")
public void test_325_M_TC034(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC034")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("TC034_Create a new Login password screen_Password updated succesfully");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	  //CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitle(),TestCaseDescription);
   	    
   	    BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}
@Test(dataProvider="DriverSheet")
public void test_325_M_TC035(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC035")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("TC035_Create a new Login password screen_Password updated succesfully");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	  //CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitle(),TestCaseDescription);
   	    
   	    BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}
@Test(dataProvider="DriverSheet")
public void test_325_M_TC036(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC036")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("TC036_Create a new Login password screen_Password updated succesfully");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	  //CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitle(),TestCaseDescription);
   	    
   	    BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}
@Test(dataProvider="DriverSheet")
public void test_325_M_TC037(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC037")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("TC037_Create a new Login password screen_Password updated succesfully");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	  //CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitle(),TestCaseDescription);
   	    
   	    BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}
@Test(dataProvider="DriverSheet")
public void test_325_M_TC038(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC038")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("TC038_Create a new Login password screen_Password updated succesfully");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	  //CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitle(),TestCaseDescription);
   	    
   	    BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}
@Test(dataProvider="DriverSheet")
public void test_325_M_TC039(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC039")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("TC039_Create a new Login password screen_Password updated succesfully");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	  //CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitle(),TestCaseDescription);
   	    
   	    BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}
@Test(dataProvider="DriverSheet")
public void test_325_M_TC040(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC040")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("TC040_Create a new Login password screen_Password updated succesfully");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	  //CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitle(),TestCaseDescription);
   	    
   	    BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}
@Test(dataProvider="DriverSheet")
public void test_325_M_TC041(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC041")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("TC041_Create a new Login password screen_Password updated succesfully");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	  //CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitle(),TestCaseDescription);
   	    
   	    BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_325_M_TC042(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC042")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("TC042_Create a new Login password screen_Password updated succesfully");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	  //CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitle(),TestCaseDescription);
   	    
   	    BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}
@Test(dataProvider="DriverSheet")
public void test_325_M_TC043(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC043")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("TC043_Create a new Login password screen_Password updated succesfully");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	  //CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitle(),TestCaseDescription);
   	    
   	    BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_325_M_TC044(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC044")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("TC044_Create a new Login password screen_Password updated succesfully");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
    	CommonFunctions.checkFontColour(driver,obj.getMinimum1lowerCase(), "rgba(0, 138, 0, 1)","Minimum 1 Lower Case Check",TestCaseDescription);
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1upperCase(), "rgba(0, 138, 0, 1)","Minimum 2 Upper Case Check",TestCaseDescription);
      	CommonFunctions.checkFontColour(driver,obj.getMinimum1Number(), "rgba(0, 138, 0, 1)","Minimum 1 Number  Check",TestCaseDescription);
      	CommonFunctions.checkFontColour(driver,obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)","Minimum 8 Characters Check",TestCaseDescription);
      	
    	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	  //CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitle(),TestCaseDescription);
   	    
   	    BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}
@Test(dataProvider="DriverSheet")
public void test_325_M_TC028(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC028")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("TC028_Create a new Login password screen_Password updated succesfully");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	  //CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitle(),TestCaseDescription);
   	    
   	    BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}
@Test(dataProvider="DriverSheet")
public void test_325_M_TC029(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC029")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("TC029_Create a new Login password screen_Password updated succesfully");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	  //CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitle(),TestCaseDescription);
   	    
   	    BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}
@Test(dataProvider="DriverSheet")
public void test_325_M_TC030(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC030")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("TC030_Create a new Login password screen_Password updated succesfully");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	  //CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitle(),TestCaseDescription);
   	    
   	    BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}
@Test(dataProvider="DriverSheet")
public void test_325_M_TC031(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC031")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("TC031_Create a new Login password screen_Password updated succesfully");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	  //CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitle(),TestCaseDescription);
   	    
   	    BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}
@Test(dataProvider="DriverSheet")
public void test_325_M_TC032(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC032")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("TC032_Create a new Login password screen_Password updated succesfully");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	  //CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitle(),TestCaseDescription);
   	    
   	    BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}




@Test(dataProvider="DriverSheet")
public void test_325_M_TC015(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC015")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("TC015_Req Id_325_view screen that advises them that the set-up of complex password and challenge information is compulsory_no upper case in password");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Description Text on Set Up Now Page", obj.getUnsecurePasswordDesc(), TestCaseDescription);
        CommonFunctions.verifyText(driver,"Text", obj.getUnsecurePasswordDesc(), TestCaseDescription);
        BaseClass.statusPassWithScreenshot(driver,"Set Up Now Screen",TestCaseDescription);
       
      	endReporting();
	}
}



@Test(dataProvider="DriverSheet")
public void test_325_M_TC032A(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC032A")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("TC032_Verify_SecondScreen_Non Meridian Client");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDEDNONMERIDIAN", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	  //CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitle(),TestCaseDescription);
   	    
   	    BaseClass.statusPassWithScreenshot(driver,"Second Screen is displayed successfully",TestCaseDescription);
       
      	endReporting();
	}
}




@Test(dataProvider="DriverSheet")
public void test_325_L_TC001(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC001")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Low"))
	{
		
		startReporting("TC001_Req Id_325_view screen to set up complex password and challenge question");
		
		accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKUNSECURE", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        BaseClass.statusPassWithScreenshot(driver,"Set Up Now Screen",TestCaseDescription);
       
      	endReporting();
	}
}







@Test(dataProvider="DriverSheet")
public void test_325_M_TC081(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC081")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("TC018_GUI_Set up challenge questions screen_Challenge questions dropdown");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDEDSECUREPASS", LanguageSettings, TestCaseDescription);
        LoginPage.LaunchURL(driver,GatewayQAURL);
     LoginPage.Login(rowNumber,accountNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
     CommonFunctions.verifyElement(driver, "Setup Now", obj.getUnsecureSetUpNowButton(), Functionality + TestCaseID);
     CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
         CommonFunctions.waitForElement(driver, obj.getSecurityQuestionTitle(),10,"Security screen Heading");         
  CommonFunctions.verifyElement(driver, "Security Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
  CommonFunctions.verifySecurityElements(driver, Functionality + TestCaseID);  
  CommonFunctions.getQuestionList(driver,obj.getQuestion2(),TestCaseDescription );
 /* CommonFunctions.setSecurityFields(driver, 10, "Autotest1", 18, "Autotest2",5, "Autotest3", TestCaseDescription);
  CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
  CommonFunctions.waitForElement(driver, obj.getEmailAddressTitle(),10,"Email address screen Heading");
  statusPass("Email verification screen reached");
  DataBase.DBVerifySecurityQuestion(driver, accountNumber, 1, "Y", 10, TestCaseDescription);
  DataBase.DBVerifySecurityQuestion(driver, accountNumber, 2, "N", 18, TestCaseDescription);
  DataBase.DBVerifySecurityQuestion(driver, accountNumber, 3, "N", 5,TestCaseDescription);    */    
  statusPassWithScreenshot(driver,"Security Question Screen",TestCaseDescription);
 endReporting();
	}
}




// 3.2.5 -> Functionality 
@Test(dataProvider="DriverSheet")
public void test_325_L_TC016(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC016")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Low"))
	{
		
		startReporting("TC016_Req Id_325_no message for setting up password and challenge question is displayed");
		
	accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
		
	//	System.out.println("username contents:"+ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	   CommonFunctions.waitForElement(driver,obj.getHomePageLogo(), 60,"Home Page Screen");
		    CommonFunctions.verifyElement(driver, "Home Page", obj.getHomePageLogo(), TestCaseDescription);
	    
	  //  CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
       /* CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	  //CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitle(),TestCaseDescription);*/
   	    
   	    BaseClass.statusPassWithScreenshot(driver,"Home Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_325_L_TC072(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC072")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Low"))
	{
		
		startReporting("TC072_Set up challenge questions screen_ setting up of challenge answer fields_answers entered are masked");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
		
	
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	   
		 	    
	    CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));

   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
   	  	CommonFunctions.setSecurityFields(driver,1, "animal",2, "porter", 6, "failure", TestCaseDescription);
   	  	CommonFunctions.verifyMasked(driver,obj.getAnswer1(),"Answer 1 Field is masked",TestCaseDescription);
   	 	CommonFunctions.verifyMasked(driver,obj.getAnswer2(),"Answer 2 Field is masked",TestCaseDescription);
   	 	CommonFunctions.verifyMasked(driver,obj.getAnswer3(),"Answer 3 Field is masked",TestCaseDescription);
   	 	BaseClass.statusPassWithScreenshot(driver,"Home Screen after Login",TestCaseDescription);
       
      	endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_325_L_TC092(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC092")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Low"))
	{
		
		startReporting("TC092_GUI_Email address update screen");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	      CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
   	  	CommonFunctions.setSecurityFields(driver,1, "animal",2, "porter", 6, "failure", TestCaseDescription);
   	  	CommonFunctions.verifyMasked(driver,obj.getAnswer1(),"Answer 1 Field is masked",TestCaseDescription);
   	 	CommonFunctions.verifyMasked(driver,obj.getAnswer2(),"Answer 2 Field is masked",TestCaseDescription);
   	 	CommonFunctions.verifyMasked(driver,obj.getAnswer3(),"Answer 3 Field is masked",TestCaseDescription);
   	 	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
   	 	CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
  	    CommonFunctions.verifyElement(driver, "Email Address Screen Email Field", obj.getEmailAddressNewEmail(),TestCaseDescription);
  	    CommonFunctions.verifyElement(driver, "Email Address Screen Confirm Email Field", obj.getEmailAddressConfirmEmail(),TestCaseDescription);
  	    CommonFunctions.verifyElement(driver, "Email Address Screen Continue Button", obj.getEmailAddressSubmitButton(),TestCaseDescription);
  	    driver.findElement(By.xpath(obj.getEmailAddressNewEmail())).sendKeys("Chinnu.Rajaram@bmo.com");
     	driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail())).sendKeys("Chinnu.Rajaram@bmo.com");
    	CommonFunctions.checkFontColour(driver, obj.getEmailAddressConfirmEmailCheck(),"rgba(0, 138, 0, 1)","Confirm Email Check", TestCaseDescription);
    	BaseClass.statusPassWithScreenshot(driver,"Email Address Screen",TestCaseDescription);
       
      	endReporting();
	}
}



@Test(dataProvider="DriverSheet")
public void test_325_M_TC003(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC003")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("TC003_Req Id_325_closes screen to set up complex password and challenge question_Relogin_view same screen again");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        driver.close();
        driver=LoginPage.LaunchBrowser(Browser);
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
  	    
        BaseClass.statusPassWithScreenshot(driver,"Complex Password Screen Setup Title",TestCaseDescription);
       
      	endReporting();
	}
}

@Test(dataProvider="DriverSheet")
public void test_325_M_TC004(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC004")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Medium"))
	{
		
		startReporting("TC004_Req Id_325_Account not activated_closed the browser without updating login password");
		
		accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
	    LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getUnsecurePasswordTitle(), TestCaseDescription);
	    CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
        CommonFunctions.checkElementColour(driver, obj.getUnsecureSetUpNowButton(),"rgba(0, 114, 193, 1)","Set Up Now Button", TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
        CommonFunctions.verifyElement(driver, "Password Change Screen", obj.getPasswordChangePageTitle(), TestCaseDescription);
  	    driver.close();
        driver=LoginPage.LaunchBrowser(Browser);
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Complex Password Screen Setup Title", obj.getGoToLoginPageButton(), TestCaseDescription);
  	    
        BaseClass.statusPassWithScreenshot(driver,"Complex Password Screen Setup Title",TestCaseDescription);
       
      	endReporting();
	}
}


@Test(dataProvider="DriverSheet")
public void test_321_C_TC005(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC005")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.1_Functional_Complex"))
	{
		
		startReporting("TC005_Change_LoginPassword_Screen");
		
		accountNumber=DataBase.DBConnection(driver,"NEWUSERACCOUNTSTC005", LanguageSettings, TestCaseDescription);
		LoginPage.LaunchURL(driver,GatewayAdminURL);
		tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber,tempPassword,"Home",TestCaseDescription);
  	    CommonFunctions.verifyElement(driver, "Create a new Password Title", obj.getPasswordChangePageTitle(), TestCaseDescription);
       
        BaseClass.statusPassWithScreenshot(driver,"Create a new Password Screen",TestCaseDescription);
       
      	endReporting();
	}
}






@Test(dataProvider="DriverSheet")
public void test_321_C_TC006(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC006")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.1_Functional_Complex"))
	{
		
		startReporting("TC006_Change_LoginPassword_Screen");
		
		accountNumber=DataBase.DBConnection(driver,"NEWUSERACCOUNTSTC006", LanguageSettings, TestCaseDescription);
		LoginPage.LaunchURL(driver,GatewayAdminURL);
		tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber,tempPassword,"Home",TestCaseDescription);
        
    
  	    CommonFunctions.waitForElement(driver, obj.getWelcomeScreenTitle(), 20, "WelcomeScreen");
        CommonFunctions.verifyText(driver, "Welcome to Gateway", obj.getWelcomeScreenTitle(), TestCaseDescription);            
        CommonFunctions.verifyElement(driver, "StartButton", obj.getWelcomeScreenStartButton(), TestCaseDescription);
        
        CommonFunctions.ClickButton(driver,obj.getWelcomeScreenStartButton());
        CommonFunctions.verifyText(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
        driver.close();
        driver=LoginPage.LaunchBrowser(Browser);
        LoginPage.LaunchURL(driver,GatewayQAURL);
        
     
        
        
        LoginPage.Login(rowNumber,accountNumber,tempPassword,"Home",TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
        
        BaseClass.statusPassWithScreenshot(driver,"Create a new Password Screen",TestCaseDescription);
       
      	endReporting();
	}
}

/*
@Test(dataProvider="DriverSheet")
public void test_321_C_TC004(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC004")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.1_Functional_Complex"))
	{
		
		startReporting("TC004_relogin _temporary password");
		
		accountNumber=DataBase.DBConnection(driver,"NEWUSERACCOUNTS", LanguageSettings, TestCaseDescription);
		LoginPage.LaunchURL(driver,GatewayAdminURL);
		tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,accountNumber,tempPassword,"Home",TestCaseDescription);
  	    CommonFunctions.waitForElement(driver, obj.getWelcomeScreenTitle(), 20, "WelcomeScreen");
        CommonFunctions.verifyText(driver, "Welcome to Gateway", obj.getWelcomeScreenTitle(), TestCaseDescription);            
        CommonFunctions.verifyElement(driver, "StartButton", obj.getWelcomeScreenStartButton(), TestCaseDescription);
        
        driver.close();
        driver=LoginPage.LaunchBrowser(Browser);
        LoginPage.LaunchURL(driver,GatewayQAURL);
        // DataBase.DBVerifyloginTC004(driver, accountNumber, TestCaseDescription);
         LoginPage.Login(rowNumber,accountNumber,tempPassword,"Home",TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
        
        BaseClass.statusPassWithScreenshot(driver,"Create a new Password Screen",TestCaseDescription);
       
      	endReporting();
	}
}
*/

//3.2.4 Functionality 

@Test(dataProvider = "DriverSheet")
public void test_324_M_TC016(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
	int rowNumber = Integer.parseInt(RowNumber);
	if (TestCaseID.equalsIgnoreCase("TC016")&& Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.4_Functional_Medium")) {

		startReporting("TC016_ 324_set up now button displayed in Account setting page");
	
		LoginPage.LaunchURL(driver, GatewayQAURL);
		accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
		LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"Home",TestCaseDescription );


		CommonFunctions.verifyElement(driver, "Home",obj.getHomePageLogo(),TestCaseDescription);

		
		CommonFunctions.verifyElement(driver, "Home",obj.getAccountSettingTab(),TestCaseDescription);

		
		CommonFunctions.ClickButton(driver,obj.getAccountSettingTab());
		
		CommonFunctions.waitForElement(driver,obj.getAccountSetting_ProfileTab(), 60, "Profile Tab in AccountSettings");
		
		CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());
		CommonFunctions.waitForElement(driver,obj.getSetUpNowSecurityQues(), 60, "Set Up Now Button in AccountSettings");
	
		CommonFunctions.waitForElement(driver,obj.getSetUpNowEmail(), 60, "Set Up Now Button in Email");
		
	  DataBase.DBChallengeQuesNotUpdated(driver,accountNumber,TestCaseDescription );
		BaseClass.statusPassWithScreenshot(driver, "AccountSettings Screen",TestCaseDescription);
		endReporting();
	}

}


@Test(dataProvider = "DriverSheet")
public void test_324_M_TC014(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
	int rowNumber = Integer.parseInt(RowNumber);
	if (TestCaseID.equalsIgnoreCase("TC014")&& Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.4_Functional_Medium")) {

		startReporting(TestCaseDescription);
	
		LoginPage.LaunchURL(driver, GatewayQAURL);
		accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
		LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"Home",TestCaseDescription );


		CommonFunctions.verifyElement(driver, "Home",obj.getHomePageLogo(),TestCaseDescription);

		
		CommonFunctions.verifyElement(driver, "Home",obj.getAccountSettingTab(),TestCaseDescription);

		CommonFunctions.ClickButton(driver,obj.getAccountSettingTab());
		
		CommonFunctions.waitForElement(driver,obj.getAccountSetting_ProfileTab(), 60, "Profile Tab in AccountSettings");
		CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());
		CommonFunctions.waitForElement(driver,obj.getSetUpNowSecurityQues(), 60, "Set Up Now Button in AccountSettings");
	


CommonFunctions.ClickButton(driver,obj.getSetUpNowEmail());

CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(),TestCaseDescription );
CommonFunctions.verifySecurityElements(driver,TestCaseDescription);

CommonFunctions.setSecurityFields(driver, 1, "animal", 2, "porter", 8, "failure", TestCaseDescription);
CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());

CommonFunctions.verifyElement(driver, "Email Screen Title",obj.getEmailAddressTitle(),TestCaseDescription);
	
System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
//CommonFunctions.verifyElement(driver, "Email Screen Title",obj.getEmailAddressTermsCheckBox(),TestCaseDescription);

//Enter valid email ID
		driver.findElement(By.xpath(obj.getEmailAddressNewEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
		driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmEmailID"));
		
		CommonFunctions.ClickButton(driver,obj.getEmailAddressTermsCheckBox());






		//Click on Save button 
		CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
		CommonFunctions.verifyElement(driver, "Email Confirmation Page", obj.getEmailConfirmationTitle(),TestCaseDescription);        
		statusPassWithScreenshot(driver,"Email verification link Message ",Functionality + TestCaseID);
		//Thread.sleep(120000);
	/*	Thread.sleep(20000);
		driver.close();
		driver= LoginPage.LaunchBrowser(Browser);
		LoginPage.LaunchURL(driver,GatewayEmailURL);
		//LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
		LoginPage.EmailLogin(rowNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailUserName"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailPwd"), TestCaseID);
	
		LoginPage.EmailValidation(rowNumber, accountNumber, TestCaseID);
		
		CommonFunctions.verifyElement(driver,"Login Button on verified account", obj.getEmailVerifiedButton(), TestCaseDescription);
		
		CommonFunctions.ClickButton(driver,obj.getEmailVerifiedButton());
	
		



		DataBase.DBEmailUpdated(driver,accountNumber, CommonFunctions.Date(driver, TestCaseID, Functionality, TestCaseDescription), TestCaseDescription);
		
*/

		BaseClass.statusPassWithScreenshot(driver, "AccountSettings Screen",TestCaseDescription);
		endReporting();
	}

}

@Test(dataProvider = "DriverSheet")
public void test_324_M_TC015(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
	int rowNumber = Integer.parseInt(RowNumber);
	if (TestCaseID.equalsIgnoreCase("TC015")&& Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.4_Functional_Medium")) {

		startReporting(TestCaseDescription);
	
		LoginPage.LaunchURL(driver, GatewayQAURL);
		accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
		LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"Home",TestCaseDescription );


		CommonFunctions.verifyElement(driver, "Home",obj.getHomePageLogo(),TestCaseDescription);

		
		CommonFunctions.verifyElement(driver, "Home",obj.getAccountSettingTab(),TestCaseDescription);

		CommonFunctions.ClickButton(driver,obj.getAccountSettingTab());
		
		CommonFunctions.waitForElement(driver,obj.getAccountSetting_ProfileTab(), 60, "Profile Tab in AccountSettings");
		CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());
		CommonFunctions.waitForElement(driver,obj.getSetUpNowSecurityQues(), 60, "Set Up Now Button in AccountSettings");
	


CommonFunctions.ClickButton(driver,obj.getSetUpNowSecurityQues());

CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(),TestCaseDescription );
CommonFunctions.verifySecurityElements(driver,TestCaseDescription);

CommonFunctions.setSecurityFields(driver, 1, "animal", 2, "porter", 8, "failure", TestCaseDescription);
CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());

CommonFunctions.verifyElement(driver, "Email Screen Title",obj.getEmailAddressTitle(),TestCaseDescription);
	
	  DataBase.DBChallengeQuesUpdated(driver,accountNumber,TestCaseDescription );
		BaseClass.statusPassWithScreenshot(driver, "AccountSettings Screen",TestCaseDescription);
		endReporting();
	}

}


@Test(dataProvider = "DriverSheet")
public void test_324_M_TC018(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
	int rowNumber = Integer.parseInt(RowNumber);
	if (TestCaseID.equalsIgnoreCase("TC018")&& Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.4_Functional_Medium")) {

		startReporting("TC018_GUI_Set up challenge questions screen");

		
		LoginPage.LaunchURL(driver, GatewayQAURL);
		
		
	   
		accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
		
		//Line Added/Modified by Sakshee
		
	//	accountNumber= ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng");
	    
	    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"Home",TestCaseDescription );
	    CommonFunctions.verifyElement(driver, "Home",obj.getHomePageLogo(),TestCaseDescription);
		CommonFunctions.verifyElement(driver, "Set Up Now ButtOn on banner",obj.getCommunicationLink(),TestCaseDescription);
		CommonFunctions.verifyElement(driver, "Communication link Text",obj.getCommunicationLink_BannerText(),TestCaseDescription);
		//CommonFunctions.verifyText(driver, "Home",obj.getCommunicationLink_BannerText(),TestCaseDescription);
        
        CommonFunctions.ClickButton(driver,obj.getCommunicationLink());
		
		CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(),TestCaseDescription );
		CommonFunctions.verifySecurityElements(driver,TestCaseDescription);
		
		BaseClass.statusPassWithScreenshot(driver, "Security Question Setup Screen",TestCaseDescription);
		endReporting();
	}

}


@Test(dataProvider = "DriverSheet")
public void test_324_M_TC020(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
	int rowNumber = Integer.parseInt(RowNumber);
	if (TestCaseID.equalsIgnoreCase("TC020")&& Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.4_Functional_Medium")) {

		startReporting("TC020_GUI_Set up challenge questions screen_Challenge questions dropdown");

		LoginPage.LaunchURL(driver, GatewayQAURL);
		
		accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
		
		//Line Added/Modified by Sakshee
		
		//accountNumber= ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng");
		
		LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"Home",TestCaseDescription );
	    CommonFunctions.verifyElement(driver, "Home",obj.getHomePageLogo(),TestCaseDescription);
		CommonFunctions.verifyElement(driver, "Set Up Now ButtOn on banner",obj.getCommunicationLink(),TestCaseDescription);
		CommonFunctions.verifyElement(driver, "Communication link Text",obj.getCommunicationLink_BannerText(),TestCaseDescription);
		//CommonFunctions.verifyText(driver, "Home",obj.getCommunicationLink_BannerText(),TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getCommunicationLink());
		
		
		CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(),TestCaseDescription );
		 
	    CommonFunctions.verifySecurityElements(driver,TestCaseDescription);
		
		// CommonFunctions.setSecurityFields(driver,1, "animal",2,"animal",3,"animal", TestCaseDescription);
		 CommonFunctions.getQuestionList(driver,obj.getQuestion2(), TestCaseDescription);
		 
		// CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		// CommonFunctions.verifyElement(driver,"Security question", obj.getSecurityQuestionMessage(),TestCaseDescription);

				
		BaseClass.statusPassWithScreenshot(driver, "Security Question Setup Screen",TestCaseDescription);
		endReporting();
	}

}

@Test(dataProvider = "DriverSheet")
public void test_324_M_TC021(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
	int rowNumber = Integer.parseInt(RowNumber);
	if (TestCaseID.equalsIgnoreCase("TC021")&& Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.4_Functional_Medium")) {

		startReporting("TC021_GUI_Set up challenge questions screen_Challenge questions dropdown");

		LoginPage.LaunchURL(driver, GatewayQAURL);
		accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
		LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"Home",TestCaseDescription );
	    CommonFunctions.verifyElement(driver, "Home",obj.getHomePageLogo(),TestCaseDescription);
		CommonFunctions.verifyElement(driver, "Set Up Now ButtOn on banner",obj.getCommunicationLink(),TestCaseDescription);
		CommonFunctions.verifyElement(driver, "Communication link Text",obj.getCommunicationLink_BannerText(),TestCaseDescription);
		//CommonFunctions.verifyText(driver, "Home",obj.getCommunicationLink_BannerText(),TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getCommunicationLink());
		
		
		CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(),TestCaseDescription );
		 CommonFunctions.verifySecurityElements(driver,TestCaseDescription);
		// CommonFunctions.setSecurityFields(driver,1, "animal",2,"animal",3,"animal", TestCaseDescription);
		 CommonFunctions.getQuestionList(driver,obj.getQuestion3(), TestCaseDescription);
		 
		// CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		// CommonFunctions.verifyElement(driver,"Security question", obj.getSecurityQuestionMessage(),TestCaseDescription);

				
		BaseClass.statusPassWithScreenshot(driver, "Security Question Setup Screen",TestCaseDescription);
		endReporting();
	}

}

@Test(dataProvider = "DriverSheet")
public void test_324_M_TC023(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
	int rowNumber = Integer.parseInt(RowNumber);
	if (TestCaseID.equalsIgnoreCase("TC023")&& Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.4_Functional_Medium")) {

		startReporting("TC023_Set up challenge questions screen_setting up of first challenge question");

		LoginPage.LaunchURL(driver, GatewayQAURL);
		
		
		accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
		
		LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"Home",TestCaseDescription );
	    CommonFunctions.verifyElement(driver, "Home",obj.getHomePageLogo(),TestCaseDescription);
		CommonFunctions.verifyElement(driver, "Set Up Now ButtOn on banner",obj.getCommunicationLink(),TestCaseDescription);
		CommonFunctions.verifyElement(driver, "Communication link Text",obj.getCommunicationLink_BannerText(),TestCaseDescription);
		//CommonFunctions.verifyText(driver, "Home",obj.getCommunicationLink_BannerText(),TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getCommunicationLink());
		
        
        CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(),TestCaseDescription );
		CommonFunctions.verifySecurityElements(driver,TestCaseDescription);
		// CommonFunctions.setSecurityFields(driver,1, "animal",2,"animal",3,"animal", TestCaseDescription);
		 CommonFunctions.getQuestionList(driver,obj.getQuestion1(), TestCaseDescription);
		 
		 CommonFunctions.selectByIndex(driver,1,obj.getQuestion1(),TestCaseDescription);
		 
	//	 CommonFunctions.verifyQuestionList(driver, obj.getQuestion2(),"",19, TestCaseDescription);
		// CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		// CommonFunctions.verifyElement(driver,"Security question", obj.getSecurityQuestionMessage(),TestCaseDescription);

				
		BaseClass.statusPassWithScreenshot(driver, "Security Question Setup Screen",TestCaseDescription);
		endReporting();
	}

}

@Test(dataProvider = "DriverSheet")
public void test_324_M_TC024(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
	int rowNumber = Integer.parseInt(RowNumber);
	if (TestCaseID.equalsIgnoreCase("TC024")&& Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.4_Functional_Medium")) {

		startReporting("TC024_Set up challenge questions screen_setting up of second challenge question");

		LoginPage.LaunchURL(driver, GatewayQAURL);
		accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
		LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"Home",TestCaseDescription );
	    CommonFunctions.verifyElement(driver, "Home",obj.getHomePageLogo(),TestCaseDescription);
		CommonFunctions.verifyElement(driver, "Set Up Now ButtOn on banner",obj.getCommunicationLink(),TestCaseDescription);
		CommonFunctions.verifyElement(driver, "Communication link Text",obj.getCommunicationLink_BannerText(),TestCaseDescription);
		//CommonFunctions.verifyText(driver, "Home",obj.getCommunicationLink_BannerText(),TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getCommunicationLink());
		
		
		
		CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(),TestCaseDescription );
		 CommonFunctions.verifySecurityElements(driver,TestCaseDescription);
		// CommonFunctions.setSecurityFields(driver,1, "animal",2,"animal",3,"animal", TestCaseDescription);
		 CommonFunctions.selectByIndex(driver,1,obj.getQuestion1(),TestCaseDescription);
		 
		CommonFunctions.verifyQuestionList(driver, obj.getQuestion2(),ReadExcelFile.getTestData(TestCaseID,Functionality, "p_SecurityQuestion1"),19, TestCaseDescription);
			
				
		BaseClass.statusPassWithScreenshot(driver, "Security Question Setup Screen",TestCaseDescription);
		endReporting();
	}

}

@Test(dataProvider = "DriverSheet")
public void test_324_M_TC025(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
	int rowNumber = Integer.parseInt(RowNumber);
	if (TestCaseID.equalsIgnoreCase("TC025")&& Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.4_Functional_Medium")) {

		startReporting("TC025_Set up challenge questions screen_setting up of third challenge question");

		// Change the URL to QA Envrionment 
		LoginPage.LaunchURL(driver, GatewayQAURL);
		accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
		LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"Home",TestCaseDescription );
	    CommonFunctions.verifyElement(driver, "Home",obj.getHomePageLogo(),TestCaseDescription);
		CommonFunctions.verifyElement(driver, "Set Up Now ButtOn on banner",obj.getCommunicationLink(),TestCaseDescription);
		CommonFunctions.verifyElement(driver, "Communication link Text",obj.getCommunicationLink_BannerText(),TestCaseDescription);
		//CommonFunctions.verifyText(driver, "Home",obj.getCommunicationLink_BannerText(),TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getCommunicationLink());
		
		
		
		CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(),TestCaseDescription );
		 CommonFunctions.verifySecurityElements(driver,TestCaseDescription);
		// CommonFunctions.setSecurityFields(driver,1, "animal",2,"animal",3,"animal", TestCaseDescription);
		 CommonFunctions.selectByIndex(driver,1,obj.getQuestion1(),TestCaseDescription);
		 CommonFunctions.verifyQuestionList(driver, obj.getQuestion2(),ReadExcelFile.getTestData(TestCaseID,Functionality, "p_SecurityQuestion1"),19, TestCaseDescription);
			
		 
		 CommonFunctions.selectByIndex(driver,2,obj.getQuestion2(),TestCaseDescription);
			
		CommonFunctions.verifyQuestionList(driver, obj.getQuestion3(),ReadExcelFile.getTestData(TestCaseID,Functionality, "p_SecurityQuestion2"),18, TestCaseDescription);
			
				
		BaseClass.statusPassWithScreenshot(driver, "Security Question Setup Screen",TestCaseDescription);
		endReporting();
	}

}

@Test(dataProvider = "DriverSheet")
public void test_324_M_TC026(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
	int rowNumber = Integer.parseInt(RowNumber);
	if (TestCaseID.equalsIgnoreCase("TC026")&& Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.4_Functional_Medium")) {

		startReporting("TC026_Set up challenge questions screen_challenge answer field");


		// Change the URL to QA Envrionment 
		LoginPage.LaunchURL(driver, GatewayQAURL);
		accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
		LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"Home",TestCaseDescription );
	    CommonFunctions.verifyElement(driver, "Home",obj.getHomePageLogo(),TestCaseDescription);
		CommonFunctions.verifyElement(driver, "Set Up Now ButtOn on banner",obj.getCommunicationLink(),TestCaseDescription);
		CommonFunctions.verifyElement(driver, "Communication link Text",obj.getCommunicationLink_BannerText(),TestCaseDescription);
		//CommonFunctions.verifyText(driver, "Home",obj.getCommunicationLink_BannerText(),TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getCommunicationLink());
		
		CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(),TestCaseDescription );
		 CommonFunctions.verifySecurityElements(driver,TestCaseDescription);
		CommonFunctions.setSecurityFields(driver,1, "animal",2,"flower",9,"nursery", TestCaseDescription);
				
				
		BaseClass.statusPassWithScreenshot(driver, "Security Question Setup Screen",TestCaseDescription);
		endReporting();
	}

}

@Test(dataProvider = "DriverSheet")
public void test_324_M_TC027(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
	int rowNumber = Integer.parseInt(RowNumber);
	if (TestCaseID.equalsIgnoreCase("TC027")&& Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.4_Functional_Medium")) {

		startReporting("TC027_Set up challenge questions screen_ setting up of challenge answer fields");

		
		// Change the URL to QA Envrionment 
		LoginPage.LaunchURL(driver, GatewayQAURL);
		accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
		LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"Home",TestCaseDescription );
	    CommonFunctions.verifyElement(driver, "Home",obj.getHomePageLogo(),TestCaseDescription);
		CommonFunctions.verifyElement(driver, "Set Up Now ButtOn on banner",obj.getCommunicationLink(),TestCaseDescription);
		CommonFunctions.verifyElement(driver, "Communication link Text",obj.getCommunicationLink_BannerText(),TestCaseDescription);
		//CommonFunctions.verifyText(driver, "Home",obj.getCommunicationLink_BannerText(),TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getCommunicationLink());
        
        
		CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(),TestCaseDescription );
		 CommonFunctions.verifySecurityElements(driver,TestCaseDescription);
		CommonFunctions.setSecurityFields(driver,1, "animal",2,"animal",9,"nursery", TestCaseDescription);
				
		CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
				 CommonFunctions.verifyElement(driver,"Security question", obj.getSecurityQuestionMessage(),TestCaseDescription);

		BaseClass.statusPassWithScreenshot(driver, "Security Question Setup Screen",TestCaseDescription);
		endReporting();
	}

}

@Test(dataProvider = "DriverSheet")
public void test_324_M_TC029(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
	int rowNumber = Integer.parseInt(RowNumber);
	if (TestCaseID.equalsIgnoreCase("TC029")&& Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.4_Functional_Medium")) {

		startReporting("TC029_Functional_Set up challenge questions screen_ Continue button");

		// Change the URL to QA Envrionment 
				LoginPage.LaunchURL(driver, GatewayQAURL);
				accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
				LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"Home",TestCaseDescription );
			    CommonFunctions.verifyElement(driver, "Home",obj.getHomePageLogo(),TestCaseDescription);
				CommonFunctions.verifyElement(driver, "Set Up Now ButtOn on banner",obj.getCommunicationLink(),TestCaseDescription);
				CommonFunctions.verifyElement(driver, "Communication link Text",obj.getCommunicationLink_BannerText(),TestCaseDescription);
				//CommonFunctions.verifyText(driver, "Home",obj.getCommunicationLink_BannerText(),TestCaseDescription);
		        CommonFunctions.ClickButton(driver,obj.getCommunicationLink());
		
		CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(),TestCaseDescription );
		 CommonFunctions.verifySecurityElements(driver,TestCaseDescription);
		CommonFunctions.setSecurityFields(driver,1, "animal",2,"flower",9,"nursery", TestCaseDescription);
				
		CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
				
				 
				 CommonFunctions.verifyElement(driver, "Provide Email Screen Title", obj.getEmailAddressTitle(),TestCaseDescription );
						 
		BaseClass.statusPassWithScreenshot(driver, "Provide Email Address Screen",TestCaseDescription);
		endReporting();
	}

}

@Test(dataProvider = "DriverSheet")
public void test_324_M_TC046(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
	int rowNumber = Integer.parseInt(RowNumber);
	if (TestCaseID.equalsIgnoreCase("TC046")&& Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.4_Functional_Medium")) {

		startReporting("TC046_Set up challenge questions screen_Error message");

		// Change the URL to QA Envrionment 
				LoginPage.LaunchURL(driver, GatewayQAURL);
				accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
				LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"Home",TestCaseDescription );
			    CommonFunctions.verifyElement(driver, "Home",obj.getHomePageLogo(),TestCaseDescription);
				CommonFunctions.verifyElement(driver, "Set Up Now ButtOn on banner",obj.getCommunicationLink(),TestCaseDescription);
				CommonFunctions.verifyElement(driver, "Communication link Text",obj.getCommunicationLink_BannerText(),TestCaseDescription);
				//CommonFunctions.verifyText(driver, "Home",obj.getCommunicationLink_BannerText(),TestCaseDescription);
		        CommonFunctions.ClickButton(driver,obj.getCommunicationLink());
		        
		CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(),TestCaseDescription );
		 CommonFunctions.verifySecurityElements(driver,TestCaseDescription);

CommonFunctions.selectByIndex(driver,1, obj.getQuestion1(), TestCaseDescription);
driver.findElement(By.xpath(obj.getAnswer1())).sendKeys("animal");
				
		CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
				 CommonFunctions.verifyElement(driver,"Security question", obj.getSecurityQuestionMessage(),TestCaseDescription);

						 
		BaseClass.statusPassWithScreenshot(driver, "Provide Email Address Screen",TestCaseDescription);
		endReporting();
	}

}

@Test(dataProvider = "DriverSheet")
public void test_324_M_TC047(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
	int rowNumber = Integer.parseInt(RowNumber);
	if (TestCaseID.equalsIgnoreCase("TC047")&& Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.4_Functional_Medium")) {

		startReporting("TC047_Set up challenge questions screen_Error message");
		// Change the URL to QA Envrionment 
				LoginPage.LaunchURL(driver, GatewayQAURL);
				accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
				LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"Home",TestCaseDescription );
			    CommonFunctions.verifyElement(driver, "Home",obj.getHomePageLogo(),TestCaseDescription);
				CommonFunctions.verifyElement(driver, "Set Up Now ButtOn on banner",obj.getCommunicationLink(),TestCaseDescription);
				CommonFunctions.verifyElement(driver, "Communication link Text",obj.getCommunicationLink_BannerText(),TestCaseDescription);
				//CommonFunctions.verifyText(driver, "Home",obj.getCommunicationLink_BannerText(),TestCaseDescription);
		        CommonFunctions.ClickButton(driver,obj.getCommunicationLink());
		
		CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(),TestCaseDescription );
		 CommonFunctions.verifySecurityElements(driver,TestCaseDescription);

CommonFunctions.setSecurityFields(driver,1, "animal", 2,"", 9, "", TestCaseDescription);			
		CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
				 CommonFunctions.verifyElement(driver,"Security question", obj.getSecurityQuestionMessage(),TestCaseDescription);

						 
		BaseClass.statusPassWithScreenshot(driver, "Provide Email Address Screen",TestCaseDescription);
		endReporting();
	}

}

@Test(dataProvider = "DriverSheet")
public void test_324_M_TC009(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
	int rowNumber = Integer.parseInt(RowNumber);
	if (TestCaseID.equalsIgnoreCase("TC009")&& Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.4_Functional_Medium")) {

		startReporting("TC009_ 324_view communication link in Home page");

		// Change the URL to QA Envrionment 
		LoginPage.LaunchURL(driver, GatewayQAURL);
		accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
		LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"Home",TestCaseDescription );
	    CommonFunctions.verifyElement(driver, "Home",obj.getHomePageLogo(),TestCaseDescription);
		CommonFunctions.verifyElement(driver, "Set Up Now ButtOn on banner",obj.getCommunicationLink(),TestCaseDescription);
		CommonFunctions.verifyElement(driver, "Communication link Text",obj.getCommunicationLink_BannerText(),TestCaseDescription);
			//CommonFunctions.verifyText(driver, "Home",obj.getCommunicationLink_BannerText(),TestCaseDescription);
    
		
						 
		BaseClass.statusPassWithScreenshot(driver, "Home Page Screen",TestCaseDescription);
		endReporting();
	}

}

@Test(dataProvider = "DriverSheet")
public void test_324_M_TC011(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
	int rowNumber = Integer.parseInt(RowNumber);
	if (TestCaseID.equalsIgnoreCase("TC011")&& Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.4_Functional_Medium")) {

		startReporting("TC011_324_view communication link in Home page each time_when logged into GW_till he setup the challenge questions or Cut-off time");

		// Change the URL to QA Envrionment 
		LoginPage.LaunchURL(driver, GatewayQAURL);
		accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
		LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"Home",TestCaseDescription );
	    CommonFunctions.verifyElement(driver, "Home",obj.getHomePageLogo(),TestCaseDescription);
		CommonFunctions.verifyElement(driver, "Set Up Now ButtOn on banner",obj.getCommunicationLink(),TestCaseDescription);
		CommonFunctions.verifyElement(driver, "Communication link Text",obj.getCommunicationLink_BannerText(),TestCaseDescription);
		//CommonFunctions.verifyText(driver, "Home",obj.getCommunicationLink_BannerText(),TestCaseDescription);
		BaseClass.statusPassWithScreenshot(driver, "Home Page Screen",TestCaseDescription);
		
		CommonFunctions.ClickButton(driver,obj.getCommunicationLink());
    	
    	
DataBase.DBChallengeQuesNotUpdated(driver,accountNumber, TestCaseDescription);
						 
	
		endReporting();
	}

}


//3.2.3 Functionality 

@Test(dataProvider = "DriverSheet")
public void test_323_L_TC065(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
	int rowNumber = Integer.parseInt(RowNumber);
	if (TestCaseID.equalsIgnoreCase("TC065")&& Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Low")) {

		startReporting("TC065_Verify_SecondScreen_MeridianClient");


		// Change the URL to QA Envrionment 
				LoginPage.LaunchURL(driver, GatewayQAURL);
				accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKUNSECUREMERIDIAN", LanguageSettings, TestCaseDescription);
				LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"Home",TestCaseDescription );
			    CommonFunctions.verifyElement(driver, "Home",obj.getHomePageLogo(),TestCaseDescription);
				CommonFunctions.verifyElement(driver, "Set Up Now ButtOn on banner",obj.getCommunicationLink(),TestCaseDescription);
				CommonFunctions.verifyElement(driver, "Communication link Text",obj.getCommunicationLink_BannerText(),TestCaseDescription);
				//CommonFunctions.verifyText(driver, "Home",obj.getCommunicationLink_BannerText(),TestCaseDescription);
		        CommonFunctions.ClickButton(driver,obj.getCommunicationLink());
		
		        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	
		        driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	
		        driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
		        CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
		        CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	
   	  	CommonFunctions.verifyElement(driver, "Trading Section Title", obj.getTradingpasswordtitle(),TestCaseDescription);
   	  
   	  	    	       
	  
		BaseClass.statusPassWithScreenshot(driver, "Trading Password Title",TestCaseDescription);
		endReporting();
	}

}


@Test(dataProvider = "DriverSheet")
public void test_323_M_TC093(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
	int rowNumber = Integer.parseInt(RowNumber);
	if (TestCaseID.equalsIgnoreCase("TC093")&& Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium")) {

		startReporting("TC093_Set up challenge questions screen_Error message");


		// Change the URL to QA Envrionment 
				LoginPage.LaunchURL(driver, GatewayQAURL);
				accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKUNSECURE", LanguageSettings, TestCaseDescription);
				LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"Home",TestCaseDescription );
			    CommonFunctions.verifyElement(driver, "Home",obj.getHomePageLogo(),TestCaseDescription);
				CommonFunctions.verifyElement(driver, "Set Up Now ButtOn on banner",obj.getCommunicationLink(),TestCaseDescription);
				CommonFunctions.verifyElement(driver, "Communication link Text",obj.getCommunicationLink_BannerText(),TestCaseDescription);
				//CommonFunctions.verifyText(driver, "Home",obj.getCommunicationLink_BannerText(),TestCaseDescription);
		        CommonFunctions.ClickButton(driver,obj.getCommunicationLink());
		
	    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	
	    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	
	    driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
   	  	

   	  	
   	  	CommonFunctions.setSecurityFields(driver,1, "animal&",2, "porter*", 6, "failure", TestCaseDescription);
   	   	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
   	 CommonFunctions.verifyElement(driver, "Error Message", obj.getSecurityErrorMessages(),TestCaseDescription);
  	  
   	  	    	       
	  
		BaseClass.statusPassWithScreenshot(driver, "Security Question Screen",TestCaseDescription);
		endReporting();
	}

}

@Test(dataProvider = "DriverSheet")
public void test_323_M_TC094(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
	int rowNumber = Integer.parseInt(RowNumber);
	if (TestCaseID.equalsIgnoreCase("TC094")&& Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium")) {

		startReporting("TC094_Set up challenge questions screen_Error message");


		// Change the URL to QA Envrionment 
				LoginPage.LaunchURL(driver, GatewayQAURL);
				accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKUNSECURE", LanguageSettings, TestCaseDescription);
				LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"Home",TestCaseDescription );
			    CommonFunctions.verifyElement(driver, "Home",obj.getHomePageLogo(),TestCaseDescription);
				CommonFunctions.verifyElement(driver, "Set Up Now ButtOn on banner",obj.getCommunicationLink(),TestCaseDescription);
				CommonFunctions.verifyElement(driver, "Communication link Text",obj.getCommunicationLink_BannerText(),TestCaseDescription);
				//CommonFunctions.verifyText(driver, "Home",obj.getCommunicationLink_BannerText(),TestCaseDescription);
		        CommonFunctions.ClickButton(driver,obj.getCommunicationLink());
		
	    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	
	    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	
	    driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
   	  	

   	 	CommonFunctions.setSecurityFields(driver,1, " animal",2, " porter", 5, " failure", TestCaseDescription);
   		CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
      	 CommonFunctions.verifyElement(driver, "Error Message", obj.getSecurityErrorMessages(),TestCaseDescription);
       
    
   	  	
   	 
 	    	       
	  
		BaseClass.statusPassWithScreenshot(driver, "Security Question Screen",TestCaseDescription);
		endReporting();
	}

}

@Test(dataProvider = "DriverSheet")
public void test_323_M_TC095(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
	int rowNumber = Integer.parseInt(RowNumber);
	if (TestCaseID.equalsIgnoreCase("TC095")&& Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium")) {

		startReporting("TC095_Set up challenge questions screen_Error message");


		// Change the URL to QA Envrionment 
				LoginPage.LaunchURL(driver, GatewayQAURL);
				accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKUNSECURE", LanguageSettings, TestCaseDescription);
				LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"Home",TestCaseDescription );
			    CommonFunctions.verifyElement(driver, "Home",obj.getHomePageLogo(),TestCaseDescription);
				CommonFunctions.verifyElement(driver, "Set Up Now ButtOn on banner",obj.getCommunicationLink(),TestCaseDescription);
				CommonFunctions.verifyElement(driver, "Communication link Text",obj.getCommunicationLink_BannerText(),TestCaseDescription);
				//CommonFunctions.verifyText(driver, "Home",obj.getCommunicationLink_BannerText(),TestCaseDescription);
		        CommonFunctions.ClickButton(driver,obj.getCommunicationLink());
		
	    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	
	    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	
	    driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
   	  	
   		CommonFunctions.setSecurityFields(driver,1, "animal ",2, "porter ", 5, "failure ", TestCaseDescription);
   		CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
      	 CommonFunctions.verifyElement(driver, "Error Message", obj.getSecurityErrorMessages(),TestCaseDescription);
     	   
    
		BaseClass.statusPassWithScreenshot(driver, "Security Question Screen",TestCaseDescription);
		endReporting();
	}

}

@Test(dataProvider = "DriverSheet")
public void test_323_M_TC096(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
	int rowNumber = Integer.parseInt(RowNumber);
	if (TestCaseID.equalsIgnoreCase("TC096")&& Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium")) {

		startReporting("TC096_Set up challenge questions screen_Error message");


		// Change the URL to QA Envrionment 
				LoginPage.LaunchURL(driver, GatewayQAURL);
				accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKUNSECURE", LanguageSettings, TestCaseDescription);
				LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"Home",TestCaseDescription );
			    CommonFunctions.verifyElement(driver, "Home",obj.getHomePageLogo(),TestCaseDescription);
				CommonFunctions.verifyElement(driver, "Set Up Now ButtOn on banner",obj.getCommunicationLink(),TestCaseDescription);
				CommonFunctions.verifyElement(driver, "Communication link Text",obj.getCommunicationLink_BannerText(),TestCaseDescription);
				//CommonFunctions.verifyText(driver, "Home",obj.getCommunicationLink_BannerText(),TestCaseDescription);
		        CommonFunctions.ClickButton(driver,obj.getCommunicationLink());
		
	    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	
	    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	
	    driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
   	  	
   	 CommonFunctions.setSecurityFields(driver,1, "animal",2, "fai lure",6, "failure", TestCaseDescription);
   	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
  //  CommonFunctions.verifyElement(driver, "Error Message", obj.getSecurityErrorMessages(),TestCaseDescription);
 	
  CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
	  
		BaseClass.statusPassWithScreenshot(driver, "Security Question Screen",TestCaseDescription);
		endReporting();
	}

}

@Test(dataProvider = "DriverSheet")
public void test_323_M_TC097(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
	int rowNumber = Integer.parseInt(RowNumber);
	if (TestCaseID.equalsIgnoreCase("TC097")&& Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium")) {

		startReporting("TC097_Set up challenge questions screen_Error message");


		// Change the URL to QA Envrionment 
				LoginPage.LaunchURL(driver, GatewayQAURL);
				accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKUNSECURE", LanguageSettings, TestCaseDescription);
				LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"Home",TestCaseDescription );
			    CommonFunctions.verifyElement(driver, "Home",obj.getHomePageLogo(),TestCaseDescription);
				CommonFunctions.verifyElement(driver, "Set Up Now ButtOn on banner",obj.getCommunicationLink(),TestCaseDescription);
				CommonFunctions.verifyElement(driver, "Communication link Text",obj.getCommunicationLink_BannerText(),TestCaseDescription);
				//CommonFunctions.verifyText(driver, "Home",obj.getCommunicationLink_BannerText(),TestCaseDescription);
		        CommonFunctions.ClickButton(driver,obj.getCommunicationLink());
		
	    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	
	    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	
	    driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);


   		CommonFunctions.setSecurityFields(driver,1, "animal",2, "abcdefghijklmnopqrstuvwxyz", 9, "failure", TestCaseDescription);
   	   CommonFunctions.checkFieldLength(driver,obj.getAnswer2(),20);	
   		   		CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
   		  	CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
   				     			
	    	
		BaseClass.statusPassWithScreenshot(driver, "Security Question Screen",TestCaseDescription);
		endReporting();
	}

}


@Test(dataProvider = "DriverSheet")
public void test_323_M_TC098(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
	int rowNumber = Integer.parseInt(RowNumber);
	if (TestCaseID.equalsIgnoreCase("TC098")&& Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium")) {

		startReporting("TC098_GUI_Email address update screen");


		// Change the URL to QA Envrionment 
				LoginPage.LaunchURL(driver, GatewayQAURL);
				accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKUNSECURE", LanguageSettings, TestCaseDescription);
				LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"Home",TestCaseDescription );
			    CommonFunctions.verifyElement(driver, "Home",obj.getHomePageLogo(),TestCaseDescription);
				CommonFunctions.verifyElement(driver, "Set Up Now ButtOn on banner",obj.getCommunicationLink(),TestCaseDescription);
				CommonFunctions.verifyElement(driver, "Communication link Text",obj.getCommunicationLink_BannerText(),TestCaseDescription);
				//CommonFunctions.verifyText(driver, "Home",obj.getCommunicationLink_BannerText(),TestCaseDescription);
		        CommonFunctions.ClickButton(driver,obj.getCommunicationLink());
		
	    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
    	
	    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
   	  	
	    driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
   	  	
   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
   	  	
   	  	CommonFunctions.setSecurityFields(driver,1, "animal",2, "failure", 9, "porter", TestCaseDescription);
   	  	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
   	  	CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
	  
   	  	
   	 CommonFunctions.verifyElement(driver, "Email Address New Email Field", obj.getEmailAddressNewEmail(),TestCaseDescription);
	  
   	CommonFunctions.verifyElement(driver, "Email Address Confirm Email Field", obj.getEmailAddressConfirmEmail(),TestCaseDescription);
	  
   	CommonFunctions.verifyElement(driver, "Email Address Submit Button", obj.getEmailAddressSubmitButton(),TestCaseDescription);
	  
   	driver.findElement(By.xpath(obj.getEmailAddressNewEmail())).sendKeys("chinnu.rajaram@bmo.com");
	driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail())).sendKeys("chinnu.rajaram@bmo.com");
   	CommonFunctions.checkFontColour(driver,obj.getEmailAddressConfirmEmailCheck(), "rgba(0, 138, 0, 1)","Confirm email Check", TestCaseDescription);
   	  	
   	  	
	BaseClass.statusPassWithScreenshot(driver, "Security Question Screen",TestCaseDescription);
			endReporting();
	}

}



//ADDED CODE FOR REQ3.5 3.6 3.7 (SAKSHEE DAYAL) TO EXECUTE ON FIREFOX BROWSER



	@Test(dataProvider="DriverSheet")
	public void test_327_M_TC048(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC048")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.7_Functional_Medium"))
		{
			
			startReporting("3.2.7_Functional_Medium_TC048_Create a new Login password screen_Error scenario");
		accountNumber=DataBase.DBConnection(driver,"ACCOUNTINACTIVEMORETHAN1YEAR", LanguageSettings, Functionality + TestCaseID);
		     LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
	       
	        
	        CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), Functionality + TestCaseID);
	         CommonFunctions.checkElementColour(driver, obj.getGoToLoginPageButton(),"rgba(0, 114, 193, 1)","Go To Login Button Colour", Functionality + TestCaseID);
	        CommonFunctions.ClickButton(driver,obj.getGoToLoginPageButton());
	        CommonFunctions.verifyElement(driver,"Login Page Displayed",obj.getUserName(),Functionality + TestCaseID);
	      
	        LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
	         LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), Functionality + TestCaseID);
	    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",Functionality + TestCaseID);
	CommonFunctions.checkEnabled(driver,obj.getSpecialCharacterAlertError(),"Invalid Special Character Entered Error Message", TestCaseDescription);
	    BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",Functionality + TestCaseID);
	 //DataBase.DBChallengeQuesNotUpdated(driver,accountNumber, "3.2.2_Functional_Low_TC117"); 
	      
	      	endReporting();
		}
	}

	@Test(dataProvider="DriverSheet")
	public void test_327_L_TC037(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC037")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.7_Functional_Low"))
		{
			
			startReporting("3.2.7_Functional_Low_TC037_Create a new Login password screen_Error scenario");
		accountNumber=DataBase.DBConnection(driver,"ACCOUNTINACTIVEMORETHAN1YEAR", LanguageSettings, "TC037_3.2.7_Functional_Low");
		     LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
	       
	        
	        CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), "TC037_3.2.7_Functional_Low");
	         CommonFunctions.checkElementColour(driver, obj.getGoToLoginPageButton(),"rgba(0, 114, 193, 1)","Go To Login Button Colour", "TC037_3.2.7_Functional_Low");
	        CommonFunctions.ClickButton(driver,obj.getGoToLoginPageButton());
	        CommonFunctions.verifyElement(driver,"Login Page Displayed",obj.getUserName(),"TC037_3.2.7_Functional_Low");
	      
	        LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
	         LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "TC037_3.2.7_Functional_Low");
	    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys("A3aaaaaa");
	CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button","TC037_3.2.7_Functional_Low" );
	    
	  BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login","TC037_3.2.7_Functional_Low");
	 //DataBase.DBChallengeQuesNotUpdated(driver,accountNumber, "3.2.2_Functional_Low_TC117"); 
	      
	      	endReporting();
		}
	}



	@Test(dataProvider="DriverSheet")
	public void test_327_L_TC047(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC047")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.7_Functional_Low"))
		{
			
			startReporting("3.2.7_Functional_Low_TC047_Create a new Login password screen_Error scenario");
		accountNumber=DataBase.DBConnection(driver,"ACCOUNTINACTIVEMORETHAN1YEAR", LanguageSettings, "TC047_3.2.7_Functional_Low");
		     LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
	       
	        
	        CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), "TC047_3.2.7_Functional_Low");
	         CommonFunctions.checkElementColour(driver, obj.getGoToLoginPageButton(),"rgba(0, 114, 193, 1)","Go To Login Button Colour", "TC047_3.2.7_Functional_Low");
	        CommonFunctions.ClickButton(driver,obj.getGoToLoginPageButton());
	        CommonFunctions.verifyElement(driver,"Login Page Displayed",obj.getUserName(),"TC047_3.2.7_Functional_Low");
	      
	        LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
	         LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "TC047_3.2.7_Functional_Low");
	    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys("A3aaaaaa");
	CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button","TC047_3.2.7_Functional_Low" );
	    
	  BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login","TC047_3.2.7_Functional_Low");
	       
	      	endReporting();
		}
	}

	@Test(dataProvider="DriverSheet")
	public void test_327_L_TC049(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC049")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.7_Functional_Low"))
		{
			
			startReporting("3.2.7_Functional_Low_TC049_GUI_Set up challenge questions screen");
		accountNumber=DataBase.DBConnection(driver,"ACCOUNTINACTIVEMORETHAN1YEAR", LanguageSettings, "TC049_3.2.7_Functional_Low");
		     LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
	       
	        CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), "TC049_3.2.7_Functional_Low");
	         CommonFunctions.checkElementColour(driver, obj.getGoToLoginPageButton(),"rgba(0, 114, 193, 1)","Go To Login Button Colour", "TC049_3.2.7_Functional_Low");
	        CommonFunctions.ClickButton(driver,obj.getGoToLoginPageButton());
	        CommonFunctions.verifyElement(driver,"Login Page Displayed",obj.getUserName(),"TC049_3.2.7_Functional_Low");
	      
	        LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
	         LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "TC049_3.2.7_Functional_Low");
	    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	    CommonFunctions.ClickButton(driver,obj.getContinueButton());
	    CommonFunctions.verifyElement(driver, "Security Question Page", obj.getChallengeQuestionTitleNew(), "TC049_3.2.7_Functional_Low");
	   // CommonFunctions.setSecurityFields(driver, 1,"animal",2, "flower",3, "return","3.2.2_Functional_Medium_TC011" );
	   //  CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	  //   CommonFunctions.verifyElement(driver, "Email Adddress Page", obj.getEmailAddressTitle(), "3.2.2_Functional_Medium_TC011");
	  
	  BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login","TC049_3.2.7_Functional_Low");
	       
	      	endReporting();
		}
	}



	@Test(dataProvider="DriverSheet")
	public void test_327_L_TC050(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC050")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.7_Functional_Low"))
		{
			
			startReporting("3.2.7_Functional_Low_TC050_GUI_Set up challenge questions screen");
		accountNumber=DataBase.DBConnection(driver,"ACCOUNTINACTIVEMORETHAN1YEAR", LanguageSettings, "TC050_3.2.7_Functional_Low");
		     LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
	       
	        CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), "TC050_3.2.7_Functional_Low");
	         CommonFunctions.checkElementColour(driver, obj.getGoToLoginPageButton(),"rgba(0, 114, 193, 1)","Go To Login Button Colour", "TC050_3.2.7_Functional_Low");
	        CommonFunctions.ClickButton(driver,obj.getGoToLoginPageButton());
	        CommonFunctions.verifyElement(driver,"Login Page Displayed",obj.getUserName(),"TC050_3.2.7_Functional_Low");
	      
	        LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
	         LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "TC050_3.2.7_Functional_Low");
	    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	    CommonFunctions.ClickButton(driver,obj.getContinueButton());
	    CommonFunctions.verifyElement(driver, "Security Question Page", obj.getChallengeQuestionTitleNew(), "TC050_3.2.7_Functional_Low");
	  CommonFunctions.verifySecurityElements(driver, "TC050_3.2.7_Functional_Low");
	    // CommonFunctions.setSecurityFields(driver, 1,"animal",2, "flower",3, "return","3.2.2_Functional_Medium_TC011" );
	   //  CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	  //   CommonFunctions.verifyElement(driver, "Email Adddress Page", obj.getEmailAddressTitle(), "3.2.2_Functional_Medium_TC011");
	  
	  BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login","TC050_3.2.7_Functional_Low");
	       
	      	endReporting();
		}
	}


	@Test(dataProvider="DriverSheet")
	public void test_327_L_TC051(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC051")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.7_Functional_Low"))
		{
			
			startReporting("3.2.7_Functional_Low_TC051_GUI_Set up challenge questions screen_Challenge questions dropdown");
		accountNumber=DataBase.DBConnection(driver,"ACCOUNTINACTIVEMORETHAN1YEAR", LanguageSettings, "TC051_3.2.7_Functional_Low");
		     LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
	       
	        CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), "TC051_3.2.7_Functional_Low");
	         CommonFunctions.checkElementColour(driver, obj.getGoToLoginPageButton(),"rgba(0, 114, 193, 1)","Go To Login Button Colour", "TC051_3.2.7_Functional_Low");
	        CommonFunctions.ClickButton(driver,obj.getGoToLoginPageButton());
	        CommonFunctions.verifyElement(driver,"Login Page Displayed",obj.getUserName(),"TC051_3.2.7_Functional_Low");
	      
	        LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
	         LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "TC051_3.2.7_Functional_Low");
	    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	    CommonFunctions.ClickButton(driver,obj.getContinueButton());
	    CommonFunctions.verifyElement(driver, "Security Question Page", obj.getChallengeQuestionTitleNew(), "TC051_3.2.7_Functional_Low");
	  CommonFunctions.verifySecurityElements(driver, "TC051_3.2.7_Functional_Low");
	  CommonFunctions.getQuestionList(driver, obj.getQuestion1(),"TC051_3.2.7_Functional_Low");
	    // CommonFunctions.setSecurityFields(driver, 1,"animal",2, "flower",3, "return","3.2.2_Functional_Medium_TC011" );
	   //  CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	  //   CommonFunctions.verifyElement(driver, "Email Adddress Page", obj.getEmailAddressTitle(), "3.2.2_Functional_Medium_TC011");
	  
	  BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login","TC051_3.2.7_Functional_Low");
	       
	      	endReporting();
		}
	}


	@Test(dataProvider="DriverSheet")
	public void test_327_L_TC052(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC052")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.7_Functional_Low"))
		{
			
			startReporting("3.2.7_Functional_Low_TC052_GUI_Set up challenge questions screen_Challenge questions dropdown");
		accountNumber=DataBase.DBConnection(driver,"ACCOUNTINACTIVEMORETHAN1YEAR", LanguageSettings, "TC052_3.2.7_Functional_Low");
		     LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
	       
	        CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), "TC052_3.2.7_Functional_Low");
	         CommonFunctions.checkElementColour(driver, obj.getGoToLoginPageButton(),"rgba(0, 114, 193, 1)","Go To Login Button Colour", "TC052_3.2.7_Functional_Low");
	        CommonFunctions.ClickButton(driver,obj.getGoToLoginPageButton());
	        CommonFunctions.verifyElement(driver,"Login Page Displayed",obj.getUserName(),"TC052_3.2.7_Functional_Low");
	      
	        LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
	         LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "TC052_3.2.7_Functional_Low");
	    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	    CommonFunctions.ClickButton(driver,obj.getContinueButton());
	    CommonFunctions.verifyElement(driver, "Security Question Page", obj.getChallengeQuestionTitleNew(), "TC052_3.2.7_Functional_Low");
	  CommonFunctions.verifySecurityElements(driver, "TC052_3.2.7_Functional_Low");
	  CommonFunctions.getQuestionList(driver, obj.getQuestion2(),"TC052_3.2.7_Functional_Low");
	    // CommonFunctions.setSecurityFields(driver, 1,"animal",2, "flower",3, "return","3.2.2_Functional_Medium_TC011" );
	   //  CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	  //   CommonFunctions.verifyElement(driver, "Email Adddress Page", obj.getEmailAddressTitle(), "3.2.2_Functional_Medium_TC011");
	  
	  BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login","TC052_3.2.7_Functional_Low");
	       
	      	endReporting();
		}
	}



	@Test(dataProvider="DriverSheet")
	public void test_327_L_TC053(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC053")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.7_Functional_Low"))
		{
			
			startReporting("3.2.7_Functional_Low_TC053_GUI_Set up challenge questions screen_Challenge questions dropdown");
			
			accountNumber=DataBase.DBConnection(driver,"ACCOUNTINACTIVEMORETHAN1YEAR", LanguageSettings, "TC053_3.2.7_Functional_Low");
		    LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
	        CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), "TC053_3.2.7_Functional_Low");
	        CommonFunctions.checkElementColour(driver, obj.getGoToLoginPageButton(),"rgba(0, 114, 193, 1)","Go To Login Button Colour", "TC053_3.2.7_Functional_Low");
	        CommonFunctions.ClickButton(driver,obj.getGoToLoginPageButton());
	        CommonFunctions.verifyElement(driver,"Login Page Displayed",obj.getUserName(),"TC053_3.2.7_Functional_Low");
	        LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "TC053_3.2.7_Functional_Low");
	    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  		CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	  	CommonFunctions.verifyElement(driver, "Security Question Page", obj.getChallengeQuestionTitleNew(), "TC053_3.2.7_Functional_Low");
	   	  	CommonFunctions.verifySecurityElements(driver, "TC053_3.2.7_Functional_Low");
	   	  	CommonFunctions.getQuestionList(driver, obj.getQuestion2(),"TC053_3.2.7_Functional_Low");
	   	  	BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login","TC053_3.2.7_Functional_Low");
	   
	      	endReporting();
		}
	}

	@Test(dataProvider="DriverSheet")
	public void test_327_M_TC033(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC033")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.7_Functional_Medium"))
		{
			
			startReporting("3.2.7_Functional_Medium_TC033_Create a new Login password screen_Error scenario");
			
			accountNumber=DataBase.DBConnection(driver,"ACCOUNTINACTIVEMORETHAN1YEAR", LanguageSettings, "3.2.7_Functional_Medium_TC033");
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
	        CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), "3.2.7_Functional_Medium_TC033");
	        CommonFunctions.checkElementColour(driver, obj.getGoToLoginPageButton(),"rgba(0, 114, 193, 1)","Go To Login Button Colour", "3.2.7_Functional_Medium_TC033");
	        CommonFunctions.ClickButton(driver,obj.getGoToLoginPageButton());
	        CommonFunctions.verifyElement(driver,"Login Page Displayed",obj.getUserName(),"3.2.7_Functional_Medium_TC033");
	        LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.7_Functional_Medium_TC033");
	    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys("");
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys("");
	   	 //CommonFunctions.checkDisabled(driver,obj.getSpecialCharacterAlertError(),"Invalid Special Character Entered Error Message", TestCaseDescription);
	   	
	   	  	CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button","3.2.7_Functional_Medium_TC033" );
	        BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login","3.2.7_Functional_Medium_TC033");
	        //DataBase.DBChallengeQuesNotUpdated(driver,accountNumber, "3.2.2_Functional_Low_TC117"); 
	      
	      	endReporting();
		}
	}


	@Test(dataProvider="DriverSheet")
	public void test_327_M_TC034(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC034")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.7_Functional_Medium"))
		{
			
			startReporting("3.2.7_Functional_Medium_TC034_Create a new Login password screen_Error scenario");
			
			accountNumber=DataBase.DBConnection(driver,"ACCOUNTINACTIVEMORETHAN1YEAR", LanguageSettings, "3.2.7_Functional_Medium_TC034");
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
	        CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), "3.2.7_Functional_Medium_TC034");
	        CommonFunctions.checkElementColour(driver, obj.getGoToLoginPageButton(),"rgba(0, 114, 193, 1)","Go To Login Button Colour", "3.2.7_Functional_Medium_TC034");
	        CommonFunctions.ClickButton(driver,obj.getGoToLoginPageButton());
	        CommonFunctions.verifyElement(driver,"Login Page Displayed",obj.getUserName(),"3.2.7_Functional_Medium_TC034");
	        LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "3.2.7_Functional_Medium_TC034");
	    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys("");
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	  // 	 CommonFunctions.checkDisabled(driver,obj.getSpecialCharacterAlertError(),"Invalid Special Character Entered Error Message", TestCaseDescription);
	    	
	   	  	CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button","3.2.7_Functional_Medium_TC034" );
	        BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login","3.2.7_Functional_Medium_TC034");
	        //DataBase.DBChallengeQuesNotUpdated(driver,accountNumber, "3.2.2_Functional_Low_TC117"); 
	      
	      	endReporting();
		}
	}


	@Test(dataProvider="DriverSheet")
	public void test_327_M_TC040(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC040")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.7_Functional_Medium"))
		{
			
			startReporting("3.2.7_Functional_Medium_TC040_Create a new Login password screen_Error scenario");
			
			accountNumber=DataBase.DBConnection(driver,"ACCOUNTINACTIVEMORETHAN1YEAR", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	        CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), TestCaseDescription);
	        CommonFunctions.checkElementColour(driver, obj.getGoToLoginPageButton(),"rgba(0, 114, 193, 1)","Go To Login Button Colour", TestCaseDescription);
	        CommonFunctions.ClickButton(driver,obj.getGoToLoginPageButton());
	        CommonFunctions.verifyElement(driver,"Login Page Displayed",obj.getUserName(),TestCaseDescription);
	        LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	// CommonFunctions.checkDisabled(driver,obj.getSpecialCharacterAlertError(),"Invalid Special Character Entered Error Message", TestCaseDescription);
	    	
	   	//  	CommonFunctions.checkEnabled(driver,obj.getSpecialCharacterAlertError(),"Invalid Special Character Entered Error Message", TestCaseDescription);
	  	  
	   	  	CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
	        BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
	       
	      	endReporting();
		}
	}


	@Test(dataProvider="DriverSheet")
	public void test_327_M_TC041(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC041")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.7_Functional_Medium"))
		{
			
			startReporting("3.2.7_Functional_Medium_TC041_Create a new Login password screen_Error scenario");
			
			accountNumber=DataBase.DBConnection(driver,"ACCOUNTINACTIVEMORETHAN1YEAR", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	        CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), TestCaseDescription);
	        CommonFunctions.checkElementColour(driver, obj.getGoToLoginPageButton(),"rgba(0, 114, 193, 1)","Go To Login Button Colour", TestCaseDescription);
	        CommonFunctions.ClickButton(driver,obj.getGoToLoginPageButton());
	        CommonFunctions.verifyElement(driver,"Login Page Displayed",obj.getUserName(),TestCaseDescription);
	        LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   //	 CommonFunctions.checkDisabled(driver,obj.getSpecialCharacterAlertError(),"Invalid Special Character Entered Error Message", TestCaseDescription);
	    	  
	  // 	  	CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
	        BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
	       
	      	endReporting();
		}
	}

	@Test(dataProvider="DriverSheet")
	public void test_327_M_TC042(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC042")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.7_Functional_Medium"))
		{
			
			startReporting("3.2.7_Functional_Medium_TC042_Create a new Login password screen_Error scenario");
			
			accountNumber=DataBase.DBConnection(driver,"ACCOUNTINACTIVEMORETHAN1YEAR", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	        CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), TestCaseDescription);
	        CommonFunctions.checkElementColour(driver, obj.getGoToLoginPageButton(),"rgba(0, 114, 193, 1)","Go To Login Button Colour", TestCaseDescription);
	        CommonFunctions.ClickButton(driver,obj.getGoToLoginPageButton());
	        CommonFunctions.verifyElement(driver,"Login Page Displayed",obj.getUserName(),TestCaseDescription);
	        LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	 CommonFunctions.checkEnabled(driver,obj.getSpecialCharacterAlertError(),"Invalid Special Character Entered Error Message", TestCaseDescription);
	  	  
	   	  	CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
	        BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
	       
	      	endReporting();
		}
	}

	@Test(dataProvider="DriverSheet")
	public void test_327_M_TC043(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC043")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.7_Functional_Medium"))
		{
			
			startReporting("3.2.7_Functional_Medium_TC043_Create a new Login password screen_Error scenario");
			
			accountNumber=DataBase.DBConnection(driver,"ACCOUNTINACTIVEMORETHAN1YEAR", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	        CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), TestCaseDescription);
	        CommonFunctions.checkElementColour(driver, obj.getGoToLoginPageButton(),"rgba(0, 114, 193, 1)","Go To Login Button Colour", TestCaseDescription);
	        CommonFunctions.ClickButton(driver,obj.getGoToLoginPageButton());
	        CommonFunctions.verifyElement(driver,"Login Page Displayed",obj.getUserName(),TestCaseDescription);
	        LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	 CommonFunctions.checkEnabled(driver,obj.getSpecialCharacterAlertError(),"Invalid Special Character Entered Error Message", TestCaseDescription);
	  	  
	   	  	CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
	        BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
	       
	      	endReporting();
		}
	}

	@Test(dataProvider="DriverSheet")
	public void test_327_M_TC044(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC044")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.7_Functional_Medium"))
		{
			
			startReporting("3.2.7_Functional_Medium_TC044_Create a new Login password screen_Error scenario");
			
			accountNumber=DataBase.DBConnection(driver,"ACCOUNTINACTIVEMORETHAN1YEAR", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	        CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), TestCaseDescription);
	        CommonFunctions.checkElementColour(driver, obj.getGoToLoginPageButton(),"rgba(0, 114, 193, 1)","Go To Login Button Colour", TestCaseDescription);
	        CommonFunctions.ClickButton(driver,obj.getGoToLoginPageButton());
	        CommonFunctions.verifyElement(driver,"Login Page Displayed",obj.getUserName(),TestCaseDescription);
	        LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	 CommonFunctions.checkEnabled(driver,obj.getSpecialCharacterAlertError(),"Invalid Special Character Entered Error Message", TestCaseDescription);
	  	  
	   	  	CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
	        BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
	       
	      	endReporting();
		}
	}


	@Test(dataProvider="DriverSheet")
	public void test_327_M_TC045(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC045")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.7_Functional_Medium"))
		{
			
			startReporting("3.2.7_Functional_Medium_TC045_Create a new Login password screen_Error scenario");
			
			accountNumber=DataBase.DBConnection(driver,"ACCOUNTINACTIVEMORETHAN1YEAR", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	        CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), TestCaseDescription);
	        CommonFunctions.checkElementColour(driver, obj.getGoToLoginPageButton(),"rgba(0, 114, 193, 1)","Go To Login Button Colour", TestCaseDescription);
	        CommonFunctions.ClickButton(driver,obj.getGoToLoginPageButton());
	        CommonFunctions.verifyElement(driver,"Login Page Displayed",obj.getUserName(),TestCaseDescription);
	        LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	 CommonFunctions.checkEnabled(driver,obj.getSpecialCharacterAlertError(),"Invalid Special Character Entered Error Message", TestCaseDescription);
	  	  
	   	  	CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
	        BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
	       
	      	endReporting();
		}
	}

	@Test(dataProvider="DriverSheet")
	public void test_327_M_TC046(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC046")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.7_Functional_Medium"))
		{
			
			startReporting("3.2.7_Functional_Medium_TC046_Create a new Login password screen_Error scenario");
			
			accountNumber=DataBase.DBConnection(driver,"ACCOUNTINACTIVEMORETHAN1YEAR", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	        CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), TestCaseDescription);
	        CommonFunctions.checkElementColour(driver, obj.getGoToLoginPageButton(),"rgba(0, 114, 193, 1)","Go To Login Button Colour", TestCaseDescription);
	        CommonFunctions.ClickButton(driver,obj.getGoToLoginPageButton());
	        CommonFunctions.verifyElement(driver,"Login Page Displayed",obj.getUserName(),TestCaseDescription);
	        LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	    CommonFunctions.checkEnabled(driver,obj.getSpecialCharacterAlertError(),"Invalid Special Character Entered Error Message", TestCaseDescription);
	   	  	CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
	        BaseClass.statusPassWithScreenshot(driver,"Error Screen after Login",TestCaseDescription);
	       
	      	endReporting();
		}
	}



	@Test(dataProvider="DriverSheet")
	public void test_327_M_TC030(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC030")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.7_Functional_Medium"))
		{
			
			startReporting("3.2.7_Functional_Medium_TC030_Create a new Login password screen_Password updated succesfully");
			
			accountNumber=DataBase.DBConnection(driver,"ACCOUNTINACTIVEMORETHAN1YEAR", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	        CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), TestCaseDescription);
	        CommonFunctions.checkElementColour(driver, obj.getGoToLoginPageButton(),"rgba(0, 114, 193, 1)","Go To Login Button Colour", TestCaseDescription);
	        CommonFunctions.ClickButton(driver,obj.getGoToLoginPageButton());
	        CommonFunctions.verifyElement(driver,"Login Page Displayed",obj.getUserName(),TestCaseDescription);
	        LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.checkFontColour(driver,obj.getMinimum1lowerCase(), "rgba(0, 138, 0, 1)","Minimum 1 Lower Case Check",TestCaseDescription);
	      	CommonFunctions.checkFontColour(driver,obj.getMinimum1upperCase(), "rgba(0, 138, 0, 1)","Minimum 2 Upper Case Check",TestCaseDescription);
	      	CommonFunctions.checkFontColour(driver,obj.getMinimum1Number(), "rgba(0, 138, 0, 1)","Minimum 1 Number  Check",TestCaseDescription);
	      	CommonFunctions.checkFontColour(driver,obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)","Minimum 8 Characters Check",TestCaseDescription);
	      	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	      	CommonFunctions.checkFontColour(driver,obj.getConfirmPasswords(), "rgba(0, 138, 0, 1)","Confirm Password Check",TestCaseDescription);
	  	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	  	   // CommonFunctions.checkDisabled(driver,obj.getSpecialCharacterAlertError(),"Invalid Special Character Entered Error Message", TestCaseDescription);
	   	   	CommonFunctions.verifyElement(driver, "Set Up Challenge Question Screen", obj.getChallengeQuestionTitleNew(), TestCaseDescription);
	   	    BaseClass.statusPassWithScreenshot(driver,"Set Up Challenge Question Screen",TestCaseDescription);
	       
	      	endReporting();
		}
	}



	@Test(dataProvider="DriverSheet")
	public void test_327_M_TC031(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC031")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.7_Functional_Medium"))
		{
			
			startReporting("3.2.7_Functional_Medium_TC031_Create a new Login password screen_Password updated succesfully");
			
			accountNumber=DataBase.DBConnection(driver,"ACCOUNTINACTIVEMORETHAN1YEAR", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	        CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), TestCaseDescription);
	        CommonFunctions.checkElementColour(driver, obj.getGoToLoginPageButton(),"rgba(0, 114, 193, 1)","Go To Login Button Colour", TestCaseDescription);
	        CommonFunctions.ClickButton(driver,obj.getGoToLoginPageButton());
	        CommonFunctions.verifyElement(driver,"Login Page Displayed",obj.getUserName(),TestCaseDescription);
	        LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.checkFontColour(driver,obj.getMinimum1lowerCase(), "rgba(0, 138, 0, 1)","Minimum 1 Lower Case Check",TestCaseDescription);
	      	CommonFunctions.checkFontColour(driver,obj.getMinimum1upperCase(), "rgba(0, 138, 0, 1)","Minimum 2 Upper Case Check",TestCaseDescription);
	      	CommonFunctions.checkFontColour(driver,obj.getMinimum1Number(), "rgba(0, 138, 0, 1)","Minimum 1 Number  Check",TestCaseDescription);
	      	CommonFunctions.checkFontColour(driver,obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)","Minimum 8 Characters Check",TestCaseDescription);
	      	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	      	CommonFunctions.checkFontColour(driver,obj.getConfirmPasswords(), "rgba(0, 138, 0, 1)","Confirm Password Check",TestCaseDescription);
	  	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	  	//  CommonFunctions.checkDisabled(driver,obj.getSpecialCharacterAlertError(),"Invalid Special Character Entered Error Message", TestCaseDescription);
	   	  
	  	  	CommonFunctions.verifyElement(driver, "Set Up Challenge Question Screen", obj.getChallengeQuestionTitleNew(), TestCaseDescription);
	   	    BaseClass.statusPassWithScreenshot(driver,"Set Up Challenge Question Screen",TestCaseDescription);
	       
	      	endReporting();
		}
	}


	@Test(dataProvider="DriverSheet")
	public void test_327_M_TC032(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC032")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.7_Functional_Medium"))
		{
			
			startReporting("3.2.7_Functional_Medium_TC032_Create a new Login password screen_Password updated succesfully");
			
			accountNumber=DataBase.DBConnection(driver,"ACCOUNTINACTIVEMORETHAN1YEAR", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	        CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), TestCaseDescription);
	        CommonFunctions.checkElementColour(driver, obj.getGoToLoginPageButton(),"rgba(0, 114, 193, 1)","Go To Login Button Colour", TestCaseDescription);
	        CommonFunctions.ClickButton(driver,obj.getGoToLoginPageButton());
	        CommonFunctions.verifyElement(driver,"Login Page Displayed",obj.getUserName(),TestCaseDescription);
	        LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.checkFontColour(driver,obj.getMinimum1lowerCase(), "rgba(0, 138, 0, 1)","Minimum 1 Lower Case Check",TestCaseDescription);
	      	CommonFunctions.checkFontColour(driver,obj.getMinimum1upperCase(), "rgba(0, 138, 0, 1)","Minimum 2 Upper Case Check",TestCaseDescription);
	      	CommonFunctions.checkFontColour(driver,obj.getMinimum1Number(), "rgba(0, 138, 0, 1)","Minimum 1 Number  Check",TestCaseDescription);
	      	CommonFunctions.checkFontColour(driver,obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)","Minimum 8 Characters Check",TestCaseDescription);
	      	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	      	CommonFunctions.checkFontColour(driver,obj.getConfirmPasswords(), "rgba(0, 138, 0, 1)","Confirm Password Check",TestCaseDescription);
	      	//CommonFunctions.checkDisabled(driver,obj.getSpecialCharacterAlertError(),"Invalid Special Character Entered Error Message", TestCaseDescription);
	       	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	 	CommonFunctions.verifyElement(driver, "Set Up Challenge Question Screen", obj.getChallengeQuestionTitleNew(), TestCaseDescription);
	   	    BaseClass.statusPassWithScreenshot(driver,"Set Up Challenge Question Screen",TestCaseDescription);
	       
	      	endReporting();
		}
	}


	

	@Test(dataProvider="DriverSheet")
	public void test_327_M_TC027(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC027")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.7_Functional_Medium"))
		{
			
			startReporting("3.2.7_Functional_Medium_TC027_Create a new Login password screen_Password updated succesfully");
			
			accountNumber=DataBase.DBConnection(driver,"ACCOUNTINACTIVEMORETHAN1YEAR", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	        CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), TestCaseDescription);
	        CommonFunctions.checkElementColour(driver, obj.getGoToLoginPageButton(),"rgba(0, 114, 193, 1)","Go To Login Button Colour", TestCaseDescription);
	        CommonFunctions.ClickButton(driver,obj.getGoToLoginPageButton());
	        CommonFunctions.verifyElement(driver,"Login Page Displayed",obj.getUserName(),TestCaseDescription);
	        LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.checkFontColour(driver,obj.getMinimum1lowerCase(), "rgba(0, 138, 0, 1)","Minimum 1 Lower Case Check",TestCaseDescription);
	      	CommonFunctions.checkFontColour(driver,obj.getMinimum1upperCase(), "rgba(0, 138, 0, 1)","Minimum 2 Upper Case Check",TestCaseDescription);
	      	CommonFunctions.checkFontColour(driver,obj.getMinimum1Number(), "rgba(0, 138, 0, 1)","Minimum 1 Number  Check",TestCaseDescription);
	      	CommonFunctions.checkFontColour(driver,obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)","Minimum 8 Characters Check",TestCaseDescription);
	      	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	      	CommonFunctions.checkFontColour(driver,obj.getConfirmPasswords(), "rgba(0, 138, 0, 1)","Confirm Password Check",TestCaseDescription);
	      	//CommonFunctions.checkDisabled(driver,obj.getSpecialCharacterAlertError(),"Invalid Special Character Entered Error Message", TestCaseDescription);
	       	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	 	CommonFunctions.verifyElement(driver, "Set Up Challenge Question Screen", obj.getChallengeQuestionTitleNew(), TestCaseDescription);
	   	    BaseClass.statusPassWithScreenshot(driver,"Set Up Challenge Question Screen",TestCaseDescription);
	       
	      	endReporting();
		}
	}

	@Test(dataProvider="DriverSheet")
	public void test_327_M_TC028(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC028")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.7_Functional_Medium"))
		{
			
			startReporting("3.2.7_Functional_Medium_TC028_Create a new Login password screen_Password updated succesfully");
			
			accountNumber=DataBase.DBConnection(driver,"ACCOUNTINACTIVEMORETHAN1YEAR", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	        CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), TestCaseDescription);
	        CommonFunctions.checkElementColour(driver, obj.getGoToLoginPageButton(),"rgba(0, 114, 193, 1)","Go To Login Button Colour", TestCaseDescription);
	        CommonFunctions.ClickButton(driver,obj.getGoToLoginPageButton());
	        CommonFunctions.verifyElement(driver,"Login Page Displayed",obj.getUserName(),TestCaseDescription);
	        LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.checkFontColour(driver,obj.getMinimum1lowerCase(), "rgba(0, 138, 0, 1)","Minimum 1 Lower Case Check",TestCaseDescription);
	      	CommonFunctions.checkFontColour(driver,obj.getMinimum1upperCase(), "rgba(0, 138, 0, 1)","Minimum 2 Upper Case Check",TestCaseDescription);
	      	CommonFunctions.checkFontColour(driver,obj.getMinimum1Number(), "rgba(0, 138, 0, 1)","Minimum 1 Number  Check",TestCaseDescription);
	      	CommonFunctions.checkFontColour(driver,obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)","Minimum 8 Characters Check",TestCaseDescription);
	      	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	      	CommonFunctions.checkFontColour(driver,obj.getConfirmPasswords(), "rgba(0, 138, 0, 1)","Confirm Password Check",TestCaseDescription);
	      	//CommonFunctions.checkDisabled(driver,obj.getSpecialCharacterAlertError(),"Invalid Special Character Entered Error Message", TestCaseDescription);
	       	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	 	CommonFunctions.verifyElement(driver, "Set Up Challenge Question Screen", obj.getChallengeQuestionTitleNew(), TestCaseDescription);
	   	    BaseClass.statusPassWithScreenshot(driver,"Set Up Challenge Question Screen",TestCaseDescription);
	       
	      	endReporting();
		}
	}
	@Test(dataProvider="DriverSheet")
	public void test_327_M_TC029(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC029")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.7_Functional_Medium"))
		{
			
			startReporting("3.2.7_Functional_Medium_TC029_Create a new Login password screen_Password updated succesfully");
			
			accountNumber=DataBase.DBConnection(driver,"ACCOUNTINACTIVEMORETHAN1YEAR", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
	        CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), TestCaseDescription);
	        CommonFunctions.checkElementColour(driver, obj.getGoToLoginPageButton(),"rgba(0, 114, 193, 1)","Go To Login Button Colour", TestCaseDescription);
	        CommonFunctions.ClickButton(driver,obj.getGoToLoginPageButton());
	        CommonFunctions.verifyElement(driver,"Login Page Displayed",obj.getUserName(),TestCaseDescription);
	        LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.checkFontColour(driver,obj.getMinimum1lowerCase(), "rgba(0, 138, 0, 1)","Minimum 1 Lower Case Check",TestCaseDescription);
	      	CommonFunctions.checkFontColour(driver,obj.getMinimum1upperCase(), "rgba(0, 138, 0, 1)","Minimum 2 Upper Case Check",TestCaseDescription);
	      	CommonFunctions.checkFontColour(driver,obj.getMinimum1Number(), "rgba(0, 138, 0, 1)","Minimum 1 Number  Check",TestCaseDescription);
	      	CommonFunctions.checkFontColour(driver,obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)","Minimum 8 Characters Check",TestCaseDescription);
	      	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	      	CommonFunctions.checkFontColour(driver,obj.getConfirmPasswords(), "rgba(0, 138, 0, 1)","Confirm Password Check",TestCaseDescription);
	      //CommonFunctions.checkDisabled(driver,obj.getSpecialCharacterAlertError(),"Invalid Special Character Entered Error Message", TestCaseDescription);
	       	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	 	CommonFunctions.verifyElement(driver, "Set Up Challenge Question Screen", obj.getChallengeQuestionTitleNew(), TestCaseDescription);
	   	    BaseClass.statusPassWithScreenshot(driver,"Set Up Challenge Question Screen",TestCaseDescription);
	       
	      	endReporting();
		}
	}



	@Test(dataProvider="DriverSheet")
	public void test_353637_L_TC006(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {

		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC006")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.5_3.6_3.7_Functional_Low"))
		{
			
			startReporting("TC006_existing GW client_forgets password and security questions_helpdesk reset password_setting new challenge questions_error message_minimum 6 characters");
			
			LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   		CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	  	CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(), TestCaseDescription);
	       CommonFunctions.checkSizeofDropDown(driver, obj.getQuestion1(), 20);
	       CommonFunctions.verifySecurityElements(driver,TestCaseDescription);
	       CommonFunctions.setSecurityFields(driver,1,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer1") ,2,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer2"),6,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer3"), TestCaseDescription);
	     CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	     Thread.sleep(5000);
	        CommonFunctions.verifyElement(driver, "Challenge Questions Title Error Message", obj.getErrorMessageChallengeQuestion(), TestCaseDescription);
	 
	 
	 //CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	// CommonFunctions.verifyElement(driver, "Email Address Section Title", obj.getEmailAddressTitle(), TestCaseDescription);
	//  CommonFunctions.checkDisabled(driver,obj.getEmailAddressSubmitButton(),"Save Button in Email Password Screen", TestCaseDescription);

	 
	 BaseClass.statusPassWithScreenshot(driver,"Security Question Sections",TestCaseDescription);

	 //DataBase.DBChallengeQuesNotUpdated(driver,accountNumber, "3.2.2_Functional_Low_TC117"); 
	      
	      	endReporting();
		}
	}

	@Test(dataProvider="DriverSheet")
	public void test_353637_L_TC007(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC007")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.5_3.6_3.7_Functional_Low"))
		{
			
			startReporting("TC007_existing GW client_forgets password and security questions_helpdesk reset password_setting new challenge questions_error message_maximum 20 characters");
			LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	       CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(), TestCaseDescription);
	       CommonFunctions.checkSizeofDropDown(driver, obj.getQuestion1(), 20);
	       CommonFunctions.verifySecurityElements(driver,TestCaseDescription);
	       CommonFunctions.setSecurityFields(driver,1,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer1") ,2,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer2"),6,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer3"), TestCaseDescription);
	       CommonFunctions.checkFieldLength(driver,obj.getAnswer1(),20);
	       CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	       
	    //   CommonFunctions.verifyElement(driver, "Challenge Questions Title Error Message", obj.getSecurityErrorMessage1(), TestCaseDescription);

	       // CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getSecurityQuestionContinueBtn(), TestCaseDescription);
	 
	 
	 //CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	// CommonFunctions.verifyElement(driver, "Email Address Section Title", obj.getEmailAddressTitle(), TestCaseDescription);
	//  CommonFunctions.checkDisabled(driver,obj.getEmailAddressSubmitButton(),"Save Button in Email Password Screen", TestCaseDescription);

	 
	 BaseClass.statusPassWithScreenshot(driver,"Security Question Sections",TestCaseDescription);

	 //DataBase.DBChallengeQuesNotUpdated(driver,accountNumber, "3.2.2_Functional_Low_TC117"); 
	      
	      	endReporting();
		}
	}

	@Test(dataProvider="DriverSheet")
	public void test_353637_L_TC008(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC008")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.5_3.6_3.7_Functional_Low"))
		{
			
			startReporting("TC008_existing GW client_forgets password and security questions_helpdesk reset password_setting new challenge questions_error message_invalid special characters");
			LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	       CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(), TestCaseDescription);
	       CommonFunctions.checkSizeofDropDown(driver, obj.getQuestion1(), 20);
	       CommonFunctions.verifySecurityElements(driver,TestCaseDescription);
	       CommonFunctions.setSecurityFields(driver,1,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer1") ,2,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer2"),6,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer3"), TestCaseDescription);
	       CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	       
	       CommonFunctions.verifyElement(driver, "Challenge Questions Title Error Message", obj.getErrorMessageChallengeQuestion(), TestCaseDescription);

	       // CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getSecurityQuestionContinueBtn(), TestCaseDescription);
	 
	 
	 //CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	// CommonFunctions.verifyElement(driver, "Email Address Section Title", obj.getEmailAddressTitle(), TestCaseDescription);
	//  CommonFunctions.checkDisabled(driver,obj.getEmailAddressSubmitButton(),"Save Button in Email Password Screen", TestCaseDescription);

	 
	 BaseClass.statusPassWithScreenshot(driver,"Security Question Sections",TestCaseDescription);

	 //DataBase.DBChallengeQuesNotUpdated(driver,accountNumber, "3.2.2_Functional_Low_TC117"); 
	      
	      	endReporting();
		}
	}

	@Test(dataProvider="DriverSheet")
	public void test_353637_L_TC009(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC009")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.5_3.6_3.7_Functional_Low"))
		{
			
			startReporting("TC009_existing GW client_forgets password and security questions_helpdesk reset password_setting new challenge questions_error message_duplicate answer");
			LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	       CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(), TestCaseDescription);
	       CommonFunctions.checkSizeofDropDown(driver, obj.getQuestion1(), 20);
	       CommonFunctions.verifySecurityElements(driver,TestCaseDescription);
	       CommonFunctions.setSecurityFields(driver,1,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer1") ,2,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer2"),3,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer3"), TestCaseDescription);
	       CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	       
	       CommonFunctions.verifyElement(driver, "Challenge Questions Title Error Message", obj.getErrorMessageChallengeQuestion(), TestCaseDescription);

	       // CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getSecurityQuestionContinueBtn(), TestCaseDescription);
	 
	 
	 //CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	// CommonFunctions.verifyElement(driver, "Email Address Section Title", obj.getEmailAddressTitle(), TestCaseDescription);
	//  CommonFunctions.checkDisabled(driver,obj.getEmailAddressSubmitButton(),"Save Button in Email Password Screen", TestCaseDescription);

	 
	 BaseClass.statusPassWithScreenshot(driver,"Security Question Sections",TestCaseDescription);

	 //DataBase.DBChallengeQuesNotUpdated(driver,accountNumber, "3.2.2_Functional_Low_TC117"); 
	      
	      	endReporting();
		}
	}

	@Test(dataProvider="DriverSheet")
	public void test_353637_L_TC010(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC010")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.5_3.6_3.7_Functional_Low"))
		{
			
			startReporting("TC010_existing GW client_forgets password and security questions_helpdesk reset password_setting new challenge questions_error message_challenge question blank");
			LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	       CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(), TestCaseDescription);
	       CommonFunctions.checkSizeofDropDown(driver, obj.getQuestion1(), 20);
	       CommonFunctions.verifySecurityElements(driver,TestCaseDescription);
	       //CommonFunctions.setSecurityFields(driver,1,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer1") ,2,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer2"),3,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer3"), TestCaseDescription);
	       CommonFunctions.selectByIndex(driver,1, obj.getQuestion1(),TestCaseDescription);
	       driver.findElement(By.xpath(obj.getAnswer1())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer1"));
	       driver.findElement(By.xpath(obj.getAnswer2())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer2"));
	       driver.findElement(By.xpath(obj.getAnswer3())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer3"));
	       
	       //*********************************************************************************************************
	       
	       CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	       
	       CommonFunctions.verifyElement(driver, "Challenge Questions Title Error Message", obj.getErrorMessageChallengeQuestion(), TestCaseDescription);

	       // CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getSecurityQuestionContinueBtn(), TestCaseDescription);
	 
	 
	 //CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	// CommonFunctions.verifyElement(driver, "Email Address Section Title", obj.getEmailAddressTitle(), TestCaseDescription);
	//  CommonFunctions.checkDisabled(driver,obj.getEmailAddressSubmitButton(),"Save Button in Email Password Screen", TestCaseDescription);

	 
	 BaseClass.statusPassWithScreenshot(driver,"Security Question Sections",TestCaseDescription);

	 //DataBase.DBChallengeQuesNotUpdated(driver,accountNumber, "3.2.2_Functional_Low_TC117"); 
	      
	      	endReporting();
		}
	}

	@Test(dataProvider="DriverSheet")
	public void test_353637_L_TC011(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC011")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.5_3.6_3.7_Functional_Low"))
		{
			
			startReporting("TC011_existing GW client_forgets password and security questions_helpdesk reset password_setting new challenge questions_error message_challenge answer blank");
			LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	       CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(), TestCaseDescription);
	       CommonFunctions.checkSizeofDropDown(driver, obj.getQuestion1(), 20);
	       CommonFunctions.verifySecurityElements(driver,TestCaseDescription);
	       CommonFunctions.setSecurityFields(driver,1,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer1") ,2,"",3,"", TestCaseDescription);
	          
	       //*********************************************************************************************************
	       
	       CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	       
	       CommonFunctions.verifyElement(driver, "Challenge Questions Title Error Message", obj.getErrorMessageChallengeQuestion(), TestCaseDescription);

	       // CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getSecurityQuestionContinueBtn(), TestCaseDescription);
	 
	 
	 //CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	// CommonFunctions.verifyElement(driver, "Email Address Section Title", obj.getEmailAddressTitle(), TestCaseDescription);
	//  CommonFunctions.checkDisabled(driver,obj.getEmailAddressSubmitButton(),"Save Button in Email Password Screen", TestCaseDescription);

	 
	 BaseClass.statusPassWithScreenshot(driver,"Security Question Sections",TestCaseDescription);

	 //DataBase.DBChallengeQuesNotUpdated(driver,accountNumber, "3.2.2_Functional_Low_TC117"); 
	      
	      	endReporting();
		}
	}

	
	
	@Test(dataProvider="DriverSheet")
	public void test_353637_M_TC005(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC005")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.5_3.6_3.7_Functional_Medium"))
		{
			
			startReporting("TC005_existing GW client_forgets password and security questions_helpdesk reset password_setting new challenge questions");
			LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	       CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(), TestCaseDescription);
	       
	       
	       CommonFunctions.checkSizeofDropDown(driver, obj.getQuestion1(), 20);
	       CommonFunctions.selectByIndex(driver,1, obj.getQuestion1(), TestCaseDescription);
	       driver.findElement(By.xpath(obj.getAnswer1())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer1"));    
	       CommonFunctions.verifyMasked(driver,obj.getAnswer1(),"Answer Field 1 is masked" , TestCaseDescription);  
	       
	       CommonFunctions.checkSizeofDropDown(driver, obj.getQuestion2(), 19);
	       CommonFunctions.selectByIndex(driver,2, obj.getQuestion2(), TestCaseDescription);
	       driver.findElement(By.xpath(obj.getAnswer2())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer2"));    
	       CommonFunctions.verifyMasked(driver,obj.getAnswer2(),"Answer Field 2 is masked" , TestCaseDescription);  
	       
	       
	       CommonFunctions.checkSizeofDropDown(driver, obj.getQuestion3(), 18);
	       CommonFunctions.selectByIndex(driver,3, obj.getQuestion3(), TestCaseDescription);
	       driver.findElement(By.xpath(obj.getAnswer3())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer3"));    
	       CommonFunctions.verifyMasked(driver,obj.getAnswer3(),"Answer Field 3 is masked" , TestCaseDescription);  
	       
	       //*********************************************************************************************************
	       
	       CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	       
	      
	     
	 
	 // CommonFunctions.verifyElement(driver, "Email Address Section Title", obj.getEmailAddressTitle(), TestCaseDescription);

	  
	  	DataBase.DBVerifyNloginPwdRequiresReset(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"),TestCaseDescription);
	  	DataBase.DBVerifyProfileValid1(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), TestCaseDescription);
	 BaseClass.statusPassWithScreenshot(driver,"Home Page Screen",TestCaseDescription);

	 
	      
	      	endReporting();
		}
	}

	@Test(dataProvider="DriverSheet")
	public void test_353637_M_TC013(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC013")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.5_3.6_3.7_Functional_Medium"))
		{
			
			startReporting("TC013_existing GW client_forgets password and security questions_helpdesk reset password_setting new challenge questions_challenge question process incomplete_browser closed");
			LoginPage.LaunchURL(driver,GatewayAdminURL);
			System.out.println("chevk 1");
	        tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
	        System.out.println("chevk 2");
LoginPage.LaunchURL(driver,GatewayQAURL);
System.out.println("chevk 3");
	        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	  	CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(), TestCaseDescription);
	   	  	driver.close();
	   	  	driver=LoginPage.LaunchBrowser(Browser);
	   	  	LoginPage.LaunchURL(driver,GatewayQAURL);
	   	  	LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"),"Home",Functionality + TestCaseID);
	     
	   	  	
	    	CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), TestCaseDescription);
	    	CommonFunctions.ClickButton(driver,obj.getGoToLoginPageButton());
	    	
	    	LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
	     
	       // CommonFunctions.verifyElement(driver, "Error message on Login Screen", obj.getLoginErrorMessage(), TestCaseDescription);
	    	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	        
	       
	  	DataBase.DBVerifyNloginPwdRequiresReset1(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"),TestCaseDescription);
//	  	DataBase.DBVerifyloginPwdProfileValid(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), TestCaseDescription);
	 BaseClass.statusPassWithScreenshot(driver,"Home Page Screen",TestCaseDescription);

	 
	      
	      	endReporting();
		}
	}


	@Test(dataProvider="DriverSheet")
	public void test_326_L_TC016(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC016")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.6_Functional_Low"))
		{
			
			startReporting("TC016_GUI_Set up challenge questions screen");
			
			accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDEDSECUREPASS", LanguageSettings, TestCaseDescription);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	     LoginPage.Login(rowNumber,accountNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
	     CommonFunctions.verifyElement(driver, "Setup Now", obj.getUnsecureSetUpNowButton(), Functionality + TestCaseID);
	     CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
	         CommonFunctions.waitForElement(driver, obj.getSecurityQuestionTitle(),10,"Security screen Heading");         
	  CommonFunctions.verifyElement(driver, "Security Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
	  CommonFunctions.verifySecurityElements(driver, Functionality + TestCaseID);                    
	 /* CommonFunctions.setSecurityFields(driver, 10, "Autotest1", 18, "Autotest2",5, "Autotest3", TestCaseDescription);
	  CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	  CommonFunctions.waitForElement(driver, obj.getEmailAddressTitle(),10,"Email address screen Heading");
	  statusPass("Email verification screen reached");
	  DataBase.DBVerifySecurityQuestion(driver, accountNumber, 1, "Y", 10, TestCaseDescription);
	  DataBase.DBVerifySecurityQuestion(driver, accountNumber, 2, "N", 18, TestCaseDescription);
	  DataBase.DBVerifySecurityQuestion(driver, accountNumber, 3, "N", 5,TestCaseDescription);    */    
	  statusPassWithScreenshot(driver,"Screenshot done",TestCaseDescription);
	 endReporting();
		}
	}


	@Test(dataProvider="DriverSheet")
	public void test_326_L_TC017(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC017")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.6_Functional_Low"))
		{
			
			startReporting("TC017_GUI_Set up challenge questions screen_Challenge questions dropdown");
			
			accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDEDSECUREPASS", LanguageSettings, TestCaseDescription);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	     LoginPage.Login(rowNumber,accountNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
	     CommonFunctions.verifyElement(driver, "Setup Now", obj.getUnsecureSetUpNowButton(), Functionality + TestCaseID);
	     CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
	         CommonFunctions.waitForElement(driver, obj.getSecurityQuestionTitle(),10,"Security screen Heading");         
	  CommonFunctions.verifyElement(driver, "Security Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
	  CommonFunctions.verifySecurityElements(driver, Functionality + TestCaseID);  
	  CommonFunctions.getQuestionList(driver,obj.getQuestion1(),TestCaseDescription );
	 /* CommonFunctions.setSecurityFields(driver, 10, "Autotest1", 18, "Autotest2",5, "Autotest3", TestCaseDescription);
	  CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	  CommonFunctions.waitForElement(driver, obj.getEmailAddressTitle(),10,"Email address screen Heading");
	  statusPass("Email verification screen reached");
	  DataBase.DBVerifySecurityQuestion(driver, accountNumber, 1, "Y", 10, TestCaseDescription);
	  DataBase.DBVerifySecurityQuestion(driver, accountNumber, 2, "N", 18, TestCaseDescription);
	  DataBase.DBVerifySecurityQuestion(driver, accountNumber, 3, "N", 5,TestCaseDescription);    */    
	  statusPassWithScreenshot(driver,"Security Question Screen",TestCaseDescription);
	 endReporting();
		}
	}



	@Test(dataProvider="DriverSheet")
	public void test_326_L_TC018(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC018")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.6_Functional_Low"))
		{
			
			startReporting("TC018_GUI_Set up challenge questions screen_Challenge questions dropdown");
			
			accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDEDSECUREPASS", LanguageSettings, TestCaseDescription);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	     LoginPage.Login(rowNumber,accountNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
	     CommonFunctions.verifyElement(driver, "Setup Now", obj.getUnsecureSetUpNowButton(), Functionality + TestCaseID);
	     CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
	         CommonFunctions.waitForElement(driver, obj.getSecurityQuestionTitle(),10,"Security screen Heading");         
	  CommonFunctions.verifyElement(driver, "Security Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
	  CommonFunctions.verifySecurityElements(driver, Functionality + TestCaseID);  
	  CommonFunctions.getQuestionList(driver,obj.getQuestion2(),TestCaseDescription );
	 /* CommonFunctions.setSecurityFields(driver, 10, "Autotest1", 18, "Autotest2",5, "Autotest3", TestCaseDescription);
	  CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	  CommonFunctions.waitForElement(driver, obj.getEmailAddressTitle(),10,"Email address screen Heading");
	  statusPass("Email verification screen reached");
	  DataBase.DBVerifySecurityQuestion(driver, accountNumber, 1, "Y", 10, TestCaseDescription);
	  DataBase.DBVerifySecurityQuestion(driver, accountNumber, 2, "N", 18, TestCaseDescription);
	  DataBase.DBVerifySecurityQuestion(driver, accountNumber, 3, "N", 5,TestCaseDescription);    */    
	  statusPassWithScreenshot(driver,"Security Question Screen",TestCaseDescription);
	 endReporting();
		}
	}


	@Test(dataProvider="DriverSheet")
	public void test_326_L_TC019(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC019")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.6_Functional_Low"))
		{
			
			startReporting("TC019_GUI_Set up challenge questions screen_Challenge questions dropdown");
			
			accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDEDSECUREPASS", LanguageSettings, TestCaseDescription);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	     LoginPage.Login(rowNumber,accountNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
	     CommonFunctions.verifyElement(driver, "Setup Now", obj.getUnsecureSetUpNowButton(), Functionality + TestCaseID);
	     CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
	         CommonFunctions.waitForElement(driver, obj.getSecurityQuestionTitle(),10,"Security screen Heading");         
	  CommonFunctions.verifyElement(driver, "Security Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
	  CommonFunctions.verifySecurityElements(driver, Functionality + TestCaseID);  
	  CommonFunctions.getQuestionList(driver,obj.getQuestion3(),TestCaseDescription );
	 /* CommonFunctions.setSecurityFields(driver, 10, "Autotest1", 18, "Autotest2",5, "Autotest3", TestCaseDescription);
	  CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	  CommonFunctions.waitForElement(driver, obj.getEmailAddressTitle(),10,"Email address screen Heading");
	  statusPass("Email verification screen reached");
	  DataBase.DBVerifySecurityQuestion(driver, accountNumber, 1, "Y", 10, TestCaseDescription);
	  DataBase.DBVerifySecurityQuestion(driver, accountNumber, 2, "N", 18, TestCaseDescription);
	  DataBase.DBVerifySecurityQuestion(driver, accountNumber, 3, "N", 5,TestCaseDescription);    */    
	  statusPassWithScreenshot(driver,"Security Question Screen",TestCaseDescription);
	 endReporting();
		}
	}

	//3.2.6

	@Test(dataProvider="DriverSheet")
	public void test_326_M_TC006(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC006")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.6_Functional_Medium"))
		{
			
			startReporting("TC006_Req Id_326_Account not activated_closed the browser without updating Email address screen");
			
			accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDEDSECUREPASS", LanguageSettings, TestCaseDescription);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	     LoginPage.Login(rowNumber,accountNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
	     CommonFunctions.verifyElement(driver, "Setup Now", obj.getUnsecureSetUpNowButton(), Functionality + TestCaseID);
	     CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
	         CommonFunctions.waitForElement(driver, obj.getSecurityQuestionTitle(),10,"Security screen Heading");         
	  CommonFunctions.verifyElement(driver, "Security Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
	  CommonFunctions.verifySecurityElements(driver, Functionality + TestCaseID);                    
	  CommonFunctions.setSecurityFields(driver, 10, "Autotest1", 18, "Autotest2",5, "Autotest3", TestCaseDescription);
	  CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	  CommonFunctions.waitForElement(driver, obj.getEmailAddressTitle(),10,"Email address screen Heading");
	  driver.close();
	  driver =	LoginPage.LaunchBrowser(Browser);
	  	LoginPage.LaunchURL(driver,GatewayQAURL);
	    LoginPage.Login(rowNumber,accountNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
	    CommonFunctions.verifyElement(driver, "Error Screen after login", obj.getGoToLoginPageButton(),TestCaseDescription);        
	    
	 /* statusPass("Email verification screen reached");
	  DataBase.DBVerifySecurityQuestion(driver, accountNumber, 1, "Y", 10, TestCaseDescription);
	  DataBase.DBVerifySecurityQuestion(driver, accountNumber, 2, "N", 18, TestCaseDescription);
	  DataBase.DBVerifySecurityQuestion(driver, accountNumber, 3, "N", 5,TestCaseDescription);    */    
	  DataBase.DBVerifyloginPwdRequiresReset(driver, accountNumber, TestCaseDescription);
	  statusPassWithScreenshot(driver,"Error Screen after login",TestCaseDescription);
	  
	  
	 endReporting();
		}
	}



	@Test(dataProvider="DriverSheet")
	public void test_326_M_TC010(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC010")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.6_Functional_Medium"))
		{
			
			startReporting("TC010_Req Id_326_view screen that advises them that the set-up of challenge information is compulsory_when logged in");
			
			accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDEDSECUREPASS", LanguageSettings, TestCaseDescription);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	     LoginPage.Login(rowNumber,accountNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
	     CommonFunctions.verifyElement(driver, "Setup Now Button Page Title", obj.getUnsecurePasswordTitle(), Functionality + TestCaseID);
	     
	     CommonFunctions.verifyElement(driver, "Setup Now Button Desc", obj.getUnsecurePasswordDesc(), Functionality + TestCaseID);
	     
	     CommonFunctions.verifyElement(driver, "Setup Now Button", obj.getUnsecureSetUpNowButton(), Functionality + TestCaseID);
	      
	 /* statusPass("Email verification screen reached");
	  DataBase.DBVerifySecurityQuestion(driver, accountNumber, 1, "Y", 10, TestCaseDescription);
	  DataBase.DBVerifySecurityQuestion(driver, accountNumber, 2, "N", 18, TestCaseDescription);
	  DataBase.DBVerifySecurityQuestion(driver, accountNumber, 3, "N", 5,TestCaseDescription);    */    
	  DataBase.DBChallengeQuesNotUpdated(driver, accountNumber, TestCaseDescription);
	  DataBase.DBVerifyloginPwdProfileValid(driver,accountNumber,TestCaseDescription );
	  statusPassWithScreenshot(driver,"Error Screen after login",TestCaseDescription);
	  
	  
	 endReporting();
		}
	}


	@Test(dataProvider="DriverSheet")
	public void test_326_M_TC011(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC011")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.6_Functional_Medium"))
		{
			
			startReporting("TC011_Req Id_326_no message for setting up password and challenge question is displayed");
			
			accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDEDSECUREPASS1", LanguageSettings, TestCaseDescription);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	     LoginPage.Login(rowNumber,accountNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
	     CommonFunctions.verifyElement(driver,"Home Page",obj.getHomePageLogo(), TestCaseDescription);
	    
	     DataBase.DBChallengeQuesUpdated(driver, accountNumber, TestCaseDescription);
	     
	     DataBase.DBVerifyProfileValid1(driver,accountNumber,TestCaseDescription );
	  statusPassWithScreenshot(driver,"Error Screen after login",TestCaseDescription);
	  
	  
	 endReporting();
		}
	}


	@Test(dataProvider="DriverSheet")
	public void test_326_M_TC012(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC012")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.6_Functional_Medium"))
		{
			
			startReporting("TC012_Req Id_326_view screen that advises them that the set-up of  challenge information is compulsory each time_when logged into GW_till he setup the challenge questions");
			
			accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	     LoginPage.Login(rowNumber,accountNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
	     CommonFunctions.verifyElement(driver, "Setup Now Button Page Title", obj.getUnsecurePasswordTitle(), Functionality + TestCaseID);
	     
	     CommonFunctions.verifyElement(driver, "Setup Now Button Desc", obj.getUnsecurePasswordDesc(), Functionality + TestCaseID);
	     
	     CommonFunctions.verifyElement(driver, "Setup Now Button", obj.getUnsecureSetUpNowButton(), Functionality + TestCaseID);
	      
	 /* statusPass("Email verification screen reached");
	  DataBase.DBVerifySecurityQuestion(driver, accountNumber, 1, "Y", 10, TestCaseDescription);
	  DataBase.DBVerifySecurityQuestion(driver, accountNumber, 2, "N", 18, TestCaseDescription);
	  DataBase.DBVerifySecurityQuestion(driver, accountNumber, 3, "N", 5,TestCaseDescription);    */    
	  DataBase.DBChallengeQuesNotUpdated(driver, accountNumber, TestCaseDescription);
	  DataBase.DBVerifyloginPwdProfileValid(driver,accountNumber,TestCaseDescription );
	  statusPassWithScreenshot(driver,"Error Screen after login",TestCaseDescription);
	  
	  
	 endReporting();
		}
	}


	@Test(dataProvider="DriverSheet")
	public void test_325_C_TC002(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC002")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Complex"))
		{
			
			startReporting("TC002_Existing client with secure password compulsorily set up challenge questions after the cut-off date");
			accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKUNSECURE", LanguageSettings, TestCaseDescription);
			System.out.println(accountNumber);
			
			LoginPage.LaunchURL(driver,GatewayQAURL);
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
		      
	     	
			CommonFunctions.verifyElement(driver, "Setup Now", obj.getUnsecureSetUpNowButton(), Functionality + TestCaseID);
		     CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
		        CommonFunctions.waitForElement(driver, obj.getSecurityQuestionTitle(),10,"Security screen Heading");         
		  CommonFunctions.verifyElement(driver, "Security Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
		  CommonFunctions.verifySecurityElements(driver, Functionality + TestCaseID);                    
		  CommonFunctions.setSecurityFields(driver, 10, "Autotest1", 18, "Autotest2",5, "Autotest3", TestCaseDescription);
		  CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		  CommonFunctions.waitForElement(driver, obj.getEmailAddressTitle(),10,"Email address screen Heading");
		  

			//Enter valid email ID
			driver.findElement(By.xpath(obj.getEmailAddressNewEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
			driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmEmailID"));
			CommonFunctions.movemousepointer(driver,"//label[@for='terms']");
			
			//Click on Save button 
			CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
			CommonFunctions.verifyElement(driver, "Email Confirmation Page", obj.getEmailConfirmationTitle(),TestCaseDescription);        
			statusPassWithScreenshot(driver,"Email verification link Message ",Functionality + TestCaseID);
		/*	Thread.sleep(20000);
			
			driver.close();
			driver= LoginPage.LaunchBrowser(Browser);
			LoginPage.LaunchURL(driver,GatewayEmailURL);
			//LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
			LoginPage.EmailLogin(rowNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailUserName"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailPwd"), TestCaseID);
		
			LoginPage.EmailValidation(rowNumber, accountNumber, TestCaseID);
			
			
			 // Close child window and activate parent window
	        // CommonFunctions.SwitchToParentWindow(driver,parentWindow);*/
			
			DataBase.DBEmailUpdated(driver, accountNumber, CommonFunctions.Date(driver, TestCaseID, Functionality, TestCaseDescription), TestCaseDescription);
			
			statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
			endReporting();
		}
	}




	@Test(dataProvider="DriverSheet")
	public void test_326_C_TC002(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC002")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.6_Functional_Complex"))
		{
			
			startReporting("TC002_Existing client with secure password compulsorily set up challenge questions after the cut-off date");
			accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
			System.out.println(accountNumber);
			
			LoginPage.LaunchURL(driver,GatewayQAURL);
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
		      
	     	
			CommonFunctions.verifyElement(driver, "Setup Now", obj.getUnsecureSetUpNowButton(), Functionality + TestCaseID);
		     CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
		        CommonFunctions.waitForElement(driver, obj.getSecurityQuestionTitle(),10,"Security screen Heading");         
		  CommonFunctions.verifyElement(driver, "Security Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
		  CommonFunctions.verifySecurityElements(driver, Functionality + TestCaseID);                    
		  CommonFunctions.setSecurityFields(driver, 10, "Autotest1", 18, "Autotest2",5, "Autotest3", TestCaseDescription);
	        CommonFunctions.waitForElement(driver, obj.getSecurityQuestionContinueBtn(),10,"Security screen Heading");         
	    	
		  CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		  CommonFunctions.waitForElement(driver, obj.getEmailAddressTitle(),10,"Email address screen Heading");
		  

			//Enter valid email ID
			driver.findElement(By.xpath(obj.getEmailAddressNewEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
			driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmEmailID"));
			CommonFunctions.movemousepointer(driver,"//label[@for='terms']");
			
			//Click on Save button 
			CommonFunctions.waitForElement(driver, obj.getEmailAddressSubmitButton(),10,"Email address screen Heading");
			 
			CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
			CommonFunctions.verifyElement(driver, "Email Confirmation Page", obj.getEmailConfirmationTitle(),TestCaseDescription);        
			statusPassWithScreenshot(driver,"Email verification link Message ",Functionality + TestCaseID);
		/*	Thread.sleep(20000);
			
			driver.close();
			driver= LoginPage.LaunchBrowser(Browser);
			LoginPage.LaunchURL(driver,GatewayEmailURL);
			//LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
			LoginPage.EmailLogin(rowNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailUserName"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailPwd"), TestCaseID);
		
			LoginPage.EmailValidation(rowNumber, accountNumber, TestCaseID);
			
			
			 // Close child window and activate parent window
	        // CommonFunctions.SwitchToParentWindow(driver,parentWindow);*/
			
			DataBase.DBEmailUpdated(driver, accountNumber, CommonFunctions.Date(driver, TestCaseID, Functionality, TestCaseDescription), TestCaseDescription);
			
			statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
			endReporting();
		}
	}




	@Test(dataProvider="DriverSheet")
	public void test_326_C_TC014(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC014")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.6_Functional_Complex"))
		{
			
			startReporting(TestCaseDescription);
			accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
			System.out.println(accountNumber);
			
			LoginPage.LaunchURL(driver,GatewayQAURL);
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
		      
	     	
			CommonFunctions.verifyElement(driver, "Setup Now", obj.getUnsecureSetUpNowButton(), Functionality + TestCaseID);
		     CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
		        CommonFunctions.waitForElement(driver, obj.getSecurityQuestionTitle(),10,"Security screen Heading");         
		  CommonFunctions.verifyElement(driver, "Security Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
		  CommonFunctions.verifySecurityElements(driver, Functionality + TestCaseID);                    
		  CommonFunctions.setSecurityFields(driver, 10, "Autotest1", 18, "Autotest2",5, "Autotest3", TestCaseDescription);
		  CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		  CommonFunctions.waitForElement(driver, obj.getEmailAddressTitle(),10,"Email address screen Heading");
		  

			//Enter valid email ID
			driver.findElement(By.xpath(obj.getEmailAddressNewEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
			driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmEmailID"));
			CommonFunctions.movemousepointer(driver,"//label[@for='terms']");
				
			//Click on Save button 
			CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
			CommonFunctions.verifyElement(driver, "Email Confirmation Page", obj.getEmailConfirmationTitle(),TestCaseDescription);        
			statusPassWithScreenshot(driver,"Email verification link Message ",Functionality + TestCaseID);
			//Thread.sleep(120000);
			/*Thread.sleep(20000);
			driver.close();
			driver= LoginPage.LaunchBrowser(Browser);
			LoginPage.LaunchURL(driver,GatewayEmailURL);
			//LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
			LoginPage.EmailLogin(rowNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailUserName"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailPwd"), TestCaseID);
		
			LoginPage.EmailValidation(rowNumber, accountNumber, TestCaseID);
			
			CommonFunctions.verifyElement(driver,"Login Button on verified account", obj.getEmailVerifiedButton(), TestCaseDescription);
			driver.findElement(By.xpath(obj.getEmailVerifiedButton()))
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
			  CommonFunctions.verifyElement(driver,"Home page",obj.getHomePageLogo(), TestCaseDescription);
			 // Close child window and activate parent window
	        // CommonFunctions.SwitchToParentWindow(driver,parentWindow);*/
			  
			  
			  DataBase.DBChallengeQuesUpdated(driver,accountNumber,TestCaseDescription);
			//  DataBase.DBVerifyNloginPwdRequiresReset (driver,accountNumber,TestCaseDescription);
			 // DataBase.DBVerifyProfileValid1 (driver,accountNumber,TestCaseDescription);
			  DataBase.DBEmailUpdated(driver,accountNumber ,CommonFunctions.Date(driver, TestCaseID, Functionality, TestCaseDescription), TestCaseDescription);
			
			statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
			endReporting();
		}
	}


	@Test(dataProvider="DriverSheet")
	public void test_326_C_TC057(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC057")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.6_Functional_Complex"))
		{
			
			startReporting(TestCaseDescription);
			accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
			System.out.println(accountNumber);
			
			LoginPage.LaunchURL(driver,GatewayQAURL);
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
		      
	     	
			CommonFunctions.verifyElement(driver, "Setup Now", obj.getUnsecureSetUpNowButton(), Functionality + TestCaseID);
		     CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
		        CommonFunctions.waitForElement(driver, obj.getSecurityQuestionTitle(),10,"Security screen Heading");         
		  CommonFunctions.verifyElement(driver, "Security Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
		  CommonFunctions.verifySecurityElements(driver, Functionality + TestCaseID);                    
		  CommonFunctions.setSecurityFields(driver, 10, "Autotest1", 18, "Autotest2",5, "Autotest3", TestCaseDescription);
		  CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		  CommonFunctions.waitForElement(driver, obj.getEmailAddressTitle(),10,"Email address screen Heading");
		  

			//Enter valid email ID
			driver.findElement(By.xpath(obj.getEmailAddressNewEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
			driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmEmailID"));
		//	driver.findElement(By.xpath(obj.getEmailAddressTermsCheckBox()))
			CommonFunctions.movemousepointer(driver,"//label[@for='terms']");
			
			//Click on Save button 
			CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
			CommonFunctions.verifyElement(driver, "Email Confirmation Page", obj.getEmailConfirmationTitle(),TestCaseDescription);        
			statusPassWithScreenshot(driver,"Email verification link Message ",Functionality + TestCaseID);
			//Thread.sleep(120000);
		/*	Thread.sleep(20000);
			driver.close();
			driver= LoginPage.LaunchBrowser(Browser);
			LoginPage.LaunchURL(driver,GatewayEmailURL);
			//LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
			LoginPage.EmailLogin(rowNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailUserName"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailPwd"), TestCaseID);
		
			LoginPage.EmailValidation(rowNumber, accountNumber, TestCaseID);
			
			CommonFunctions.verifyElement(driver,"Login Button on verified account", obj.getEmailVerifiedButton(), TestCaseDescription);
			driver.findElement(By.xpath(obj.getEmailVerifiedButton()))CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());
			 DataBase.DBEmailUpdated(driver,accountNumber ,CommonFunctions.Date(driver, TestCaseID, Functionality, TestCaseDescription), TestCaseDescription);
				
				statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
			endReporting();
		}
	}

	//COMPLETE END TO END

	@Test(dataProvider="DriverSheet")
	public void test_326_C_TC058(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC058")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.6_Functional_Complex"))
		{
			
			startReporting(TestCaseDescription);
			accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
			System.out.println(accountNumber);
			
			LoginPage.LaunchURL(driver,GatewayQAURL);
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
		      
	     	
			CommonFunctions.verifyElement(driver, "Setup Now", obj.getUnsecureSetUpNowButton(), Functionality + TestCaseID);
		     CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
		        CommonFunctions.waitForElement(driver, obj.getSecurityQuestionTitle(),10,"Security screen Heading");         
		  CommonFunctions.verifyElement(driver, "Security Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
		  CommonFunctions.verifySecurityElements(driver, Functionality + TestCaseID);                    
		  CommonFunctions.setSecurityFields(driver, 10, "Autotest1", 18, "Autotest2",5, "Autotest3", TestCaseDescription);
		  CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		  CommonFunctions.waitForElement(driver, obj.getEmailAddressTitle(),10,"Email address screen Heading");
		  

			//Enter valid email ID
			driver.findElement(By.xpath(obj.getEmailAddressNewEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
			driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmEmailID"));
			CommonFunctions.movemousepointer(driver,"//label[@for='terms']");
			
			//Click on Save button 
			CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
			CommonFunctions.verifyElement(driver, "Email Confirmation Page", obj.getEmailConfirmationTitle(),TestCaseDescription);        
			statusPassWithScreenshot(driver,"Email verification link Message ",Functionality + TestCaseID);
			
			
			//Thread.sleep(120000);
			/*Thread.sleep(20000);
			driver.close();
			driver= LoginPage.LaunchBrowser(Browser);
			LoginPage.LaunchURL(driver,GatewayEmailURL);
			//LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
			LoginPage.EmailLogin(rowNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailUserName"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailPwd"), TestCaseID);
		
			LoginPage.EmailValidation(rowNumber, accountNumber, TestCaseID);
			
			CommonFunctions.verifyElement(driver,"Login Button on verified account", obj.getEmailVerifiedButton(), TestCaseDescription);
			driver.findElement(By.xpath(obj.getEmailVerifiedButton()))
			LoginPage.LaunchURL(driver,GatewayQAURL);
			
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
			  CommonFunctions.verifyElement(driver,"Home page",obj.getHomePageLogo(), TestCaseDescription);*/
			 // Close child window and activate parent window
	        // CommonFunctions.SwitchToParentWindow(driver,parentWindow);
			  
			  DataBase.DBEmailUpdated(driver,accountNumber ,CommonFunctions.Date(driver, TestCaseID, Functionality, TestCaseDescription), TestCaseDescription);
				
			
			statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
			endReporting();
		}
	}


	@Test(dataProvider="DriverSheet")
	public void test_326_C_TC046(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC046")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.6_Functional_Complex"))
		{
			
			startReporting(TestCaseDescription);
			accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
			System.out.println(accountNumber);
			
			LoginPage.LaunchURL(driver,GatewayQAURL);
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
		      
	     	
			CommonFunctions.verifyElement(driver, "Setup Now", obj.getUnsecureSetUpNowButton(), Functionality + TestCaseID);
		     CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
		        CommonFunctions.waitForElement(driver, obj.getSecurityQuestionTitle(),10,"Security screen Heading");         
		  CommonFunctions.verifyElement(driver, "Security Screen", obj.getChallengeQuestionTitleNew(),TestCaseDescription);        
		  CommonFunctions.verifySecurityElements(driver, Functionality + TestCaseID);                    
		  CommonFunctions.setSecurityFields(driver, 10, "Autotest1", 18, "Autotest2",5, "Autotest3", TestCaseDescription);
		  CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		  CommonFunctions.waitForElement(driver, obj.getEmailAddressTitle(),10,"Email address screen Heading");
		  

			//Enter valid email ID
			driver.findElement(By.xpath(obj.getEmailAddressNewEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
			driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmEmailID"));
		//	driver.findElement(By.xpath(obj.getEmailAddressTermsCheckBox()))
			CommonFunctions.movemousepointer(driver,"//label[@for='terms']");
			CommonFunctions.checkFontColour(driver,obj.getEmailAddressConfirmEmailCheck(), "rgba(0, 138, 0, 1)","Confirm Email Check",TestCaseDescription);
		      
			
			statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
			endReporting();

		}
	}


	@Test(dataProvider="DriverSheet")
	public void test_326_C_TC020(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC020")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.6_Functional_Complex"))
		{
			
			startReporting(TestCaseDescription);
			accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
			System.out.println(accountNumber);
			
			LoginPage.LaunchURL(driver,GatewayQAURL);
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
		      
	     	
			CommonFunctions.verifyElement(driver, "Setup Now", obj.getUnsecureSetUpNowButton(), Functionality + TestCaseID);
		     CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
		        CommonFunctions.waitForElement(driver, obj.getSecurityQuestionTitle(),10,"Security screen Heading");         
		  CommonFunctions.verifyElement(driver, "Security Screen", obj.getChallengeQuestionTitleNew(),TestCaseDescription);        
		  CommonFunctions.verifySecurityElements(driver, Functionality + TestCaseID);  
		  
		  //1->2->3
		  CommonFunctions.getQuestionList(driver,obj.getQuestion1(), TestCaseDescription);
		  CommonFunctions.setSecurityFields(driver, 1, "Autotest1", 2, "Autotest2",3, "Autotest3", TestCaseDescription);
		  statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);   
			driver.navigate().refresh();
			
			 //1->3->2
			 Thread.sleep(5000);
			  CommonFunctions.getQuestionList(driver,obj.getQuestion1(), TestCaseDescription);
			  CommonFunctions.setSecurityFields(driver, 1, "Autotest1", 3, "Autotest2",2, "Autotest3", TestCaseDescription);
			  statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);   
				driver.navigate().refresh();
				
				//2->1->3
				 Thread.sleep(5000);
				  CommonFunctions.getQuestionList(driver,obj.getQuestion1(), TestCaseDescription);
				  CommonFunctions.setSecurityFields(driver, 2, "Autotest1", 1, "Autotest2",3, "Autotest3", TestCaseDescription);
				  statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);   
					driver.navigate().refresh();
		//2->3->1	
			 Thread.sleep(5000);
			CommonFunctions.getQuestionList(driver,obj.getQuestion1(), TestCaseDescription);
			  CommonFunctions.setSecurityFields(driver, 2, "Autotest1", 3, "Autotest2",1, "Autotest3", TestCaseDescription);
			  statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
				driver.navigate().refresh();
				//3->1->2	
				 Thread.sleep(5000);
				CommonFunctions.getQuestionList(driver,obj.getQuestion1(), TestCaseDescription);
				  CommonFunctions.setSecurityFields(driver, 3, "Autotest1", 1, "Autotest2",2, "Autotest3", TestCaseDescription);
				  statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
					driver.navigate().refresh();
			  //3->2->1
			  Thread.sleep(5000);
			  CommonFunctions.getQuestionList(driver,obj.getQuestion1(), TestCaseDescription);
			  CommonFunctions.setSecurityFields(driver, 3, "Autotest1", 2, "Autotest2",1, "Autotest3", TestCaseDescription);
			 
			statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
			endReporting();
		}
	}


	@Test(dataProvider="DriverSheet")
	public void test_326_M_TC053(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC053")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.6_Functional_Medium"))
		{
			
			startReporting(TestCaseDescription);
			accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
			System.out.println(accountNumber);
			
			LoginPage.LaunchURL(driver,GatewayQAURL);
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
		      
	     	
			CommonFunctions.verifyElement(driver, "Setup Now", obj.getUnsecureSetUpNowButton(), Functionality + TestCaseID);
		     CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
		        CommonFunctions.waitForElement(driver, obj.getSecurityQuestionTitle(),10,"Security screen Heading");         
		  CommonFunctions.verifyElement(driver, "Security Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
		  CommonFunctions.verifySecurityElements(driver, Functionality + TestCaseID);                    
		  CommonFunctions.setSecurityFields(driver, 10, "Autotest1", 18, "Autotest2",5, "Autotest3", TestCaseDescription);
		  CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		  CommonFunctions.waitForElement(driver, obj.getEmailAddressTitle(),10,"Email address screen Heading");
		  

			//Enter valid email ID
			driver.findElement(By.xpath(obj.getEmailAddressNewEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
			driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmEmailID"));
			
			CommonFunctions.movemousepointer(driver,"//label[@for='terms']");
			
			
			//Click on Save button 
			CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
			CommonFunctions.verifyElement(driver, "Email Confirmation Page", obj.getEmailConfirmationTitle(),TestCaseDescription);        
			statusPassWithScreenshot(driver,"Email verification link Message ",Functionality + TestCaseID);
			
			Thread.sleep(3000);
			DataBase.DBEmailUpdated(driver,accountNumber, CommonFunctions.Date(driver, TestCaseID, Functionality, TestCaseDescription), TestCaseDescription);
			
			statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
			endReporting();
		}
	}


	@Test(dataProvider="DriverSheet")
	public void test_326_M_TC054(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC054")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.6_Functional_Medium"))
		{
			
			startReporting(TestCaseDescription);
			accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
			System.out.println(accountNumber);
			
			LoginPage.LaunchURL(driver,GatewayQAURL);
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
		      
	     	
			CommonFunctions.verifyElement(driver, "Setup Now", obj.getUnsecureSetUpNowButton(), Functionality + TestCaseID);
		     CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
		        CommonFunctions.waitForElement(driver, obj.getSecurityQuestionTitle(),10,"Security screen Heading");         
		  CommonFunctions.verifyElement(driver, "Security Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
		  CommonFunctions.verifySecurityElements(driver, Functionality + TestCaseID);                    
		  CommonFunctions.setSecurityFields(driver, 10, "Autotest1", 18, "Autotest2",5, "Autotest3", TestCaseDescription);
		  CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		  CommonFunctions.waitForElement(driver, obj.getEmailAddressTitle(),10,"Email address screen Heading");
		  

			//Enter valid email ID
			driver.findElement(By.xpath(obj.getEmailAddressNewEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
			driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmEmailID"));
			CommonFunctions.movemousepointer(driver,"//label[@for='terms']");
			
			
			//Click on Save button 
			CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
			CommonFunctions.verifyElement(driver, "Email Confirmation Page", obj.getEmailConfirmationTitle(),TestCaseDescription);        
			statusPassWithScreenshot(driver,"Email verification link Message ",Functionality + TestCaseID);
		/*	driver.close();
			driver= LoginPage.LaunchBrowser(Browser);
			LoginPage.LaunchURL(driver,GatewayEmailURL);
			//LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
			LoginPage.EmailLogin(rowNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailUserName"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailPwd"), TestCaseID);
		
			LoginPage.EmailValidation(rowNumber, accountNumber, TestCaseID);
			
			CommonFunctions.verifyElement(driver,"Login Button on verified account", obj.getEmailVerifiedButton(), TestCaseDescription);
			driver.findElement(By.xpath(obj.getEmailVerifiedButton()))
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
			  CommonFunctions.verifyElement(driver,"Home page",obj.getHomePageLogo(), TestCaseDescription);
			 // Close child window and activate parent window
	        // CommonFunctions.SwitchToParentWindow(driver,parentWindow);
			  
			  Thread.sleep(3000);*/
				DataBase.DBEmailUpdated(driver,accountNumber, CommonFunctions.Date(driver, TestCaseID, Functionality, TestCaseDescription), TestCaseDescription);
				
			
			statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
			endReporting();
		}
	}


	@Test(dataProvider="DriverSheet")
	public void test_326_M_TC060(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC060")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.6_Functional_Medium"))
		{
			
			startReporting(TestCaseDescription);
			accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
			System.out.println(accountNumber);
			
			LoginPage.LaunchURL(driver,GatewayQAURL);
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
		      
	     	
			CommonFunctions.verifyElement(driver, "Setup Now", obj.getUnsecureSetUpNowButton(), Functionality + TestCaseID);
		     CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
		        CommonFunctions.waitForElement(driver, obj.getSecurityQuestionTitle(),10,"Security screen Heading");         
		  CommonFunctions.verifyElement(driver, "Security Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
		  CommonFunctions.verifySecurityElements(driver, Functionality + TestCaseID);                    
		  CommonFunctions.setSecurityFields(driver, 10, "Autotest1", 18, "Autotest2",5, "Autotest3", TestCaseDescription);
		  CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		  CommonFunctions.waitForElement(driver, obj.getEmailAddressTitle(),10,"Email address screen Heading");
		  

			//Enter valid email ID
			driver.findElement(By.xpath(obj.getEmailAddressNewEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
			driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmEmailID"));
		CommonFunctions.movemousepointer(driver,"//label[@for='terms']");
			
			//Click on Save button 
			CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
			
			LoginPage.LaunchURL(driver,GatewayQAURL);
			
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
			  CommonFunctions.verifyElement(driver,"Go To Login Page Button",obj.getGoToLoginPageButton(), TestCaseDescription);
			 // Close child window and activate parent window
	        // CommonFunctions.SwitchToParentWindow(driver,parentWindow);
			  
			  Thread.sleep(3000);
				DataBase.DBEmailUpdated(driver,accountNumber, CommonFunctions.Date(driver, TestCaseID, Functionality, TestCaseDescription), TestCaseDescription);
				
			
			statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
			endReporting();
		}
	}


	@Test(dataProvider="DriverSheet")
	public void test_326_M_TC061(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC061")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.6_Functional_Medium"))
		{
			
			startReporting(TestCaseDescription);
			accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
			System.out.println(accountNumber);
			
			LoginPage.LaunchURL(driver,GatewayQAURL);
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
		      
	     	
			CommonFunctions.verifyElement(driver, "Setup Now", obj.getUnsecureSetUpNowButton(), Functionality + TestCaseID);
		     CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
		        CommonFunctions.waitForElement(driver, obj.getSecurityQuestionTitle(),10,"Security screen Heading");         
		  CommonFunctions.verifyElement(driver, "Security Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
		  CommonFunctions.verifySecurityElements(driver, Functionality + TestCaseID);                    
		  CommonFunctions.setSecurityFields(driver, 10, "Autotest1", 18, "Autotest2",5, "Autotest3", TestCaseDescription);
		  CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		  CommonFunctions.waitForElement(driver, obj.getEmailAddressTitle(),10,"Email address screen Heading");
		  

			//Enter valid email ID
			driver.findElement(By.xpath(obj.getEmailAddressNewEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
			driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmEmailID"));
			CommonFunctions.movemousepointer(driver,"//label[@for='terms']");
			
			
			//Click on Save button 
			CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
			
			LoginPage.LaunchURL(driver,GatewayQAURL);
			
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
			  CommonFunctions.verifyElement(driver,"Go To Login Page Button",obj.getGoToLoginPageButton(), TestCaseDescription);
			 // Close child window and activate parent window
	        // CommonFunctions.SwitchToParentWindow(driver,parentWindow);
			  
			  Thread.sleep(3000);
				DataBase.DBEmailUpdated(driver,accountNumber, CommonFunctions.Date(driver, TestCaseID, Functionality, TestCaseDescription), TestCaseDescription);
				
			
			statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
			endReporting();
		}
	}

	@Test(dataProvider="DriverSheet")
	public void test_326_M_TC056(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC056")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.6_Functional_Medium"))
		{
			
			startReporting(TestCaseDescription);
			accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
			System.out.println(accountNumber);
			
			LoginPage.LaunchURL(driver,GatewayQAURL);
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
		      
	     	
			CommonFunctions.verifyElement(driver, "Setup Now", obj.getUnsecureSetUpNowButton(), Functionality + TestCaseID);
		     CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
		     
		      CommonFunctions.waitForElement(driver, obj.getSecurityQuestionTitle(),10,"Security screen Heading");         
		  CommonFunctions.verifyElement(driver, "Security Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
		  CommonFunctions.verifySecurityElements(driver, Functionality + TestCaseID);                    
		  CommonFunctions.setSecurityFields(driver, 10, "Autotest1", 18, "Autotest2",5, "Autotest3", TestCaseDescription);
		  CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		  CommonFunctions.waitForElement(driver, obj.getEmailAddressTitle(),10,"Email address screen Heading");
		  

			//Enter valid email ID
			driver.findElement(By.xpath(obj.getEmailAddressNewEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
			driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmEmailID"));
			CommonFunctions.movemousepointer(driver,"//label[@for='terms']");
			
			//Click on Save button 
			CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
			CommonFunctions.verifyElement(driver, "Email Confirmation Page", obj.getEmailConfirmationTitle(),TestCaseDescription);        
			statusPassWithScreenshot(driver,"Email verification link Message ",Functionality + TestCaseID);
			
			DataBase.DBEmailUpdated(driver, accountNumber, CommonFunctions.Date(driver, TestCaseID, Functionality, TestCaseDescription), TestCaseDescription);
			//Thread.sleep(120000);
			/*Thread.sleep(20000);
			driver.close();
			driver= LoginPage.LaunchBrowser(Browser);
			LoginPage.LaunchURL(driver,GatewayEmailURL);
			//LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
			LoginPage.EmailLogin(rowNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailUserName"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailPwd"), TestCaseID);
		
			LoginPage.EmailValidation(rowNumber, accountNumber, TestCaseID);
			
			CommonFunctions.verifyElement(driver,"Login Button on verified account", obj.getEmailVerifiedButton(), TestCaseDescription);
			driver.findElement(By.xpath(obj.getEmailVerifiedButton()))
			LoginPage.LaunchURL(driver,GatewayQAURL);
			
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
			  CommonFunctions.verifyElement(driver,"Home page",obj.getHomePageLogo(), TestCaseDescription);
			 // Close child window and activate parent window
	        // CommonFunctions.SwitchToParentWindow(driver,parentWindow);*/
			  
			  
			
			statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
			endReporting();
		}
	}

	@Test(dataProvider="DriverSheet")
	public void test_326_C_TC005(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC005")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.6_Functional_Complex"))
		{
			
			startReporting(TestCaseDescription);
			accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
			System.out.println(accountNumber);
			
			LoginPage.LaunchURL(driver,GatewayQAURL);
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
		      
	     	
			CommonFunctions.verifyElement(driver, "Setup Now", obj.getUnsecureSetUpNowButton(), Functionality + TestCaseID);
		     CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
		     
		     
		     
		      CommonFunctions.waitForElement(driver, obj.getSecurityQuestionTitle(),10,"Security screen Heading"); 
		      
		    driver.close();
			driver= LoginPage.LaunchBrowser(Browser);
			LoginPage.LaunchURL(driver,GatewayQAURL);
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
			CommonFunctions.waitForElement(driver, obj.getGoToLoginPageButton(),10,"Go To Login Page Button"); 
			
			  LoginPage.LaunchURL(driver,GatewayAdminURL);
		      String tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
		   
		      LoginPage.LaunchURL(driver,GatewayQAURL);
				LoginPage.Login(rowNumber,accountNumber,tempPassword,"Home",Functionality + TestCaseID);
			  
				CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
		   	   // CommonFunctions.checkDisabled(driver, obj.getContinueButton(), "Login Password Page Continue Button",TestCaseDescription );
		      CommonFunctions.ClickButton(driver,obj.getContinueButton());
				
		  CommonFunctions.verifyElement(driver, "Security Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
		  CommonFunctions.verifySecurityElements(driver, Functionality + TestCaseID);                    
		  CommonFunctions.setSecurityFields(driver, 10, "Autotest1", 18, "Autotest2",5, "Autotest3", TestCaseDescription);
		  CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		  CommonFunctions.waitForElement(driver, obj.getEmailAddressTitle(),10,"Email address screen Heading");
		  
		  
		
			//Enter valid email ID
			driver.findElement(By.xpath(obj.getEmailAddressNewEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
			driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmEmailID"));
			CommonFunctions.movemousepointer(driver,"//label[@for='terms']");
			
			
			//Click on Save button 
			CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
			CommonFunctions.verifyElement(driver, "Email Confirmation Page", obj.getEmailConfirmationTitle(),TestCaseDescription);        
			statusPassWithScreenshot(driver,"Email verification link Message ",Functionality + TestCaseID);
			//Thread.sleep(120000);
			/*Thread.sleep(20000);
			driver.close();
			driver= LoginPage.LaunchBrowser(Browser);
			LoginPage.LaunchURL(driver,GatewayEmailURL);
			//LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
			LoginPage.EmailLogin(rowNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailUserName"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailPwd"), TestCaseID);
		
			LoginPage.EmailValidation(rowNumber, accountNumber, TestCaseID);
			
			CommonFunctions.verifyElement(driver,"Login Button on verified account", obj.getEmailVerifiedButton(), TestCaseDescription);
			driver.findElement(By.xpath(obj.getEmailVerifiedButton()))
		
			
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"),"Home",Functionality + TestCaseID);
			  CommonFunctions.verifyElement(driver,"Home page",obj.getHomePageLogo(), TestCaseDescription);
			 // Close child window and activate parent window
	        // CommonFunctions.SwitchToParentWindow(driver,parentWindow);*/
			  
			  DataBase.DBChallengeQuesUpdated(driver,accountNumber,TestCaseDescription);
			//  DataBase.DBVerifyNloginPwdRequiresReset (driver,accountNumber,TestCaseDescription);
			 // DataBase.DBVerifyProfileValid1 (driver,accountNumber,TestCaseDescription);
			  
			
			  DataBase.DBEmailUpdated(driver,accountNumber ,CommonFunctions.Date(driver, TestCaseID, Functionality, TestCaseDescription), TestCaseDescription);
				
			statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
			endReporting();
		}
	}

	@Test(dataProvider="DriverSheet")
	public void test_326_C_TC007(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC007")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.6_Functional_Complex"))
		{
			
			startReporting(TestCaseDescription);
			accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
			System.out.println(accountNumber);
			
			LoginPage.LaunchURL(driver,GatewayQAURL);
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
		      
	     	
			CommonFunctions.verifyElement(driver, "Setup Now", obj.getUnsecureSetUpNowButton(), Functionality + TestCaseID);
		    
		     CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
		     
		     
		     
		      CommonFunctions.waitForElement(driver, obj.getSecurityQuestionTitle(),10,"Security screen Heading"); 
		      CommonFunctions.verifySecurityElements(driver, Functionality + TestCaseID);                    
			  CommonFunctions.setSecurityFields(driver, 10, "Autotest1", 18, "Autotest2",5, "Autotest3", TestCaseDescription);
			  CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
			  CommonFunctions.waitForElement(driver, obj.getEmailAddressTitle(),10,"Email address screen Heading");
			
		    driver.close();
			driver= LoginPage.LaunchBrowser(Browser);
			LoginPage.LaunchURL(driver,GatewayQAURL);
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
			CommonFunctions.waitForElement(driver, obj.getGoToLoginPageButton(),10,"Go To Login Page Button"); 
			
			  LoginPage.LaunchURL(driver,GatewayAdminURL);
		      String tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
		   
		      LoginPage.LaunchURL(driver,GatewayQAURL);
				LoginPage.Login(rowNumber,accountNumber,tempPassword,"Home",Functionality + TestCaseID);
			  
				CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmPassword_Eng"));
		   	  CommonFunctions.ClickButton(driver,obj.getContinueButton());
				
		  CommonFunctions.verifyElement(driver, "Security Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
		  CommonFunctions.verifySecurityElements(driver, Functionality + TestCaseID);                    
		  CommonFunctions.setSecurityFields(driver, 10, "Autotest1", 18, "Autotest2",5, "Autotest3", TestCaseDescription);
		  CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		  CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		  CommonFunctions.waitForElement(driver, obj.getEmailAddressTitle(),10,"Email address screen Heading");
		  
		  
		
			//Enter valid email ID
			driver.findElement(By.xpath(obj.getEmailAddressNewEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
			driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmEmailID"));
			CommonFunctions.movemousepointer(driver,"//label[@for='terms']");
				
			//Click on Save button 
			
			CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
			CommonFunctions.verifyElement(driver, "Email Confirmation Page", obj.getEmailConfirmationTitle(),TestCaseDescription);        
			statusPassWithScreenshot(driver,"Email verification link Message ",Functionality + TestCaseID);
			//Thread.sleep(120000);
			/*Thread.sleep(20000);
			driver.close();
			driver= LoginPage.LaunchBrowser(Browser);
			LoginPage.LaunchURL(driver,GatewayEmailURL);
			//LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
			LoginPage.EmailLogin(rowNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailUserName"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailPwd"), TestCaseID);
		
			LoginPage.EmailValidation(rowNumber, accountNumber, TestCaseID);
			
			CommonFunctions.verifyElement(driver,"Login Button on verified account", obj.getEmailVerifiedButton(), TestCaseDescription);
			driver.findElement(By.xpath(obj.getEmailVerifiedButton()))
		
			
			LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"),"Home",Functionality + TestCaseID);
			  CommonFunctions.verifyElement(driver,"Home page",obj.getHomePageLogo(), TestCaseDescription);
			 // Close child window and activate parent window
	        // CommonFunctions.SwitchToParentWindow(driver,parentWindow);*/
			  
			  DataBase.DBChallengeQuesUpdated(driver,accountNumber,TestCaseDescription);
			//  DataBase.DBVerifyNloginPwdRequiresReset (driver,accountNumber,TestCaseDescription);
			//  DataBase.DBVerifyProfileValid1 (driver,accountNumber,TestCaseDescription);
			
			  DataBase.DBEmailUpdated(driver,accountNumber ,CommonFunctions.Date(driver, TestCaseID, Functionality, TestCaseDescription), TestCaseDescription);
				
			statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
			endReporting();
		}


 }



//************************** END OF CODE **************************************
	
	
	/*__________________Statrt of Poorva Scripts______________________*/
	
	
	
	
	
	/*
	 * @author=Poorva Dixit
	 */

	@Test(dataProvider = "DriverSheet")
	public void test_322_TC081(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC081")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.2_Functional_Low")) {

			startReporting("3.2.2_Functional_Low_TC081_GUI_Set up challenge questions screen");

			// Launching the admin url
			LoginPage.LaunchURL(driver, GatewayAdminURL);
			// Storing temporary password from admin Url
			String tempPassword = Admin.getTemporaryPassword(driver,
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			// Storing the trading password

			Admin.getTemporaryTradingPassword(driver, ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Username_Eng"));

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));
			// Logging in using temporary password
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), tempPassword, "Home",
					Functionality + TestCaseID);
			// verifying the screen of create a new password
			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(),
					"3.2.2_Functional_Low_TC081");
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					"3.2.2_Functional_Low_TC081");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					"3.2.2_Functional_Low_TC081");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					"3.2.2_Functional_Low_TC081");
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", "3.2.2_Functional_Low_TC081");

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_ConfirmPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					"3.2.2_Functional_Low_TC081");
			
			
			
			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			/*
			 * Moving to Trading screen verifyElement
			 */CommonFunctions.verifyText(driver,
					"Create a new Trading password", obj.getTradingTitle(),
					"3.2.2_Functional_Low_TC081");

			driver.findElement(By.xpath(obj.getTradingNewPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_TradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingMinimum6chracters(), "rgba(0, 138, 0, 1)",
					"Minimum 6 characters", "3.2.2_Functional_Low_TC081");

			driver.findElement(By.xpath(obj.getTradingConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality,
									"p_ConfirmTradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingConfirmPasswordCheck(), "rgba(0, 138, 0, 1)",
					"Confirmed, your Trading passwords match",
					"3.2.2_Functional_Low_TC081");

			
			CommonFunctions.ClickButton(driver,obj.getTradingContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.2_Functional_Low_TC081");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC081",
					"3.2.2_Functional_Low_TC081");

			endReporting();

		}
	}

	/*
	 * @author=Poorva Dixit
	 */

	@Test(dataProvider = "DriverSheet")
	public void test_322_TC082(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC082")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.2_Functional_Low")) {

			startReporting("3.2.2_Functional_Low_TC082_GUI_Set up challenge questions screen");

			// Launching the admin url
			LoginPage.LaunchURL(driver, GatewayAdminURL);
			// Storing temporary password from admin Url
			String tempPassword = Admin.getTemporaryPassword(driver,
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			// Storing the trading password

			Admin.getTemporaryTradingPassword(driver, ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Username_Eng"));

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));
			// Logging in using temporary password
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), tempPassword, "Home",
					Functionality + TestCaseID);
			// verifying the screen of create a new password
			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(),
					"3.2.2_Functional_Low_TC082");
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					"3.2.2_Functional_Low_TC082");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					"3.2.2_Functional_Low_TC082");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					"3.2.2_Functional_Low_TC082");
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", "3.2.2_Functional_Low_TC082");

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_ConfirmPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					"3.2.2_Functional_Low_TC082");
			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			/*
			 * Moving to Trading screen verifyElement
			 */CommonFunctions.verifyText(driver,
					"Create a new Trading password", obj.getTradingTitle(),
					"3.2.2_Functional_Low_TC082");

			driver.findElement(By.xpath(obj.getTradingNewPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_TradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingMinimum6chracters(), "rgba(0, 138, 0, 1)",
					"Minimum 6 characters", "3.2.2_Functional_Low_TC082");

			driver.findElement(By.xpath(obj.getTradingConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality,
									"p_ConfirmTradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingConfirmPasswordCheck(), "rgba(0, 138, 0, 1)",
					"Confirmed, your Trading passwords match",
					"3.2.2_Functional_Low_TC082");

			CommonFunctions.ClickButton(driver,obj.getTradingContinueButton());
			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.2_Functional_Low_TC082");
			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getQuestion1(), "3.2.2_Functional_Low_TC082");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getQuestion2(), "3.2.2_Functional_Low_TC082");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getQuestion3(), "3.2.2_Functional_Low_TC082");

			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_322_TC083(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC083")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.2_Functional_Low")) {

			startReporting("3.2.2_Functional_Low_TC083_GUI_Set up challenge questions screen_Challenge questions dropdown");

			// Launching the admin url
			LoginPage.LaunchURL(driver, GatewayAdminURL);
			// Storing temporary password from admin Url
			String tempPassword = Admin.getTemporaryPassword(driver,
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			// Storing the trading password

			Admin.getTemporaryTradingPassword(driver, ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Username_Eng"));

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));
			// Logging in using temporary password
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), tempPassword, "Home",
					Functionality + TestCaseID);
			// verifying the screen of create a new password
			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(),
					"3.2.2_Functional_Low_TC083");
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					"3.2.2_Functional_Low_TC083");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					"3.2.2_Functional_Low_TC083");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					"3.2.2_Functional_Low_TC083");
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", "3.2.2_Functional_Low_TC083");

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_ConfirmPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					"3.2.2_Functional_Low_TC083");
			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			/*
			 * Moving to Trading screen verifyElement
			 */CommonFunctions.verifyText(driver,
					"Create a new Trading password", obj.getTradingTitle(),
					"3.2.2_Functional_Low_TC083");

			driver.findElement(By.xpath(obj.getTradingNewPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_TradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingMinimum6chracters(), "rgba(0, 138, 0, 1)",
					"Minimum 6 characters", "3.2.2_Functional_Low_TC083");

			driver.findElement(By.xpath(obj.getTradingConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality,
									"p_ConfirmTradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingConfirmPasswordCheck(), "rgba(0, 138, 0, 1)",
					"Confirmed, your Trading passwords match",
					"3.2.2_Functional_Low_TC083");

			CommonFunctions.ClickButton(driver,obj.getTradingContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.2_Functional_Low_TC083");
			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getQuestion1(), "3.2.2_Functional_Low_TC083");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getQuestion2(), "3.2.2_Functional_Low_TC083");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getQuestion3(), "3.2.2_Functional_Low_TC083");
			// Clicking on First question dropdown
			
			CommonFunctions.ClickButton(driver,obj.getQuestion1());

		CommonFunctions.getQuestionList(driver, obj.getQuestion1(),"3.2.2_Functional_Low_TC083");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_322_TC084(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC084")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.2_Functional_Low")) {

			startReporting("3.2.2_Functional_Low_TC084_GUI_Set up challenge questions screen_Challenge questions dropdow");
			/*------------  Pre-requisites---------- */
			LoginPage.LaunchURL(driver, GatewayAdminURL);

			String tempPassword = Admin.getTemporaryPassword(driver,
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			// Storing the trading password

			Admin.getTemporaryTradingPassword(driver, ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Username_Eng"));
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));
			// Logging in using temporary password

			/*------------  Step2 and Step3 and Step4 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), tempPassword, "Home",
					Functionality + TestCaseID);

			/*------------  Step5---------- */

			// verifying the screen of create a new password
			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(),
					"3.2.2_Functional_Low_TC084");

			/*------------  Step6---------- */
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					"3.2.2_Functional_Low_TC084");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					"3.2.2_Functional_Low_TC084");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					"3.2.2_Functional_Low_TC084");
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", "3.2.2_Functional_Low_TC084");

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_ConfirmPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					"3.2.2_Functional_Low_TC084");
			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			/*------------  Step7---------- */

			/*
			 * Moving to Trading screen verifyElement
			 */CommonFunctions.verifyText(driver,
					"Create a new Trading password", obj.getTradingTitle(),
					"3.2.2_Functional_Low_TC084");

			driver.findElement(By.xpath(obj.getTradingNewPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_TradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingMinimum6chracters(), "rgba(0, 138, 0, 1)",
					"Minimum 6 characters", "3.2.2_Functional_Low_TC084");

			driver.findElement(By.xpath(obj.getTradingConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality,
									"p_ConfirmTradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingConfirmPasswordCheck(), "rgba(0, 138, 0, 1)",
					"Confirmed, your Trading passwords match",
					"3.2.2_Functional_Low_TC084");

			CommonFunctions.ClickButton(driver,obj.getTradingContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.2_Functional_Low_TC084");

			/*------------  Step8---------- */

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getQuestion1(), "3.2.2_Functional_Low_TC084");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getQuestion2(), "3.2.2_Functional_Low_TC084");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getQuestion3(), "3.2.2_Functional_Low_TC084");

			/*------------  Step9---------- */

			// Clicking on First question dropdown
			
			CommonFunctions.ClickButton(driver,obj.getQuestion2());
			

			CommonFunctions.getQuestionList(driver, obj.getQuestion2(),"3.2.2_Functional_Low_TC084");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_322_TC085(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC085")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.2.2_Functional_Low")) {

			startReporting("3.2.2_Functional_Low_TC085_GUI_Set up challenge questions screen_Challenge questions dropdow");

			/*------------  Pre-requisites---------- */
			LoginPage.LaunchURL(driver, GatewayAdminURL);

			String tempPassword = Admin.getTemporaryPassword(driver,
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Username_Eng"));
			// Storing the trading password

			Admin.getTemporaryTradingPassword(driver, ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Username_Eng"));
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));
			// Logging in using temporary password

			/*------------  Step2 and Step3 and Step4 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), tempPassword, "Home",
					Functionality + TestCaseID);

			/*------------  Step5---------- */

			// verifying the screen of create a new password
			CommonFunctions.verifyText(driver, "Create a new Password",
					obj.getPasswordChangePageTitle(),
					"3.2.2_Functional_Low_TC085");

			/*------------  Step6---------- */
			driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(
					ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_NewPassword_Eng"));

			CommonFunctions.checkFontColour(driver, obj.getMinimum1lowerCase(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Lower Case Check",
					"3.2.2_Functional_Low_TC085");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1upperCase(),
					"rgba(0, 138, 0, 1)", "Minimum 2 Upper Case Check",
					"3.2.2_Functional_Low_TC085");
			CommonFunctions.checkFontColour(driver, obj.getMinimum1Number(),
					"rgba(0, 138, 0, 1)", "Minimum 1 Number  Check",
					"3.2.2_Functional_Low_TC085");
			CommonFunctions.checkFontColour(driver,
					obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)",
					"Minimum 8 Characters Check", "3.2.2_Functional_Low_TC085");

			driver.findElement(By.xpath(obj.getConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_ConfirmPassword_Eng"));
			CommonFunctions.checkFontColour(driver, obj.getConfirmPasswords(),
					"rgba(0, 138, 0, 1)", "Confirm Password Check",
					"3.2.2_Functional_Low_TC085");
			CommonFunctions.ClickButton(driver,obj.getContinueButton());

			/*------------  Step7---------- */

			/*
			 * Moving to Trading screen verifyElement
			 */CommonFunctions.verifyText(driver,
					"Create a new Trading password", obj.getTradingTitle(),
					"3.2.2_Functional_Low_TC085");

			driver.findElement(By.xpath(obj.getTradingNewPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_TradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingMinimum6chracters(), "rgba(0, 138, 0, 1)",
					"Minimum 6 characters", "3.2.2_Functional_Low_TC085");

			driver.findElement(By.xpath(obj.getTradingConfirmPasswordField()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality,
									"p_ConfirmTradingPassword_Eng"));

			CommonFunctions.checkFontColour(driver,
					obj.getTradingConfirmPasswordCheck(), "rgba(0, 138, 0, 1)",
					"Confirmed, your Trading passwords match",
					"3.2.2_Functional_Low_TC085");
			CommonFunctions.ClickButton(driver,obj.getTradingContinueButton());

			CommonFunctions.verifyText(driver, "Set up challenge questions",
					obj.getSecurityQuestionTitle(),
					"3.2.2_Functional_Low_TC085");

			/*------------  Step8---------- */

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getQuestion1(), "3.2.2_Functional_Low_TC085");

			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getQuestion2(), "3.2.2_Functional_Low_TC085");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getQuestion3(), "3.2.2_Functional_Low_TC085");

			/*------------  Step9---------- */

			// Clicking on First question dropdown
			
			CommonFunctions.ClickButton(driver,obj.getQuestion3());
			

			CommonFunctions.getQuestionList(driver, obj.getQuestion3(),
					"3.2.2_Functional_Low_TC085");

			//BaseClass.statusPassWithScreenshot(driver, "Screen For TC085",					"3.2.2_Functional_Low_TC085");
			endReporting();
		}

	}
	
	
	/*
	 * @author=Poorva Dixit
	 * 
	 * TC001_ UI_ Challenge Questions
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC001(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC001")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

			startReporting("3.3.1_Functional_Low_TC001_ UI_ Challenge Questions");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC001");

			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// verifying the Challenge Questions

			CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_Verifytext_Eng"), obj
					.getAccountSetting_ProfileTab_SecurityQuesHeading(),
					"3.3.1_Functional_Low_TC001");

			/*------------  Step5 ---------- */

			// verify Spelling of Challenge Question

			CommonFunctions.verifySpellingText(driver, "Challenge questions",
					obj.getAccountSetting_ProfileTab_SecurityQuesHeading(),
					"3.3.1_Functional_Low_TC001");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC001",
					"3.3.1_Functional_Low_TC001");

			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC002_ UI_ Edit button
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC002(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		try {
			int rowNumber = Integer.parseInt(RowNumber);
			if (TestCaseID.equalsIgnoreCase("TC002")
					&& Execution.equalsIgnoreCase("Y")
					&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

				startReporting("3.3.1_Functional_Low_TC002_ UI_ Edit button");

				/*------------  Step1---------- */

				// Launching QA Gateway
				LoginPage.LaunchURL(driver, GatewayQAURL);
				System.out.println("*****************"
						+ ReadExcelFile.getTestData(TestCaseID, Functionality,
								"p_Password_Eng"));

				// Logging in using password and Navigating to the eServices tab
				// page

				/*------------  Step2 ---------- */
				LoginPage.Login(rowNumber, ReadExcelFile.getTestData(
						TestCaseID, Functionality, "p_Username_Eng"),
						ReadExcelFile.getTestData(TestCaseID, Functionality,
								"p_Password_Eng"), "eServices", Functionality
								+ TestCaseID);

				CommonFunctions.verifyText(driver, "Profile",
						obj.getAccountSetting_ProfileTab(),
						"3.3.1_Functional_Low_TC002");
				/*------------  Step3 ---------- */

				CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

				/*------------  Step4---------- */

				// verifying the Edit button

				CommonFunctions.waitForElement(driver,
						obj.getEditChallengeqtnbtn(), 40,
						"3.3.1_Functional_Low_TC002");

				CommonFunctions.verifyText(driver, "Edit",
						obj.getEditChallengeqtnbtn(),
						"3.3.1_Functional_Low_TC002");

				/*
				 * CommonFunctions.verifyHorizontalLocationOfElement(driver,
				 * obj.getAccountSetting_ProfileTab_SecurityQuesHeading(),
				 * obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC002");
				 */

				System.out.println("Step4 done");

				/*------------  Step5 ---------- */

				// verify Font Of Edit Button

				/*
				 * CommonFunctions.verifyButtonFont(driver, "#0079c1", "#fff",
				 * "#CCCCCC", "Grey", obj.getEditChallengeqtnbtn(),
				 * "3.3.1_Functional_Low_TC002");
				 * System.out.println("Step5 done");
				 */
				BaseClass.statusPassWithScreenshot(driver, "Screen For TC002",
						"3.3.1_Functional_Low_TC002");

				endReporting();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw e;
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC003_functionality_ Edit button
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC003(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC003")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

			startReporting("3.3.1_Functional_Low_TC003_functionality_ Edit button");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC003");

			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC003");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC003");
			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			CommonFunctions.waitForElement(driver,
					obj.getProfileChallengeqtncontinuebtn(), 40,
					"3.3.1_Functional_Low_TC003");

			CommonFunctions.checkEnabled(driver,
					obj.getProfileChallengeqtncontinuebtn(), "Continue Button",
					"3.3.1_Functional_Low_TC003");

			CommonFunctions.waitForElement(driver,
					obj.getProfileChallengeqtncancelbtn(), 40,
					"3.3.1_Functional_Low_TC003");
			CommonFunctions.checkEnabled(driver,
					obj.getProfileChallengeqtncancelbtn(), "Cancel Button",
					"3.3.1_Functional_Low_TC003");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC003",
					"3.3.1_Functional_Low_TC003");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC005_ UI_ Save Button
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC005(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC005")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

			startReporting("3.3.1_Functional_Low_TC005_ UI_ Save Button");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC005");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			CommonFunctions.checkEnabled(driver,
					obj.getProfileChallengeqtnonetextbox(), "TextBox Area",
					"3.3.1_Functional_Low_TC005");

			/*------------  Step5---------- */

			// "Verify the availabilty of save  Button for challange questions section "

			CommonFunctions.checkEnabled(driver,
					obj.getProfileChallengeqtnonetextbox(), "Continue Button",
					"3.3.1_Functional_Low_TC005");

			/*------------  Step6---------- */
			// Verify if the save Button

			/*
			 * CommonFunctions.verifyButtonFont(driver, "Save", "White", "Blue",
			 * "NULL", obj.getEditChallengeqtnbtn(),
			 * "3.3.1_Functional_Low_TC005");
			 */

			CommonFunctions.verifySpellingText(driver, "Save",
					obj.getProfileChallengeqtncontinuebtn(),
					"3.3.1_Functional_Low_TC005");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC005",
					"3.3.1_Functional_Low_TC005");
			endReporting();
		}

	}
	
	/*
	 * @author=Poorva Dixit
	 * 
	 * TC007_ UI_ Cancel button
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC007(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC007")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

			startReporting("3.3.1_Functional_Low_TC007_ UI_ Cancel  button");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC007");

			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */
			/*
			 * CommonFunctions.verifyElement(driver, "Edit",
			 * obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC007");
			 * 
			 * CommonFunctions.verifyHorizontalLocationOfElement(driver,
			 * obj.getAccountSetting_ProfileTab_SecurityQuesHeading(),
			 * obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC007");
			 */

			/*------------  Step5---------- */
			// click on Edit Button of Challenge question Section

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());
			CommonFunctions.checkEnabled(driver,
					obj.getProfileChallengeqtnonetextbox(), "TextBox Area",
					"3.3.1_Functional_Low_TC007");

			/*------------  Step5---------- */

			// "Verify the availabilty of save  Button for challange questions section "

			CommonFunctions.checkEnabled(driver,
					obj.getProfileChallengeqtnonetextbox(), "Continue Button",
					"3.3.1_Functional_Low_TC007");

			/*------------  Step6---------- */
			// Verify if the Cancel Button

			// Verification Of Cancel Button Font is Pending as per discussion

			CommonFunctions.verifySpellingText(driver, "Cancel",
					obj.getProfileChallengeqtncancelbtn(),
					"3.3.1_Functional_Low_TC007");

			/*
			 * CommonFunctions.verifyButtonFont(driver, "CancelButton", "Blue",
			 * "White", "Grey", obj.getProfileChallengeqtncancelbtn(),
			 * "3.3.1_Functional_Low_TC007");
			 */

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC007",
					"3.3.1_Functional_Low_TC007");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC009_ UI_Question _Text Fields
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC009(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC009")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

			startReporting("3.3.1_Functional_Low_TC009_ UI_Question _Text Fields");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC009");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Low_TC009");
			CommonFunctions.verifyElement(driver, "Question 2",
					obj.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Low_TC009");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Low_TC009");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC009",
					"3.3.1_Functional_Low_TC009");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC010_ UI_Answer_Text Fields
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC010(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC010")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

			startReporting("3.3.1_Functional_Low_TC010_ UI_Answer_Text Fields");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC010");

			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			CommonFunctions.verifyElement(driver, "Question 1",
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Low_TC010");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getProfileChallengeansonetextbox(),
					"3.3.1_Functional_Low_TC010");
			CommonFunctions.verifyElement(driver, "Answer 2",
					obj.getProfileChallengeanstwotextbox(),
					"3.3.1_Functional_Low_TC010");
			CommonFunctions.verifyElement(driver, "Question 3",
					obj.getProfileChallengeansthreetextbox(),
					"3.3.1_Functional_Low_TC010");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC010",
					"3.3.1_Functional_Low_TC010");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC011_ UI_Login password
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC011(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC011")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

			startReporting("3.3.1_Functional_Low_TC011_ UI_Login password");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC010");

			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			CommonFunctions.verifyText(driver, "Login Password",
					obj.getProfiletextboxloginheader(),
					"3.3.1_Functional_Low_TC011");

			CommonFunctions.checkCapitalize(driver,
					obj.getProfiletextboxloginheader());

			/*------------  Step6---------- */

			
			CommonFunctions.ClickButton(driver,obj.getProfiletextboxlogin());

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC011",
					"3.3.1_Functional_Low_TC011");
			endReporting();
		}

	}

	
	
	
	
	
	
	/*
	 * @author=Poorva Dixit
	 * 
	 * TC013_UI_Updated Date_Collapsed
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC013(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC013")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

			startReporting("3.3.1_Functional_Low_TC013_UI_Updated Date_Collapsed");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC013");
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());
			/*------------  Step3 ---------- */

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());
			


			/*------------  Step4---------- */
			// Check Date Element and see if its disabled

			CommonFunctions.verifyElement(driver, "Date",
					obj.getProfileTabChallengeQuestionDate(),
					"3.3.1_Functional_Low_TC013");
			

			//CommonFunctions.CheckNonEditable(driver, "Date",obj.getProfileTabChallengeQuestionDate(),"3.3.1_Functional_Low_TC013");
			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

		//	CommonFunctions.verifyDateformat(driver,obj.getProfileTabChallengeQuestionDate(),"3.3.1_Functional_Low_TC013");

			/*------------  Step6---------- */
			// Verify DB Date as Updated Date

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC013",
					"3.3.1_Functional_Low_TC013");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC014_UI_Updated Date_expanded
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC014(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC014")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Low")) {

			startReporting("3.3.1_Functional_Low_TC014_UI_Updated Date_expanded");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Low_TC014");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Check Date Element and see if its Non Editable

			CommonFunctions.verifyElement(driver, "Date",
					obj.getProfileTabChallengeQuestionDate(),
					"3.3.1_Functional_Low_TC014");

		//	CommonFunctions.CheckNonEditable(driver, "Date",obj.getProfileTabChallengeQuestionDate(),"3.3.1_Functional_Low_TC014");
		
			CommonFunctions.ClickButton(driver,obj.getProfileTabChallengeQuestionDate());

			
			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

		//	CommonFunctions.verifyDateformat(driver,obj.getProfileTabChallengeQuestionDate(),"3.3.1_Functional_Low_TC014");

			/*------------  Step6---------- */

			// Verify DB Date as Updated Date waiting for DB method

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC014",
					"3.3.1_Functional_Low_TC014");
			endReporting();
		}

	}

	
	//MEDIUM
	
	/*
	 * @author=Poorva Dixit
	 * 
	 * TC006_ Functionality _ Save Button
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC006(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC006")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC006_Functionality_Save Button");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC006");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC006");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC006");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC006");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step6---------- */

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"));

			
			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());

			CommonFunctions.verifyText(driver,  ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),obj
					.getProfiletabchallengequestionmsg(),
					"3.3.1_Functional_Medium_TC006");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC006",
					"3.3.1_Functional_Medium_TC006");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC008_ Functionality _ Cancel button
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC008(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC008")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC008_Functionality_Cancel button");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC008");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC008");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC008");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC008");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step6---------- */
			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"));
		
			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncancelbtn());

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC008",
					"3.3.1_Functional_Medium_TC008");
			endReporting();
		}

	}
	
	
	/*
	 * @author=Poorva Dixit
	 * 
	 * TC012_functional_Navigates without saving
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC012(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC012")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC012_functional_Navigates without saving");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "eServices",
					obj.getAccountSetting_eServicesTab(),
					"3.3.1_Functional_Medium_TC012");

			/*------------  Step3 ---------- */
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC012");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC012");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC012");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step6---------- */

			
			
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_eServicesTab());

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC012",
					"3.3.1_Functional_Medium_TC012");
			endReporting();
		}

	}
	
	/*
	 * @author=Poorva Dixit
	 * 
	 * TC015_Error message_ same answer for two security question
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC015(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC015")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC015_Error message_ same answer for two security question");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC015");
			/*------------  Step3 ---------- */
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC015");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC015");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC015");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step6---------- */
			/*
			 * Here Continue button is present instead of save Button
			 */

		
			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());

			CommonFunctions.verifyText(driver,  ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),obj
					.getProfiletabchallengequestionmsg(),
					"3.3.1_Functional_Medium_TC006");
			/*
			 * Here answers defect is there as answers aresaved asthe cancel
			 * button is clicked
			 */

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC015",
					"3.3.1_Functional_Medium_TC015");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC016_Error message_ same answer already on file
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC016(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC016")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC016_Error message_ same answer already on file");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC015");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC015");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC015");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC015");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step6---------- */
			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC016");

		
			
			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());

			CommonFunctions.verifyText(driver,  ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),obj
					.getProfiletabchallengequestionmsg(),
					"3.3.1_Functional_Medium_TC006");
		

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC016",
					"3.3.1_Functional_Medium_TC016");
			endReporting();
		}

	}

	/**
	 * TC017_ Change challenge question 1
	 * 
	 * @throws Exception
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC017(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC017")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC017_ Change challenge question 1");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC017");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			String s1 = CommonFunctions.getQuestionValue(driver,
					obj.getProfileChallengeqtnonetextbox());

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnonetextbox(), s1, 17,
					"3.3.1_Functional_Medium_TC017");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC016",
					"3.3.1_Functional_Medium_TC016");
			endReporting();
		}

	}

	/**
	 * TC018_ Change challenge question 2
	 * 
	 * @throws Exception
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC018(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC018")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC018_ Change challenge question 2");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC018");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			String s2 = CommonFunctions.getQuestionValue(driver,
					obj.getProfileChallengeqtntwotextbox());

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtntwotextbox(), s2, 18,
					"3.3.1_Functional_Medium_TC018");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC018",
					"3.3.1_Functional_Medium_TC018");
			endReporting();
		}

	}

	/**
	 * TC019_ Change challenge question 3
	 * 
	 * @throws Exception
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC019(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC019")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_3.3.1_Functional_Medium_TC019 3");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC019");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			String s3 = CommonFunctions.getQuestionValue(driver,
					obj.getProfileChallengeqtnthreetextbox());

			CommonFunctions.verifyQuestionList(driver,
					obj.getProfileChallengeqtnthreetextbox(), s3, 18,
					"3.3.1_Functional_Medium_TC019");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC019",
					"3.3.1_Functional_Medium_TC019");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC020_error _Change challenge question _answer not given
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC020(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC020")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC020_error _Change challenge question _answer not given");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC020");
			/*------------  Step3 ---------- */
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC020");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC020");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, ""));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC020");

			/*------------  Step6---------- */
			// Click on Save button with success text

			/*
			 * Here Continue button is present instead of save Button
			 */

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyText(driver,  ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),obj
					.getProfiletabchallengequestionmsg(),
					"3.3.1_Functional_Medium_TC006");
		
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("window.scrollBy(0,-250)", "");
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC020",
					"3.3.1_Functional_Medium_TC020");
			endReporting();
		}

	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC021_error _Change challenge question _Incorrect Login password
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC021(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC021")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC021_error _Change challenge question _Incorrect Login password");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC021");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC021");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC021");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC021");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step6---------- */
			// Click on Save button with success text

			/*
			 * Here Continue button is present instead of save Button And Login
			 * password Field is absent
			 */

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC021");
			;

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyText(driver,  ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),obj
					.getProfiletabchallengequestionmsg(),
					"3.3.1_Functional_Medium_TC006");
		

			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("window.scrollBy(0,-250)", "");
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC021",
					"3.3.1_Functional_Medium_TC021");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC022_error _Change challenge question _and answer for different question
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC022(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC022")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC022_error _Change challenge question _and answer for different question");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC022");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC022");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC022");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, ""));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC022");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step6---------- */

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC022");
			;

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyText(driver,  ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),obj
					.getProfiletabchallengequestionmsg(),
					"3.3.1_Functional_Medium_TC006");
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("window.scrollBy(0,-250)", "");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC022",
					"3.3.1_Functional_Medium_TC022");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC023_error _Change challenge question _and answer for different question
	 * with incorrect password error message
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC023(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC023")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC023_error _Change challenge question _and answer for different question with incorrect password error message");

			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC023");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers
			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC023");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC023");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, ""));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC023");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step6---------- */
			// Click on Save button with success text
			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC022");
			;

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyText(driver,  ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),obj
					.getProfiletabchallengequestionmsg(),
					"3.3.1_Functional_Medium_TC006");
		
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("window.scrollBy(0,-250)", "");
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC023",
					"3.3.1_Functional_Medium_TC023");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC024_error _Change challenge question _blank Login password
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC024(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC024")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC024_error _Change challenge question _blank  Login password");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC024");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC024");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC024");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC024");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			/*------------  Step6---------- */
			// Click on Save button with success text

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys("");
			;

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyText(driver,  ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),obj
					.getProfiletabchallengequestionmsg(),
					"3.3.1_Functional_Medium_TC006");
		
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("window.scrollBy(0,-250)", "");
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC024",
					"3.3.1_Functional_Medium_TC024");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC025_error _Change answer to challenge question _Incorrect Login
	 * password
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC025(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC025")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC025_error _Change answer to challenge question _Incorrect Login password");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC025");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC024");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC024");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC024");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());

	

			CommonFunctions.verifyText(driver,  ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),obj
					.getProfiletabchallengequestionmsg(),
					"3.3.1_Functional_Medium_TC006");
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("window.scrollBy(0,-250)", "");
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC025",
					"3.3.1_Functional_Medium_TC025");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC026_error _Change answer to challenge question _blank Login password
	 * password
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC026(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC026")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC026_error _Change answer to challenge question _blank  Login password");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC026");
			/*------------  Step3 ---------- */

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC020");
			/*------------  Step3 ---------- */
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC026");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC026");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC026");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

		
			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());

			
			CommonFunctions.verifyText(driver,  ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),obj
					.getProfiletabchallengequestionmsg(),
					"3.3.1_Functional_Medium_TC006");
		
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("window.scrollBy(0,-350)", "");
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC026",
					"3.3.1_Functional_Medium_TC026");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC027_error _challange answer less than 6 characters
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC027(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC027")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC027_error _challange answer less than 6 characters");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC027");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());
			/*------------  Step4---------- */

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC020");
			/*------------  Step3 ---------- */
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers
			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC027");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC027");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC027");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());

	
			CommonFunctions.verifyText(driver,  ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),obj
					.getProfiletabchallengequestionmsg(),
					"3.3.1_Functional_Medium_TC006");
		
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("window.scrollBy(0,-250)", "");
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC027",
					"3.3.1_Functional_Medium_TC027");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC028_error _challange answer with special character at beginning of
	 * answer
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC028(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC028")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC028_error _challange answer with special character at beginning of answer");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC028");
			/*------------  Step3 ---------- */

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC020");
			/*------------  Step3 ---------- */
			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers
			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC028");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC028");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC028");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());

	
			CommonFunctions.verifyText(driver,  ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),obj
					.getProfiletabchallengequestionmsg(),
					"3.3.1_Functional_Medium_TC006");
		
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("window.scrollBy(0,-400)", "");
			BaseClass.statusPassWithScreenshot(driver, "Screen For TC028",
					"3.3.1_Functional_Medium_TC028");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit TC029_error _challange answer with special character
	 * in middle of answer
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC029(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC029")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC029_error _challange answer with special character in middle of answer");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC029");
			/*------------  Step3 ---------- */
			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC020");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers
			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC029");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC029");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC029");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_UpdatedSecurityQuestion1"),
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC029");

			// Answer Special Character in Middle
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "P_UpdatedAnswer1"));

			/*------------  Step6---------- */
			// Click on Save button with success text

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC025");
			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC029");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC029",
					"3.3.1_Functional_Medium_TC029");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit TC030_error _challange answer with special character
	 * at end of answer
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC030(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC030")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC030_error _challange answer with special character at end of answer");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC030");
			/*------------  Step3 ---------- */

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC020");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section
			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			// Select Challenge question and corresponding answers
			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC030");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys("p_Answer1");

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC030");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC030");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_UpdatedSecurityQuestion1"),
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC030");

			// Answer Special Characterat the end
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_UpdatedAnswer1"));

			/*------------  Step6---------- */
			// Click on Save button with success text
			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC025");

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC030");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC030",
					"3.3.1_Functional_Medium_TC030");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit TC031_error _challange answer beginning with a space
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC031(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC031")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC031_error _challange answer beginning with a space");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC031");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC031");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC031");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC031");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_UpdatedSecurityQuestion1"),
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC031");

			// Answer with More than 20 characters
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_UpdatedAnswer1"));

			/*------------  Step6---------- */
			// Click on Save button with success text

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC025");
			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC031");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC031",
					"3.3.1_Functional_Medium_TC031");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC032_error _challange answer ending with a space
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC032(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC032")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC032_error _challange answer ending with a space");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC032");
			/*------------  Step3 ---------- */

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC032");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC032");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC032");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_UpdatedSecurityQuestion1"),
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC032");

			// Answer with More than 20 characters
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_UpdatedAnswer1"));

			/*------------  Step6---------- */
			// Click on Save button with success text

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC025");

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC032");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC032",
					"3.3.1_Functional_Medium_TC032");
			endReporting();
		}
	}

	/*
	 * @author=Poorva Dixit
	 * 
	 * TC033_challange answer with a space in between two characters
	 */
	@Test(dataProvider = "DriverSheet")
	public void test_331_TC033(String RowNumber, String Functionality,
			String TestCaseID, String TestCaseDescription, String Execution,
			String Status) throws Exception {
		int rowNumber = Integer.parseInt(RowNumber);
		if (TestCaseID.equalsIgnoreCase("TC033")
				&& Execution.equalsIgnoreCase("Y")
				&& Functionality.equalsIgnoreCase("3.3.1_Functional_Medium")) {

			startReporting("3.3.1_Functional_Medium_TC033_challange answer  with a space in between two characters");
			/*------------  Step1---------- */

			// Launching QA Gateway
			LoginPage.LaunchURL(driver, GatewayQAURL);
			System.out.println("*****************"
					+ ReadExcelFile.getTestData(TestCaseID, Functionality,
							"p_Password_Eng"));

			// Logging in using password and Navigating to the eServices tab
			// page

			/*------------  Step2 ---------- */
			LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,
					Functionality, "p_Username_Eng"), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_Password_Eng"),
					"eServices", Functionality + TestCaseID);

			CommonFunctions.verifyText(driver, "Profile",
					obj.getAccountSetting_ProfileTab(),
					"3.3.1_Functional_Medium_TC033");
			/*------------  Step3 ---------- */

			CommonFunctions.ClickButton(driver,obj.getAccountSetting_ProfileTab());

			/*------------  Step4---------- */

			// click on Edit Button of Challenge question Section

			CommonFunctions.waitForElement(driver,
					obj.getEditChallengeqtnbtn(), 40,
					"3.3.1_Functional_Low_TC005");

			CommonFunctions.verifyText(driver, "Edit",
					obj.getEditChallengeqtnbtn(), "3.3.1_Functional_Low_TC005");

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			/*------------  Step5---------- */

			// Select Challenge question and corresponding answers

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion1"), obj
					.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC033");
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer1"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion2"), obj
					.getProfileChallengeqtntwotextbox(),
					"3.3.1_Functional_Medium_TC033");
			driver.findElement(By.xpath(obj.getProfileChallengeanstwotextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer2"));

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_SecurityQuestion3"), obj
					.getProfileChallengeqtnthreetextbox(),
					"3.3.1_Functional_Medium_TC033");
			driver.findElement(
					By.xpath(obj.getProfileChallengeansthreetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Answer3"));

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());

			CommonFunctions.ClickButton(driver,obj.getEditChallengeqtnbtn());

			CommonFunctions.select(driver, ReadExcelFile.getTestData(
					TestCaseID, Functionality, "p_UpdatedSecurityQuestion1"),
					obj.getProfileChallengeqtnonetextbox(),
					"3.3.1_Functional_Medium_TC033");

			// Answer with space in between
			driver.findElement(By.xpath(obj.getProfileChallengeansonetextbox()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_UpdatedAnswer1"));

			/*------------  Step6---------- */
			// Click on Save button with success text

			driver.findElement(By.xpath(obj.getProfiletextboxlogin()))
					.sendKeys(
							ReadExcelFile.getTestData(TestCaseID,
									Functionality, "p_Password_Eng"),
							"3.3.1_Functional_Medium_TC025");

			CommonFunctions.ClickButton(driver,obj.getProfileChallengeqtncontinuebtn());
			CommonFunctions.verifyText(driver, obj
					.getProfiletabchallengequestionmsg(), ReadExcelFile
					.getTestData(TestCaseID, Functionality, "p_ErrorMsg"),
					"3.3.1_Functional_Medium_TC033");

			BaseClass.statusPassWithScreenshot(driver, "Screen For TC033",
					"3.3.1_Functional_Medium_TC033");
			endReporting();
		}
	}

	
	@Test(dataProvider="DriverSheet")
	public void test_353637_M_TC014(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	 {
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC014")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.5_3.6_3.7_Functional_Medium"))
		{

			
			startReporting("TC014_existing GW client_forgets password and security questions_helpdesk reset password_setting new challenge questions_challenge question process incomplete_stop session midway");
		
			LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
	        
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	  	
	   	 CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(), TestCaseDescription);
	   	 
	   
	   	 
	   	 CommonFunctions.checkSizeofDropDown(driver, obj.getQuestion3(), 20);
	     CommonFunctions.selectByIndex(driver,3, obj.getQuestion3(), TestCaseDescription);
	     driver.findElement(By.xpath(obj.getAnswer3())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer3")); 	
	   	 
	     
	     CommonFunctions.checkSizeofDropDown(driver, obj.getQuestion2(), 19);
	     CommonFunctions.selectByIndex(driver,2, obj.getQuestion2(), TestCaseDescription);
	     driver.findElement(By.xpath(obj.getAnswer2())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer2"));    
	      	
	   	 CommonFunctions.checkSizeofDropDown(driver, obj.getQuestion1(), 18);
	     CommonFunctions.selectByIndex(driver,1, obj.getQuestion1(), TestCaseDescription);
	     driver.findElement(By.xpath(obj.getAnswer1())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer1"));    
	       
	     driver.close();
	     
	     
	     driver=LoginPage.LaunchBrowser(Browser);
		 LoginPage.LaunchURL(driver,GatewayQAURL);
		 LoginPage.Login(rowNumber, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_Username_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_NewPassword_Eng"),"Home", Functionality + TestCaseID);
	  	 CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), TestCaseDescription);
	 	
	 	 LoginPage.LaunchURL(driver,GatewayAdminURL);
	 	 System.out.println("After Admin");
	 	 tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
	 	 System.out.println("Before QA");
	 	 LoginPage.LaunchURL(driver,GatewayQAURL);
	 	 LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
	    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), "TestCaseDescription"); 
	    
	   // DataBase.DBVerifyNloginPwdRequiresReset(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"),TestCaseDescription);
		
	   // DataBase.DBVerifyProfileValid1(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), TestCaseDescription);
	    BaseClass.statusPassWithScreenshot(driver,"Home Page Screen",TestCaseDescription);
		
	    endReporting();
		
		}
	 }
	@Test(dataProvider="DriverSheet")
	public void test_353637_M_TC015(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	 {
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC015")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.5_3.6_3.7_Functional_Medium"))
		{

			
			startReporting(TestCaseDescription);
		
			LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
	        
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	  	
	   	  	CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(), TestCaseDescription);
	   	 	 
	   	 CommonFunctions.checkSizeofDropDown(driver, obj.getQuestion3(), 17);
	     CommonFunctions.selectByIndex(driver,3, obj.getQuestion3(), TestCaseDescription);
	     driver.findElement(By.xpath(obj.getAnswer3())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer3")); 	
	   	 
	     
	     CommonFunctions.checkSizeofDropDown(driver, obj.getQuestion2(), 16);
	     CommonFunctions.selectByIndex(driver,2, obj.getQuestion2(), TestCaseDescription);
	     driver.findElement(By.xpath(obj.getAnswer2())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer2"));    
	      	
	   	 CommonFunctions.checkSizeofDropDown(driver, obj.getQuestion1(), 15);
	     CommonFunctions.selectByIndex(driver,1, obj.getQuestion1(), TestCaseDescription);
	     driver.findElement(By.xpath(obj.getAnswer1())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Answer1"));    
	       
	     CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	     CommonFunctions.verifyElement(driver, "Create a new Password", obj.getHomePageLogo(), TestCaseDescription);
	       BaseClass.statusPassWithScreenshot(driver,"Home Page Screen",TestCaseDescription);
		
	    endReporting();
		
		}
	 }
		


	@Test(dataProvider="DriverSheet")
	public void test_353637_M_TC016(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	 {
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC016")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.5_3.6_3.7_Functional_Medium"))
		{

			
			startReporting(TestCaseDescription);
		
			LoginPage.LaunchURL(driver,GatewayAdminURL);
	        tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
	        
	        LoginPage.LaunchURL(driver,GatewayQAURL);
	        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
	      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	      	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	  	
	   	  	CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(), TestCaseDescription);
	   	 	 
	   		CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
	   	  	CommonFunctions.setSecurityFields(driver,1, "",2, "", 6, "", TestCaseDescription);
	   	 	statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);
	  
	   	 	
	   	 CommonFunctions.setSecurityFields(driver,3, "",4, "", 5, "", TestCaseDescription);
		
		 	
		 	CommonFunctions.setSecurityFields(driver,2, "",6, "", 1, "", TestCaseDescription);
		 	statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);

		 	CommonFunctions.setSecurityFields(driver,3, "",4, "", 5, "", TestCaseDescription);
		
		 	
			CommonFunctions.setSecurityFields(driver,6, "",1, "", 2, "", TestCaseDescription);
		 	statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);

	    	 
	   	  	
	     CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		
		
		CommonFunctions.verifyElement(driver, "Create a new Password", obj.getHomePageLogo(), TestCaseDescription);
	    
	    BaseClass.statusPassWithScreenshot(driver,"Home Page Screen",TestCaseDescription);
		
	    endReporting();
		
		}
	 }
		
	@Test(dataProvider="DriverSheet")
	public void test_325_C_TC066(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC066")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Complex"))
		{
			
			startReporting(Functionality);
			
			accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
		  //  CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
	      //  CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
		    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
			    
		    CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
		    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
	   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
	   	  	CommonFunctions.setSecurityFields(driver,1, "",2, "", 6, "", TestCaseDescription);
	   	 	statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);
	  
	   	 	
	   	 CommonFunctions.setSecurityFields(driver,3, "",4, "", 5, "", TestCaseDescription);
		
		 	
		 	CommonFunctions.setSecurityFields(driver,2, "",6, "", 1, "", TestCaseDescription);
		 	statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);

		 	CommonFunctions.setSecurityFields(driver,3, "",4, "", 5, "", TestCaseDescription);
		
		 	
			CommonFunctions.setSecurityFields(driver,6, "",1, "", 2, "", TestCaseDescription);
		 	statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);

	    	 
	    	 
	    	 
	    	 
	      	endReporting();
		}
	}



	@Test(dataProvider="DriverSheet")
	public void test_325_C_TC099(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
	{
		
		int rowNumber = Integer.parseInt(RowNumber);
		if(TestCaseID.equalsIgnoreCase("TC099")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Complex"))
		{
			
			startReporting(Functionality);
			
			accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
		    LoginPage.LaunchURL(driver,GatewayQAURL);
		    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
		  //  CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
	      //  CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
		    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
		    CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
		    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
	    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
	   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
	   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
	   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
	   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
	   	  	CommonFunctions.setSecurityFields(driver,1, "animal",2, "porter", 6, "failure", TestCaseDescription);
	   	 	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
	   	 	CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
	  	    driver.findElement(By.xpath(obj.getEmailAddressNewEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
	     	driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
	     	
	     	

	    	BaseClass.statusPassWithScreenshot(driver,"Email Address Screen",TestCaseDescription);
	    	CommonFunctions.movemousepointer(driver,"//label[@for='terms']");
	        CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
	        CommonFunctions.waitForElement(driver, obj.getEmailConfirmationPageTitle(), 10, "verification");
	        
	        
	        LoginPage.LaunchURL(driver,GatewayEmailURL);
	        CommonFunctions.EmailLogin(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailUserName"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailPwd"), TestCaseDescription);
	        Thread.sleep(2000);
	        System.out.println("check1");
	        CommonFunctions.EmailValidation(driver, accountNumber, TestCaseDescription);
	        statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);
	  

	    	 
	    	 
	    	 
	    	 
	      	endReporting();
		}
	}

		@Test(dataProvider="DriverSheet")
		public void test_325_C_TC100(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
		{
			
			int rowNumber = Integer.parseInt(RowNumber);
			if(TestCaseID.equalsIgnoreCase("TC100")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Complex"))
			{
				
				startReporting(Functionality);
				
				accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
			    LoginPage.LaunchURL(driver,GatewayQAURL);
			    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
			    CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
		        CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
				      
			  //  CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
			    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
		   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
		   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
		   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
		   	  	CommonFunctions.setSecurityFields(driver,1, "animal",2, "porter", 6, "failure", TestCaseDescription);
		   	 	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		   	 	CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
		  	    driver.findElement(By.xpath(obj.getEmailAddressNewEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
		     	driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
		     	
		     	

		    	BaseClass.statusPassWithScreenshot(driver,"Email Address Screen",TestCaseDescription);
		    	CommonFunctions.movemousepointer(driver,"//label[@for='terms']");
		        CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
		        CommonFunctions.waitForElement(driver, obj.getEmailConfirmationPageTitle(), 10, "verification");
		        
		        
		        LoginPage.LaunchURL(driver,GatewayEmailURL);
		        CommonFunctions.EmailLogin(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailUserName"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailPwd"), TestCaseDescription);
		        Thread.sleep(2000);
		        System.out.println("check1");
		        CommonFunctions.EmailValidation(driver, accountNumber, TestCaseDescription);
		        statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);
		  
		
		    	 
		    	 
		    	 
		    	 
		      	endReporting();
			}
		}
		
		@Test(dataProvider="DriverSheet")
		public void test_327_M_TC026(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
		{
			
			int rowNumber = Integer.parseInt(RowNumber);
			if(TestCaseID.equalsIgnoreCase("TC026")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.7_Functional_Medium"))
			{
				
				startReporting("3.2.7_Functional_Medium_TC026_Create a new Login password screen_Password updated succesfully");
				
				accountNumber=DataBase.DBConnection(driver,"ACCOUNTINACTIVEMORETHAN1YEAR", LanguageSettings, TestCaseDescription);
			    LoginPage.LaunchURL(driver,GatewayQAURL);
			    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
		        CommonFunctions.verifyElement(driver, "Go To Login Page Button", obj.getGoToLoginPageButton(), TestCaseDescription);
		        CommonFunctions.checkElementColour(driver, obj.getGoToLoginPageButton(),"rgba(0, 114, 193, 1)","Go To Login Button Colour", TestCaseDescription);
		        CommonFunctions.ClickButton(driver,obj.getGoToLoginPageButton());
		        CommonFunctions.verifyElement(driver,"Login Page Displayed",obj.getUserName(),TestCaseDescription);
		        LoginPage.LaunchURL(driver,GatewayAdminURL);
		        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
		        LoginPage.LaunchURL(driver,GatewayQAURL);
		        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
		      	CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    	driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	CommonFunctions.checkFontColour(driver,obj.getMinimum1lowerCase(), "rgba(0, 138, 0, 1)","Minimum 1 Lower Case Check",TestCaseDescription);
		      	CommonFunctions.checkFontColour(driver,obj.getMinimum1upperCase(), "rgba(0, 138, 0, 1)","Minimum 2 Upper Case Check",TestCaseDescription);
		      	CommonFunctions.checkFontColour(driver,obj.getMinimum1Number(), "rgba(0, 138, 0, 1)","Minimum 1 Number  Check",TestCaseDescription);
		      	CommonFunctions.checkFontColour(driver,obj.getMinimum8Characters(), "rgba(0, 138, 0, 1)","Minimum 8 Characters Check",TestCaseDescription);
		      	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		      	CommonFunctions.checkFontColour(driver,obj.getConfirmPasswords(), "rgba(0, 138, 0, 1)","Confirm Password Check",TestCaseDescription);
		      	//CommonFunctions.checkDisabled(driver,obj.getSpecialCharacterAlertError(),"Invalid Special Character Entered Error Message", TestCaseDescription);
		       	CommonFunctions.ClickButton(driver,obj.getContinueButton());
		   	 	CommonFunctions.verifyElement(driver, "Set Up Challenge Question Screen", obj.getChallengeQuestionTitleNew(), TestCaseDescription);
		   	    BaseClass.statusPassWithScreenshot(driver,"Set Up Challenge Question Screen",TestCaseDescription);
		       
		      	endReporting();
			}
		}
		
		
		
		@Test(dataProvider="DriverSheet")
		public void test_321_L_TC056(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription,  String Execution, String Status)throws Exception
		{
			int rowNumber = Integer.parseInt(RowNumber);
			if(TestCaseID.equalsIgnoreCase("TC056")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.1_Functional_Low"))
			{
				//LoginPage.LaunchURL(driver,"https://www.yahoo.com");
				startReporting("3.2.1_Functional_Low_TC056_ErrorMessage_one Challange question is not selected");
				accountNumber=DataBase.DBConnection(driver,"NEWUSERACCOUNTS", LanguageSettings, "3.2.1_Functional_Low	");
				LoginPage.LaunchURL(driver,GatewayAdminURL);
				String tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
				LoginPage.LaunchURL(driver,GatewayQAURL);
				LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
				
				CommonFunctions.waitForElement(driver, obj.getWelcomeScreenTitle(),40, "WelcomeScreen");
				
				CommonFunctions.verifyElement(driver, "StartButton", obj.getWelcomeScreenStartButton(), TestCaseDescription);
				driver.findElement(By.xpath(obj.getWelcomeScreenStartButton())).click();
				CommonFunctions.waitForElement(driver, obj.getPasswordChangePageTitle(),40, "Create a new Password");
			
				driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys("B7aaaaaa");
				driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys("B7aaaaaa");
				driver.findElement(By.xpath(obj.getContinueButton())).click();
				//CommonFunctions.verifyText(driver, "Create a new Trading password", obj.getTradingpasswordtitle(), TestCaseDescription);
				CommonFunctions.waitForElement(driver, obj.getNewTradingpassword(),40, "New Trading Password");
				System.out.println("Before new trade password set");
				driver.findElement(By.xpath(obj.getNewTradingpassword())).sendKeys("Trade123");
				System.out.println("After new trade password set");
				driver.findElement(By.xpath(obj.getConfirmTradingpassword())).sendKeys("Trade123");
				
				System.out.println("After confirm new Trade password");
				CommonFunctions.ClickButton(driver,obj.getTradingcontinue());
				CommonFunctions.waitForElement(driver, obj.getSecurityQuestionTitle(),40, "Title");
				CommonFunctions.verifyElement(driver, "SecurityQuestion1", obj.getQuestion1(), TestCaseDescription);
				CommonFunctions.verifyElement(driver, "SecurityQuestion2", obj.getQuestion2(), TestCaseDescription);
				CommonFunctions.verifyElement(driver, "SecurityQuestion3", obj.getQuestion3(), TestCaseDescription);
				CommonFunctions.waitForElement(driver, obj.getQuestion1(),10, "Question");
				CommonFunctions.selectByIndex(driver, 2, obj.getQuestion1(), TestCaseDescription);
				driver.findElement(By.xpath(obj.getAnswer1())).sendKeys("abcdefgh");
				CommonFunctions.selectByIndex(driver, 3, obj.getQuestion2(), TestCaseDescription);
				driver.findElement(By.xpath(obj.getAnswer2())).sendKeys("abcdefgj");
				//CommonFunctions.selectByIndex(driver, 4, obj.getQuestion3(), TestCaseDescription);
				//driver.findElement(By.xpath(obj.getAnswer3())).sendKeys("abcdefg");
				CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
				//CommonFunctions.verifyText(driver, "We're sorry, but the fields outlined in red require updating. Please review the comments in red and update the information in order to proceed.", obj.getSecurityQuestionMessage(), TestCaseDescription);
					  CommonFunctions.verifyText(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_VerifyText_Eng") , obj.getSecurityQuestionMessage(), TestCaseDescription);
					
				statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
				endReporting();
			}
		}
		
		@Test(dataProvider="DriverSheet")
		public void test_321_L_TC057(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
		{
			int rowNumber = Integer.parseInt(RowNumber);
			if(TestCaseID.equalsIgnoreCase("TC057")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.1_Functional_Low"))
			{
				//LoginPage.LaunchURL(driver,"https://www.yahoo.com");
				startReporting("3.2.1_Functional_Low_TC057_ErrorMessage_two  Challange question is not selected");
				accountNumber=DataBase.DBConnection(driver,"NEWUSERACCOUNTS", LanguageSettings, "3.2.1_Functional_Low	");
				LoginPage.LaunchURL(driver,GatewayAdminURL);
				String tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
				LoginPage.LaunchURL(driver,GatewayQAURL);
				LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
				
				CommonFunctions.waitForElement(driver, obj.getWelcomeScreenTitle(),40, "WelcomeScreen");
				//CommonFunctions.verifyText(driver, "Welcome to Gateway", obj.getWelcomeScreenTitle(), TestCaseDescription);		
				CommonFunctions.verifyElement(driver, "StartButton", obj.getWelcomeScreenStartButton(), TestCaseDescription);
				driver.findElement(By.xpath(obj.getWelcomeScreenStartButton())).click();
				
				//CommonFunctions.verifyText(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
				CommonFunctions.waitForElement(driver, obj.getNewPasswordField(),40, "Newpassword");
				driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys("B2aaaaaa");
				driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys("B2aaaaaa");
				driver.findElement(By.xpath(obj.getContinueButton())).click();
				//CommonFunctions.verifyText(driver, "Create a new Trading password", obj.getTradingpasswordtitle(), TestCaseDescription);
	CommonFunctions.waitForElement(driver, obj.getNewTradingpassword(),40, "New Trading Password");
				
				driver.findElement(By.xpath(obj.getNewTradingpassword())).sendKeys("Trade123");
				driver.findElement(By.xpath(obj.getConfirmTradingpassword())).sendKeys("Trade123");
				CommonFunctions.ClickButton(driver,obj.getTradingcontinue());
				CommonFunctions.waitForElement(driver, obj.getSecurityQuestionTitle(),40, "Title");
					//Thread.sleep(2000);
				//CommonFunctions.verifyText(driver, "Set up challenge questions", obj.getSecurityQuestionTitle(), TestCaseDescription);
				
				CommonFunctions.verifyElement(driver, "SecurityQuestion1", obj.getQuestion1(), TestCaseDescription);
				CommonFunctions.verifyElement(driver, "SecurityQuestion2", obj.getQuestion2(), TestCaseDescription);
				CommonFunctions.verifyElement(driver, "SecurityQuestion3", obj.getQuestion3(), TestCaseDescription);
				
				CommonFunctions.selectByIndex(driver, 2, obj.getQuestion1(), TestCaseDescription);
				driver.findElement(By.xpath(obj.getAnswer1())).sendKeys("abcdefgh");
				//CommonFunctions.selectByIndex(driver, 3, obj.getQuestion2(), TestCaseDescription);
				//driver.findElement(By.xpath(obj.getAnswer2())).sendKeys("abcdefgj");
				//CommonFunctions.selectByIndex(driver, 4, obj.getQuestion3(), TestCaseDescription);
				//driver.findElement(By.xpath(obj.getAnswer3())).sendKeys("abcdefg");
				CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
				//CommonFunctions.verifyText(driver, "We're sorry, but the fields outlined in red require updating. Please review the comments in red and update the information in order to proceed.", obj.getSecurityQuestionMessage(), TestCaseDescription);
				  CommonFunctions.verifyText(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_VerifyText_Eng") , obj.getSecurityQuestionMessage(), TestCaseDescription);
						statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
				endReporting();
			}
		}
		
		
		@Test(dataProvider="DriverSheet")
		public void test_321_L_TC031(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription,  String Execution, String Status)throws Exception
		{
			int rowNumber = Integer.parseInt(RowNumber);
			if(TestCaseID.equalsIgnoreCase("TC031")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.1_Functional_Low"))
			{
				//LoginPage.LaunchURL(driver,"https://www.yahoo.com");
				startReporting(TestCaseDescription);
				accountNumber=DataBase.DBConnection(driver,"NEWUSERACCOUNTS", LanguageSettings, "3.2.1_Functional_Low	");
				LoginPage.LaunchURL(driver,GatewayAdminURL);
				String tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
				LoginPage.LaunchURL(driver,GatewayQAURL);
				LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
				CommonFunctions.waitForElement(driver, obj.getWelcomeScreenTitle(), 40, "WelcomeScreen");
				CommonFunctions.verifyElement(driver, "StartButton", obj.getWelcomeScreenStartButton(), TestCaseDescription);
				driver.findElement(By.xpath(obj.getWelcomeScreenStartButton())).click();
				CommonFunctions.waitForElement(driver, obj.getPasswordChangePageTitle(), 40, "Create a new Password");
				CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
				driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys("B8aaaaaa");
				driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys("B8aaaaaa");
				driver.findElement(By.xpath(obj.getContinueButton())).click();
		CommonFunctions.waitForElement(driver, obj.getNewTradingpassword(),40, "New Trading Password");
				
				driver.findElement(By.xpath(obj.getNewTradingpassword())).sendKeys("Trade123");
				driver.findElement(By.xpath(obj.getConfirmTradingpassword())).sendKeys("Trade123");
			
				CommonFunctions.waitForElement(driver,obj.getTradingMinimum6chracters(), 10, "Minimum 6 Characters");
				CommonFunctions.checkFontColour(driver, obj.getTradingMinimum6chracters(), "rgba(0, 138, 0, 1)", "Green", TestCaseDescription);
				//CommonFunctions.checkFontColour(driver, obj.getTradingSpecialCharacter(), "rgba(0, 138, 0, 1)", "Green", TestCaseDescription);
				CommonFunctions.checkFontColour(driver, obj.getTradingConfirmPasswordCheck(), "rgba(0, 138, 0, 1)", "Green", TestCaseDescription);
				
				statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
				endReporting();
			}
		}
		
		@Test(dataProvider="DriverSheet")
		public void test_322_M_TC122(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription,  String Execution, String Status)throws Exception
		{
			int rowNumber = Integer.parseInt(RowNumber);
			if(TestCaseID.equalsIgnoreCase("TC122")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Medium"))
			{
				
				startReporting(TestCaseDescription);
				accountNumber=DataBase.DBConnection(driver,"ACCOUNTWITHNOSECURITYQUES", LanguageSettings, TestCaseDescription);
				
				LoginPage.LaunchURL(driver,GatewayAdminURL);
				String tempPassword=Admin.getTemporaryPassword(driver, accountNumber);
				Admin.getTemporaryTradingPassword(driver, accountNumber);
				LoginPage.LaunchURL(driver,GatewayQAURL);

				//accountNumber=ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username",TestDataID);
				LoginPage.Login(rowNumber,accountNumber,tempPassword ,"Home",Functionality + TestCaseID);
				
				CommonFunctions.verifyText(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		  		
		  		driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		        driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		        CommonFunctions.ClickButton(driver,obj.getContinueButton());
		        
		        CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
		        //System.out.println(obj.getNewTradingpassword());
		        
		        
		        driver.findElement(By.xpath(obj.getNewTradingpassword())).sendKeys("aaaaaa");
		        driver.findElement(By.xpath(obj.getConfirmTradingpassword())).sendKeys("aaaaaa");
		        CommonFunctions.ClickButton(driver,obj.getTradingcontinue());
		    
		        CommonFunctions.verifyElement(driver, "Challenge Question Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
			    CommonFunctions.setSecurityFields(driver, 5,"porter", 7, "animal",8, "tester",TestCaseDescription);
			    CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
			    CommonFunctions.verifyElement(driver, "Email address screen", obj.getEmailAddressTitle(),TestCaseDescription);        
			  
			          
			    CommonFunctions.SetText(driver, obj.getEmailAddressNewEmail(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID") );
			    CommonFunctions.SetText(driver, obj.getEmailAddressConfirmEmail(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID") );
			  CommonFunctions.movemousepointer(driver,"//label[@for='terms']"); 
			    //Thread.sleep(6000);
			    CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
			    CommonFunctions.waitForElement(driver, obj.getEmailConfirmationPageTitle(), 10, "verification");
			    BaseClass.statusPassWithScreenshot(driver, "Email Screen Dispalyed",Browser+"_"+TestCaseDescription+"_1");
			        
			 	LoginPage.LaunchURL(driver,GatewayEmailURL);
				CommonFunctions.EmailLogin(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailUserName"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailPwd"), TestCaseDescription);
				Thread.sleep(2000);
				System.out.println("check1");
				CommonFunctions.EmailValidation(driver, accountNumber, TestCaseDescription);
				statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);
				
				String CurrentDate=CommonFunctions.Date(driver,TestCaseID,Functionality, TestCaseDescription);
				DataBase.DBEmailUpdated(driver,accountNumber,CurrentDate,TestCaseDescription);
				statusPassWithScreenshot(driver,"Screenshot done",Functionality + "TC122");
			
				endReporting();
			}
		}
		
		
		@Test(dataProvider="DriverSheet")
		public void test_322_M_TC123(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
		{
			int rowNumber = Integer.parseInt(RowNumber);
			if(TestCaseID.equalsIgnoreCase("TC123")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Medium"))
			{
				
				startReporting(TestCaseDescription);
				accountNumber=DataBase.DBConnection(driver,"ACCOUNTWITHNOSECURITYQUES", LanguageSettings, TestCaseDescription);
				
				LoginPage.LaunchURL(driver,GatewayAdminURL);
				String tempPassword=Admin.getTemporaryPassword(driver, accountNumber);
				Admin.getTemporaryTradingPassword(driver, accountNumber);
				LoginPage.LaunchURL(driver,GatewayQAURL);

				//accountNumber=ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username",TestDataID);
				LoginPage.Login(rowNumber,accountNumber,tempPassword ,"Home",Functionality + TestCaseID);
				
				CommonFunctions.verifyText(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		  		
		  		driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		        driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		        CommonFunctions.ClickButton(driver,obj.getContinueButton());
		        
		        CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
		        //System.out.println(obj.getNewTradingpassword());
		        
		        
		        driver.findElement(By.xpath(obj.getNewTradingpassword())).sendKeys("aaaaaa");
		        driver.findElement(By.xpath(obj.getConfirmTradingpassword())).sendKeys("aaaaaa");
		        CommonFunctions.ClickButton(driver,obj.getTradingcontinue());
		    
		        CommonFunctions.verifyElement(driver, "Challenge Question Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
			    CommonFunctions.setSecurityFields(driver, 5,"porter", 7, "animal",8, "tester",TestCaseDescription);
			    CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
			    CommonFunctions.verifyElement(driver, "Email address screen", obj.getEmailAddressTitle(),TestCaseDescription);        
			  
			          
			    CommonFunctions.SetText(driver, obj.getEmailAddressNewEmail(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID") );
			    CommonFunctions.SetText(driver, obj.getEmailAddressConfirmEmail(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID") );
			  CommonFunctions.movemousepointer(driver,"//label[@for='terms']"); 
			    //Thread.sleep(6000);
			    CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
			    CommonFunctions.waitForElement(driver, obj.getEmailConfirmationPageTitle(), 10, "verification");
			    BaseClass.statusPassWithScreenshot(driver, "Email Screen Dispalyed",Browser+"_"+TestCaseDescription+"_1");
			        
			 	LoginPage.LaunchURL(driver,GatewayEmailURL);
				CommonFunctions.EmailLogin(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailUserName"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailPwd"), TestCaseDescription);
				Thread.sleep(2000);
				System.out.println("check1");
				CommonFunctions.EmailValidation(driver, accountNumber, TestCaseDescription);
				statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);
				
				String CurrentDate=CommonFunctions.Date(driver,TestCaseID,Functionality, TestCaseDescription);
				DataBase.DBEmailUpdated(driver,accountNumber,CurrentDate,TestCaseDescription);
				statusPassWithScreenshot(driver,"Screenshot done",Functionality + "TC122");
			
				endReporting();
			}
		}
		
		@Test(dataProvider="DriverSheet")
		public void test_322_M_TC124(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription,String Execution, String Status)throws Exception
		{
			int rowNumber = Integer.parseInt(RowNumber);
			if(TestCaseID.equalsIgnoreCase("TC124")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Medium"))
			{
				
				startReporting(TestCaseDescription);
				accountNumber=DataBase.DBConnection(driver,"ACCOUNTWITHNOSECURITYQUES", LanguageSettings, TestCaseDescription);
				
				LoginPage.LaunchURL(driver,GatewayAdminURL);
				String tempPassword=Admin.getTemporaryPassword(driver, accountNumber);
				Admin.getTemporaryTradingPassword(driver, accountNumber);
				LoginPage.LaunchURL(driver,GatewayQAURL);

				//accountNumber=ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username",TestDataID);
				LoginPage.Login(rowNumber,accountNumber,tempPassword ,"Home",Functionality + TestCaseID);
				
				CommonFunctions.verifyText(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		  		
		  		driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		        driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		        CommonFunctions.ClickButton(driver,obj.getContinueButton());
		        
		        CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
		        //System.out.println(obj.getNewTradingpassword());
		        
		        
		        driver.findElement(By.xpath(obj.getNewTradingpassword())).sendKeys("aaaaaa");
		        driver.findElement(By.xpath(obj.getConfirmTradingpassword())).sendKeys("aaaaaa");
		        CommonFunctions.ClickButton(driver,obj.getTradingcontinue());
		    
		        CommonFunctions.verifyElement(driver, "Challenge Question Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
			    CommonFunctions.setSecurityFields(driver, 5,"porter", 7, "animal",8, "tester",TestCaseDescription);
			    CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
			    CommonFunctions.verifyElement(driver, "Email address screen", obj.getEmailAddressTitle(),TestCaseDescription);        
			  
			          
			    CommonFunctions.SetText(driver, obj.getEmailAddressNewEmail(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID") );
			    CommonFunctions.SetText(driver, obj.getEmailAddressConfirmEmail(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID") );
			  CommonFunctions.movemousepointer(driver,"//label[@for='terms']"); 
			    //Thread.sleep(6000);
			    CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
			    CommonFunctions.waitForElement(driver, obj.getEmailConfirmationPageTitle(), 10, "verification");
			    BaseClass.statusPassWithScreenshot(driver, "Email Screen Dispalyed",Browser+"_"+TestCaseDescription+"_1");
			        
			 	LoginPage.LaunchURL(driver,GatewayEmailURL);
				CommonFunctions.EmailLogin(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailUserName"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailPwd"), TestCaseDescription);
				Thread.sleep(2000);
				System.out.println("check1");
				CommonFunctions.EmailValidation(driver, accountNumber, TestCaseDescription);
				
			    CommonFunctions.ClickButton(driver,obj.getGotoLoginButton());
		      //  LoginPage.LaunchURL(driver,GatewayQAURL);
			  //  LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
			   CommonFunctions.waitForElement(driver,obj.getUserName(), 30, "verification");
		    
			
				statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);
				
				String CurrentDate=CommonFunctions.Date(driver,TestCaseID,Functionality, TestCaseDescription);
				DataBase.DBEmailUpdated(driver,accountNumber,CurrentDate,TestCaseDescription);
				statusPassWithScreenshot(driver,"Screenshot done",Functionality + "TC122");
			
				endReporting();
			}
		}
		
		@Test(dataProvider="DriverSheet")
		public void test_322_M_TC126(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription,String Execution, String Status)throws Exception
		{
			int rowNumber = Integer.parseInt(RowNumber);
			if(TestCaseID.equalsIgnoreCase("TC126")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Medium"))
			{
				
				startReporting(TestCaseDescription);
				accountNumber=DataBase.DBConnection(driver,"ACCOUNTWITHNOSECURITYQUES", LanguageSettings, TestCaseDescription);
				
				LoginPage.LaunchURL(driver,GatewayAdminURL);
				String tempPassword=Admin.getTemporaryPassword(driver, accountNumber);
				Admin.getTemporaryTradingPassword(driver, accountNumber);
				LoginPage.LaunchURL(driver,GatewayQAURL);

				//accountNumber=ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username",TestDataID);
				LoginPage.Login(rowNumber,accountNumber,tempPassword ,"Home",Functionality + TestCaseID);
				
				CommonFunctions.verifyText(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		  		
		  		driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		        driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		        CommonFunctions.ClickButton(driver,obj.getContinueButton());
		        
		        CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
		        //System.out.println(obj.getNewTradingpassword());
		        
		        
		        driver.findElement(By.xpath(obj.getNewTradingpassword())).sendKeys("aaaaaa");
		        driver.findElement(By.xpath(obj.getConfirmTradingpassword())).sendKeys("aaaaaa");
		        CommonFunctions.ClickButton(driver,obj.getTradingcontinue());
		    
		        CommonFunctions.verifyElement(driver, "Challenge Question Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
			    CommonFunctions.setSecurityFields(driver, 5,"porter", 7, "animal",8, "tester",TestCaseDescription);
			    CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
			    CommonFunctions.verifyElement(driver, "Email address screen", obj.getEmailAddressTitle(),TestCaseDescription);        
			  
			          
			    CommonFunctions.SetText(driver, obj.getEmailAddressNewEmail(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID") );
			    CommonFunctions.SetText(driver, obj.getEmailAddressConfirmEmail(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID") );
			    CommonFunctions.movemousepointer(driver,"//label[@for='terms']"); 
			    //Thread.sleep(6000);
			    CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
			    CommonFunctions.waitForElement(driver, obj.getEmailConfirmationPageTitle(), 10, "verification");
			    BaseClass.statusPassWithScreenshot(driver, "Email Screen Dispalyed",Browser+"_"+TestCaseDescription+"_1");
			 
				
				String CurrentDate=CommonFunctions.Date(driver,TestCaseID,Functionality, TestCaseDescription);
				DataBase.DBEmailUpdated(driver,accountNumber,CurrentDate,TestCaseDescription);
				statusPassWithScreenshot(driver,"Screenshot done",Functionality + "TC122");
				
				
				
				LoginPage.LaunchURL(driver,GatewayQAURL);

				//accountNumber=ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username",TestDataID);
				LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"),"Home",Functionality + TestCaseID);
			
				   CommonFunctions.verifyText(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_VerifyText_Eng") , obj.getUnSecureError(), TestCaseDescription);
					
				endReporting();
			}
		}
		
		
		@Test(dataProvider="DriverSheet")
		public void test_322_M_TC127(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription,String Execution, String Status)throws Exception
		{
			int rowNumber = Integer.parseInt(RowNumber);
			if(TestCaseID.equalsIgnoreCase("TC127")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Medium"))
			{
				
				startReporting(TestCaseDescription);
				accountNumber=DataBase.DBConnection(driver,"ACCOUNTWITHNOSECURITYQUES", LanguageSettings, TestCaseDescription);
				
				LoginPage.LaunchURL(driver,GatewayAdminURL);
				String tempPassword=Admin.getTemporaryPassword(driver, accountNumber);
				Admin.getTemporaryTradingPassword(driver, accountNumber);
				LoginPage.LaunchURL(driver,GatewayQAURL);

				//accountNumber=ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username",TestDataID);
				LoginPage.Login(rowNumber,accountNumber,tempPassword ,"Home",Functionality + TestCaseID);
				
				CommonFunctions.verifyText(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		  		
		  		driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		        driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		        CommonFunctions.ClickButton(driver,obj.getContinueButton());
		        
		        CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
		        //System.out.println(obj.getNewTradingpassword());
		        
		        
		        driver.findElement(By.xpath(obj.getNewTradingpassword())).sendKeys("aaaaaa");
		        driver.findElement(By.xpath(obj.getConfirmTradingpassword())).sendKeys("aaaaaa");
		        CommonFunctions.ClickButton(driver,obj.getTradingcontinue());
		    
		        CommonFunctions.verifyElement(driver, "Challenge Question Screen", obj.getSecurityQuestionTitle(),TestCaseDescription);        
			    CommonFunctions.setSecurityFields(driver, 5,"porter", 7, "animal",8, "tester",TestCaseDescription);
			    CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
			    CommonFunctions.verifyElement(driver, "Email address screen", obj.getEmailAddressTitle(),TestCaseDescription);        
			  
			          
			    CommonFunctions.SetText(driver, obj.getEmailAddressNewEmail(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID") );
			    CommonFunctions.SetText(driver, obj.getEmailAddressConfirmEmail(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID") );
			    CommonFunctions.movemousepointer(driver,"//label[@for='terms']"); 
			    //Thread.sleep(6000);
			    CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
			    CommonFunctions.waitForElement(driver, obj.getEmailConfirmationPageTitle(), 10, "verification");
			    BaseClass.statusPassWithScreenshot(driver, "Email Screen Dispalyed",Browser+"_"+TestCaseDescription+"_1");
			 
				
				String CurrentDate=CommonFunctions.Date(driver,TestCaseID,Functionality, TestCaseDescription);
				DataBase.DBEmailUpdated(driver,accountNumber,CurrentDate,TestCaseDescription);
				statusPassWithScreenshot(driver,"Screenshot done",Functionality + "TC122");
				
				
				
				LoginPage.LaunchURL(driver,GatewayQAURL);

				//accountNumber=ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username",TestDataID);
				LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"),"Home",Functionality + TestCaseID);
			
				   CommonFunctions.verifyText(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_VerifyText_Eng") , obj.getUnSecureError(), TestCaseDescription);
					
				endReporting();
			}
		}
		
		
		
		
		
		
		@Test(dataProvider = "DriverSheet")
		public void test_324_M_TC019(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
			int rowNumber = Integer.parseInt(RowNumber);
			if (TestCaseID.equalsIgnoreCase("TC019")&& Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.4_Functional_Medium")) {

				startReporting("TC019_GUI_Set up challenge questions screen_Challenge questions dropdown");
				LoginPage.LaunchURL(driver, GatewayQAURL);
				
				
				accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
				
				//Line Added/Modified by Sakshee
				
				//accountNumber= ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng");
				
				LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"Home",TestCaseDescription );
			    CommonFunctions.verifyElement(driver, "Home",obj.getHomePageLogo(),TestCaseDescription);
				CommonFunctions.verifyElement(driver, "Set Up Now ButtOn on banner",obj.getCommunicationLink(),TestCaseDescription);
				CommonFunctions.verifyElement(driver, "Communication link Text",obj.getCommunicationLink_BannerText(),TestCaseDescription);
				//CommonFunctions.verifyText(driver, "Home",obj.getCommunicationLink_BannerText(),TestCaseDescription);
		        CommonFunctions.ClickButton(driver,obj.getCommunicationLink());
				
				
				CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(),TestCaseDescription );
				 CommonFunctions.verifySecurityElements(driver,TestCaseDescription);
				// CommonFunctions.setSecurityFields(driver,1, "animal",2,"animal",3,"animal", TestCaseDescription);
				 CommonFunctions.getQuestionList(driver,obj.getQuestion1(), TestCaseDescription);
				 CommonFunctions.getQuestionList(driver,obj.getQuestion2(), TestCaseDescription);
				 CommonFunctions.getQuestionList(driver,obj.getQuestion3(), TestCaseDescription);
				 
				// CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
				// CommonFunctions.verifyElement(driver,"Security question", obj.getSecurityQuestionMessage(),TestCaseDescription);

						
				BaseClass.statusPassWithScreenshot(driver, "Security Question Setup Screen",TestCaseDescription);
				endReporting();
			}

		}
		@Test(dataProvider="DriverSheet")
		public void test_325_C_TC005(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
		{
			
			int rowNumber = Integer.parseInt(RowNumber);
			if(TestCaseID.equalsIgnoreCase("TC005")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Complex"))
			{
				
				startReporting(Functionality);
				
				accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
			    LoginPage.LaunchURL(driver,GatewayQAURL);
			    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
			 //   CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
		      //  CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
			    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
			            
			   CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
			    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    	driver.close();
		    	driver=LoginPage.LaunchBrowser(Browser);
		    	LoginPage.LaunchURL(driver,GatewayQAURL);
				LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
				 
				   CommonFunctions.verifyText(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_VerifyText_Eng") , obj.getUnSecureError(), TestCaseDescription);
				    
				
				LoginPage.LaunchURL(driver,GatewayAdminURL);
		        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
		      //  Admin.getTemporaryTradingPassword(driver,accountNumber);
		        LoginPage.LaunchURL(driver,GatewayQAURL);
		        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
		        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
			    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
		   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
		   	  	
		  /* 	 CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
		        //System.out.println(obj.getNewTradingpassword());
		        
		        
		        driver.findElement(By.xpath(obj.getNewTradingpassword())).sendKeys("aaaaaa");
		        driver.findElement(By.xpath(obj.getConfirmTradingpassword())).sendKeys("aaaaaa");
		        CommonFunctions.ClickButton(driver,obj.getTradingcontinue());*/
		        
		        
		   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
		   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
		   	  	CommonFunctions.setSecurityFields(driver,1, "animal",2, "porter", 6, "failure", TestCaseDescription);
		   	 	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		   	 	CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
		  	    driver.findElement(By.xpath(obj.getEmailAddressNewEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
		     	driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
		     	BaseClass.statusPassWithScreenshot(driver,"Email Address Screen",TestCaseDescription);
		    	CommonFunctions.movemousepointer(driver,"//label[@for='terms']");
		        CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
		        CommonFunctions.waitForElement(driver, obj.getEmailConfirmationPageTitle(), 10, "verification");
		        LoginPage.LaunchURL(driver,GatewayEmailURL);
		        CommonFunctions.EmailLogin(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailUserName"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailPwd"), TestCaseDescription);
		        Thread.sleep(2000);
		        System.out.println("check1");
		        CommonFunctions.EmailValidation(driver, accountNumber, TestCaseDescription);
		        statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);
		  
		        CommonFunctions.ClickButton(driver,obj.getGotoLoginButton());
		        LoginPage.LaunchURL(driver,GatewayQAURL);
			    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
			 
			    CommonFunctions.waitForElement(driver, obj.getHomePageLogo(), 10, "verification");
			      
		    	 
		    	 
		    	 
		    	 
		      	endReporting();
			}
		}
		
		
		@Test(dataProvider="DriverSheet")
		public void test_325_C_TC007(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
		{
			
			int rowNumber = Integer.parseInt(RowNumber);
			if(TestCaseID.equalsIgnoreCase("TC007")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Complex"))
			{
				
				startReporting(Functionality);
				
				accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
			    LoginPage.LaunchURL(driver,GatewayQAURL);
			    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
			 //   CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
		      //  CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
			    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
			            
			   CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
			    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    	
			    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys("A2aaaaaa");
		   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys("A2aaaaaa");
		   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
		   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
		   	  	
		   		CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
		   	 
		   
			    
			    driver.close();
		    	driver=LoginPage.LaunchBrowser(Browser);
		    	LoginPage.LaunchURL(driver,GatewayQAURL);
				LoginPage.Login(rowNumber,accountNumber, "A2aaaaaa","Home",TestCaseDescription);
				 
				   CommonFunctions.verifyText(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_VerifyText_Eng") , obj.getUnSecureError(), TestCaseDescription);
				    
				
				LoginPage.LaunchURL(driver,GatewayAdminURL);
		        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
		      //  Admin.getTemporaryTradingPassword(driver,accountNumber);
		        LoginPage.LaunchURL(driver,GatewayQAURL);
		        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
		        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
			    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
		   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
		   	  	
		  /* 	 CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
		        //System.out.println(obj.getNewTradingpassword());
		        
		        
		        driver.findElement(By.xpath(obj.getNewTradingpassword())).sendKeys("aaaaaa");
		        driver.findElement(By.xpath(obj.getConfirmTradingpassword())).sendKeys("aaaaaa");
		        CommonFunctions.ClickButton(driver,obj.getTradingcontinue());*/
		        
		        
		   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
		   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
		   	  	CommonFunctions.setSecurityFields(driver,1, "animal",2, "porter", 6, "failure", TestCaseDescription);
		   	 	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		   	 	CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
		  	    driver.findElement(By.xpath(obj.getEmailAddressNewEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
		     	driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
		     	BaseClass.statusPassWithScreenshot(driver,"Email Address Screen",TestCaseDescription);
		    	CommonFunctions.movemousepointer(driver,"//label[@for='terms']");
		        CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
		        CommonFunctions.waitForElement(driver, obj.getEmailConfirmationPageTitle(), 10, "verification");
		        LoginPage.LaunchURL(driver,GatewayEmailURL);
		        CommonFunctions.EmailLogin(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailUserName"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailPwd"), TestCaseDescription);
		        Thread.sleep(2000);
		        System.out.println("check1");
		        CommonFunctions.EmailValidation(driver, accountNumber, TestCaseDescription);
		        statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);
		  
		        CommonFunctions.ClickButton(driver,obj.getGotoLoginButton());
		        LoginPage.LaunchURL(driver,GatewayQAURL);
			    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
			 
			    CommonFunctions.waitForElement(driver, obj.getHomePageLogo(), 10, "verification");
			      
		    	 
		    	 
		    	 
		    	 
		      	endReporting();
			}
		}
		
		
		@Test(dataProvider="DriverSheet")
		public void test_325_C_TC008(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
		{
			
			int rowNumber = Integer.parseInt(RowNumber);
			if(TestCaseID.equalsIgnoreCase("TC008")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Complex"))
			{
				
				startReporting(Functionality);
				
				accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
			    LoginPage.LaunchURL(driver,GatewayQAURL);
			    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
			 //   CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
		      //  CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
			    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
			            
			   CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
			   
			    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
			    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
		   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
		   	  	
		  /* 	 CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
		        //System.out.println(obj.getNewTradingpassword());
		        
		        
		        driver.findElement(By.xpath(obj.getNewTradingpassword())).sendKeys("aaaaaa");
		        driver.findElement(By.xpath(obj.getConfirmTradingpassword())).sendKeys("aaaaaa");
		        CommonFunctions.ClickButton(driver,obj.getTradingcontinue());*/
		        
		        
		   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
		   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
		   	  	CommonFunctions.setSecurityFields(driver,1, "animal",2, "porter", 6, "failure", TestCaseDescription);
		   	 	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		   	 	CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
		  	
			 
			    
			    driver.close();
		    	driver=LoginPage.LaunchBrowser(Browser);
		    	LoginPage.LaunchURL(driver,GatewayQAURL);
				LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"),"Home",TestCaseDescription);
				CommonFunctions.verifyText(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_VerifyText_Eng") , obj.getUnSecureError(), TestCaseDescription);
				    
				
				  	 
		    	 
		    	 
		    	 
		      	endReporting();
			}
		}
		
		
		@Test(dataProvider="DriverSheet")
		public void test_325_C_TC009(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
		{
			
			int rowNumber = Integer.parseInt(RowNumber);
			if(TestCaseID.equalsIgnoreCase("TC009")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.5_Functional_Complex"))
			{
				
				startReporting(Functionality);
				
				accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
			    LoginPage.LaunchURL(driver,GatewayQAURL);
			    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
			 //   CommonFunctions.verifyElement(driver, "Set Up Now Button", obj.getUnsecureSetUpNowButton(), TestCaseDescription);
		      //  CommonFunctions.ClickButton(driver,obj.getUnsecureSetUpNowButton());
			    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
			            
			   CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
			    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
		    	
			    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys("A2aaaaaa");
		   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys("A2aaaaaa");
		   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
		   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
		   	  	
		   		CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
		   	 
		   		CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
		   	  	CommonFunctions.setSecurityFields(driver,1, "animal",2, "porter", 6, "failure", TestCaseDescription);
		   	 	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		   	 	CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
		  	
			    
			    driver.close();
		    	driver=LoginPage.LaunchBrowser(Browser);
		    	LoginPage.LaunchURL(driver,GatewayQAURL);
				LoginPage.Login(rowNumber,accountNumber, "A2aaaaaa","Home",TestCaseDescription);
				 
				   CommonFunctions.verifyText(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_VerifyText_Eng") , obj.getUnSecureError(), TestCaseDescription);
				    
				
				LoginPage.LaunchURL(driver,GatewayAdminURL);
		        tempPassword=Admin.getTemporaryPassword(driver,accountNumber);
		      //  Admin.getTemporaryTradingPassword(driver,accountNumber);
		        LoginPage.LaunchURL(driver,GatewayQAURL);
		        LoginPage.Login(rowNumber,accountNumber, tempPassword,"Home",Functionality + TestCaseID);
		        CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
			    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
		   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
		   	  	
		  /* 	 CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
		        //System.out.println(obj.getNewTradingpassword());
		        
		        
		        driver.findElement(By.xpath(obj.getNewTradingpassword())).sendKeys("aaaaaa");
		        driver.findElement(By.xpath(obj.getConfirmTradingpassword())).sendKeys("aaaaaa");
		        CommonFunctions.ClickButton(driver,obj.getTradingcontinue());*/
		        
		        
		   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
		   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
		   	  	CommonFunctions.setSecurityFields(driver,8, "animal1",5, "porter1", 10, "failure1", TestCaseDescription);
		   	 	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		   	 	CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
		  	    driver.findElement(By.xpath(obj.getEmailAddressNewEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
		     	driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
		     	BaseClass.statusPassWithScreenshot(driver,"Email Address Screen",TestCaseDescription);
		    	CommonFunctions.movemousepointer(driver,"//label[@for='terms']");
		        CommonFunctions.ClickButton(driver,obj.getEmailAddressSubmitButton());
		        CommonFunctions.waitForElement(driver, obj.getEmailConfirmationPageTitle(), 10, "verification");
		        LoginPage.LaunchURL(driver,GatewayEmailURL);
		        CommonFunctions.EmailLogin(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailUserName"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailPwd"), TestCaseDescription);
		        Thread.sleep(2000);
		        System.out.println("check1");
		        CommonFunctions.EmailValidation(driver, accountNumber, TestCaseDescription);
		        statusPassWithScreenshot(driver,"Email Verification done",TestCaseID);
		  
		        CommonFunctions.ClickButton(driver,obj.getGotoLoginButton());
		        LoginPage.LaunchURL(driver,GatewayQAURL);
			    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
			 
			    CommonFunctions.waitForElement(driver, obj.getHomePageLogo(), 10, "verification");
			      
		    	 
		    	 
		    	 
		    	 
		      	endReporting();
			}
		}
		
		
		
		@Test(dataProvider="DriverSheet")
		public void test_323_M_TC076(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
		{
			
			int rowNumber = Integer.parseInt(RowNumber);
			if(TestCaseID.equalsIgnoreCase("TC076")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium"))
			{
				
				startReporting(TestCaseDescription);
				
				accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
			    LoginPage.LaunchURL(driver,GatewayQAURL);
			    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
			    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
			    CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
			    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
			    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
			    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
		   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
		   	  	//CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
		   	 CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
		   	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
	   	  	CommonFunctions.setSecurityFields(driver,8, "animal1",5, "porter1", 10, "failure1", TestCaseDescription);
	   	  
		     //CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
		        statusPassWithScreenshot(driver,"Security Question Screen",TestCaseID);
		  
		       	 
		    	 
		    	 
		    	 
		      	endReporting();
			}
		}
		
		@Test(dataProvider="DriverSheet")
		public void test_323_M_TC077(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
		{
			
			int rowNumber = Integer.parseInt(RowNumber);
			if(TestCaseID.equalsIgnoreCase("TC077")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium"))
			{
				
				startReporting(TestCaseDescription);
				
				accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
			    LoginPage.LaunchURL(driver,GatewayQAURL);
			    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
			    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
			    CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
			    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
			    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
			    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
		   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
		   	  	//CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
		   	 CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
		   	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
	   	  	CommonFunctions.setSecurityFields(driver,8, "animal1",5, "porter1", 10, "failure1", TestCaseDescription);
	   	  
		     //CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
		        statusPassWithScreenshot(driver,"Security Question Screen",TestCaseID);
		  
		       	 
		    	 
		    	 
		    	 
		      	endReporting();
			}
		}
		
		
		@Test(dataProvider="DriverSheet")
		public void test_323_M_TC078(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
		{
			
			int rowNumber = Integer.parseInt(RowNumber);
			if(TestCaseID.equalsIgnoreCase("TC078")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium"))
			{
				
				startReporting(TestCaseDescription);
				
				accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
			    LoginPage.LaunchURL(driver,GatewayQAURL);
			    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
			    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
			    CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
			    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
			    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
			    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
		   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
		   	  	//CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
		   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
		   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
		   	  	CommonFunctions.setSecurityFields(driver,8, "animal1",5, "animal1", 10, "animal1", TestCaseDescription);
		   	  	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		   		CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Verifytext_Eng"), obj.getSecurityErrorMessages(),TestCaseDescription);
		   		statusPassWithScreenshot(driver,"Security Question Screen",TestCaseID);
		   		     
		      	endReporting();
			}
		}
		
		
		@Test(dataProvider="DriverSheet")
		public void test_323_M_TC087(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
		{
			
			int rowNumber = Integer.parseInt(RowNumber);
			if(TestCaseID.equalsIgnoreCase("TC087")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium"))
			{
				
				startReporting(TestCaseDescription);
				
				accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
			    LoginPage.LaunchURL(driver,GatewayQAURL);
			    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
			    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
			    CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
			    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
			    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
			    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
		   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
		   	  	//CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
		   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
		   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
		   	  	CommonFunctions.setSecurityFields(driver,8, "animal1",5, "animal1", 10, "porter1", TestCaseDescription);
		   	  	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		   		CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Verifytext_Eng"), obj.getSecurityErrorMessages(),TestCaseDescription);
		   		statusPassWithScreenshot(driver,"Security Question Screen",TestCaseID);
		   		     
		      	endReporting();
			}
		}
		
		
		@Test(dataProvider="DriverSheet")
		public void test_323_M_TC023(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
		{
			
			int rowNumber = Integer.parseInt(RowNumber);
			if(TestCaseID.equalsIgnoreCase("TC023")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium"))
			{
				
				startReporting(TestCaseDescription);
				
				//Login to the Application	
				LoginPage.LaunchURL(driver,GatewayQAURL);
				accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
				   
				LoginPage.Login(rowNumber,accountNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng") ,"eServices",Functionality + TestCaseID);
				CommonFunctions.waitForElement(driver, obj.getLoginDropDown(),10,"LoginPage");              
				CommonFunctions.verifyElement(driver,"eServices", obj.getAccountSetting_eServicesTab(),TestCaseDescription);
			    statusPass("eServices page displayed");   
			    CommonFunctions.verifyElement(driver,"Profile", obj.getAccountSetting_ProfileTab(),TestCaseDescription);
		        driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab())).click();
		        CommonFunctions.verifyText(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Verifytext_Eng"),obj.getProfileEmailadreditbtn(),TestCaseDescription);
		     
		     
				
		   		statusPassWithScreenshot(driver,"Profile Screen",TestCaseID);
		   		     
		      	endReporting();
			}
		}
		@Test(dataProvider="DriverSheet")
		public void test_323_M_TC080(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
		{
			
			int rowNumber = Integer.parseInt(RowNumber);
			if(TestCaseID.equalsIgnoreCase("TC080")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium"))
			{
				
				startReporting(TestCaseDescription);
				
				accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
			    LoginPage.LaunchURL(driver,GatewayQAURL);
			    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
			    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
			    CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
			    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
			    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
			    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
		   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
		   	  	//CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
		   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
		   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
		   	  	CommonFunctions.setSecurityFields(driver,8, "animal1",5, "porter1", 10, "tester12", TestCaseDescription);
		   	  	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		   		CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
			  	
		   		statusPassWithScreenshot(driver,"Email Screen",TestCaseID);
		   		     
		      	endReporting();
			}
		}
		
		
		@Test(dataProvider="DriverSheet")
		public void test_323_M_TC082(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
		{
			
			int rowNumber = Integer.parseInt(RowNumber);
			if(TestCaseID.equalsIgnoreCase("TC082")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium"))
			{
				
				startReporting(TestCaseDescription);
				
				accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
			    LoginPage.LaunchURL(driver,GatewayQAURL);
			    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
			    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
			    CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
			    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
			    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
			    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
		   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
		   	  	//CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
		   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
		   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
		   	  	CommonFunctions.setSecurityFields(driver,5, "animal1",7, "porter1", 8, "tester12", TestCaseDescription);
		   	  	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		   		CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
			  	
		   		statusPassWithScreenshot(driver,"Email Screen",TestCaseID);
		   		     
		      	endReporting();
			}
		}
		
		@Test(dataProvider="DriverSheet")
		public void test_323_M_TC083(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
		{
			
			int rowNumber = Integer.parseInt(RowNumber);
			if(TestCaseID.equalsIgnoreCase("TC083")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium"))
			{
				
				startReporting(TestCaseDescription);
				
				accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
			    LoginPage.LaunchURL(driver,GatewayQAURL);
			    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
			    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
			    CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
			    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
			    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
			    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
		   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
		   	  	//CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
		   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
		   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
		   	  	CommonFunctions.setSecurityFields(driver,5, "animal1",18, "porter1", 10, "tester12", TestCaseDescription);
		   	  	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		   		CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
			  	
		   		statusPassWithScreenshot(driver,"Email Screen",TestCaseID);
		   		     
		      	endReporting();
			}
		}
		
		@Test(dataProvider="DriverSheet")
		public void test_323_M_TC084(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
		{
			
			int rowNumber = Integer.parseInt(RowNumber);
			if(TestCaseID.equalsIgnoreCase("TC084")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium"))
			{
				
				startReporting(TestCaseDescription);
				
				accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
			    LoginPage.LaunchURL(driver,GatewayQAURL);
			    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
			    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
			    CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
			    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
			    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
			    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
		   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
		   	  	//CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
		   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
		   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
		   	  	CommonFunctions.setSecurityFields(driver,10, "animal1",5, "porter1", 18, "tester12", TestCaseDescription);
		   	  	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		   		CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
			  	
		   		statusPassWithScreenshot(driver,"Email Screen",TestCaseID);
		   		     
		      	endReporting();
			}
		}
		
		
		@Test(dataProvider="DriverSheet")
		public void test_323_M_TC086(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
		{
			
			int rowNumber = Integer.parseInt(RowNumber);
			if(TestCaseID.equalsIgnoreCase("TC086")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium"))
			{
				
				startReporting(TestCaseDescription);
				
				accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
			    LoginPage.LaunchURL(driver,GatewayQAURL);
			    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
			    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
			    CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
			    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
			    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
			    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
		   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
		   	  	//CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
		   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
		   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
		   	  	CommonFunctions.setSecurityFields(driver,10, "animal1",18, "porter1", 5, "tester12", TestCaseDescription);
		   	  	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		   		CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
			  	
		   		statusPassWithScreenshot(driver,"Email Screen",TestCaseID);
		   		     
		      	endReporting();
			}
		}

		@Test(dataProvider="DriverSheet")
		public void test_323_M_TC085(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
		{
			
			int rowNumber = Integer.parseInt(RowNumber);
			if(TestCaseID.equalsIgnoreCase("TC085")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.3_Functional_Medium"))
			{
				
				startReporting(TestCaseDescription);
				
				accountNumber=DataBase.DBConnection(driver,"SECQUESCUTOFFDATEEXCEEDED", LanguageSettings, TestCaseDescription);
			    LoginPage.LaunchURL(driver,GatewayQAURL);
			    LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",TestCaseDescription);
			    CommonFunctions.verifyElement(driver, "Set Up Now Button", "//span[@class='span-button']", TestCaseDescription);
			    CommonFunctions.ClickButton(driver,"//span[@class='span-button']");
			    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
			    CommonFunctions.verifyElement(driver, "Create a new Password", obj.getPasswordChangePageTitle(), TestCaseDescription);
			    driver.findElement(By.xpath(obj.getNewPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	driver.findElement(By.xpath(obj.getConfirmPasswordField())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewPassword_Eng"));
		   	  	CommonFunctions.verifyElement(driver, "Continue Button", obj.getContinueButton(), TestCaseDescription);
		   	  	CommonFunctions.ClickButton(driver,obj.getContinueButton());
		   	  	//CommonFunctions.waitForElement(driver, obj.getTradingpasswordtitle(), 20, "Tradingscreen");
		   	  	CommonFunctions.verifyElement(driver, "Challenge Question title", obj.getChallengeQuestionTitleNew(),TestCaseDescription);
		   	  	CommonFunctions.verifySecurityElements(driver, TestCaseDescription);
		   	  	CommonFunctions.setSecurityFields(driver,18, "animal1",10, "porter1", 5, "tester12", TestCaseDescription);
		   	  	CommonFunctions.ClickButton(driver,obj.getSecurityQuestionContinueBtn());
		   		CommonFunctions.verifyElement(driver, "Email Address Screen", obj.getEmailAddressTitle(),TestCaseDescription);
			  	
		   		statusPassWithScreenshot(driver,"Email Screen",TestCaseID);
		   		     
		      	endReporting();
			}
		}
		
		
	
@AfterTest
public void afterTest() throws Exception
{
		
}
	
@AfterSuite
public void afterSuite() throws Exception
{
      closeReporting();
      LoginPage.closeDriver();
      ReadExcelFile.endExcelFileRead();
}
}
