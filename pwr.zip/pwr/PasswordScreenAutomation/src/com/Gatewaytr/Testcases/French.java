/**
 * 
 */
package com.Gatewaytr.Testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.testng.annotations.Test;

import java.awt.Image;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.List;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import com.Gateway.GlobalParameters.BaseClass;
import com.Gateway.GlobalParameters.FetchingOR;
import com.Gatewaytr.ExcelFile.ReadExcelFile;
import com.Gatewaytr.pages.Admin;
import com.Gatewaytr.pages.CommonFunctions;
import com.Gatewaytr.pages.DataBase;
import com.Gatewaytr.pages.LoginPage;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.model.Screencast;



/**
 * @author craja01
 * TestNG Class
 *
 */
public class French extends BaseClass {

	
	WebDriver driver;
	ExtentReports extent;
	ExtentTest logger;
	public FetchingOR obj=null;
	public String fileName="C:\\GatewayPasswordReset\\Configuration\\ConfigurationPage.property";
	public String fileName_French="C:\\GatewayPasswordReset\\Configuration\\ConfigurationPage_French.property";
	File src = new File("C:\\GatewayPasswordReset\\DriverSheet\\DriveSheetSample.xls");
	int rowNumber;
	
	@DataProvider(name="DriverSheet")
	public Object[][] driverSheetData() {
		Object[][] arrayObject = getExcelData("C:\\GatewayPasswordReset\\DriverSheet\\DriveSheetSample.xls","Sheet1");
		return arrayObject;
	}

	public String[][] getExcelData(String fileName, String sheetName) {
		String[][] arrayExcelData = null;
		try {
			FileInputStream fs = new FileInputStream(fileName);
			Workbook wb = Workbook.getWorkbook(fs);
			Sheet sh = wb.getSheet(sheetName);

			int totalNoOfCols = sh.getColumns();
			int totalNoOfRows = sh.getRows();
			
			arrayExcelData = new String[totalNoOfRows-1][totalNoOfCols];
			
			for (int i= 1 ; i < totalNoOfRows; i++) 
			{
				
				for (int j=0; j < totalNoOfCols; j++) {
					arrayExcelData[i-1][j] = sh.getCell(j, i).getContents();
					
				}

			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
			e.printStackTrace();
		} catch (BiffException e) {
			e.printStackTrace();
		}
		return arrayExcelData;
	}	

	
@BeforeSuite
public void beforeSuite() throws Exception
{
	 	     
     setReport();
    
}
String Browser,LanguageSettings;
String accountNumber;

String tempPassword;
@BeforeTest
@Parameters({ "browserName" ,"language"})
public void beforeTest(String browserName,String language) throws Exception
{
	
	Browser=browserName;
	LanguageSettings=language;
	System.out.println("*****************"+Browser);
	System.out.println("*****************"+LanguageSettings);
	if(LanguageSettings.equalsIgnoreCase("English"))
	{
	obj = new FetchingOR(fileName);
	}
	else
	{
		obj = new FetchingOR(fileName_French);
	}
	ReadExcelFile.setExcelFile(filePath, LanguageSettings);
	driver=LoginPage.LaunchBrowser(Browser);
	
}


/*----- Author - Chinnu Rajaram -----*/

@Test(dataProvider="DriverSheet")
public void test_French_TC002(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Execution, String Status)throws Exception
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC025")&&Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.2_Functional_Low"))
	{
		
		startReporting("3.2.2_Functional_Low_TC025_Create a new Login password screen_Password updated succesfully");
		
		LoginPage.LaunchURL(driver,GatewayAdminURL);
        String tempPassword=Admin.getTemporaryPassword(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"));
        LoginPage.LaunchURL(driver,GatewayQAURL);
        LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), tempPassword,"Home",Functionality + TestCaseID);
      	
        CommonFunctions.verifyElement(driver, "Create Password Page",obj.getPasswordChangePageTitle(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Create Password Page",obj.getMinimum1lowerCase(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Create Password Page",obj.getMinimum1upperCase(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Create Password Page",obj.getMinimum1Number(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Create Password Page",obj.getMinimum8Characters(), TestCaseDescription);
        CommonFunctions.verifyElement(driver, "Create Password Page",obj.getConfirmPasswords(), TestCaseDescription);
        CommonFunctions.verifyText(driver, "Continuer",obj.getContinueButton(), TestCaseDescription);
        BaseClass.statusPassWithScreenshot(driver, "Create Password Screen",TestCaseDescription);

        endReporting();
	}
}


@Test(dataProvider = "DriverSheet")
public void test_324_M_TC014(String RowNumber, String Functionality,String TestCaseID, String TestCaseDescription, String Execution,String Status) throws Exception {
	int rowNumber = Integer.parseInt(RowNumber);
	if (TestCaseID.equalsIgnoreCase("TC014")&& Execution.equalsIgnoreCase("Y")&&Functionality.equalsIgnoreCase("3.2.4_Functional_Medium")) {

		startReporting(TestCaseDescription);
	
		LoginPage.LaunchURL(driver, GatewayQAURL);
		accountNumber=DataBase.DBConnection(driver,"COMMUNICATIONLINKSECURE", LanguageSettings, TestCaseDescription);
		LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID, Functionality, "p_Password_Eng"),"Home",TestCaseDescription );


		CommonFunctions.verifyElement(driver, "Home",obj.getHomePageLogo(),TestCaseDescription);

		
		CommonFunctions.verifyElement(driver, "Home",obj.getAccountSettingTab(),TestCaseDescription);

		driver.findElement(By.xpath(obj.getAccountSettingTab())).click();
		
		CommonFunctions.waitForElement(driver,obj.getAccountSetting_ProfileTab(), 60, "Profile Tab in AccountSettings");
		driver.findElement(By.xpath(obj.getAccountSetting_ProfileTab())).click();
		CommonFunctions.waitForElement(driver,obj.getSetUpNowSecurityQues(), 60, "Set Up Now Button in AccountSettings");
	

driver.findElement(By.xpath(obj.getSetUpNowEmail())).click();

CommonFunctions.verifyElement(driver, "Challenge Questions Title", obj.getChallengeQuestionTitleNew(),TestCaseDescription );
CommonFunctions.verifySecurityElements(driver,TestCaseDescription);

CommonFunctions.setSecurityFields(driver, 1, "animal", 2, "porter", 8, "failure", TestCaseDescription);
driver.findElement(By.xpath(obj.getSecurityQuestionContinueBtn())).click();

CommonFunctions.verifyElement(driver, "Email Screen Title",obj.getEmailAddressTitle(),TestCaseDescription);
	
System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
//CommonFunctions.verifyElement(driver, "Email Screen Title",obj.getEmailAddressTermsCheckBox(),TestCaseDescription);

//Enter valid email ID
		driver.findElement(By.xpath(obj.getEmailAddressNewEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewEmailID"));
		driver.findElement(By.xpath(obj.getEmailAddressConfirmEmail())).sendKeys(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ConfirmEmailID"));
		driver.findElement(By.xpath(obj.getEmailAddressTermsCheckBox())).click();






		//Click on Save button 
		driver.findElement(By.xpath(obj.getEmailAddressSubmitButton())).click();
		CommonFunctions.verifyElement(driver, "Email Confirmation Page", obj.getEmailConfirmationTitle(),TestCaseDescription);        
		statusPassWithScreenshot(driver,"Email verification link Message ",Functionality + TestCaseID);
		//Thread.sleep(120000);
		Thread.sleep(20000);
		driver.close();
		driver= LoginPage.LaunchBrowser(Browser);
		LoginPage.LaunchURL(driver,GatewayEmailURL);
		//LoginPage.Login(rowNumber,accountNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),"Home",Functionality + TestCaseID);
		LoginPage.EmailLogin(rowNumber, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailUserName"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_EmailPwd"), TestCaseID);
	
		LoginPage.EmailValidation(rowNumber, accountNumber, TestCaseID);
		
		CommonFunctions.verifyElement(driver,"Login Button on verified account", obj.getEmailVerifiedButton(), TestCaseDescription);
		driver.findElement(By.xpath(obj.getEmailVerifiedButton())).click();
	
		



		DataBase.DBEmailUpdated(driver,accountNumber, CommonFunctions.Date(driver, TestCaseID, Functionality, TestCaseDescription), TestCaseDescription);
		


		BaseClass.statusPassWithScreenshot(driver, "AccountSettings Screen",TestCaseDescription);
		endReporting();
	}

}



//************************** END OF CODE **************************************
@AfterTest
public void afterTest() throws Exception
{
		
}
	
@AfterSuite
public void afterSuite() throws Exception
{
      closeReporting();
      LoginPage.closeDriver();
      ReadExcelFile.endExcelFileRead();
}
}
