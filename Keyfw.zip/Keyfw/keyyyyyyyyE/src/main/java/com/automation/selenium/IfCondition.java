package com.automation.selenium;

public class IfCondition extends BaseClass {

  DateTimeFunctions dtfObj = new DateTimeFunctions();
  TestDetailedReport tdrObj = new TestDetailedReport();
  DataTable dtObj = new DataTable();

  public int ifContidionSkipper(String strifConditionStatus) throws Exception {
    try {

      String strKeyword;
      log("info", "Entering Function if condition skipper: " + strifConditionStatus + " & " + j);
      if (strifConditionStatus.equalsIgnoreCase("false")) {
        log("info", "If loop of condition skipper: " + strifConditionStatus + " & " + j);
        while (true) {
          log("info", "Im inside while loop " + j);
          // j = j + 1;
          strKeyword = TScsheet.getCell(1, j).getContents();
          log("info", "Do loop skipping action-" + strKeyword);


          if (strKeyword.equalsIgnoreCase("Endcondition")) {
            j = j - 1;
            break;
          }
          j = j + 1;
        }
      }
    } catch (Exception e) {
      log("error", "Exeption Caught in ifContidionSkipper:" + e.getMessage());
    }
    return j;
  }

  public String Func_IfCondition(String strConditionArgs) throws Exception {
    int iFlag = 1;
    String str[] = strConditionArgs.split(";");
    String value1 = str[0].trim();
    String value2 = str[2].trim();
    String strOperation = str[1];
    strOperation = strOperation.toLowerCase().trim();


    if (value1.substring(0, 1).equalsIgnoreCase("#")) {
      value1 = map.get(value1.substring(1, (value1.length())));
    }

    if (value2.substring(0, 1).equalsIgnoreCase("#")) {
      value2 = map.get(value2.substring(1, (value2.length())));
    }

    if (value1.substring(0, 1).equalsIgnoreCase("$")) {
      value1 = dtfObj.getSystemVariable(value1);
    }

    if (value2.substring(0, 1).equalsIgnoreCase("$")) {
      value2 = dtfObj.getSystemVariable(value2);;
    }


    if (value1.substring(0, 3).equalsIgnoreCase("dt_")) {
      value1 = dtObj.getDataTableValue(value1, dtrownum);
    }

    if (value2.substring(0, 3).equalsIgnoreCase("dt_")) {
      value2 = dtObj.getDataTableValue(value2, dtrownum);
    }



    log("info", "Values to compare in condition statement are: " + value1 + " & " + value2);

    switch (strOperation) {
      case "equals":
        if (value1.trim().equalsIgnoreCase(value2.trim())) {
          iFlag = 0;
        }
        break;

      case "notequals":
        if (!value1.trim().equals(value2.trim())) {
          iFlag = 0;
        }
        break;

      case "greaterthan":
        if (isInteger(value1) && isInteger(value2)) {
          if (Integer.parseInt(value1) > Integer.parseInt(value2)) {
            iFlag = 0;
          }
        } else {
          // Report
        }
        break;
      case "lessthan":
        if (isInteger(value1) && isInteger(value2)) {
          if (Integer.parseInt(value1) < Integer.parseInt(value2)) {
            iFlag = 0;
          }
        } else {
          // Report
        }
        break;
      default:
        tdrObj.Update_Report("missing");

    }
    if (iFlag == 0) {
      return "true";
    } else {
      return "false";
    }

  }

  public boolean isInteger(String input) {
    try {
      Integer.parseInt(input);
      return true;
    } catch (Exception e) {
      return false;
    }
  }

}
