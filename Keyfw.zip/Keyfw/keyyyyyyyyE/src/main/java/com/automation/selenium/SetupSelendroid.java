package com.automation.selenium;
/*
import io.selendroid.SelendroidCapabilities;
import io.selendroid.SelendroidConfiguration;
import io.selendroid.SelendroidDriver;
import io.selendroid.SelendroidLauncher;

import org.openqa.selenium.remote.DesiredCapabilities;

public class SetupSelendroid extends BaseClass {

  public void setupSelendroidDriver(String automationName, String platformName,
      String platformVersion, String browserName, String browserVersion, String deviceName,
      String appPackage, String appActivity) throws Exception {
    try {
      log("info", "Started setting up Selendroid driver.....");


      if (selendroidServer != null) {
        selendroidServer.stopSelendroid();
      }

      SelendroidConfiguration config = new SelendroidConfiguration();
      if (appPackage.trim() != "") {
        config.addSupportedApp("E:\\Yuvaraj\\Testing\\Selenium\\ProjectFramework\\TestData\\"
            + appPackage);
      }
      // config.setPort(5555);
      // config.setShouldKeepAdbAlive(false);
      // config.setVerbose(true);
      // config.setRestartAdb(false);
      // config.setSelendroidServerPort(5555);
      // config.setTimeoutEmulatorStart(600000);
      // config.setServerHost("http://localhost:5555/wd/hub");
      selendroidServer = new SelendroidLauncher(config);
      selendroidServer.lauchSelendroid();

      DesiredCapabilities caps;

      if (browserName.equalsIgnoreCase("android")) {
        caps = SelendroidCapabilities.android();
      } else {
        caps = new SelendroidCapabilities();
      }


      caps.setCapability(SelendroidCapabilities.EMULATOR, true);
      if (appActivity.trim() != "") {
        caps.setCapability(SelendroidCapabilities.AUT, appActivity);
      }
      // caps.setCapability(SelendroidCapabilities.ANDROID_TARGET,"ANDROID18");
      // caps.setCapability(CapabilityType.PLATFORM,"ANDROID");
      // caps.setCapability(CapabilityType.BROWSER_NAME,"android");
      // caps.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);

      D8 = new SelendroidDriver("http://127.0.0.1:4444/wd/hub", caps);
      log("info", "Selendroid hub started successfully @ http://127.0.0.1:4444/wd/hub ");
    }

    catch (Exception e) {
      setUpSuccess = false;
      log("error", "Exception caught while launching Selendroid: " + e.getMessage());
    }

  }
}
*/
