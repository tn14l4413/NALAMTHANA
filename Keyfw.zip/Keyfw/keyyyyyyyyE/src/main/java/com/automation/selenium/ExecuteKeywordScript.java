package com.automation.selenium;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import jxl.Workbook;
import jxl.WorkbookSettings;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.Point;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ExecuteKeywordScript extends BaseClass {

  TestDetailedReport tdrObj = new TestDetailedReport();
  TestSummaryReport tsrObj = new TestSummaryReport();
  ObjectRepository orObj = new ObjectRepository();
  KeywordRelatedFunctions krfObj = new KeywordRelatedFunctions();
  IfCondition ifcObj = new IfCondition();
  FindElement fEObj = new FindElement();
  ScreenShot ssObj = new ScreenShot();
  StoreCheck scObj = new StoreCheck();
  RobotActions raObj = new RobotActions();
  DateTimeFunctions dtfObj = new DateTimeFunctions();
  CustomExceptionMessages cemObj = new CustomExceptionMessages();
  DataTable dtObj = new DataTable();
  CheckWindowPresence cwpObj = new CheckWindowPresence();
  WaitForElement wfeObj = new WaitForElement();
  AutoGenerateComments agcObj = new AutoGenerateComments();
  MiscFunctions mfObj = new MiscFunctions();
  DataBase dbObj = new DataBase();
  MobileGesturesAppium mgaObj = new MobileGesturesAppium();
  MobileGesturesSelendroid mgsObj = new MobileGesturesSelendroid();
  CustomKeywords cuskeyObj = new CustomKeywords();
  PDFUtility pdfutilObj = new PDFUtility();
  StoreValue stValObj = new StoreValue();
  DBConnection dbcObj=new DBConnection();
  //DBConnection dbcObj=new DBConnection("10.193.16.54","1521","SIRW2", "jdbc:oracle:thin:@","rchanda","Welcome2");


  public void ExecKeywordScript(String packageName, String scriptName, String TestScript, String ObjectRepository) throws Exception {
    // Report header
	log("info", "Started Execute keyword script function..") ; 
    cur_dt = new Date();
    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
    String strTimeStamp = dateFormat.format(cur_dt);

    if (ReportsPath == "") { // if results path is passed as null, by
      // default 'C:\' drive is used
      ReportsPath = "C:\\";
    }

    if (ReportsPath.endsWith("\\")) { // checks whether the path ends with
      // '/'
      ReportsPath = ReportsPath + "\\";
    }
    String[] TCNm = scriptName.split("\\.");
    //strResultPath = ReportsPath + "/" + TCNm[0] + "/";
    strResultPath = ReportsPath + "/" + testExecutionFunctionality + "/" + TCNm[0] + "/";
    // String htmlname = ReportsPath + "/" + TCNm[0] + "/" + strTimeStamp + ".html";
    detailHTMLReport = ReportsPath + "/" + testExecutionFunctionality + "/" + TCNm[0] + "/" + strTimeStamp + ".html";
    
    File f = new File(strResultPath);
    f.mkdirs();
    tdrObj.createDetailedRptHeader(TCNm[0]);


    //String scriptPath = TestScript + scriptName;
    String scriptPath = TestScript + packageName + ".xls";
    TScname = scriptName;
    int loopcount = 0;
    int startrow = 0;
    boolean isLoopStmtExist = false;
    FileInputStream fs1 = null;
    WorkbookSettings ws1 = null;
    fs1 = new FileInputStream(new File(scriptPath));
    ws1 = new WorkbookSettings();
    ws1.setLocale(new Locale("en", "EN"));
    Workbook TScworkbook = Workbook.getWorkbook(fs1, ws1);
 

    // Sheet TScsheet = TScworkbook.getSheet(0); ***Causes null pointer error in ifcondition
    // skipper*****
    TScsheet = TScworkbook.getSheet(0);
    TScrowcount = TScsheet.getRows();
    // *This is the Data Table Sheet-I think its test script sheet-Yuva
    rowcnt = 0;
    // try { //Moving this try below to catch stale exception and continue loop

  String testCaseRowMatch = "";

    keywordScriptForLoop: for (j = 1; j < TScrowcount; j++) {
    	//log("info", "Started Executing keyword:" + TScsheet.getCell(1, j).getContents()) ; 	

   
      if(((TScsheet.getCell(1, j).getContents()).equalsIgnoreCase(TScname) == true)) {
    	  
    	  testCaseRowMatch = "true";
    	  
    	  //log("info", "Test case begins at row: " + (j-1) );
    	  //break keywordScriptForLoop;
           // System.out.println("DEBUG:Entering  KeywordScript Loop No-" + j);
      // Thread.sleep(1000);

      rowcnt = rowcnt + 1;
      //String TSvalidate = "r";
      //if (((TScsheet.getCell(0, j).getContents()).equalsIgnoreCase(TSvalidate) == true)) {
      
      
      	Action = TScsheet.getCell(6, j).getContents(); // Keyword(E) from test script sheet.
      	cCellData = TScsheet.getCell(7, j).getContents(); // Data from test script sheet.
      	dCellData = TScsheet.getCell(5, j).getContents(); // Object from test script sheet.
      	eCellData = TScsheet.getCell(8, j).getContents(); // ProceedOnError  from test script sheet.
      	fCellData = TScsheet.getCell(4, j).getContents(); // Description from test script sheet.
      	
      	
      	String ORPath = ObjectRepository + "OR_SHARED.xls"; // this is shared repopsitory
      	
      	//log("info", "Executing step{" + Action + "}  {" + cCellData + "}  {" + dCellData + "}  {" + eCellData + "}");
        //Action = TScsheet.getCell(1, j).getContents(); // Keyword(B) from test script sheet.
        //cCellData = TScsheet.getCell(2, j).getContents(); // Object details(C) from test script
                                                          // sheet.
        //dCellData = TScsheet.getCell(3, j).getContents(); // Action (D) from test script sheet.
        //eCellData = TScsheet.getCell(4, j).getContents(); // Action2 (E) from test script sheet.
        //fCellData = TScsheet.getCell(5, j).getContents(); // Comments (F) from test script sheet.
        //String ORPath = ObjectRepository + "OR_SHARED.xls"; // this is shared repopsitory
        //String TSORPath = ObjectRepository + ScriptORName; // this is script specific repository
        FileInputStream fs2 = null;
        WorkbookSettings ws2 = null;
        fs2 = new FileInputStream(new File(ORPath));
        ws2 = new WorkbookSettings();
        ws2.setLocale(new Locale("en", "EN"));
        try {
          Workbook ORworkbook = Workbook.getWorkbook(fs2, ws2);
          ORsheet = ORworkbook.getSheet(0);
          ORrowcount = ORsheet.getRows();
          ActionVal = Action.toLowerCase();
          iflag = 0;

        } catch (Exception e) {
          System.out.println(e);
          // fail("Test Script Excel file is not correct.");
        }
        try {
        	
          // ***Moving this try to before keywordScriptForLoop will terminate loop on exception.
          log("info", "Executing step with Action {" + Action + "} with Data {" + cCellData + "} with Object {" + dCellData + "} and Proceeed on error {" + eCellData + "}");
          
          /*
          //update start
          if (cCellData.trim().contains("_"))
           {
        	 //cCellData = cCellData.trim() + ".xls";
          dataTableExcel =
              seleniumDir[0].replace("\\", "//") + "//ProjectFramework//TestData//TestData.xls"; //Need to take from Utility file
                 // + cCellData.trim();
          String[] cCellDataSplit = cCellData.trim().split("_",2);
          
          dataSheetName = cCellDataSplit[0];
          dataSheetColumnHeader=cCellDataSplit[1];
          
          log("info", "Data Sheet Name: {" + dataSheetName + "}  {" + dataSheetColumnHeader + "}");
          //System.out.println(cCellDataSplit[0]);
          //dataTableSheet = dCellData.trim();
          //tdrObj.Update_Report("executed");
          }
        	  
          //End
          */
          //reset the error description
          errorDesc = "";
          runTimeValue = "";
          if (fCellData.trim() == "")
            fCellData = agcObj.generateComments(Action, cCellData, dCellData);

          /*Fetch the object details
           *  from shared OR
           */
          String ObjectVal = "";
         
            ObjectVal = dCellData.trim();
          
           if(! ObjectVal.isEmpty()) { 
           String getObjectLocatorString = orObj.getObjectLocator(ObjectVal);

            if (getObjectLocatorString == null) {

              throw new Exception("ObjectLocatorNotFoundInOR");
            } else {

            if (getObjectLocatorString.contains("==") == false) {
              throw new Exception("SyntaxErrorInORLocator");
            }

            String[] objectLocatorDetails = getObjectLocatorString.split("==");
            ORvalname = objectLocatorDetails[0];
            ORvalue = objectLocatorDetails[1];
           }
           }
            
          switch (ActionVal) {
          
          //Keyword code begin..
          //##################################################################################################
          
          case "launchapp":
              //if (cCellData.trim().startsWith("http") == false
              //    && cCellData.trim().startsWith("file://") == false)
              //  cCellData = "http://" + cCellData.trim();
              D8.get(dtObj.getDataTableValueFor(cCellData));
              
              /*
              if(testRunLanguage.equalsIgnoreCase("FRE")) {
            	  D8.findElement(By.linkText("Canada-French")).click();
            	  
            	  WebElement frenchLoginButtonLoaded =
                  new WebDriverWait(D8, Integer.parseInt("30"))
                      .until(ExpectedConditions.visibilityOfElementLocated(By
                          .linkText("Ouverture de session")));
            	  
            	  if(frenchLoginButtonLoaded.isDisplayed()) {
            		  log("info", "French Page loaded successfully");
            	  } else {
            		  tdrObj.Update_Report("failed" + "Prt_Msg" + "French  Page did not load in 30 secs..");
            		  break;
            	  }
              }
              */
              tdrObj.Update_Report("executed");
              break;

          case "set":
      
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
              // elem.focus();
              elem.clear();
              elem.sendKeys(dtObj.getDataTableValueFor(cCellData)); 
              tdrObj.Update_Report("executed");
              if (captureperform == true) {
                ssObj.screenshot(loopnum, TScrowcount, TScname);
              }
              break;
              
          case "setwithoutclear":
              
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
              // elem.focus();
            
              elem.sendKeys(dtObj.getDataTableValueFor(cCellData)); 
              tdrObj.Update_Report("executed");
              if (captureperform == true) {
                ssObj.screenshot(loopnum, TScrowcount, TScname);
              }
              break;
              
case "setbackspace":
              
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
              // elem.focus();
        	  elem.sendKeys(Keys.BACK_SPACE);
             
              tdrObj.Update_Report("executed");
              if (captureperform == true) {
                ssObj.screenshot(loopnum, TScrowcount, TScname);
              }
              break;
              
case "setenter":
    
	  fEObj.Func_FindObj(ORvalname, ORvalue);
    // elem.focus();
	  elem.sendKeys(Keys.ENTER);
   
    tdrObj.Update_Report("executed");
    if (captureperform == true) {
      ssObj.screenshot(loopnum, TScrowcount, TScname);
    }
    break;
        
              
          case "setkey":
              
        	//  fEObj.Func_FindObj(ORvalname, ORvalue);
              // elem.focus();
              //elem.clear();
        	  
        	  String data=dtObj.getDataTableValueFor(cCellData);
        	  
        	  JavascriptExecutor executor = (JavascriptExecutor)D8;
        	    executor.executeScript("document.getElementById('key').value = '"+data+"';");
        	 
              //elem.sendKeys(Keys.TAB); 
              tdrObj.Update_Report("executed");
              if (captureperform == true) {
                ssObj.screenshot(loopnum, TScrowcount, TScname);
              }
              break;

          case "click":
        	
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	  elem.click();
              tdrObj.Update_Report("executed");
              if (captureperform == true) {
                ssObj.screenshot(loopnum, TScrowcount, TScname);
              }
              break;

              
          case "clickbutton":
          	
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	  elem.click();
              tdrObj.Update_Report("executed");
              if (captureperform == true) {
                ssObj.screenshot(loopnum, TScrowcount, TScname);
              }
              break;
              
          case "submit":
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	  elem.submit();
              tdrObj.Update_Report("executed");
              if (captureperform == true) {
                ssObj.screenshot(loopnum, TScrowcount, TScname);
              }
              break;

          case "select":
        	  
        	  if(! ORvalname.equalsIgnoreCase("css")) {
        		 throw new Exception("For consistent behaviour please use CSS selctor."); 
        	  }
        	  
        	  String valueToSelect = dtObj.getDataTableValueFor(cCellData.trim());
        	  if(krfObj.selectOptionFromDropdown(ORvalue, valueToSelect)) {
        		  tdrObj.Update_Report("executed");
              }
        	  else {
        		  testStatus = "FAIL";
                  tdrObj.Update_Report("failed" + "Prt_Msg" + "Unable to select the value {" + valueToSelect +"} from dropdown."); 
        	  }
             
              if (captureperform == true) {
                ssObj.screenshot(loopnum, TScrowcount, TScname);
              }

              break;

          case "verifytext":
        	  String expText = dtObj.getDataTableValueFor(cCellData).trim();
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	  String actText = elem.getText().trim();
             
        	  if (expText.equalsIgnoreCase(actText)) {
                  log("info", "Actual value matches with expected value. Actual value is: " + actText);
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "Actual value doesn't match with expected value. Actual value is: " + actText
                      + " Expected : " + expText);
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Actual value is:" + actText);
                  }
                  if (capturecheckvalue == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                }
              
              break;

          case "verifyvalue":
        	  String expval = dtObj.getDataTableValueFor(cCellData).trim();
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	  String actval = new Select(elem).getFirstSelectedOption().getText().toString().trim();
             
        	  if (expval.equalsIgnoreCase(actval)) {
                  log("info", "Actual value matches with expected value. Actual value is: " + actval);
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "Actual value doesn't match with expected value. Actual value is: " + actval
                      + " Expected : " + expval);
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Actual value is:" + actval);
                  }
                  if (capturecheckvalue == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                }
              break;

          case "checkvisibility":
        	  String expVisibility = dtObj.getDataTableValueFor(cCellData); 
        	  
        	  String actVisibility = "";
        	  boolean actVisibilityTemp ;
        	  
        	  if(expVisibility.equalsIgnoreCase("false")) {
        		   int noOfElements = fEObj.getElementCount(ORvalname, ORvalue);
        		   
        		   if(noOfElements > 0) {
        			   fEObj.Func_FindObj(ORvalname, ORvalue);
                 	   actVisibilityTemp = elem.isDisplayed();
        		   } else {
        		   actVisibilityTemp = false ;
        		   }
        		   
        		   actVisibility =String.valueOf(actVisibilityTemp); 
        	 
        	  } else {
        		   fEObj.Func_FindObj(ORvalname, ORvalue);
             	   actVisibilityTemp = elem.isDisplayed();
            	   actVisibility =String.valueOf(actVisibilityTemp);  
        	  }
        	  
             
        	  if (expVisibility.equalsIgnoreCase(actVisibility)) {
                  log("info", "Actual value matches with expected value. Actual value is: " + actVisibility);
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "Actual value doesn't match with expected value. Actual value is: " + actVisibility
                      + " Expected : " + expVisibility);
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Actual value is:" + actVisibility);
                  }
                  if (capturecheckvalue == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                }
              break;

          case "waittillvisible":
        	  WebElement elementVisible = null;
        	  
        	  String timout = cCellData;

              if (ORvalname.equalsIgnoreCase("id")) {
                elementVisible =
                    new WebDriverWait(D8, Integer.parseInt(timout))
                        .until(ExpectedConditions.visibilityOfElementLocated(By.id(ORvalue)));
              } else if (ORvalname.equalsIgnoreCase("name")) {
                elementVisible =
                    new WebDriverWait(D8, Integer.parseInt(timout))
                        .until(ExpectedConditions.visibilityOfElementLocated(By.name(ORvalue)));
              } else if (ORvalname.equalsIgnoreCase("xpath")) {
                elementVisible =
                    new WebDriverWait(D8, Integer.parseInt(timout))
                        .until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ORvalue)));
              } else if (ORvalname.equalsIgnoreCase("link")) {
                elementVisible =
                    new WebDriverWait(D8, Integer.parseInt(timout))
                        .until(ExpectedConditions.visibilityOfElementLocated(By
                            .linkText(ORvalue)));
              } else if (ORvalname.equalsIgnoreCase("partiallink")) {
                elementVisible =
                    new WebDriverWait(D8, Integer.parseInt(timout))
                        .until(ExpectedConditions.visibilityOfElementLocated(By
                            .partialLinkText(ORvalue)));
              } else if (ORvalname.equalsIgnoreCase("css")) {
                elementVisible =
                    new WebDriverWait(D8, Integer.parseInt(timout))
                        .until(ExpectedConditions.visibilityOfElementLocated(By
                            .cssSelector(ORvalue)));
              } else if (ORvalname.equalsIgnoreCase("class")) {
                elementVisible =
                    new WebDriverWait(D8, Integer.parseInt(timout))
                        .until(ExpectedConditions.visibilityOfElementLocated(By
                            .className(ORvalue)));
              } else if (ORvalname.equalsIgnoreCase("tag")) {
                elementVisible =
                    new WebDriverWait(D8, Integer.parseInt(timout))
                        .until(ExpectedConditions.visibilityOfElementLocated(By
                            .tagName(ORvalue)));
              }



              if (elementVisible != null) {
                tdrObj.Update_Report("executed");
              } else {
                testStatus = "FAIL";
                tdrObj.Update_Report("failed" + "Prt_Msg"
                    + "Element was not visible till the specified time.");

              }
              if (captureperform == true) {
                ssObj.screenshot(loopnum, TScrowcount, TScname);
              }
              break;
             
          case "takescreenshot":
              ssObj.screenshot(loopnum, TScrowcount, TScname);
              tdrObj.Update_Report("takescreenshot");
              break;
              
              
          case "logincredentials":
        	  String preRequisite = dtObj.getDataTableValueFor(cCellData).trim();
          	
        	    boolean dbResult = cuskeyObj.DBConnection(preRequisite);
        	  if (dbResult) {
        		  log("info", "Open DB connectiion set properly");
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "Open DB connectiion set properly");
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "DB Connection not set properly");
                  }
                  if (capturecheckvalue == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                }
        	  
        	  break;
        	  
          case "logincredentialstraining":
        	  String preRequisite2 = dtObj.getDataTableValueFor(cCellData).trim();
          	
        	    boolean dbResult2 = cuskeyObj.DBConnectionTraining(preRequisite2);
        	    		if (dbResult2) {
        		  log("info", "Open DB connectiion set properly");
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "Open DB connectiion set properly");
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "DB Connection not set properly");
                  }
                  if (capturecheckvalue == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                }
        	  
        	  break;
        	  
          case "setnewuserid":
        	  String preRequisite1 = dtObj.getDataTableValueFor(cCellData).trim();
          	
        	    boolean dbResult1 = cuskeyObj.setNewUserID(preRequisite1);
        	  if (dbResult1) {
        		  log("info", "Open DB connectiion set properly");
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "Open DB connectiion set properly");
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "DB Connection not set properly");
                  }
                  if (capturecheckvalue == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                }
        	  
        	  break;
          
          case "takescreenshotofelement":
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	  ((JavascriptExecutor) D8).executeScript("arguments[0].scrollIntoView(true);", elem);
        	  ssObj.screenshot(loopnum, TScrowcount, TScname);
              tdrObj.Update_Report("takescreenshot");
              break;
              
          case "selectdate":
        	  
        	  String dateToSelect = dtObj.getDataTableValueFor(cCellData).trim(); 
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	  elem.click();
        	 
        	  if (cuskeyObj.datePicker(dateToSelect)) {
                  log("info", "Date selected successfully from date picker. ");
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "Date NOT selected from date picker.");
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Unable to select the date from picker.");
                  }
                  if (capturecheckvalue == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                }
              break;
              
        
          case "tablesort":
        	  String tableXpath = ORvalue;
        	  String columnName = dtObj.getDataTableValueFor(cCellData);
        	  boolean sortResult = cuskeyObj.tableSort(tableXpath, columnName);
        	  
        	  if (sortResult) {
                  log("info", "Table is sorted correctly.");
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "Table is NOT sorted correctly");
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Table column is not sorted.");
                  }
                  if (capturecheckvalue == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                }
        	  
        	  break;
        	
          case "verifycolor": 
               String expColor = dtObj.getDataTableValueFor(cCellData);
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	  log("debug", "getCssValue for background-color:" + elem.getCssValue("background-color"));
        	  
        	  String elemColor = elem.getCssValue("background-color");
        	
        	  String hexColor[];  
				// Converting RGB color value  to Hexadecimal color value
				//hexColor = elemColor.replace("rgba(", "").split(",");  
				hexColor = elemColor.replace("rgb", "").replace("a","").replace("(","").replace(")","").split(",");  
				
				String actColor = String.format("#%02x%02x%02x", Integer.parseInt(hexColor[0].trim()), Integer.parseInt(hexColor[1].trim()), Integer.parseInt(hexColor[2].trim()));  
			
				 if (actColor.equalsIgnoreCase(expColor)) {
	                  log("info", "Actual value matches with expected value. Actual value is: " + actColor);
	                  tdrObj.Update_Report("executed");
	                } else {
	                  log("info", "Actual value doesn't match with expected value. Actual value is: " + actColor
	                      + " Expected : " + expColor);
	                  if (ORvalname == "exit") {
	                    tdrObj.Update_Report("missing");
	                  } else {
	                    testStatus = "FAIL";
	                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Actual value is:" + actColor);
	                  }
	                  if (capturecheckvalue == true) {
	                    ssObj.screenshot(loopnum, TScrowcount, TScname);
	                  }
	                }
        	  break;
        	 
          case "checkcurrency":
        	  String expCurrency = dtObj.getDataTableValueFor(cCellData);
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	  String actualCurrency = elem.getText();
        	  
        	  if (actualCurrency.endsWith(expCurrency)) {
                  log("info", "Actual value matches with expected value. Actual value is: " + actualCurrency);
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "Actual value doesn't match with expected value. Actual value is: " + actualCurrency
                      + " Expected : " + expCurrency);
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Actual value is:" + actualCurrency);
                  }
                  if (capturecheckvalue == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                }
        	 
        	  break;
        	  
          case "checkbox":
        	 
        	  String expAction = dtObj.getDataTableValueFor(cCellData);
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	  
        	  log("debug", "Checkbox element current display state:" + elem.isDisplayed());  
        	  log("debug", "Checkbox element current enable state:" + elem.isEnabled()); 
        	  
        	  //App specific code..
        	  try{
        	  if(dCellData.equalsIgnoreCase("chk_Login_RememberMe")) {	 
        		  log("debug", "Performing app specfic action for checkbox:" + dCellData);  
        	  WebElement temp = D8.findElement(By.cssSelector("label[for='remember_me']"));
        	  temp.click();
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	  if(! elem.isSelected() & expAction.equalsIgnoreCase("select")) {
        		  temp.click();
        	  }
        	  
        	  if( elem.isSelected() & expAction.equalsIgnoreCase("unselect")) {
        		  temp.click();
        	  }
        	  //Actions tempAct = new Actions(D8);
        	  //tempAct.doubleClick(temp).build().perform();
        	  Thread.sleep(500);
        	  }
        	  } catch(Exception e) {
        		  log("error", "Exception caught in checkbox keyword.This is app specific code:" + e.getMessage());
        	  }
        	  
        	 
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	  boolean value=elem.isSelected();
        	
        	  log("info","is checkbox selected ? " + value);
        	     if(expAction.equalsIgnoreCase("select")) {
        		 if(elem.isSelected()){
        			 log("info","Element is already selected. Not performing any action.");
        		 } else {
        			 log("info","Element is NOT  selected. Trying to select.");
        		     elem.click();	 
        		 }
        	  
        	  } else if(expAction.equalsIgnoreCase("unselect")){
        		 
        		  if(elem.isSelected()){
        			  log("info","Element is already selected. Trying to unselect...");
        			  elem.click();	 
         			 
         		 } else {
         			log("info","Element is unselected. Not performing any action.");
         		 }
        		  
        	  }
        	  
        	  tdrObj.Update_Report("executed");
              if (captureperform == true) {
                ssObj.screenshot(loopnum, TScrowcount, TScname);
              }
        	  
        	  break;
         
          case "ischecked":
        	  String expState = dtObj.getDataTableValueFor(cCellData);
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	  boolean actStateTemp = elem.isDisplayed();
        	  String actState =String.valueOf(actStateTemp);
        	  
        	  if (expState.equalsIgnoreCase(actState)) {
                  log("info", "Actual value matches with expected value. Actual value is: " + actState);
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "Actual value doesn't match with expected value. Actual value is: " + actState
                      + " Expected : " + actState);
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Actual value is:" + actState);
                  }
                  if (capturecheckvalue == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                }
        	 
        	  break;
        	  	  
          case "verifymaskeduserid":
        	  String expUserID = dtObj.getDataTableValueFor(cCellData).trim();
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	  String actUserID = elem.getAttribute("value").trim();
        	  
        	  if (expUserID.endsWith(actUserID.replace("*", ""))) {
                  log("info", "Actual User ID is masked correctly. Actual value is: " + actUserID);
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "Actual User ID is NOT masked correctly. Actual value is: " + actUserID
                      + " Expected : " + expUserID);
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Actual User ID value is:" + actUserID);
                  }
                  if (capturecheckvalue == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                }
        	 
        	  break;
        	  
          case "verifymaskedtextfield":
        	 
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        //	  String actTextField = elem.getAttribute("value").trim();
        	  boolean isMasked= elem.getAttribute("type").equals("password");
        	  
        	  if (isMasked==true) {
                  log("info", "Actual Text field is masked correctly. Actual value is: " + isMasked);
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "Actual Text Field is NOT masked correctly. Actual value is: " + isMasked);
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Actual Text Field value is:" + isMasked);
                  }
                  if (capturecheckvalue == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                }
        	 
        	  break;
        	
        	
          case "switchtowindow":
        	  
        	  String switchToWindow = dtObj.getDataTableValueFor(cCellData).toLowerCase().trim();
              if (switchToWindow.equalsIgnoreCase("parentwindow")) {
                log("info", "Driver switched to ParentWindow- "
                    + D8.switchTo().window(parentWindow).getTitle());
              }

              else {
            	krfObj.waitForPopUpToAppear(20);  
                D8.getWindowHandle();
                Set<String> pops = D8.getWindowHandles();
                log("info", "Window handlers size:" + pops.size());
                
                Iterator<String> it = pops.iterator();
                boolean exitWhile = false;
                while (it.hasNext() & exitWhile == false) {
                  String popupHandle = it.next().toString();
                  // if(!popupHandle.contains(parent)){
                  String windowTitle = D8.switchTo().window(popupHandle).getTitle().toLowerCase();
               D8.manage().window().maximize();
                  if(windowTitle.trim().contains(switchToWindow)) {
                     exitWhile = true;
                  }
                  
                  log("info", "Driver switched to window with Title :" +  windowTitle);
                  // D8.switchTo().window(popupHandle);
                  // System.out.println("DEBUG:Pop Up Title- "+ popupHandle);
                  // }
                }
              }
              tdrObj.Update_Report("executed");
              break;
              
              
          
              
case "switchtowindowie":
        	  
        	  String switchToWindowie = dtObj.getDataTableValueFor(cCellData).toLowerCase().trim();
//              if (switchToWindowie.equalsIgnoreCase("parentwindow")) {
//                log("info", "Driver switched to ParentWindow- "
//                    + D8.switchTo().window(parentWindow).getTitle());
//                System.out.println("Parent window title"+D8.getTitle());
//              }
//
//              else {
        	  if(true){
        		 
            	krfObj.waitForPopUpToAppear(20);  
                D8.getWindowHandle();
                Set<String> pops = D8.getWindowHandles();
                log("info", "Window handlers size:" + pops.size());
                
                Iterator<String> it = pops.iterator();
                boolean exitWhile = false;
                while (it.hasNext() & exitWhile == false) {
                  String popupHandle = it.next().toString();
                  // if(!popupHandle.contains(parent)){
                  String windowTitle = D8.switchTo().window(popupHandle).getTitle().toLowerCase();
                  if (switchToWindowie.equalsIgnoreCase("parentwindow"))
        		  {
        			  windowTitle+="Parent Window :";
        			  exitWhile = true;
        		  }
                  
                  if(windowTitle.trim().contains(switchToWindowie)) {
                     exitWhile = true;
                  }
                  
                  log("info", "Driver switched to window with Title :" +  windowTitle);
                  // D8.switchTo().window(popupHandle);
                  // System.out.println("DEBUG:Pop Up Title- "+ popupHandle);
                  // }
                }
              }
              tdrObj.Update_Report("executed");
              break;
        	  
          case "wait":
              Thread.sleep(Long.parseLong(cCellData) * 1000);
              // tdrObj.Update_Report("executed");
              break;
          

        	  
          case "checkpdfdisplayed":
        	    String expPDFUrlPart = dtObj.getDataTableValueFor(cCellData).trim();
              	 krfObj.waitForPopUpToAppear(20);  
                  Set<String> pops = D8.getWindowHandles();
                  log("info", "Window handlers size:" + pops.size());
                  
                  Iterator<String> it = pops.iterator();
                  boolean pdfFound = false;
                  while (it.hasNext() & pdfFound == false) {
                    String popupHandle = it.next().toString();
                    log("debug","POPUP HANDLE VALUE" +popupHandle);
                    log("debug","Window title before waiting for the page to load:" + D8.switchTo().window(popupHandle).getTitle());
                    krfObj.waitForPageToLoad(30);
                    String windowTitle =  D8.switchTo().window(popupHandle).getTitle().toLowerCase();
                    String windowUrl =  D8.switchTo().window(popupHandle).getCurrentUrl().toLowerCase();
                    log("debug","Window title after waiting for the page to load:" + windowTitle);
                    log("debug","Window url after waiting for the page to load:" + windowUrl);
                    
                    if(windowUrl.contains(expPDFUrlPart)) {
                    	log("info", "Driver switched to window with Title :" +  windowTitle);
                    	log("info", "Current window URL:" +  windowUrl);
                    	log("info", "Make sure to switch to parent window to perform further actions on it!");
                    	pdfFound = true;
                    }
                  }
                  log("info", "PDF Found value"+pdfFound);
              	
                if(pdfFound)  { 
                tdrObj.Update_Report("executed");
                }
                else {
                tdrObj.Update_Report("failed" + "Prt_Msg" + "PDF did not load properly.");	
                }
                break;
         
          case "checkpdfprint":
        	  Actions builder = new Actions(D8);
        	  
        	  builder.contextClick().build().perform();
        	  cwpObj.isWindowPresentWithTitle("Print", 30);
        	  tdrObj.Update_Report("skipped");
        	  break;
        	  
          case "checkpdfdownload":
        	  Actions builder1 = new Actions(D8);
        	  
        	  builder1.contextClick().sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.RETURN).build().perform();
        	  cwpObj.isWindowPresentWithTitle("Save As", 30);
        	  tdrObj.Update_Report("skipped");
        	  break;
        	  
          case "downloadfile":
        	  tdrObj.Update_Report("skipped");
        	  break;
        	  
          case "verifypdfcontent":
        	  pdfutilObj.verifyPDFContent(D8.getCurrentUrl(), "Sometext");
        	  tdrObj.Update_Report("skipped");
        	  break;
        
          case "verifypagecontent":

        	  String contentToCheck =  dtObj.getDataTableValueFor(cCellData).trim();
        	  
              if (D8.findElement(By.tagName("HTML")).getText().contains(contentToCheck)) {
            	  log("info", "Page contains the text:" + contentToCheck);
                tdrObj.Update_Report("executed");
              }

              else if (D8.findElements(By.xpath("//*[contains(text(), '" + contentToCheck
                  + "')]")).size() > 0) {
            	  log("info", "Page contains the text:" + contentToCheck);
                tdrObj.Update_Report("executed");
              }

              else {
            	  
            	  testStatus = "FAIL";
            	  log("error", "Page does NOT contains the text:" + contentToCheck);
               
            	  tdrObj.Update_Report("failed" + "Prt_Msg"
                    + "Page does not contain the text:" + contentToCheck );
                
              }

              break;
              
              
          case "enternicknameforacct":
        	  String acctAndNickName[] =  dtObj.getDataTableValueFor(cCellData).trim().split(":");
        	  
        	  if(acctAndNickName.length < 2) {
        		  log("error", "Data for this keyword should be format as accountno:nickname");
        	  }
        	  
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	  
        	  if (cuskeyObj.nickNameEntry(acctAndNickName[0],acctAndNickName[1])) {
                  log("info", "Nick name entered for account no:  " + acctAndNickName[0]);
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "Nick name NOT entered for account no:  " + acctAndNickName[0]);
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Nick name NOT entered for account no:  " + acctAndNickName[0]);
                  }
                }
        	   
              break;
              
          case "verifymarketmovertablesort":
        	  String sortByValue =  dtObj.getDataTableValueFor(cCellData).trim();
        	 
        	  if (cuskeyObj.isMarketMoverTableSorted(sortByValue)) {
                  log("info", "Market mover table is sorted corectly by value " + sortByValue);
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "Market mover table is NOT sorted corectly by value" + sortByValue);
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Market mover table is NOT sorted corectly by value" + sortByValue);
                  }
                }
        	  
        	  
              break;
              
          case "closenewwindow":
             // fEObj.Func_FindObj(ORvalname, ORvalue);
               	  
               	//  String newwindowtitle =  dtObj.getDataTableValueFor(cCellData).trim();
        	  D8.close();
                
               	  //if (cuskeyObj.closenewwindow()) {
               		//
                         log("info", "close new window passed" );
                         
                      // } else {
                        // log("info", "close new window failed");
                          //if (ORvalname == "exit") {
                           //tdrObj.Update_Report("missing");
                         //} else {
                           //testStatus = "FAIL";
                           //tdrObj.Update_Report("failed" + "Prt_Msg" + "Unable to close the new window");
                        // }
             //          }
                         break;
              
          case "opennewwindow":
       fEObj.Func_FindObj(ORvalname, ORvalue);
        	  
        	  String newwindowtitle =  dtObj.getDataTableValueFor(cCellData).trim();
         	 
        	  if (cuskeyObj.opennewwindow(elem, newwindowtitle)) {
        		
                  log("info", "New window passed" + newwindowtitle);
                  
                } else {
                  log("info", "New Window failed");
                  log("info", "New window failed" + newwindowtitle);
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Unable to open the new window");
                  }
                }
          break;
          case "switchto":
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	  String parentHandle=D8.getWindowHandle();
        	  elem.click();
        	  Thread.sleep(2000);
        	  String newwindow=D8.getWindowHandle();
        	  D8.switchTo().window(newwindow);
        	 // Thread.sleep(2000);
              tdrObj.Update_Report("Passed" + "Prt_Msg" + "Scrrenshot for Test Evidence");
              
              D8.close();
              D8.switchTo().window(parentHandle);
              break;
         
          case "securitycheck":
        	 
        	  if (cuskeyObj.securitycheck()) {
                  log("info", "security check passed");
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "Security check failed");
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Security Check link not selected");
                  }
                }
        	  
        	  
              break;
              
          case "verifyemptytextbox":
        	  
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	  
        	  if (elem.getAttribute("value").equalsIgnoreCase("")) {
                  log("info", "Text box is empty for ");
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "Text box is not empty");
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Text box is not empty");
                  }
                }
        	   
              break;
           
          case "verifytextboxvalue":
        	  
        	  String expTextBoxValue = dtObj.getDataTableValueFor(cCellData).trim();
        	  
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	  
        	  if (elem.getAttribute("value").equalsIgnoreCase(expTextBoxValue)) {
                  log("info", "Text box value is correct.");
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "Text box Actual value{" + elem.getAttribute("value") +"} did not match the expected value {" +expTextBoxValue+ "}");
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Text box Actual value{" + elem.getAttribute("value") +"} did not match the expected value {" +expTextBoxValue+ "}");
                  }
                }
        	   
              break;    
              
          case "authenticatedialog":
        	  String credentials[] =  dtObj.getDataTableValueFor(cCellData).trim().split(":");
        	  
              if (krfObj.isModalDialogShowing()) {
                raObj.copyAndPaste(credentials[0]);
                Thread.sleep(500);
                raObj.robotSendKey("TAB");
                Thread.sleep(500);
                raObj.copyAndPaste(credentials[1]);
                Thread.sleep(500);
                raObj.robotSendKey("ENTER");
                tdrObj.Update_Report("executed");
              } else {
                tdrObj.Update_Report("executed" + "Prt_Msg"
                    + "WARNING! Authentication Dialog was not present.");
              }
              break;
                            
          case "verifypagedoesnotcontain":

        	  String contentToCheck1 =  dtObj.getDataTableValueFor(cCellData).trim();
              
        	 if (D8.findElements(By.xpath("//*[contains(text(), '" + contentToCheck1
                  + "')]")).size() == 0) {
        		 log("info", "Page does contains the text:" + contentToCheck1); 
                tdrObj.Update_Report("executed");
              }

              else {
            	  log("error", "Page contains the text:" + contentToCheck1); 
            	  
            	  testStatus = "FAIL";
            	  
            			  
            	  tdrObj.Update_Report("failed" + "Prt_Msg"
                    + "Page contains the text:" + contentToCheck1 + " in the tag " + D8.findElement(By.xpath("//*[contains(text(), '" + contentToCheck1
                            + "')]")).getTagName());
                
                 
              }

              break;  
          case "comparebalance":
        	  boolean compareBalanceResult = cuskeyObj.compareBalance();
        	  if (compareBalanceResult) {
                  log("info", "Total Cost and Total Market Value are different.");
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "Total Cost and Total Market Value are NOT different");
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Total Cost and Total Market Value are NOT different.");
                  }
                  if (capturecheckvalue == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                }
        	  
        	  break;
          case "clickifvisible":
          	
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	  if(elem.isDisplayed())
        	  {
        		  elem.click();
        		  tdrObj.Update_Report("executed");
        	  }else
        	  {
        		  log("info", "Element is not visible."); 
        	  }
              
              if (captureperform == true) {
                ssObj.screenshot(loopnum, TScrowcount, TScname);
              }
              break;
              
          case "storevalue":
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	  String[] variableValueType = cCellData.trim().split(":");
        	  stValObj.storeValueInVarible(variableValueType[1], variableValueType[0]);
        	 // tdrObj.Update_Report("executed");
        	  break;
        	  
          case "comparevaluesaresame":
        	  String[] compareVars = cCellData.trim().split(":");
        	  
        	  if(compareVars[0].startsWith("#") ) {
        		  compareVars[0] = map.get(compareVars[0].replace("#", ""));
        	  }else
        	  {
        		  compareVars[0] = dtObj.getDataTableValueFor(compareVars[0]).trim();
        	  }
        	  if(compareVars[1].startsWith("#") ) {
        		  compareVars[1] = map.get(compareVars[1].replace("#", ""));
        	  }else
        	  {
        		  compareVars[1] = dtObj.getDataTableValueFor(compareVars[1]).trim();
        	  }
        	  
        	  if (compareVars[0].equals(compareVars[1])) {
                  log("info", "Two variable values are same.");
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "Two variable values are different {" + compareVars[0] + "}{" + compareVars[1] + "}");
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Two variable values are different {" + compareVars[0] + "}{" + compareVars[1] + "}");
                  }
                  if (capturecheckvalue == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                }
        	  
        	  break;
        	
          case "comparevaluesaredifferent":
        	 // String[] compareVarsDiff = cCellData.trim().split(":");
        	 
        	  String[] compareVarsDiff = cCellData.trim().split(":");
         	 
//        	  String[] compareVarsDiff =  dtObj.getDataTableValueFor(cCellData).trim().split(":");
        	  if(compareVarsDiff[0].startsWith("#") ) {
        		  compareVarsDiff[0] = map.get(compareVarsDiff[0].replace("#", ""));
        	  }else
        	  {
        		  compareVarsDiff[0] = dtObj.getDataTableValueFor(compareVarsDiff[0]).trim();
        	  }
        	  if(compareVarsDiff[1].startsWith("#") ) {
        		  compareVarsDiff[1] = map.get(compareVarsDiff[1].replace("#", ""));
        	  }else
        	  {
        		  compareVarsDiff[1] = dtObj.getDataTableValueFor(compareVarsDiff[1]).trim();
        	  }
        	  
        	  if (! compareVarsDiff[0].equals(compareVarsDiff[1])) {
                  log("info", "Two variable values are different.");
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "Two variable values are NOT different {" + compareVarsDiff[0] + "}{" + compareVarsDiff[1] + "}");
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Two variable values are NOT different {" + compareVarsDiff[0] + "}{" + compareVarsDiff[1] + "}");
                  }
                  if (capturecheckvalue == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                }
        	  
        	  break;
          case "stringcontains":
        	  String[] valueCheck = cCellData.trim().split(":");
        	  
        	  if(valueCheck[0].startsWith("#") ) {
        		  valueCheck[0] = map.get(valueCheck[0].replace("#", ""));
        	  }else
        	  {
        		  valueCheck[0] = dtObj.getDataTableValueFor(valueCheck[0]).trim();
        	  }
        	  if(valueCheck[1].startsWith("#") ) {
        		  valueCheck[1] = map.get(valueCheck[1].replace("#", ""));
        	  }else
        	  {
        		  valueCheck[1] = dtObj.getDataTableValueFor(valueCheck[1]).trim();
        	  }
        	  
        	  if (valueCheck[0].contains(valueCheck[1])) {
                  log("info", "string contains the specified sequence of char values");
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "string does not contain the specified sequence of char value {" + valueCheck[0] + "}{" + valueCheck[1] + "}");
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "string does not contain the specified sequence of char value {" + valueCheck[0] + "}{" + valueCheck[1] + "}");
                  }
                  if (capturecheckvalue == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                }
        	  break;
          case "positioncheck":
        	  String[] positionCheck = cCellData.trim().split(":");
        	  int firstElementPosition;
        	  int secondElementPosition;
        	  if(positionCheck[0].startsWith("#") ) {
        		  positionCheck[0] = map.get(positionCheck[0].replace("#", ""));
        		  firstElementPosition = Integer.parseInt(positionCheck[0]);
        	  }else
        	  {
        		  positionCheck[0] = dtObj.getDataTableValueFor(positionCheck[0]).trim();
        		  firstElementPosition = Integer.parseInt(positionCheck[0]);
        	  }
        	  if(positionCheck[1].startsWith("#") ) {
        		  positionCheck[1] = map.get(positionCheck[1].replace("#", ""));
        		  secondElementPosition = Integer.parseInt(positionCheck[1]);
        	  }else
        	  {
        		  positionCheck[1] = dtObj.getDataTableValueFor(positionCheck[1]).trim();
        		  secondElementPosition = Integer.parseInt(positionCheck[1]);
        	  }
        	  
        	  if (firstElementPosition<secondElementPosition) {
                  log("info", "Element is located correctly ");
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "Element is not positioned correctly {" + firstElementPosition + "}{" + secondElementPosition + "}");
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Element is not positioned correctly {" + firstElementPosition + "}{" + secondElementPosition + "}");
                  }
                  if (capturecheckvalue == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                }
        	  break;
          case "clickaccount":
          	  String accountNumber= dtObj.getDataTableValueFor(cCellData).trim();
          	log("info", "Account Number"+accountNumber);
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	  elem.findElement(By.linkText(accountNumber)).click();
        	  tdrObj.Update_Report("executed");
              if (captureperform == true) {
                ssObj.screenshot(loopnum, TScrowcount, TScname);
              }
              break; 
          case "actiondate": 
        	     if (cuskeyObj.actionDate()) {
                  log("info", "Todays date is displayed");
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "Todays date is NOT displayed ");
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Unable to verify Todays date.");
                  }
                  if (capturecheckvalue == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                }
        	  break;
        	  
          case "updateondateformat": 
        	  
        	  String xpathValue = ORvalue;
        	 
        	 	     if (cuskeyObj.updateonDate(xpathValue)) {
               log("info", "success -> Update On Date Format");
               tdrObj.Update_Report("executed");
             } else {
            	 log("info", "failure -> Update On Date Format");
               if (ORvalname == "exit") {
                 tdrObj.Update_Report("missing");
               } else {
                 testStatus = "FAIL";
                 tdrObj.Update_Report("failed" + "Prt_Msg" + "Update On Date is Not displayed in MMM DD, YYYY Format");
               }
               if (capturecheckvalue == true) {
                 ssObj.screenshot(loopnum, TScrowcount, TScname);
               }
             }
     	  break;
     	  
case "updateontodaydateformat": 
        	  
        	  String xpathValue1 = ORvalue;
        	 
        	 	     if (cuskeyObj.updateonDate(xpathValue1)) {
               log("info", "success -> Update On Today Date Format");
               tdrObj.Update_Report("executed");
             } else {
            	 log("info", "failure -> Update On Today Date Format");
               if (ORvalname == "exit") {
                 tdrObj.Update_Report("missing");
               } else {
                 testStatus = "FAIL";
                 tdrObj.Update_Report("failed" + "Prt_Msg" + "Update On Date field (Todays Date) is Not displayed in MMM DD, YYYY Format");
               }
               if (capturecheckvalue == true) {
                 ssObj.screenshot(loopnum, TScrowcount, TScname);
               }
             }
     	  break;
     	  
        	  
          case "languagecheck":
        	  log("info", "inside language case");
        	  boolean languageCheckResult = cuskeyObj.languageCheck();
        	  if (languageCheckResult) {
                  log("info", "Language Settings check - Success");
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "Language Settings check - Failed");
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Language Settings Mismatch");
                    
                  }
                  if (capturecheckvalue == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                }
        	  
        	  break;
          case "changelanguage":
        	  boolean changeLanguageResult = cuskeyObj.changeLanguage();
        	  if (changeLanguageResult) {
                  log("info", "Language Settings change - Success");
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "Language Settings change - Failed");
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Language Settings Change cannot be performed");
                  }
                  if (capturecheckvalue == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                }
        	  
        	  break;
        	  
          case "radiocomparevalues":
        	  String[] radioCompareVars = cCellData.trim().split(":");
        	  
        	  if(radioCompareVars[0].startsWith("#") ) {
        		  radioCompareVars[0] = map.get(radioCompareVars[0].replace("#", ""));
        	  }else
        	  {
        		  radioCompareVars[0] = dtObj.getDataTableValueFor(radioCompareVars[0]).trim();
        	  }
        	  if(radioCompareVars[1].startsWith("#") ) {
        		  radioCompareVars[1] = map.get(radioCompareVars[1].replace("#", ""));
        	  }else
        	  {
        		  radioCompareVars[1] = dtObj.getDataTableValueFor(radioCompareVars[1]).trim();
        	  }
        	  
        	  if (radioCompareVars[0].equals(radioCompareVars[1])) {
                  log("info", "Two variable values are same.");
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "Two variable values are different {" + radioCompareVars[0] + "}{" + radioCompareVars[1] + "}");
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Default radio button settings mismatch");
                  }
                  if (capturecheckvalue == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                }
        	  
        	  break;
          
          case "tablesortholding":
        	  String tableXpathHolding = ORvalue;
        	  String columnNameHolding = dtObj.getDataTableValueFor(cCellData);
        	  log("info", "tableXpathHolding:"+tableXpathHolding);
        	  log("info", "columnNameHolding:"+columnNameHolding);
        	  boolean sortResultHolding = cuskeyObj.tableSortHolding(tableXpathHolding, columnNameHolding);
        	  
        	  if (sortResultHolding) {
                  log("info", "Table is sorted correctly.");
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "Table is NOT sorted correctly");
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Table column is not sorted.");
                  }
                  if (capturecheckvalue == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                }
        	  
        	  break;
          case "checkcapitalize":
          	
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	  String elementText=elem.getText();
        	  boolean capitalizeCheckValue=cuskeyObj.checkCapitalize(elementText);
              //tdrObj.Update_Report("executed");
              if (capitalizeCheckValue) 
              {
                  log("info", "Captilize : Text matched & executed successfully");
                  tdrObj.Update_Report("executed");
                }
              else
              {
                  log("info", "Capitalize : Text is not matched & status is failed");
                  if (ORvalname == "exit") 
                  {
                    tdrObj.Update_Report("missing");
                  } else
                  {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Object Text is not displayed in Format : First Letter Captial & Rest with small");
                  }
              }   
              if  (capitalizeCheckValue == true) {
                ssObj.screenshot(loopnum, TScrowcount, TScname);
              }
              break;
              
          case "checkcolour":
            	
        	  String expColour = dtObj.getDataTableValueFor(cCellData).trim();
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	  String cssValue=elem.getCssValue("background-color");
        	  
        	  	 //   	  String cssValue1=elem.getCssValue("color");
        	  
        	        	  
        	  //log("info","generated css value background colour:"+cssValue);
        	//  log("info","generated css value color:"+cssValue1);
        	  
        	  log ("info","generated css value color:"+ cssValue);
        	  
        	  if (cssValue.equalsIgnoreCase(expColour)) 
              {
                  log("info", ": Pass");
                  tdrObj.Update_Report("executed");
                }
              else
              {
                  log("info", "Colour mismatch : Fail");
                  if (ORvalname == "exit") 
                  {
                    tdrObj.Update_Report("missing");
                  } else
                  {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Object Background Colour mismatch");
                  }
              }   
              if  (cssValue.equalsIgnoreCase(expColour)) {
                ssObj.screenshot(loopnum, TScrowcount, TScname);
              }
              break;
              
          case "checkpdfurl":
        	 
        	  
        	  String expurl = dtObj.getDataTableValueFor(cCellData).trim();
        	 //  String cssValue=elem.getCssValue("background-color");
        	  String actualurl=D8.getCurrentUrl().toLowerCase();
        	  	 //   	  String cssValue1=elem.getCssValue("color");
        	  String expurl1=expurl.toLowerCase();
        	        	  
        	  //log("info","generated css value background colour:"+cssValue);
        	//  log("info","generated css value color:"+cssValue1);
        	  
        	  
        	  if (actualurl.contains(expurl1)) 
              {
                  log("info", ": Pass");
                  tdrObj.Update_Report("executed");
                }
              else
              {
                  log("info", "PDF is not displayed properly: Fail");
                  if (ORvalname == "exit") 
                  {
                    tdrObj.Update_Report("missing");
                  } else
                  {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "PDF is not displayed properly");
                  }
              }   
              if  (actualurl.contains(expurl1)) {
                ssObj.screenshot(loopnum, TScrowcount, TScname);
              }
              break;
              
          case "checkdateformat":
        	  
        	  final String NEW_FORMAT = "MMM DD, YYYY";
          	
        	  String expDateFormat = dtObj.getDataTableValueFor(cCellData).trim();
        	 
        	  String[] parts =expDateFormat.split("on ");
        	  
        	  
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	 String actualDateFormat=elem.getText();
        	 
        	 SimpleDateFormat sdf = new SimpleDateFormat(parts[1]);
        	 Date d = sdf.parse(actualDateFormat);
        	 sdf.applyPattern(NEW_FORMAT);
        	 String newDateString = sdf.format(d);
        	 
        	 log ("info","expected date format from user(format)"+ expDateFormat);
        	 log ("info","actual date from application(actual date):"+ actualDateFormat);
        		 log ("info","new date string(conevrted date)  "+ newDateString);
        	  
        	         	  
        	 log("info", "Date format success: Pass");
        	  
        	  if (newDateString.equalsIgnoreCase(actualDateFormat)) 
              {
                  log("info", "Date format success: Pass");
                  tdrObj.Update_Report("executed");
                }
              else
              {
                  log("info", "Date format mismatch : Fail");
                  if (ORvalname == "exit") 
                  {
                    tdrObj.Update_Report("missing");
                  } else
                  {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Date Format is not in expected");
                  }
              }   
              if  (newDateString.equalsIgnoreCase(actualDateFormat)) {
                ssObj.screenshot(loopnum, TScrowcount, TScname);
              }
              break;
              
          case "checkfont":
          	
        	  String expFontColour = dtObj.getDataTableValueFor(cCellData).trim();
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	  String cssFontValue=elem.getCssValue("color");
        	  
        	  	 //   	  String cssValue1=elem.getCssValue("color");
        	  
        	        	  
        	  //log("info","generated css value background colour:"+cssValue);
        	//  log("info","generated css value color:"+cssValue1);
        	  
        	  log ("info","generated css value color:"+ cssFontValue);
        	  
        	  if (cssFontValue.equalsIgnoreCase(expFontColour)) 
              {
                  log("info", ": Pass");
                  tdrObj.Update_Report("executed");
                }
              else
              {
                  log("info", "Font Colour mismatch : Fail");
                  if (ORvalname == "exit") 
                  {
                    tdrObj.Update_Report("missing");
                  } else
                  {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Object Font Colour mismatch");
                  }
              }   
              if  (cssFontValue.equalsIgnoreCase(expFontColour)) {
                ssObj.screenshot(loopnum, TScrowcount, TScname);
              }
              break;
              
              
          case "checkbold":
            	
        	  String expBold = dtObj.getDataTableValueFor(cCellData).trim();
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	  String cssBoldValue=elem.getCssValue("font-size");
        	  
        	  	 //   	  String cssValue1=elem.getCssValue("color");
        	  
        	        	  
        	  //log("info","generated css value background colour:"+cssValue);
        	//  log("info","generated css value color:"+cssValue1);
        	  
        	  log ("info","generated css Bold colour:"+ cssBoldValue);
        	  
        	  if (cssBoldValue.equalsIgnoreCase(expBold)) 
              {
                  log("info", ": Pass");
                  tdrObj.Update_Report("executed");
                }
              else
              {
                  log("info", "Test is not bold : Fail");
                  if (ORvalname == "exit") 
                  {
                    tdrObj.Update_Report("missing");
                  } else
                  {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Text is not bold");
                  }
              }   
              if  (cssBoldValue.equalsIgnoreCase(expBold)) {
                ssObj.screenshot(loopnum, TScrowcount, TScname);
              }
              break;
              
          case "checkcharactercount":
          	
        	  String expCount = dtObj.getDataTableValueFor(cCellData).trim();
        	  int expCount1=Integer.parseInt(expCount);
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	  String enteredText=elem.getAttribute("value");
        	
        	  int cssCountValueInt=enteredText.length();
      
        	  log("info","entered text in text box:"+expCount1);
        	log("info","entered text in text box:"+enteredText);
        	
        	  log("info","generated character count value Integer:"+cssCountValueInt);
        	        	  
        
        
        	 
        	  
        	  if (cssCountValueInt<=expCount1) 
              {
                  log("info", "character count: Pass");
                  tdrObj.Update_Report("executed");
                }
              else
              {
                  log("info", "Character count  : Fail");
                  if (ORvalname == "exit") 
                  {
                    tdrObj.Update_Report("missing");
                  } else
                  {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Text field accepts more characters than the expected bandwidth");
                  }
              }   
              if  (cssCountValueInt<=expCount1) {
                ssObj.screenshot(loopnum, TScrowcount, TScname);
              }
              break;
              
          case "tablesortconsolidatedtrans":
        	  String tableXpathConTrans = ORvalue;
        	  String columnNameConTrans = dtObj.getDataTableValueFor(cCellData);
        	  log("info", "tableXpathHolding:"+tableXpathConTrans);
        	  log("info", "columnNameHolding:"+columnNameConTrans);
        	  boolean sortResultConTrans = cuskeyObj.tableSortConsolidatedTrans(tableXpathConTrans, columnNameConTrans);
        	  
        	  if (sortResultConTrans) {
                  log("info", "Table is sorted correctly.");
                  tdrObj.Update_Report("executed");
                } else {
                  log("info", "Table is NOT sorted correctly");
                  if (ORvalname == "exit") {
                    tdrObj.Update_Report("missing");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "Table column is not sorted.");
                  }
                  if (capturecheckvalue == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                }
        	  
        	  break;
          case "switchtoframe":
              WebDriverWait waitForFrame =
                  new WebDriverWait(D8, Integer.parseInt(dCellData.trim()));
              waitForFrame.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(cCellData
                  .trim()));
              // tdrObj.Update_Report("executed");
              break;
              
          case "uploadfile":
          		String filePath = dtObj.getDataTableValueFor(cCellData);
          		D8.findElement(By.xpath("/html/body/form/p[1]/input")).sendKeys(filePath);
          		       	         	
          		break;
          		
          case "mouseover":
        	  String moveMouse = ORvalue;
        	      	  
        	  Point coordinates = D8.findElement(By.xpath(moveMouse)).getLocation();
        	  Robot robot = new Robot();
        	  robot.mouseMove(coordinates.getX(),coordinates.getY()+120);
        	  
              break;
          case "cleartextbox":
        	  fEObj.Func_FindObj(ORvalname, ORvalue);
        	  elem.clear();
              tdrObj.Update_Report("executed");
              if (captureperform == true) {
                ssObj.screenshot(loopnum, TScrowcount, TScname);
              }
              break;
          
              
              
          //Keyword code end..Add any new keywords above this...
          //##################################################################################################  
          //Below are existing keywords....do not edit
          //###############################################################################################
            case "loop":
              isLoopStmtExist = true;
              loopnum = 1;
              if (cCellData.trim().equals("")) {
                loopcount = dtObj.getDataTableRowCount();
              } else {
                loopcount = Integer.parseInt(cCellData);
              }

              startrow = j;
              tdrObj.Update_Report("executed");
              // tdrObj.Update_Report("loop" + " Start of loop number" + loopnum);
              tdrObj.Update_Report("loop" + " Starting loop iterations...");
              break;
            case "endloop":
              dtrownum++;
              int loopnumber = loopnum;
              loopcount = loopcount - 1;
              loopnum = loopnum + 1;
              if (loopcount <= 0) {
                System.out.println("Reached End of Loop");
              } else

              {
                j = startrow;
              }
              rowcnt = 1;
              // tdrObj.Update_Report("loop" + " End of loop number" + loopnumber);
              tdrObj.Update_Report("loop" + " Ending loop iteration no:" + loopnumber);
              break;

            /*

            case "wait":
              Thread.sleep(Long.parseLong(cCellData) * 1000);
              // tdrObj.Update_Report("executed");
              break;

            case "waitforpagetoload":
              krfObj.waitForPageToLoad(Integer.parseInt(cCellData));
              tdrObj.Update_Report("executed");
              break;

            case "condition":
              String strConditionStatus = ifcObj.Func_IfCondition(cCellData);
              if (strConditionStatus.equalsIgnoreCase("false")) {
                j = ifcObj.ifContidionSkipper(strConditionStatus);
                // j = j + 1;
                log("info", "Line number from ifcond skipper-" + j);

              }
              tdrObj.Update_Report("executed");
              break;

            case "endcondition":
              tdrObj.Update_Report("executed");
              break;

            case "screencaptureoption":
              String[] sco = cCellData.split(";");

              for (int s = 0; s < sco.length; s++) {
                if (sco[s].equalsIgnoreCase("perform")) {
                  captureperform = true;
                }
                if (sco[s].equalsIgnoreCase("storevalue")) {
                  capturestorevalue = true;
                }
                if (sco[s].equalsIgnoreCase("check")) {
                  capturecheckvalue = true;
                }

              }
              tdrObj.Update_Report("executed");
              break;
            case "importdata":
              
               // String xcelpath = cCellData; FileInputStream fs3 = null; WorkbookSettings ws3 =
               // null; fs3 = new FileInputStream(new File(seleniumDir[0].replace("\\", "//") +
               // "//ProjectFramework//TestData//" + xcelpath )); ws3 = new WorkbookSettings();
               // ws3.setLocale(new Locale("en", "EN")); Workbook DTworkbook =
               // Workbook.getWorkbook(fs3, ws3); DTsheet = DTworkbook.getSheet(0); //int DTrowcount
               // = DTsheet.getRows(); DTrowcount = DTsheet.getRows();
              
              if (!cCellData.trim().endsWith(".xls")) cCellData = cCellData.trim() + ".xls";
              dataTableExcel =
                  seleniumDir[0].replace("\\", "//") + "//ProjectFramework//TestData//"
                      + cCellData.trim();
              dataTableSheet = dCellData.trim();
              tdrObj.Update_Report("executed");
              break;

            case "savedialog":
              Runtime rt = Runtime.getRuntime();
              rt.exec("D://AutoITScript/FileDown.exe");
              break;

            case "connecttodb":
              dbObj.connectToDB(krfObj.getcCellData());
              break;

            case "executesql":
              dbObj.executeQuery(krfObj.getcCellData());
              break;

            case "draganddrop":
              String dragAndDropArgs[] = krfObj.getcCellData().split(";");
              if (dragAndDropArgs.length != 2) throw new Exception("InvalidAgruments");

              String srcObjectNodeAndValue[] =
                  orObj.getObjectNodeAndValue(dragAndDropArgs[0]).split("&&");
              fEObj.Func_FindObj(srcObjectNodeAndValue[0], srcObjectNodeAndValue[1]);
              WebElement srcElement = elem;

              String destObjectNodeAndValue[] =
                  orObj.getObjectNodeAndValue(dragAndDropArgs[1]).split("&&");
              fEObj.Func_FindObj(destObjectNodeAndValue[0], destObjectNodeAndValue[1]);
              WebElement destElement = elem;

              Actions builder = new Actions(D8);
              builder.dragAndDrop(srcElement, destElement).build().perform();
              tdrObj.Update_Report("executed");
              break;

            case "draganddropby":
              String dragAndDropByArgs[] = krfObj.getcCellData().split(";");
              if (dragAndDropByArgs.length != 3) throw new Exception("InvalidAgruments");

              String srcObjectNodeAndValue2[] =
                  orObj.getObjectNodeAndValue(dragAndDropByArgs[0]).split("&&");
              fEObj.Func_FindObj(srcObjectNodeAndValue2[0], srcObjectNodeAndValue2[1]);
              WebElement srcElement2 = elem;

              Actions builder2 = new Actions(D8);
              builder2
                  .dragAndDropBy(srcElement2, Integer.parseInt(dragAndDropByArgs[1]),
                      Integer.parseInt(dragAndDropByArgs[2])).build().perform();
              tdrObj.Update_Report("executed");

              break;

            case "screencapture":
              ssObj.screenshot(loopnum, TScrowcount, TScname);
              tdrObj.Update_Report("executed");
              break;


            case "check":
              //scObj.Func_StoreCheck(TSORPath);
              scObj.Func_StoreCheck();
              break;

            case "checkpagecontent":

              if (D8.findElement(By.tagName("HTML")).getText().contains(krfObj.getcCellData())) {
                tdrObj.Update_Report("executed");
              }

              else if (D8.findElement(By.xpath("//*[contains(text(), '" + krfObj.getcCellData()
                  + "')]")) != null) {
                tdrObj.Update_Report("executed");
              }

              else {
                tdrObj.Update_Report("failed" + "Prt_Msg"
                    + "Page does not contain the text specified.");
                testStatus = "FAIL";
              }

              break;

            case "storevalue":
              //scObj.Func_StoreCheck(TSORPath);
              scObj.Func_StoreCheck();
              break;
            case "switchto":
              if (cCellData.trim().equalsIgnoreCase("parentwindow")) {
                log("info", "Driver switched to ParentWindow- "
                    + D8.switchTo().window(parentWindow).getTitle());
              }

              else {
                D8.getWindowHandle();
                Set<String> pops = D8.getWindowHandles();
                log("info", "Window handlers size- " + pops.size());
                Iterator<String> it = pops.iterator();
                while (it.hasNext()) {
                  String popupHandle = it.next().toString();
                  // if(!popupHandle.contains(parent)){
                  log("info",
                      "Driver switched to Pop Up Title- "
                          + D8.switchTo().window(popupHandle).getTitle());
                  // D8.switchTo().window(popupHandle);
                  // System.out.println("DEBUG:Pop Up Title- "+ popupHandle);
                  // }
                }
              }
              // tdrObj.Update_Report("executed");
              break;

            case "sendkeys":
              raObj.robotSendKey(cCellData);
              tdrObj.Update_Report("executed");
              break;

            case "authenticatedialog":
              if (krfObj.isModalDialogShowing()) {
                String credentials[] = cCellData.trim().split("::");
                raObj.copyAndPaste(credentials[0]);
                Thread.sleep(500);
                raObj.robotSendKey("TAB");
                Thread.sleep(500);
                raObj.copyAndPaste(credentials[1]);
                Thread.sleep(500);
                raObj.robotSendKey("ENTER");
                tdrObj.Update_Report("executed");
              } else {
                tdrObj.Update_Report("executed" + "Prt_Msg"
                    + "WARNING! Authentication Dialog was not present.");
              }
              break;

            case "savefileas":
              String fileToSave =
                  seleniumDir[0] + "\\ProjectFramework\\TestData\\" + krfObj.getcCellData();
              mfObj.deleteFileIfExists(fileToSave);

              if (cwpObj.isWindowPresentWithTitle("Opening", 30)) {
                Thread.sleep(1000);
                raObj.robotSendKey("ENTER");
              }

              if (cwpObj.isWindowPresentWithTitle("Enter name of file", 30)) {
                raObj.copyAndPaste(fileToSave);
                Thread.sleep(1000);
                raObj.robotSendKey("ENTER");
              }

              if (dCellData.trim().isEmpty()) {
                // krfObj.isCompletelyDownloaded(fileToSave,5);
                krfObj.isFolderUpdateComplete(seleniumDir[0] + "\\ProjectFramework\\TestData\\", 5);
              } else {
                krfObj.isCompletelyDownloaded(fileToSave, Integer.parseInt(dCellData));
              }

              tdrObj.Update_Report("executed");

              break;

            case "copyandpaste":
              raObj.copyAndPaste(krfObj.getcCellData());

              tdrObj.Update_Report("executed");
              break;

            case "uploadfile":
              // robotSendString(cCellData.trim());
              raObj.copyAndPaste(cCellData.trim());
              raObj.robotSendKey("enter");
              tdrObj.Update_Report("executed");
              break;

            case "runprogram":
              Runtime icR = Runtime.getRuntime();
              icR.exec(cCellData.trim());
              break;

            case "mousehovermenu":

              String[] menuItems = cCellData.split(">>");
              log("info", "Mouse hover menu items count:-" + menuItems.length);
              Actions actions = new Actions(D8);
              WebElement tempElem;
              for (int i = 0; i < menuItems.length; i++) {
                // tempElem = D8.findElement(By.linkText(menuItems[i].trim()));
                tempElem =
                    new WebDriverWait(D8, 5).until(ExpectedConditions.visibilityOfElementLocated(By
                        .linkText(menuItems[i].trim())));
                // tempElem = new WebDriverWait(D8,
                // 5).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[text()='" +
                // menuItems[i].trim() + "']")));
                actions.moveToElement(tempElem).build().perform();
                // actions.moveToElement(tempElem).build();

              }
              actions.click();
              actions.perform();

              tdrObj.Update_Report("executed");
              break;

            case "switchtoframe":
              WebDriverWait waitForFrame =
                  new WebDriverWait(D8, Integer.parseInt(dCellData.trim()));
              waitForFrame.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(cCellData
                  .trim()));
              // tdrObj.Update_Report("executed");
              break;

            case "m.perform":
              if (automationEnvironment.equalsIgnoreCase("Appium")) {
                mgaObj.executeMobileGesturesInAppium();
                tdrObj.Update_Report("executed");

              } else if ((automationEnvironment.equalsIgnoreCase("Selendroid"))) {
                mgsObj.executeMobileGesturesInSelendroid();
                tdrObj.Update_Report("executed");
              } else {
                log("info", "WARNING! This keyword is only for Mobile Testing.Skipping Step");
              }
              break;
             */
              
            case "perform":
            	/*
              String ObjectVal = "";
              if (cCellData.split(";").length == 0) {
                ObjectVal = cCellData.trim();
              } else {
                String[] cCellDataVal = cCellData.split(";");
                // String ObjectVal = cCellData.substring(cCellDataVal[0].length() +
                // 1,cCellData.length());
                ObjectVal = cCellDataVal[1].trim();
              }

              String[] dCellDataVal = dCellData.split(":");
              String ObjectSet = dCellDataVal[0].toLowerCase();
              String ObjectSetVal = "";

            
               // if(dCellData.contains("dt_")){ DTcolumncount = 0; DTcolumncount =
             //DTsheet.getColumns(); }
               

              if (dCellDataVal.length == 2) {

                ObjectSetVal = dCellDataVal[1];
              }


              String getObjectLocatorString = orObj.getObjectLocator(ObjectVal);

              if (getObjectLocatorString == null) {

                throw new Exception("ObjectLocatorNotFoundInOR");
              } else {

                if (getObjectLocatorString.contains("==") == false) {
                  throw new Exception("SyntaxErrorInORLocator");
                }

                String[] objectLocatorDetails = getObjectLocatorString.split("==");
                ORvalname = objectLocatorDetails[0];
                ORvalue = objectLocatorDetails[1];
              }
               */
            /*	
              switch (ObjectSet) {

                case "set":
                  wfeObj.waitTillVisible("60");
                  if (ObjectSetVal.substring(0, 1).equalsIgnoreCase("$")) {
                    ObjectSetVal = dtfObj.getSystemVariable(ObjectSetVal.trim());
                  }
                  if (ObjectSetVal.substring(0, 1).equalsIgnoreCase("#")) {
                    ObjectSetVal = map.get(ObjectSetVal.substring(1, (ObjectSetVal.length())));
                  }
                  if (ObjectSetVal.substring(0, 3).equalsIgnoreCase("dt_")) {
                    ObjectSetVal = dtObj.getDataTableValue(ObjectSetVal, dtrownum);
                  }
                  if (ObjectSetVal.substring(0, 3).equalsIgnoreCase("db_")) {
                    ObjectSetVal =
                        DBResultSet2D.get(ObjectSetVal.substring(3, (ObjectSetVal.length())));
                  }

                  runTimeValue = ObjectSetVal;
                 
                   // String ObjectSetValtableheader[] = ObjectSetVal .split("_"); int column = 0;
                  //String Searchtext = ObjectSetValtableheader[1]; for (column = 0; column <
                  // DTcolumncount; column++) { if (Searchtext.equalsIgnoreCase(DTsheet
                   // .getCell(column, 0).getContents()) == true) { ObjectSetVal =
                   // DTsheet.getCell(column, dtrownum).getContents(); iflag = 1; }
                  // 
                   // } if (iflag == 0) { ORvalname = "exit"; } }
                  


                  fEObj.Func_FindObj(ORvalname, ORvalue);
                  // elem.focus();
                  // elem.clear();
                  elem.sendKeys(ObjectSetVal);
                  tdrObj.Update_Report("executed");
                  if (captureperform == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }

                  break;

                case "listselect":
                  wfeObj.waitTillClickable("60");
                  if (ObjectSetVal.substring(0, 3).equalsIgnoreCase("dt_")) {
                    ObjectSetVal = dtObj.getDataTableValue(ObjectSetVal, dtrownum);
                  }
                  if (ObjectSetVal.substring(0, 3).equalsIgnoreCase("db_")) {
                    ObjectSetVal =
                        DBResultSet2D.get(ObjectSetVal.substring(3, (ObjectSetVal.length())));
                  }
                  runTimeValue = ObjectSetVal;
                  fEObj.Func_FindObj(ORvalname, ORvalue);
                  String[] listvalues = ObjectSetVal.split(",");

                  List<WebElement> listboxitems = elem.findElements(By.tagName("option"));
                  Select chooseoptn = new Select(elem);
                  chooseoptn.deselectAll();
                  for (WebElement opt : listboxitems) { // System.out.println(opt.getText());
                    for (int i = 0; i < listvalues.length; i++) {
                      if (opt.getText().equalsIgnoreCase(listvalues[i])) {
                        // System.out.println(listvalues[i]);
                        chooseoptn.selectByVisibleText(opt.getText());
                      }
                    }
                  }

                  tdrObj.Update_Report("executed");
                  if (captureperform == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }

                  break;

                case "select":
                  wfeObj.waitTillClickable("60");
                  if (ObjectSetVal.substring(0, 1).equalsIgnoreCase("$")) {
                    ObjectSetVal = dtfObj.getSystemVariable(ObjectSetVal.trim());
                  }
                  if (ObjectSetVal.substring(0, 1).equalsIgnoreCase("#")) {
                    ObjectSetVal = map.get(ObjectSetVal.substring(1, (ObjectSetVal.length())));
                  }
                  if (ObjectSetVal.substring(0, 3).equalsIgnoreCase("dt_")) {
                    ObjectSetVal = dtObj.getDataTableValue(ObjectSetVal, dtrownum);
                  }
                  if (ObjectSetVal.substring(0, 3).equalsIgnoreCase("db_")) {
                    ObjectSetVal =
                        DBResultSet2D.get(ObjectSetVal.substring(3, (ObjectSetVal.length())));
                  }

                  //
                   // if (ObjectSetVal.contains("dt_")) { String ObjectSetValtableheader[] =
                   // ObjectSetVal .split("_"); int column = 0; String Searchtext =
                  // ObjectSetValtableheader[1];
                   // 
                  // for (column = 0; column < DTcolumncount; column++) { if
                 // (Searchtext.equalsIgnoreCase(DTsheet .getCell(column, 0).getContents()) ==
                   // true) { ObjectSetVal = DTsheet.getCell(column, dtrownum).getContents(); iflag =
                   // 1; }
                   // 
                  // } if (iflag == 0) { ORvalname = "exit"; } }
                   //
                  runTimeValue = ObjectSetVal;
                  fEObj.Func_FindObj(ORvalname, ORvalue);
                  new Select(elem).selectByVisibleText(ObjectSetVal);
                  tdrObj.Update_Report("executed");
                  if (captureperform == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }

                  break;

                case "check":
                  wfeObj.waitTillClickable("60");
                  if (ObjectSetVal.substring(0, 1).equalsIgnoreCase("$")) {
                    ObjectSetVal = dtfObj.getSystemVariable(ObjectSetVal.trim());
                  }
                  if (ObjectSetVal.substring(0, 1).equalsIgnoreCase("#")) {
                    ObjectSetVal = map.get(ObjectSetVal.substring(1, (ObjectSetVal.length())));
                  }
                  if (ObjectSetVal.substring(0, 3).equalsIgnoreCase("dt_")) {
                    ObjectSetVal = dtObj.getDataTableValue(ObjectSetVal, dtrownum);
                  }
                  if (ObjectSetVal.substring(0, 3).equalsIgnoreCase("db_")) {
                    ObjectSetVal =
                        DBResultSet2D.get(ObjectSetVal.substring(3, (ObjectSetVal.length())));
                  }

                  
                 //if (ObjectSetVal.contains("dt_")) { String ObjectSetValtableheader[] =
                  // ObjectSetVal .split("_"); int column = 0; String Searchtext =
                   // ObjectSetValtableheader[1]; for (column = 0; column < DTcolumncount; column++)
                  // { if (Searchtext.equalsIgnoreCase(DTsheet .getCell(column, 0).getContents()) ==
                   // true) { ObjectSetVal = DTsheet.getCell(column, dtrownum).getContents(); iflag =
                   // 1; } } if (iflag == 0) { ORvalname = "exit"; } }
                
                  runTimeValue = ObjectSetVal;
                  fEObj.Func_FindObj(ORvalname, ORvalue);
                  if (elem.isSelected() && dCellDataVal[1].equalsIgnoreCase("On")) {

                  } else if (elem.isSelected() || dCellDataVal[1].equalsIgnoreCase("On")) {
                    elem.click();
                  }
                  tdrObj.Update_Report("executed");
                  if (captureperform == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                  break;

                case "attachfile":
                  if (ObjectSetVal.substring(0, 1).equalsIgnoreCase("#")) {
                    ObjectSetVal = map.get(ObjectSetVal.substring(1, (ObjectSetVal.length())));
                  }
                  if (ObjectSetVal.substring(0, 3).equalsIgnoreCase("dt_")) {
                    ObjectSetVal = dtObj.getDataTableValue(ObjectSetVal, dtrownum);
                  }
                  if (ObjectSetVal.substring(0, 3).equalsIgnoreCase("db_")) {
                    ObjectSetVal =
                        DBResultSet2D.get(ObjectSetVal.substring(3, (ObjectSetVal.length())));
                  }

                  runTimeValue = ObjectSetVal;
                  fEObj.Func_FindObj(ORvalname, ORvalue);
                  // Concatenate the full path with filename
                  ObjectSetVal = seleniumDir[0] + "\\ProjectFramework\\TestData\\" + ObjectSetVal;
                  log("info", "Attaching file-" + ObjectSetVal);
                  elem.sendKeys(ObjectSetVal);

                  tdrObj.Update_Report("executed");
                  if (captureperform == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                  break;

                case "click":
                  wfeObj.waitTillClickable("60");
                  fEObj.Func_FindObj(ORvalname, ORvalue);
                  elem.click();

                  tdrObj.Update_Report("executed");
                  if (captureperform == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                  break;

                case "clear":
                  wfeObj.waitTillVisible("60");
                  fEObj.Func_FindObj(ORvalname, ORvalue);
                  elem.clear();

                  tdrObj.Update_Report("executed");
                  if (captureperform == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                  break;

                case "submit":
                  wfeObj.waitTillClickable("60");
                  fEObj.Func_FindObj(ORvalname, ORvalue);
                  elem.submit();

                  tdrObj.Update_Report("executed");
                  if (captureperform == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                  break;

                case "enter":
                  fEObj.Func_FindObj(ORvalname, ORvalue);
                  elem.sendKeys("\n");

                  tdrObj.Update_Report("executed");
                  if (captureperform == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                  break;

                case "waittillclickable":

                  WebElement elementClickable = null;

                  if (ORvalname.equalsIgnoreCase("id")) {
                    elementClickable =
                        new WebDriverWait(D8, Integer.parseInt(ObjectSetVal))
                            .until(ExpectedConditions.elementToBeClickable(By.id(ORvalue)));
                  } else if (ORvalname.equalsIgnoreCase("name")) {
                    elementClickable =
                        new WebDriverWait(D8, Integer.parseInt(ObjectSetVal))
                            .until(ExpectedConditions.elementToBeClickable(By.name(ORvalue)));
                  } else if (ORvalname.equalsIgnoreCase("xpath")) {
                    elementClickable =
                        new WebDriverWait(D8, Integer.parseInt(ObjectSetVal))
                            .until(ExpectedConditions.elementToBeClickable(By.xpath(ORvalue)));
                  } else if (ORvalname.equalsIgnoreCase("link")) {
                    elementClickable =
                        new WebDriverWait(D8, Integer.parseInt(ObjectSetVal))
                            .until(ExpectedConditions.elementToBeClickable(By.linkText(ORvalue)));
                  } else if (ORvalname.equalsIgnoreCase("partiallink")) {
                    elementClickable =
                        new WebDriverWait(D8, Integer.parseInt(ObjectSetVal))
                            .until(ExpectedConditions.elementToBeClickable(By
                                .partialLinkText(ORvalue)));
                  } else if (ORvalname.equalsIgnoreCase("css")) {
                    elementClickable =
                        new WebDriverWait(D8, Integer.parseInt(ObjectSetVal))
                            .until(ExpectedConditions.elementToBeClickable(By.cssSelector(ORvalue)));
                  } else if (ORvalname.equalsIgnoreCase("class")) {
                    elementClickable =
                        new WebDriverWait(D8, Integer.parseInt(ObjectSetVal))
                            .until(ExpectedConditions.elementToBeClickable(By.className(ORvalue)));
                  } else if (ORvalname.equalsIgnoreCase("tag")) {
                    elementClickable =
                        new WebDriverWait(D8, Integer.parseInt(ObjectSetVal))
                            .until(ExpectedConditions.elementToBeClickable(By.tagName(ORvalue)));
                  }



                  if (elementClickable != null) {
                    tdrObj.Update_Report("executed");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg"
                        + "Element was not clickable till the specified time.");

                  }
                  if (captureperform == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                  break;

                case "waittillvisible":

                  WebElement elementVisible = null;


                  if (ORvalname.equalsIgnoreCase("id")) {
                    elementVisible =
                        new WebDriverWait(D8, Integer.parseInt(ObjectSetVal))
                            .until(ExpectedConditions.visibilityOfElementLocated(By.id(ORvalue)));
                  } else if (ORvalname.equalsIgnoreCase("name")) {
                    elementVisible =
                        new WebDriverWait(D8, Integer.parseInt(ObjectSetVal))
                            .until(ExpectedConditions.visibilityOfElementLocated(By.name(ORvalue)));
                  } else if (ORvalname.equalsIgnoreCase("xpath")) {
                    elementVisible =
                        new WebDriverWait(D8, Integer.parseInt(ObjectSetVal))
                            .until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ORvalue)));
                  } else if (ORvalname.equalsIgnoreCase("link")) {
                    elementVisible =
                        new WebDriverWait(D8, Integer.parseInt(ObjectSetVal))
                            .until(ExpectedConditions.visibilityOfElementLocated(By
                                .linkText(ORvalue)));
                  } else if (ORvalname.equalsIgnoreCase("partiallink")) {
                    elementVisible =
                        new WebDriverWait(D8, Integer.parseInt(ObjectSetVal))
                            .until(ExpectedConditions.visibilityOfElementLocated(By
                                .partialLinkText(ORvalue)));
                  } else if (ORvalname.equalsIgnoreCase("css")) {
                    elementVisible =
                        new WebDriverWait(D8, Integer.parseInt(ObjectSetVal))
                            .until(ExpectedConditions.visibilityOfElementLocated(By
                                .cssSelector(ORvalue)));
                  } else if (ORvalname.equalsIgnoreCase("class")) {
                    elementVisible =
                        new WebDriverWait(D8, Integer.parseInt(ObjectSetVal))
                            .until(ExpectedConditions.visibilityOfElementLocated(By
                                .className(ORvalue)));
                  } else if (ORvalname.equalsIgnoreCase("tag")) {
                    elementVisible =
                        new WebDriverWait(D8, Integer.parseInt(ObjectSetVal))
                            .until(ExpectedConditions.visibilityOfElementLocated(By
                                .tagName(ORvalue)));
                  }



                  if (elementVisible != null) {
                    tdrObj.Update_Report("executed");
                  } else {
                    testStatus = "FAIL";
                    tdrObj.Update_Report("failed" + "Prt_Msg"
                        + "Element was not visible till the specified time.");

                  }
                  if (captureperform == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                  break;

                case "alert":
                  try {
                    Alert alert = D8.switchTo().alert();
                    String actualAlertMsg = alert.getText();
                    if (dCellDataVal[1].equalsIgnoreCase("ok")
                        && actualAlertMsg.contains(ObjectVal) == true) {
                      alert.accept();
                      tdrObj.Update_Report("executed");
                    }
                    if (dCellDataVal[1].equalsIgnoreCase("cancel")
                        && actualAlertMsg.contains(ObjectVal) == true) {
                      alert.dismiss();
                      tdrObj.Update_Report("executed");
                    }

                    if (dCellDataVal[1].equalsIgnoreCase("ok")
                        && actualAlertMsg.contains(ObjectVal) == false) {
                      alert.accept();
                      tdrObj.Update_Report("failed" + "Prt_Msg" + "Actual Alert text is:"
                          + actualAlertMsg);
                      testStatus = "FAIL";
                    }
                    if (dCellDataVal[1].equalsIgnoreCase("cancel")
                        && actualAlertMsg.contains(ObjectVal) == false) {
                      alert.dismiss();
                      tdrObj.Update_Report("failed" + "Prt_Msg" + "Actual Alert text is:"
                          + actualAlertMsg);
                      testStatus = "FAIL";
                    }

                  } catch (NoAlertPresentException ex) {
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "No Such Alert Present");
                    testStatus = "FAIL";
                    // No alert present
                  }

                  if (captureperform == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                  break;

                case "frame":
                  try {
                    if (dCellDataVal[1].equalsIgnoreCase("switchto")) {
                      fEObj.Func_FindObj(ORvalname, ORvalue);
                      D8.switchTo().frame(elem);
                      tdrObj.Update_Report("executed");
                    }
                    if (dCellDataVal[1].equalsIgnoreCase("switchfrom")) {
                      // D8.switchTo().defaultContent;
                      tdrObj.Update_Report("executed");
                    }

                  } catch (Exception ex) {
                    tdrObj.Update_Report("failed" + "Prt_Msg" + "No Such Frame Present");
                    testStatus = "FAIL";
                    // No Frame present
                  }

                  if (captureperform == true) {
                    ssObj.screenshot(loopnum, TScrowcount, TScname);
                  }
                  break;

              }// End of Objectset Switch
               // tdrObj.Update_Report("executed");
              
             */
              
              break;
   
            default:
              tdrObj.Update_Report("skipped");
              break;
          }// End of Actval Switch
           // }// End of IF loop
           // }// End of For loop that get all rows in Test Script
           // bw.close(); //moving close to just below after completing header write in case of
           // exception.-Yuva

        } catch (StaleElementReferenceException e) {
          log("error", "Stale Element exception Caught in Execute keyword Script.");
          // staleElemChecker = j;

          if (staleElemExCtr > 5) {
            log("error", "Stale Element exception exceeded retry limit.Ending keyword Script.");
            errorDesc = cemObj.getErrorDescription(e.getMessage());
            tdrObj.Update_Report("failed");
            testStatus = "FAIL";
            log("info",
                "Updating summary report [StaleElementReferenceException catch block] with test status as: "
                    + testStatus);
            tsrObj.updateSummaryReport(scriptName, "failed");
            bw.close();
            testStatus = "SKIP_SUMMARYREPORT_UPDATE";
            break keywordScriptForLoop;

            // Throw an exception to halt the script.
            // throw("Stale Element Exception Caught");
          }

          else {
            // Just update the for loop counter to retry.
            j--;
            staleElemExCtr++;
          }

          // System.out.println(e);
          // System.out.println("Because of specification of SeleniumWebDriver, downloading may be failed.");
          // System.out.println("Please confirm the report file and screenshot about test result.");
        } catch (Exception ex) {
        	
        	 log("error", "Exception Caught in Execute keyword Script:" + ex.getMessage());
        	 
          if (ActionVal.equalsIgnoreCase("checkPageContent")) {
            errorDesc = cemObj.getErrorDescription("ContentNotFoundInPage");
          } else {
            errorDesc = cemObj.getErrorDescription(ex.getMessage());

          }
          tdrObj.Update_Report("failed");

          if (isLoopStmtExist == true && loopcount > 0) {
            // Do not break the loop-keyword.. continue the loop till it ends.
            log("info", "Catching exception with Loop count as:" + loopcount);

            dtrownum++;
            int loopnumber = loopnum;
            loopcount = loopcount - 1;
            // loopnum = loopnum + 1;


            if (loopcount == 0) {
              log("info", "Reached End of Loop @ keyword script catch exception");
              log("info",
                  "Getting the row no of Endloop keyword with para{" + j + "}:"
                      + krfObj.getEndLoopRowNo(j));
              j = krfObj.getEndLoopRowNo(j);
            }

            else {
              loopnum = loopnum + 1;
              j = startrow;
              rowcnt = 1;
              tdrObj.Update_Report("loop: A Step failed during loop no- " + loopnumber
                  + ".Skipping remaining steps of loop.");
            }


          } else {
            testStatus = "FAIL";
            log("info",
                "Updating summary report [execute keyword script catch] with test status as: "
                    + testStatus);
            tsrObj.updateSummaryReport(scriptName, "failed");
            bw.close();
            // bwSummaryRpt.close();

            log("error", "Exception Caught in Execute keyword Script: " + ex.getMessage());


            testStatus = "SKIP_SUMMARYREPORT_UPDATE";
            
            //Stop execution if proceed on error is set to N in test script sheet.
            if(eCellData.trim().equalsIgnoreCase("N")) {
            	 break keywordScriptForLoop;
            }
           
          }



        }
      //}// End of IF loop
    } // End of check tcname if loop  
      else {
    	  
    	  if( ! testCaseRowMatch.isEmpty() & (((TScsheet.getCell(1, j).getContents()).equalsIgnoreCase(TScname) == false))) {
    	    	 break keywordScriptForLoop;
    	     }
    	     
      }
      
    }// End of For loop that get all rows in Test Script
    bw.close(); // moving close to just below after completing header write in case of
                // exception.-Yuva
   log("info","Reached end of executing keywords for script {"+ scriptName +"}");
  }// End of Function


}
