package com.automation.selenium;

public class CloseFunction extends BaseClass {


  ZipTestResults zObj = new ZipTestResults();
  //EmailingTestResults eObj = new EmailingTestResults();
  DateTimeFunctions dtfObj = new DateTimeFunctions();
  DataBase dbObj = new DataBase();


  public void close() {
    // public void close() throws Exception {
    try {
      log("info", "Test Complete.see summary-" + summaryReportHTML);
      if (automationEnvironment.equalsIgnoreCase("PC")) {
        D8.get("file:///" + summaryReportHTML);
      }

      // Cleanup any open DB Connections.
      dbObj.cleanUpDBConnections();

      // Create the zip file either to send email or to attach to Quality Center.

      //if (gs_sendEmailAfterTest.equalsIgnoreCase("Yes")
      //    || gs_updateQCAfterTest.equalsIgnoreCase("Yes")) {
    	  
     /*
        testResultsZipFile =
            seleniumDir[0] + "\\ProjectFramework\\zipFiles\\TestResults_"
                + testExecutionType + "_" + testRunEnvironment + "_" + testRunLanguage + "_" + testExecutionBrowserName + "_"
                + dtfObj.getCurrFormattedTimestamp() + ".zip";
        zObj.zipfolder(testResultsZipFile, seleniumDir[0] + "\\ProjectFramework\\TestResults");
     */ 
      
      //}

  /*
      // Upload Test Results to QC and disconnect.
      if (itdc != null) {
        QualityCenter qcObj = new QualityCenter();
        qcObj.uploadTestResultZipToQC(testResultsZipFile);
        qcObj.disconnectFromQC();
      }

  */
      if (gs_closeBrowserAfterTest.equalsIgnoreCase("Yes")) {
        D8.close();
        D8.quit();
      }

  /*
      if (gs_sendEmailAfterTest.equalsIgnoreCase("Yes")) {
        eObj.sendmailAttachment(testResultsZipFile);
      }
   */

    } catch (Exception e) {
      log("error", "Exception caught in close function-" + e.getMessage());
    }
  }

}
