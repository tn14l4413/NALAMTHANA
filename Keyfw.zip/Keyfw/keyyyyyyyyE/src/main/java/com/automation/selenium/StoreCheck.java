package com.automation.selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class StoreCheck extends BaseClass {

  ObjectRepository orObj = new ObjectRepository();
  DateTimeFunctions dtfObj = new DateTimeFunctions();
  TestDetailedReport tdrObj = new TestDetailedReport();
  FindElement fEObj = new FindElement();
  ScreenShot ssObj = new ScreenShot();
  DataTable dtObj = new DataTable();



  //public void Func_StoreCheck(String scriptORPath) throws Exception {
  public void Func_StoreCheck() throws Exception {	  
    String actval = null;
    String expval;
    Boolean boolval = null;
    String varname;
    String ObjectValCh;

    if (cCellData.split(";").length == 0) {
      ObjectValCh = cCellData.trim();
    } else {
      String[] cCellDataValCh = cCellData.split(";");
      ObjectValCh = cCellDataValCh[1];
    }

    String[] dCellDataValCh = dCellData.split(":");
    String ObjectSetCh = dCellDataValCh[0];
    String ObjectSetValCh = "";
    /*
     * if(dCellData.contains("dt_")){ DTsheet.getColumns(); }
     */
    if (dCellDataValCh.length == 2) {
      ObjectSetValCh = dCellDataValCh[1];
    }

    String getObjectLocatorString = orObj.getObjectLocator(ObjectValCh);
    if (getObjectLocatorString == null) {

      throw new Exception("ObjectLocatorNotFoundInOR");
    } else {
      String[] objectLocatorDetails = getObjectLocatorString.split("==");
      ORvalname = objectLocatorDetails[0];
      ORvalue = objectLocatorDetails[1];
    }

    runTimeValue = ObjectSetValCh;
    /*
     * if (ObjectSetValCh.substring(0, 1).equalsIgnoreCase("$")) { ObjectSetValCh =
     * dtfObj.getSystemVariable(ObjectSetValCh.trim()); }
     * 
     * if (ObjectSetValCh.substring(0, 1).equalsIgnoreCase("#")) { ObjectSetValCh =
     * map.get(ObjectSetValCh.substring(1, (ObjectSetValCh.length())));
     * 
     * } else if (ObjectSetValCh.contains("dt_")) { String ObjectSetValtableheader[] =
     * ObjectSetValCh.split("_"); int column = 0; String Searchtext = ObjectSetValtableheader[1];
     * 
     * for (column = 0; column < DTcolumncount; column++) { if
     * (Searchtext.equalsIgnoreCase(DTsheet.getCell(column, 0) .getContents()) == true) {
     * ObjectSetValCh = DTsheet.getCell(column, dtrownum) .getContents(); iflag = 1; } } if (iflag
     * == 0) { ORvalname = "exit"; } }
     */

    switch (ObjectSetCh.toLowerCase()) {
      case "readonly":
        fEObj.Func_FindObj(ORvalname, ORvalue);
        actval = elem.getAttribute("readonly");
        break;
      case "enabled":
        fEObj.Func_FindObj(ORvalname, ORvalue);
        boolval = elem.isEnabled();
        actval = boolval.toString();
        break;
      case "text":
        fEObj.Func_FindObj(ORvalname, ORvalue);
        // actval = elem.getAttribute("value");
        actval = elem.getText().toString();
        break;
      case "numfromtext":
        fEObj.Func_FindObj(ORvalname, ORvalue);
        // actval = elem.getAttribute("value");
        actval = elem.getText().replaceFirst(".*?(\\d+).*", "$1");
        break;
      case "value":
        fEObj.Func_FindObj(ORvalname, ORvalue);
        actval = new Select(elem).getFirstSelectedOption().getText().toString();
        break;
      case "visible":
        fEObj.Func_FindObj(ORvalname, ORvalue);
        boolval = elem.isDisplayed();
        actval = boolval.toString();
        break;
      case "checked":
        fEObj.Func_FindObj(ORvalname, ORvalue);
        boolval = elem.isSelected();
        actval = boolval.toString();
        if (actval.equalsIgnoreCase("True"))
          actval = "on";
        else
          actval = "Off";
        break;
      case "linktext":
        fEObj.Func_FindObj(ORvalname, ORvalue);
        actval = elem.getText();
        break;
      case "tabletext":
        fEObj.Func_FindObj(ORvalname, ORvalue);
        actval = "NO MATCH FOUND";
        List<WebElement> tr_collection = elem.findElements(By.xpath("tr"));
        log("info", "NUMBER OF ROWS IN THIS TABLE = " + tr_collection.size());
        int tbl_row_num,
        tbl_col_num;
        tbl_row_num = 1;
        for (WebElement trElement : tr_collection) {
          List<WebElement> td_collection = trElement.findElements(By.xpath("td"));
          log("info", "NUMBER OF COLUMNS=" + td_collection.size());
          tbl_col_num = 1;
          for (WebElement tdElement : td_collection) {
            log("info",
                "row # " + tbl_row_num + ", col # " + tbl_col_num + "text=" + tdElement.getText());
            if (tdElement.getText().equals(ObjectSetValCh)) {
              actval = tdElement.getText();
              break;
            }
            tbl_col_num++;
          }
          tbl_row_num++;
        }
        // actval = elem.getText();
        break;


      default:
        if (ObjectSetCh.toLowerCase().contains("partialtext")) {
          fEObj.Func_FindObj(ORvalname, ORvalue);
          String parameter = ObjectSetCh.substring(12, ObjectSetCh.length() - 1);
          String[] args = parameter.split(",");
          log("info",
              "Partial Text Parameter =" + parameter + " Args[0]="
                  + Integer.parseInt(args[0].trim()) + " Args[1]="
                  + Integer.parseInt(args[1].trim()));

          actval =
              elem.getText()
                  .toString()
                  .substring(Integer.parseInt(args[0].trim()) - 1,
                      Integer.parseInt(args[0].trim()) + Integer.parseInt(args[1].trim()) - 1);
          break;
        } else {
          actval = "Invalid syntax";
          break;
        }
    }

    if ((ActionVal).equalsIgnoreCase("check")) {
      log("info", "Started performing check operation..");

      if (ObjectSetValCh.substring(0, 1).equalsIgnoreCase("$")) {
        ObjectSetValCh = dtfObj.getSystemVariable(ObjectSetValCh.trim());
      }

      if (ObjectSetValCh.substring(0, 1).equalsIgnoreCase("#")) {
        ObjectSetValCh = map.get(ObjectSetValCh.substring(1, (ObjectSetValCh.length())));
      }

      if (ObjectSetValCh.substring(0, 3).equalsIgnoreCase("dt_")) {
        ObjectSetValCh = dtObj.getDataTableValue(ObjectSetValCh.trim(), dtrownum);
      }
      if (ObjectSetValCh.substring(0, 3).equalsIgnoreCase("db_")) {
        ObjectSetValCh = DBResultSet2D.get(ObjectSetValCh.substring(3, (ObjectSetValCh.length())));
      }

      expval = ObjectSetValCh;
      runTimeValue = ObjectSetValCh;
      if (expval.equalsIgnoreCase(actval)) {
        log("info", "Actual value matches with expected value. Actual value is: " + actval);
        tdrObj.Update_Report("executed");
      } else {
        log("info", "Actual value doesn't match with expected value. Actual value is: " + actval
            + " Expected : " + expval);
        if (ORvalname == "exit") {
          tdrObj.Update_Report("missing");
        } else {
          testStatus = "FAIL";
          tdrObj.Update_Report("failed" + "Prt_Msg" + "Actual value is:" + actval);
        }
        if (capturecheckvalue == true) {
          ssObj.screenshot(loopnum, TScrowcount, TScname);
        }
      }
    } else if ((ActionVal).equalsIgnoreCase("storevalue")) {

      log("info", "Started performing storevalue operation..");

      if (actval.equalsIgnoreCase("Invalid syntax")) {
        tdrObj.Update_Report("missing");
      } else {
        runTimeValue = "{" + actval + "}";
        // Decide whether to store in variable or data table
        if (ObjectSetValCh.substring(0, 1).equalsIgnoreCase("#")) {
          // Store the actual value in variable
          varname = ObjectSetValCh.substring(1, (ObjectSetValCh.length()));
          if (map.containsKey(varname)) {
            map.put(varname, actval);
            tdrObj.Update_Report("executed" + "Prt_Msg" + map.get(varname));
            log("info", "Variable already exists.Value overwritten into the variable{ " + varname
                + "}.");
          } else {
            map.put(varname, actval);
            tdrObj.Update_Report("executed" + "Prt_Msg" + map.get(varname));
            log("info", "Value stored into the new variable{ " + varname + "}.");
          }
        }

        else if (ObjectSetValCh.substring(0, 3).equalsIgnoreCase("dt_")) {
          // store the actual value in datatable
          dtObj.putValueToDataTable(ObjectSetValCh, dtrownum, actval);
          tdrObj.Update_Report("executed" + "Prt_Msg" + actval);
          log("info", "Datatable column {" + ObjectSetValCh + "} is updated with value{ " + actval
              + "}.");
        }

        else {
          // Storage variable in invalid.
          throw new Exception("InvalidStorageVariableFoundInTS");
        }


      }
      /*
       * varname = ObjectSetValCh; if (actval.equalsIgnoreCase("Invalid syntax"))
       * {tdrObj.Update_Report("missing");} else{
       * 
       * if (map.containsKey(varname)) { map.put(varname, actval); tdrObj.Update_Report("executed" +
       * "Prt_Msg"+ map.get(varname)); log("info","Overwriting the value of the variable " + varname
       * + " to store the value as mentioned in the test case row number- If part" + rowcnt);
       * map.remove(varname);} else { map.put(varname, actval); tdrObj.Update_Report("executed" +
       * "Prt_Msg"+ map.get(varname)); log("info","Overwriting the value of the variable "+ varname
       * + " to store the value as mentioned in the test case row number- else part" + rowcnt); if
       * (ORvalname == "exit") {tdrObj.Update_Report("missing");} else {} }
       * 
       * }
       */


      if (capturestorevalue == true) {
        ssObj.screenshot(loopnum, TScrowcount, TScname);
      }
    }
  }
}
