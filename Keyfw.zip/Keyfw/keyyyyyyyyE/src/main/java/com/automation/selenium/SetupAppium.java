package com.automation.selenium;

import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class SetupAppium extends BaseClass {

  public void setupAppiumdDriver(String automationName, String platformName,
      String platformVersion, String browserName, String browserVersion, String deviceName,
      String appPackage, String appActivity) throws Exception {
    try {
      log("info", "Started setting up Appium driver.....");
      DesiredCapabilities capabilities = new DesiredCapabilities();
      
      capabilities.setCapability("device", "Android");
      capabilities.setCapability(CapabilityType.BROWSER_NAME, browserName);
      capabilities.setCapability(CapabilityType.VERSION, "4.3");
      capabilities.setCapability(CapabilityType.PLATFORM, platformName);
      capabilities.setCapability("app-package", appPackage);
      capabilities.setCapability("app-activity", appActivity);
      
      D8 = new RemoteWebDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
      D8.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
      log("info", "Appium hub started successfully @ http://127.0.0.1:4723/wd/hub");
    } catch (Exception e) {
      setUpSuccess = false;
      log("error",
          "Exception caught while setting up the Appium Hub:Please make sure if the device is connected or any emulator is up and running."
              + e.getMessage());
    }
  }
}
