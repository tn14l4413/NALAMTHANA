package com.automation.selenium;

import java.net.MalformedURLException;

public class EnvironmentSetup extends BaseClass {
  SettingsFile sfObj = new SettingsFile();
  //SetupSelendroid stpSelObj = new SetupSelendroid();
  SetupAppium stpAppObj = new SetupAppium();
  SetupPC stpPCObj = new SetupPC();

  public void setup(String automationName, String platformName, String platformVersion,
      String browserName, String browserVersion, String deviceName, String appPackage,
      String appActivity) throws MalformedURLException {
    try {
      log("info", "Started Setup function...");
      //log("info", "Current user dir-" + System.getProperty("user.dir"));
      //seleniumDir = System.getProperty("user.dir").split("ProjectFramework");
      String currentClassPath = this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath();
      log("info", "Current class path =" + currentClassPath);
      seleniumDir = currentClassPath.split("ProjectFramework");
      
      sfObj.readSettingsFile();

      log("info", "XML Parameters:{" + automationName + "}{" + platformName + "}{"
          + platformVersion + "}{" + browserName + "}{" + browserVersion + "}{" + deviceName + "}{"
          + appPackage + "}{" + appActivity + "}");

      if (automationName.equalsIgnoreCase("Appium"))
        stpAppObj.setupAppiumdDriver(automationName, platformName, platformVersion, browserName,
            browserVersion, deviceName, appPackage, appActivity);

      /*
       if (automationName.equalsIgnoreCase("Selendroid"))
        stpSelObj.setupSelendroidDriver(automationName, platformName, platformVersion, browserName,
            browserVersion, deviceName, appPackage, appActivity);
      */
 
      if (automationName.equalsIgnoreCase("PC"))
        stpPCObj.setupPCDriver(automationName, platformName, platformVersion, browserName,
            browserVersion, deviceName, appPackage, appActivity);

    } catch (Exception e) {
      log("error", "Exception Caught in setup function:" + e.getMessage());
    }
  }



}
