package com.automation.selenium;

import java.io.File;
import java.io.IOException;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class SettingsFile extends BaseClass {

  public void readSettingsFile() throws IOException {
    log("info", "Started reading the settings file.");

    Workbook settingsFile = null;
    try {
      settingsFile =
          Workbook.getWorkbook(new File(seleniumDir[0].replace("\\", "//")
              + "//ProjectFramework//Config//Settings.xls"));

      Sheet settingsSheet = settingsFile.getSheet(0);

      gs_closeBrowserAfterTest = settingsSheet.getCell(1, 2).getContents().trim(); // getCell(column,row)-index
                                                                                   // starts with
                                                                                   // (0,0)
      gs_sendEmailAfterTest = settingsSheet.getCell(1, 1).getContents().trim();
      gs_emailSMTP = settingsSheet.getCell(2, 1).getContents().trim();
      gs_emailAuth = settingsSheet.getCell(3, 1).getContents().trim();
      gs_emailFROM = settingsSheet.getCell(4, 1).getContents().trim();
      gs_emailTO = settingsSheet.getCell(5, 1).getContents().trim();
      gs_emailCC = settingsSheet.getCell(6, 1).getContents().trim();
      gs_emailSubject = settingsSheet.getCell(7, 1).getContents().trim();
      gs_testEnvironment = settingsSheet.getCell(8, 1).getContents().trim();

      gs_updateQCAfterTest = settingsSheet.getCell(1, 4).getContents().trim();
      gs_QCUrl = settingsSheet.getCell(2, 4).getContents().trim();
      gs_QCAuth = settingsSheet.getCell(3, 4).getContents().trim();
      gs_QCTestSet = settingsSheet.getCell(4, 4).getContents().trim();

      gs_dateTimeFormat = settingsSheet.getCell(1, 6).getContents().trim();
      gs_timeZone = settingsSheet.getCell(2, 6).getContents().trim();

      gs_cleanTestResultsFolder = settingsSheet.getCell(1, 8).getContents().trim();

      gs_runWebdriverOn = settingsSheet.getCell(1, 10).getContents().trim();

      gs_testSuiteToRun = settingsSheet.getCell(1, 12).getContents().trim();

      settingsFile.close();
      log("info", "Completed reading the settings file");

    } catch (BiffException e) {
      log("error", "Caught BiffException in readSettingsFile function:" + e.getMessage());
    } catch (IOException e) {
      log("error", "Caught IOException in readSettingsFile function:" + e.getMessage());
    } catch (Exception e) {
      log("error", "Caught Exception in readSettingsFile function:" + e.getCause());
    }
  }


}
