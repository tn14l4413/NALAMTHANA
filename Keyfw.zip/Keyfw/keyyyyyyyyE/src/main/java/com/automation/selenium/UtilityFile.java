package com.automation.selenium;

import java.io.File;
import java.io.IOException;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class UtilityFile extends BaseClass {

  DateTimeFunctions dtfObj = new DateTimeFunctions();
  CleanDirectory cdObj = new CleanDirectory();
  ObjectRepository orObj = new ObjectRepository();
  ExecuteTestScripts etsObj = new ExecuteTestScripts();

  public void ReadUtilFile(String language, String suiteType, String testEnvironment) throws Exception {

    {

      // PrintWriter pw = new PrintWriter(new FileWriter("E:/test.html"));
      // pw.println("<TABLE BORDER><TR><TH>Execute<TH>Keyword<TH>Object<TH>Action<Result></TR>");

      Workbook w1 = null;
      try {
        log("info", "Current Selenium dir-" + seleniumDir[0].replace("\\", "//"));
        w1 =
            Workbook.getWorkbook(new File(seleniumDir[0].replace("\\", "//")
                + "//ProjectFramework//Utility//Selenium_Utility.xls"));
      } catch (BiffException e) { // TODO Auto-generated catch block
        e.printStackTrace();
      } catch (IOException e) { // TODO Auto-generated catch block
        e.printStackTrace();
      }
      Sheet sheet = w1.getSheet(0);
      // TestSuite = sheet.getCell(1, 1).getContents();
      TestSuite = getTestSuiteFullPath(sheet.getCell(1, 1).getContents(), gs_testSuiteToRun);
      TestScript = sheet.getCell(1, 2).getContents();
      ObjectRepository = sheet.getCell(1, 3).getContents();
      ReportsPath = sheet.getCell(1, 6).getContents(); // Need to change to detailed report path-see
                                                       // below [check where its being used before
                                                       // renaming]
      TestReport = sheet.getCell(1, 5).getContents(); // Need to change to screen shot path-see
                                                      // below [check where its being used before
                                                      // renaming]
      summaryReportPath = sheet.getCell(1, 4).getContents();
      // screenShotReport = sheet.getCell(1, 5).getContents();
      // detailedReport = sheet.getCell(1, 6).getContents();


      executionStartTime = dtfObj.getDateTimeWithZone();

      /*
      if (gs_updateQCAfterTest.equalsIgnoreCase("Yes")) {
        QualityCenter qcObj = new QualityCenter();
        qcObj.connectToQC();
      }
     */

      if (gs_cleanTestResultsFolder.equalsIgnoreCase("Yes")) {

        log("info", "Started Cleaning TestResult Summary Folder.... ");
        cdObj.cleanFolder(new File(summaryReportPath));
        log("info", "Started Cleaning TestResult Detailed Folder....");
        cdObj.cleanFolder(new File(ReportsPath));
      }

      orObj.generateSharedORMAP();

      etsObj.FindExecTestscript(TestSuite, TestScript, ObjectRepository, language,  suiteType,  testEnvironment);
    }
  }


  public String getTestSuiteFullPath(String dir, String testSetName) throws Exception {
    String testSuiteFullPath = "";
    if (testSetName.contains(".xls") == false) testSetName = testSetName + ".xls";

    try {
      boolean matchFound = false;
      File testSuiteDir = new File(dir);
      if (testSuiteDir.listFiles().length == 0)
        throw new Exception("No Test Suite found in the directory-" + testSuiteDir.getPath());
      for (File file : testSuiteDir.listFiles()) {

        if (testSetName.equalsIgnoreCase("default.xls")) {
          log("info", "Using default Test Suite for execution:-" + file.getPath());
          testSuiteFullPath = file.getPath();
          matchFound = true;
          break;
        } else if (file.getName().equalsIgnoreCase(testSetName)) {
          log("info", "Match found.Using Test Suite for execution:-" + file.getPath());
          testSuiteFullPath = file.getPath();
          matchFound = true;
          break;
        }

        else {
          testSuiteFullPath = file.getPath();
        }
      }

      if (matchFound == false) {
        log("info", "Test Suite specified is not present. Using default Suite for execution:-"
            + testSuiteFullPath);
      }

    } catch (Exception e) {
      log("error", "Exception caught while cleaning folder.(" + e.getMessage() + ")");
    }

    return testSuiteFullPath;

  }


}






