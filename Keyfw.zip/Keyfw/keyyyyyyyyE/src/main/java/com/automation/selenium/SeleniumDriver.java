package com.automation.selenium;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;



public class SeleniumDriver extends BaseClass {
  @Parameters({"automationName", "platformName", "platformVersion", "browserName",
      "browserVersion", "language", "suiteType", "testEnvironment"})
  @BeforeTest(alwaysRun = true)
  public void startSetup(String automationName, String platformName, String platformVersion,
      String browserName, String browserVersion, String language, String suiteType,
      String testEnvironment) throws Exception {
    try {
      automationEnvironment = automationName;
      testRunEnvironment = testEnvironment;
      testRunLanguage = language;
      testExecutionType = suiteType;
      testExecutionBrowserName = browserName;
      EnvironmentSetup esObj = new EnvironmentSetup();
      esObj.setup(automationName, platformName, platformVersion, browserName, browserVersion,
    		  language, suiteType, testEnvironment);
    } catch (Exception e) {
      setUpSuccess = false;
      log("error",
          "Exception caught in StartSetUp function. Aborting the operation." + e.getMessage());
    }
  }

  @Parameters({"language", "suiteType", "testEnvironment"})
  @Test
  public void startExecution( String language, String suiteType, String testEnvironment) throws Exception {
    if (setUpSuccess) {
     log("info", "Language-suiteType-testEnviroment:" + language + " " + suiteType + " " + testEnvironment );	
      UtilityFile ufObj = new UtilityFile();
      ufObj.ReadUtilFile( language,  suiteType,  testEnvironment);
    }
  }


  @AfterTest
  public void cleanUpAfterExecution() throws Exception {
    if (setUpSuccess) {
      CloseFunction cfObj = new CloseFunction();
      cfObj.close();
    }
  }

}
