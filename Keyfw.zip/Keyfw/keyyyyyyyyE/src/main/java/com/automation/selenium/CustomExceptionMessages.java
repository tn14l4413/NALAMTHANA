package com.automation.selenium;

public class CustomExceptionMessages extends BaseClass {

  public String getErrorDescription(String exceptionMessage) {
    String customErrorMsg = "An Error occured during execution.";


    if (exceptionMessage.toLowerCase().contains("Timedout after 60 secs"))
      customErrorMsg = exceptionMessage;

    if (exceptionMessage.toLowerCase().contains("waiting for visibility of element located"))
      customErrorMsg = "Element not visible in the application.";

    if (exceptionMessage.toLowerCase().contains("waiting for element to be clickable"))
      customErrorMsg = "Element not clickable until the specified time.";

    if (exceptionMessage.toLowerCase().contains("unable to locate element")
        || exceptionMessage.toLowerCase().contains("unable to find element"))
      customErrorMsg = "Element not present in the application.";

    if (exceptionMessage.toLowerCase().contains("contentnotfoundinpage"))
      customErrorMsg = "The Text is not present in the application.";

    if (exceptionMessage.toLowerCase().contains("no such element"))
      customErrorMsg = "Element is not present in the application.";

    if (exceptionMessage.toLowerCase().contains("objectlocatornotfoundinor"))
      customErrorMsg = "Object locator NOT Found in Shared/Script OR";

    if (exceptionMessage.toLowerCase().contains("invalidobjectlocatorinor"))
      customErrorMsg =
          "Object Locator is wrong or not supported. Supported Locators are Id,Name,LinkText,PartialLinkText,Xpath & CSS";


    if (exceptionMessage.toLowerCase().contains("syntaxerrorinorlocator"))
      customErrorMsg =
          "Syntax Error in Object Locator. Locator should contain '=='. Please rectify the OR Spreadsheet. ";

    return customErrorMsg;
  }
}
