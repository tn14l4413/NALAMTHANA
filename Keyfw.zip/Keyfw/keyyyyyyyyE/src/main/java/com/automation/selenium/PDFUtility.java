package com.automation.selenium;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.pdfbox.cos.COSDocument;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;
import org.openqa.selenium.By;
import org.testng.Assert;

public class PDFUtility extends BaseClass {

 
	
	public void verifyPDFTextInBrowser() {
		
		D8.get("http://www.princexml.com/samples/");
		D8.findElement(By.linkText("PDF flyer")).click();
		Assert.assertTrue(verifyPDFContent(D8.getCurrentUrl(), "Prince Cascading"));
	}

	

	public void verifyPDFInURL() {
		D8.get("http://www.princexml.com/samples/");
		D8.findElement(By.linkText("PDF flyer")).click();
		String getURL = D8.getCurrentUrl();
		Assert.assertTrue(getURL.contains(".pdf"));
	}

	
	public boolean verifyPDFContent(String strURL, String reqTextInPDF) {
		
	    	boolean flag = false;
			
			PDFTextStripper pdfStripper = null;
			PDDocument pdDoc = null;
			COSDocument cosDoc = null;
			String parsedText = null;

			try {
				URL url = new URL(strURL);
				
				File file = new File("C:\\Users\\rchanda\\Desktop\\36199454_Prospectus_18 January 2017.pdf");
				PDFParser parser = new PDFParser(new FileInputStream(file));
				
				//BufferedInputStream file = new BufferedInputStream(url.openStream());
				//PDFParser parser = new PDFParser(file);
				
				parser.parse();
				cosDoc = parser.getDocument();
				pdfStripper = new PDFTextStripper();
				pdfStripper.setStartPage(1);
				pdfStripper.setEndPage(1);
				
				pdDoc = new PDDocument(cosDoc);
				parsedText = pdfStripper.getText(pdDoc);
			
			
		} catch (MalformedURLException e2) {
			log("error","URL string could not be parsed "+e2.getMessage());
		} catch (IOException e) {
			log("error","Unable to open PDF Parser. " + e.getMessage());
			try {
				if (pdDoc != null)
					pdDoc.close();
			} catch (Exception e1) {
				log("error","Exception closing the pdf stream:" + e1.getMessage());
			}
		}
		
		log("debug","----------------------PDF CONTENT BEGIN------------------------------------------");
		log("debug",parsedText);
		log("debug","----------------------PDF CONTENT END------------------------------------------");

		if(parsedText.contains(reqTextInPDF)) {
			flag=true;
		}
		
		return flag;
	}
	

}


