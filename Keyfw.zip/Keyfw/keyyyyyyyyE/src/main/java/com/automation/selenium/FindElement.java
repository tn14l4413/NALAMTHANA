package com.automation.selenium;

import org.openqa.selenium.By;

public class FindElement extends BaseClass {
  ObjectRepository orObj = new ObjectRepository();

  public void Func_FindObj(String strObjtype, String strObjpath) throws Exception {
    log("info", "Searching AUT for test object using Node{" + strObjtype + "} and value{"
        + strObjpath + "}.");
    if (strObjtype.equalsIgnoreCase("id")) {
      elem = D8.findElement(By.id(strObjpath));
    } else if (strObjtype.equalsIgnoreCase("name")) {
      elem = D8.findElement(By.name(strObjpath));
    } else if (strObjtype.equalsIgnoreCase("xpath")) {
      elem = D8.findElement(By.xpath(strObjpath));
    } else if (strObjtype.equalsIgnoreCase("linktext")) {
      elem = D8.findElement(By.linkText(strObjpath.toString()));
    } else if (strObjtype.equalsIgnoreCase("css")) {
      elem = D8.findElement(By.cssSelector(strObjpath));
    } else if (strObjtype.equalsIgnoreCase("class")) {
      elem = D8.findElement(By.className(strObjpath));
    } else if (strObjtype.equalsIgnoreCase("tag")) {
      elem = D8.findElement(By.tagName(strObjpath));
    } else if (strObjtype.equalsIgnoreCase("partiallinktext")) {
      elem = D8.findElement(By.partialLinkText(strObjpath));
    } else {
      throw new Exception("InvalidObjectLocatorInOR");
    }
  }

  public int getElementCount(String strObjtype, String strObjpath) throws Exception {
	    log("info", "Searching AUT for test object using Node{" + strObjtype + "} and value{"
	        + strObjpath + "}.");
	    if (strObjtype.equalsIgnoreCase("id")) {
	      return D8.findElements(By.id(strObjpath)).size();
	    } else if (strObjtype.equalsIgnoreCase("name")) {
	      return  D8.findElements(By.name(strObjpath)).size();
	    } else if (strObjtype.equalsIgnoreCase("xpath")) {
	      return  D8.findElements(By.xpath(strObjpath)).size();
	    } else if (strObjtype.equalsIgnoreCase("linktext")) {
	    	return  D8.findElements(By.linkText(strObjpath.toString())).size();
	    } else if (strObjtype.equalsIgnoreCase("css")) {
	    	return  D8.findElements(By.cssSelector(strObjpath)).size();
	    } else if (strObjtype.equalsIgnoreCase("class")) {
	    	return  D8.findElements(By.className(strObjpath)).size();
	    } else if (strObjtype.equalsIgnoreCase("tag")) {
	    	return  D8.findElements(By.tagName(strObjpath)).size();
	    } else if (strObjtype.equalsIgnoreCase("partiallinktext")) {
	    	return  D8.findElements(By.partialLinkText(strObjpath)).size();
	    } else {
	      throw new Exception("InvalidObjectLocatorInOR");
	    }
	  }
  
  
  public void parseAndFindElement(String objectDetails) throws Exception {
    String ObjectVal = "";

    if (objectDetails.contains(";") == false) {
      ObjectVal = objectDetails.trim();
    } else {
      String[] cCellDataVal = objectDetails.split(";");
      ObjectVal = cCellDataVal[1].trim();
    }

    String getObjectLocatorString = orObj.getObjectLocator(ObjectVal);

    if (getObjectLocatorString == null) {

      throw new Exception("ObjectLocatorNotFoundInOR");
    } else {

      if (getObjectLocatorString.contains("==") == false) {
        throw new Exception("SyntaxErrorInORLocator");
      }

      String[] objectLocatorDetails = getObjectLocatorString.split("==");
      ORvalname = objectLocatorDetails[0];
      ORvalue = objectLocatorDetails[1];
      Func_FindObj(ORvalname, ORvalue);
    }
  }

}
