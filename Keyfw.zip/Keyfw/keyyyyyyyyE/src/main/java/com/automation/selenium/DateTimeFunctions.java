package com.automation.selenium;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class DateTimeFunctions extends BaseClass {


  public String getSystemVariable(String value) {
    String sysVariable = value.toUpperCase();
    String retValue = "";
    String retValue1 = "";

    switch (sysVariable) {

      case "$$CURRDATETIME":
        DateFormat cpyDateFormat = new SimpleDateFormat("MM-dd-yyyy-HH-mm-ss");
        Date cpyDate = new Date();
        retValue = cpyDateFormat.format(cpyDate);
        break;

      case "$$TODAYSDATE":
          DateFormat currDateFormat = new SimpleDateFormat("MM/dd/yyyy");
          Date currDate = new Date();
          retValue = currDateFormat.format(currDate);
          break;
          
      case "$$FIRSTDATEOFMONTH":
          DateFormat firstDateFormat = new SimpleDateFormat("MM/dd/yyyy");
          Calendar date = Calendar.getInstance();
          date.set(Calendar.DAY_OF_MONTH, 1);
          retValue = firstDateFormat.format(date.getTime());
          break;
          
      case "$$TODAY (DD MMM YYYY)":
          DateFormat cpyDateFormat1;
          if(testRunLanguage.equalsIgnoreCase("FRE")) {
        	  cpyDateFormat1 = new SimpleDateFormat("dd MMMM YYYY", Locale.CANADA_FRENCH);
          }else {
          cpyDateFormat1 = new SimpleDateFormat("dd MMMM YYYY");
          }
          
          Date cpyDate1 = new Date();
          retValue = cpyDateFormat1.format(cpyDate1);
          
          if(testRunLanguage.equalsIgnoreCase("FRE")) {
        	  retValue = "Jour m�me (" + retValue + ")";
          }else {
        	  retValue = "Today (" + retValue + ")";
          }
          
          break;
          
      case "$$UPDATEON(MMM DD, YYYY)":
          DateFormat cpyDateFormat2;
          if(testRunLanguage.equalsIgnoreCase("FRE")) {
        	  cpyDateFormat2 = new SimpleDateFormat("MMM DD, YYYY", Locale.CANADA_FRENCH);
          }else {
          cpyDateFormat2 = new SimpleDateFormat("MMM DD, YYYY");
          }
          
          log("info", "RETURN VALUE"+retValue1);
          
          Date cpyDate2 = new Date();
          retValue1 = cpyDateFormat2.format(cpyDate2);
          log("info", "RETURN VALUE 1"+retValue1);
          if(testRunLanguage.equalsIgnoreCase("FRE")) {
        	  retValue1 = "Mis � jour le " + retValue1 + "";
          }else {
        	  retValue1 = "Update on " + retValue1 + "";
          }
          log("info", "RETURN VALUE 2"+retValue1);
          
          break;
     
      default:
        retValue = sysVariable;
        break;
    }

    return retValue;
  }

  public String getCurrFormattedTimestamp() throws Exception {
    cur_dt = new Date();
    DateFormat dateFormat = new SimpleDateFormat("yyyy-MMM-dd-HH-mm-ss");
    String strTimeStamp = dateFormat.format(cur_dt);
    return strTimeStamp;
  }


  public String getDateTimeWithZone() throws Exception {
    String dateTimeWithZone = "";
    try {

      DateFormat formatter = new SimpleDateFormat(gs_dateTimeFormat);
      TimeZone tz = TimeZone.getTimeZone(gs_timeZone);
      formatter.setTimeZone(tz);

      Date temp_dt = new Date();
      dateTimeWithZone = formatter.format(temp_dt);
    } catch (Exception e) {
      log("error", "Exception Caught in getDateTimeWithZone function:" + e.getMessage());
    }


    return dateTimeWithZone;
  }

  public String getElapsedTime(String startDate, String endDate) throws Exception {
    String elapsedTime = "";

    try {

      double elapsedTimeInSecs = 0;
      double elapsedHours = 0;
      double elapsedMins = 0;
      double elapsedSecs = 0;

      DateFormat formatter = new SimpleDateFormat(gs_dateTimeFormat);
      Date begin = (Date) formatter.parse(startDate);
      Date end = (Date) formatter.parse(endDate);


      elapsedTimeInSecs = (end.getTime() - begin.getTime()) / 1000;
      log("info", "Total Elapsed time in secs=" + elapsedTimeInSecs);

      if (elapsedTimeInSecs >= 3600) {
        elapsedHours = Math.floor(elapsedTimeInSecs / 3600);
        elapsedMins = Math.floor((elapsedTimeInSecs % 3600) / 60);
        elapsedSecs = (elapsedTimeInSecs % 3600) % 60;// something wrong here....
      }

      else if (elapsedTimeInSecs >= 60) {
        elapsedMins = Math.floor(elapsedTimeInSecs / 60);
        elapsedSecs = elapsedTimeInSecs % 60;
      } else {
        elapsedSecs = elapsedTimeInSecs;
      }


      elapsedTime =
          (int) elapsedHours + " Hr(s) " + (int) elapsedMins + " Min(s) " + (int) elapsedSecs
              + " Sec(s).";



    } catch (Exception e) {
      log("error", "Exception Caught in getElapsedTime function:" + e.getMessage());
    }
    return elapsedTime;
  }

}
