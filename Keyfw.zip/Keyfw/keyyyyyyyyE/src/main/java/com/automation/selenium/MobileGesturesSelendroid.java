package com.automation.selenium;

import org.openqa.selenium.interactions.touch.TouchActions;

public class MobileGesturesSelendroid extends BaseClass {
  public void executeMobileGesturesInSelendroid() {
    switch (dCellData.toLowerCase().trim()) {
      case "tap":
        break;
      case "swipeleft":
        break;
      case "swiperight":
        TouchActions swiperight = new TouchActions(D8).flick(elem, -100, 0, 0);
        swiperight.perform();
        break;
      case "flick":
        break;
      case "scroll":
        break;
      case "doubletap":
        break;
      default:
        break;
    }
  }
}
