package com.automation.selenium;

import java.io.File;

public class CleanDirectory extends BaseClass {

  public void cleanFolder(File dir) throws Exception {
    try {
      for (File file : dir.listFiles()) {
        if (file.isDirectory()) cleanFolder(file);
        file.delete();
        log("info", "Deleted " + file.getPath());
      }

    } catch (Exception e) {
      log("error", "Exception caught while cleaning folder.(" + e.getMessage() + ")");
    }
  }
}
