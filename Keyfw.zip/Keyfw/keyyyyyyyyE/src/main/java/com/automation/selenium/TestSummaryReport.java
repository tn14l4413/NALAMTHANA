package com.automation.selenium;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TestSummaryReport extends BaseClass {

  DateTimeFunctions dtfObj = new DateTimeFunctions();
  TestEnvInfoReport tirObj = new TestEnvInfoReport();



  public void createSummaryRptHeader() throws Exception {
    String sysInfoPathLink = tirObj.createSysInfoReport();
    cur_dt = new Date();
    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
    String strTimeStamp = dateFormat.format(cur_dt);


    if (summaryReportPath.endsWith("\\")) { // checks whether the path ends with
      // '/'
      summaryReportPath = summaryReportPath + "\\";
    }
    strSummaryReportPath = summaryReportPath + "/";
    summaryReportHTML = summaryReportPath + "TestSummaryReport_" 
    		 + testExecutionType  + "_"
    		 + testRunEnvironment + "_"
    		 +  testExecutionBrowserName + "_"
    		 +  testRunLanguage + "_"
	     	 + strTimeStamp + ".html";
    
    
    // summaryReportHTML = summaryReportPath + "/" +"TestSummaryReport@" + strTimeStamp + ".html";
    // File f1 = new File(strSummaryReportPath);
    // f1.mkdirs();
    bwSummaryRpt = new BufferedWriter(new FileWriter(summaryReportHTML));
    bwSummaryRpt
        .write("<!DOCTYPE HTML>"
            + "<HEAD> <link type=\"text/css\" href=../css/reports-style-sheet.css rel=\"stylesheet\"/>  </HEAD>"
            + "<BODY><SCRIPT language='javascript' type='text/javascript'> function showSysInfo(url){ newwindow=window.open(url,'System Info','height=350,width=350,top=200,left=400,resizable=no,status=no,menubar=no,toolbar=no,location=no'); return false;  }</SCRIPT>");

    bwSummaryRpt.write("<TABLE class=\"summ-rpt-main-header-tbl\" >");
    bwSummaryRpt
        .write("<TR><TD><P class=\"para-summ-rpt-main-header-tbl\">Test Result Summary Report</P></TD></TR>");
    bwSummaryRpt.write("</TABLE>");



    bwSummaryRpt.write("<TABLE class=\"summ-rpt-sub-header-tbl\" >");
    bwSummaryRpt.write("<TR><TD id=srsh-tsn>Test Suite Name:</TD> " + "<TD id=srsh-ts>" + TestSuite
        + "</TD>" + "<TD><A id=srsh-tenvl href='' target = '' onclick= showSysInfo('"
        + sysInfoPathLink + "')> Test Env Info </A>" + "</TD>");
    bwSummaryRpt.write("</TR></TABLE>");


    bwSummaryRpt.write("<TABLE class=\"summ-rpt-columns-header-tbl\" >");
    //bwSummaryRpt.write("<TR><TD id=srch-sno> Script.No</TD>" + "<TD id=srch-sn> Script Name</TD>"
    //    + "<TD id=srch-et> Execution Time</TD>" + "<TD id=srch-st> Status</TD>" + "</TR></TABLE>");
    
    bwSummaryRpt.write("<TR><TD id=srch-sno> Script.No</TD>" 
    		//+ "<TD id=srch-sn> Package</TD>"
    		+ "<TD id=srch-sn> Test ID</TD>"
            //+ "<TD id=srch-sn> TestDataID</TD>"
            + "<TD id=srch-et> Execution Time</TD>" 
            + "<TD id=srch-st> Status</TD>" + "</TR></TABLE>");

    bwSummaryRpt.write("<TABLE class=\"summ-rpt-body-tbl\" >");
  }

  public void createSummaryRptFooter() throws Exception {

    bwSummaryRpt.write("</TABLE>"); // closing the summ-rpt-body-tbl
    bwSummaryRpt.write("<TABLE class=\"summ-rpt-footer-tbl\" >");
    bwSummaryRpt
        .write("<TR><TD id=srf-ebt><span id=srf-ebtl> Execution Begin Time: </span><span id=srf-ebtd>"
            + executionStartTime + "</span></TD>");
    bwSummaryRpt
        .write("<TD id=srf-eet><span id=srf-eetl>Execution End Time: </span><span id=srf-eetd>"
            + executionEndTime + "</span></TD>");
    bwSummaryRpt
        .write("<TD id=srf-tet><span id=srf-tetl>Total Execution Time: </span><span id=srf-tetd>"
            + totalExecutionTime + "</span></TD></TR>");
    bwSummaryRpt.write("</TABLE>");

  }



  public void updateSummaryReport(String TSName, String Res_type) throws IOException {
    try {

      String str_time = dtfObj.getDateTimeWithZone();
      String dtlRtpObsletePath[] = detailHTMLReport.split("TestResults");

      if (Res_type.startsWith("executed")) {
        testResultsMap.put(TSName, "Passed");
        totalScriptsPassed++;

        bwSummaryRpt.write("<TR><TD id=srb-sno>" + scriptNum + "</TD>"
        	//+ "<TD id=srb-et>" + "TODO" + "</TD>"	
            + "<TD id=srb-sn><A class=\"det-rpt-link\" HREF=.."
            + dtlRtpObsletePath[1].replace("//", "/") + ">" + testExecutionFunctionality + "-" + TSName + "-" + testExecutionTestDataID + "</A></TD>"
            //+ "<TD id=srb-et>" + "TODO" + "</TD>"	
            + "<TD id=srb-et>" + str_time + "</TD>" + "<TD id=srb-st-p> Passed </TD></TR>");

        /*
        if (gs_updateQCAfterTest.equalsIgnoreCase("yes")) {
          QualityCenter qcObj = new QualityCenter();
          qcObj.updateTestResultInQC(TSName, "Passed");
        }
        */

      } else if (Res_type.startsWith("failed")) {
        testResultsMap.put(TSName, "Failed");
        totalScriptsFailed++;

        bwSummaryRpt.write("<TR><TD id=srb-sno>" + scriptNum + "</TD>"
        	//+ "<TD id=srb-et>" + "TODO" + "</TD>"		
            + "<TD id=srb-sn><A class=\"det-rpt-link\" HREF=.."
            + dtlRtpObsletePath[1].replace("//", "/") + ">" + testExecutionFunctionality + "-" + TSName +  "-" + testExecutionTestDataID +  "</A></TD>"
           // + "<TD id=srb-et>" + "TODO" + "</TD>"	
            + "<TD id=srb-et>" + str_time + "</TD>" + "<TD id=srb-st-f> Failed </TD></TR>");

        /*
        if (gs_updateQCAfterTest.equalsIgnoreCase("yes")) {
          QualityCenter qcObj = new QualityCenter();
          qcObj.updateTestResultInQC(TSName, "Failed");
        }
        */

      }

    } catch (Exception e) {
      log("error", "DEBUG:Exception caught in updateSummaryReport function:" + e.getMessage());
    }
  }

}
