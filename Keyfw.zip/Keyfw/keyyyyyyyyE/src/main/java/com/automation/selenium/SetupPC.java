package com.automation.selenium;

import java.io.File;
import java.net.URL;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;

//import com.opera.core.systems.OperaDriver;

public class SetupPC extends BaseClass {
  MiscFunctions mfObj = new MiscFunctions();

  public void setupPCDriver(String automationName, String platformName, String platformVersion,
      String browserName, String browserVersion, String deviceName, String appPackage,
      String appActivity) throws Exception {
    try {
      log("info", "Started setting up PC webdriver.....");
      DesiredCapabilities caps = new DesiredCapabilities();
      // Platforms
      if (platformName.equalsIgnoreCase("Windows"))
        caps.setPlatform(org.openqa.selenium.Platform.WINDOWS);
      if (platformName.equalsIgnoreCase("MAC")) caps.setPlatform(org.openqa.selenium.Platform.MAC);

      // Browsers
      if (browserName.equalsIgnoreCase("Internet Explorer")) {
        caps = DesiredCapabilities.internetExplorer();
        caps.setCapability(InternetExplorerDriver.UNEXPECTED_ALERT_BEHAVIOR,
            org.openqa.selenium.UnexpectedAlertBehaviour.IGNORE);

        if (gs_runWebdriverOn.equalsIgnoreCase("local")) {
          System.setProperty("webdriver.ie.driver", mfObj.getFullPathOfSoftware("IEDriverServer"));
          D8 = new InternetExplorerDriver(caps);
          
        }
      }

      if (browserName.equalsIgnoreCase("Edge")) {
          
          if (gs_runWebdriverOn.equalsIgnoreCase("local")) {
            System.setProperty("webdriver.edge.driver", mfObj.getFullPathOfSoftware("MicrosoftWebDriver"));
            D8 = new EdgeDriver();
            
          }
        }
      
      if (browserName.equalsIgnoreCase("Firefox")) {

    	  //File pathBinary = new File("C:\\program files\\Mozilla Firefox\\firefox.exe");
    	  //FirefoxBinary firefoxBinary = new FirefoxBinary(pathBinary);
    	  
        caps = DesiredCapabilities.firefox();
        /*
         * ProfilesIni profile = new ProfilesIni(); FirefoxProfile ffprofile =
         * profile.getProfile("default"); caps.setCapability(FirefoxDriver.PROFILE,
         * ffprofile.toString()); caps.setCapability("profile", ffprofile);
         */
        caps.setCapability("unexpectedAlertBehaviour", "ignore");

        if (gs_runWebdriverOn.equalsIgnoreCase("local")) {
          System.setProperty("webdriver.firefox.bin","C:\\program files\\Mozilla Firefox\\firefox.exe");
          System.setProperty("webdriver.firefox.profile", "default");
          System.setProperty("webdriver.firefox.logfile", seleniumDir[0]
              + "\\ProjectFramework\\Logs\\FF-log.txt");
          D8 = new FirefoxDriver(caps);
        }
      }

      if (browserName.equalsIgnoreCase("Safari")) {
        caps = DesiredCapabilities.safari();
        // caps.setCapability(SafariDriver.DATA_DIR_CAPABILITY,true);

        if (gs_runWebdriverOn.equalsIgnoreCase("local")) {
          D8 = new SafariDriver(caps);
        }
      }

      /*
      if (browserName.equalsIgnoreCase("Opera")) {
        caps = DesiredCapabilities.opera();
        caps.setCapability("opera.launcher", "<path-to>\\launcher.exe");
        caps.setCapability("opera.binary", "<path-to>\\opera.exe");

        if (gs_runWebdriverOn.equalsIgnoreCase("local")) {
          D8 = new OperaDriver(caps);
        }
      }
     */
      
      if (browserName.equalsIgnoreCase("Chrome")) {

        caps = DesiredCapabilities.chrome();

        if (gs_runWebdriverOn.equalsIgnoreCase("local")) {
          System
              .setProperty("webdriver.chrome.driver", mfObj.getFullPathOfSoftware("chromedriver"));
          ChromeOptions chromeOptions = new ChromeOptions();
          //chromeOptions.addArguments("mark-non-secure-as=show-non-secure-passwords-cc-ui");
          //chromeOptions.addArguments("user-data-dir=C:\\selenium\\chromeprofile");
          caps.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
          D8 = new ChromeDriver(caps);
        }
      }

      // Version
      // caps.setVersion(version);

      if (gs_runWebdriverOn.equalsIgnoreCase("remote")) {
        D8 = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), caps);
        log("info", "Selenium hub started successfully @ http://localhost:4444/wd/hub ");
      }

      D8.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
      D8.manage().window().maximize(); // Window handling not supported for Android
      D8.manage().timeouts().pageLoadTimeout(300, TimeUnit.SECONDS); //pageload timeout not
      // supported
      // for Safari.
      parentWindow = D8.getWindowHandle();

    } catch (Exception e) {
      setUpSuccess = false;
      log("error", "Exception caught while setting up the PC Browser:" + e.getMessage());
    }
  }
}
