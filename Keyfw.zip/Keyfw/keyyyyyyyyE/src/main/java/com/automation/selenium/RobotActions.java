package com.automation.selenium;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

public class RobotActions extends BaseClass {


  public void copyAndPaste(String value) throws Exception {
    Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
    StringSelection stringSelection = new StringSelection(value);
    clipboard.setContents(stringSelection, null);

    Robot robot = new Robot();
    robot.keyPress(KeyEvent.VK_CONTROL);
    robot.keyPress(KeyEvent.VK_V);
    robot.keyRelease(KeyEvent.VK_V);
    robot.keyRelease(KeyEvent.VK_CONTROL);
  }

  public void robotSendKey(String value) throws Exception {
    Robot robot = new Robot();
    String keysToSendString = value.toUpperCase();
    log("info", "Keys to send in uppper case: " + keysToSendString);

    String[] keysToSend = keysToSendString.split("\\+"); // + is a special character which denotes a
                                                         // quantifier meaning one of more
                                                         // occurrences. Therefore it should be
                                                         // escaped to specify the literal character
    log("info", "Keys to send array length " + keysToSend.length);

    for (int index = 0; index < keysToSend.length; index++) {
      if (keysToSend[index].trim().equalsIgnoreCase("ENTER")) robot.keyPress(KeyEvent.VK_ENTER);
      if (keysToSend[index].trim().equalsIgnoreCase("TAB")) robot.keyPress(KeyEvent.VK_TAB);
      if (keysToSend[index].trim().equalsIgnoreCase("CTRL")) robot.keyPress(KeyEvent.VK_CONTROL);
      if (keysToSend[index].trim().equalsIgnoreCase("ALT")) robot.keyPress(KeyEvent.VK_ALT);
      if (keysToSend[index].trim().equalsIgnoreCase("SHIFT")) robot.keyPress(KeyEvent.VK_SHIFT);
      if (keysToSend[index].trim().length() == 1)
        robot.keyPress(keysToSend[index].trim().charAt(0));
    }

    for (int index = keysToSend.length - 1; index >= 0; index--) {
      if (keysToSend[index].trim().equalsIgnoreCase("ENTER")) robot.keyRelease(KeyEvent.VK_ENTER);
      if (keysToSend[index].trim().equalsIgnoreCase("TAB")) robot.keyRelease(KeyEvent.VK_TAB);
      if (keysToSend[index].trim().equalsIgnoreCase("CTRL")) robot.keyRelease(KeyEvent.VK_CONTROL);
      if (keysToSend[index].trim().equalsIgnoreCase("ALT")) robot.keyRelease(KeyEvent.VK_ALT);
      if (keysToSend[index].trim().equalsIgnoreCase("SHIFT")) robot.keyRelease(KeyEvent.VK_SHIFT);
      if (keysToSend[index].trim().length() == 1)
        robot.keyRelease(keysToSend[index].trim().charAt(0));
    }


  }

}
