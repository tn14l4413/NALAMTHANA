package com.automation.selenium;

import java.io.BufferedWriter;
import java.io.FileWriter;

public class TestDetailedReport extends BaseClass {

  DateTimeFunctions dtfObj = new DateTimeFunctions();
  ScreenShot ssObj = new ScreenShot();


  public void createDetailedRptHeader(String tcName) throws Exception {


    bw = new BufferedWriter(new FileWriter(detailHTMLReport));
    bw.write("<!DOCTYPE HTML>"
        + "<HEAD> <link type=\"text/css\" href=../../../css/reports-style-sheet.css rel=\"stylesheet\"/>  </HEAD>"
        + "<BODY><A class=\"back-to-summ-rpt-link\" HREF=javascript:history.back()>Back to Summary Report</A>");


    bw.write("<TABLE class=\"det-rpt-main-header-tbl\" >");
    bw.write("<TR><TD><P class=\"para-det-rpt-main-header-tbl\">Test Result Detailed Report</P></TD></TR>");
    bw.write("</TABLE>");


    bw.write("<TABLE class=\"det-rpt-sub-header-tbl\" >");
    bw.write("<TR><TD id=drsh-tcnl>Test ID :</TD>" + "<TD id=drsh-tcnd>" + testExecutionFunctionality + "-" + testExecutionTestcaseID + "-" + testExecutionTestDataID + "</TD>"
        + "</TR></TABLE>");

    bw.write("<TABLE  class=\"det-rpt-column-header-tbl\" >");
    bw.write("<TR><TD id=drch-row> Step No.</TD>"
        +
        // "<TD id=drch-kw> Keyword</TD>" +
        // "<TD id=drch-obj> Object</TD>" +
        // "<TD id=drch-act> Action</TD>" +
        "<TD id=drch-desc> Step Description</TD>" + "<TD id=drch-et> Execution Time</TD>"
        + "<TD id=drch-st> Status</TD>" + "</TR></TABLE>");

    bw.write("<TABLE class=\"det-rpt-body-tbl\" >");

  }

  public void Update_Report(String Res_type) throws Exception {
    String str_time = dtfObj.getDateTimeWithZone();

    if ((cCellData.toLowerCase().contains("password"))
        && (dCellData.toLowerCase().contains("set:"))) {
      // mask the dCellData to hide password from report.
      dCellData = "set:*******";
    }

    fCellData = fCellData.replace("%RUNTIMEVALUE%", runTimeValue);
    stepNo++;

    if (Res_type.startsWith("executed")) {
      String printMsg[] = Res_type.split("Prt_Msg");
      if (printMsg.length > 1) {
        dCellData = dCellData + "(" + printMsg[1] + ")";
      }

      bw.write("<TR><TD id=drb-row>"
          + stepNo
          + "</TD>"
          // + "<TD id=drb-kw>" + Action + "</TD>"
          // + "<TD id=drb-obj>" + cCellData + "</TD>"
          // + "<TD id=drb-act>" + dCellData + "</TD>"
          + "<TD id=drb-desc>" + fCellData + "</TD>" + "<TD id=drb-et>" + str_time + "</TD>"
          + "<TD id=drb-st-p>" + "Passed" + "</TD>" + "</TR>");

    } else if (Res_type.startsWith("failed")) {
      String failScreenshotLink = ssObj.screenshotLink(loopnum, TScrowcount, TScname);
      String failScreenshotObseletePath[] = failScreenshotLink.split("Screenshots");
      if (errorDesc == "") {
        String errMsg[] = Res_type.split("Prt_Msg");
        errorDesc = errMsg[1];
      }

      bw.write("<TR><TD id=drb-row>"
          + stepNo
          + "</TD>"
          // + "<TD id=drb-kw>" + Action + "</TD>"
          // + "<TD id=drb-obj>" + cCellData + "</TD>"
          // + "<TD id=drb-act>" + dCellData + "</TD>"
          + "<TD id=drb-desc>" + fCellData + "</TD>" + "<TD id=drb-et>" + str_time + "</TD>"
          + "<TD id=drb-st-f><A class=\"det-rpt-failed-link\" TARGET=_BLANK HREF=../Screenshots"
          + failScreenshotObseletePath[1].replace("//", "/") + ">" + "Failed" + "</A></TD></TR>");
      bw.write("<TR><TD id=drb-info-row-fail colspan=6><span id=drb-fail-icon>X </span> <span id=drb-fail-msg>Reason for Failure @ step"
          + (stepNo) + ": " + errorDesc + "</span></TD></TR>");

    } else if (Res_type.startsWith("loop")) {

      bw.write("<TR><TD id=drb-info-row-loop colspan=6><span id=drb-loop-icon>X </span><span id=drb-loop-msg>"
          + Res_type + "</span></TD></TR>");

    } else if (Res_type.startsWith("missing")) {

      bw.write("<TR><TD id=drb-row>"
          + stepNo
          + "</TD>"
          // + "<TD id=drb-kw>" + Action + "</TD>"
          // + "<TD id=drb-obj>" + cCellData + "</TD>"
          // + "<TD id=drb-act>" + dCellData + "</TD>"
          + "<TD id=drb-desc>" + fCellData + "</TD>" + "<TD id=drb-et>" + str_time + "</TD>"
          + "<TD id=drb-st-m>" + "Failed" + "</TD></TR>");
      bw.write("<TR><TD id=drb-info-row-miss colspan=6><span id=drb-missing-icon>X </span><span id=drb-missing-msg>Error Occurred in Keyword test step number "
          + (stepNo) + ".Description: The Datatable column name not found</span></TD></TR>");

    } else if (Res_type.startsWith("ObjectLocator")) {

      bw.write("<TR><TD id=drb-row>"
          + stepNo
          + "</TD>"
          // + "<TD id=drb-kw>" + Action + "</TD>"
          // + "<TD id=drb-obj>" + cCellData + "</TD>"
          // + "<TD id=drb-act>" + dCellData + "</TD>"
          + "<TD id=drb-desc>" + fCellData + "</TD>" + "<TD id=drb-et>" + str_time + "</TD>"
          + "<TD id=drb-st-ol>" + "Failed" + "</TD></TR>");
      bw.write("<TR><TD id=drb-info-row-ol colspan=6><span id=drb-ol-icon>X </span><span id=drb-ol-msg>Error Occurred in Keyword test step number "
          + (stepNo)
          + ".Description: Object Locator is wrong or not supported. Supported Locators are Id,Name,LinkText,PartialLinkText,Xpath & CSS</span></TD></TR>");

    } else if (Res_type.startsWith("skipped")) {

      bw.write("<TR><TD id=drb-row>"
          + stepNo
          + "</TD>"
          // + "<TD id=drb-kw>" + Action + "</TD>"
          // + "<TD id=drb-obj>" + cCellData + "</TD>"
          // + "<TD id=drb-act>" + dCellData + "</TD>"
          + "<TD id=drb-desc>" + fCellData + "</TD>" + "<TD id=drb-et>" + str_time + "</TD>"
          + "<TD id=drb-st-skip>" + "Skipped" + "</TD></TR>");
      bw.write("<TR><TD id=drb-info-row-ol colspan=6><span id=drb-ol-icon>X </span><span id=drb-ol-msg>Warning! Keyword @ test step number "
          + (stepNo) + " is Invalid.Please rectify the test script.</span></TD></TR>");
   
    } else if (Res_type.startsWith("takescreenshot")) {
        String takeScreenshotLink = ssObj.screenshotLink(loopnum, TScrowcount, TScname);
        String takeScreenshotObseletePath[] = takeScreenshotLink.split("Screenshots");
        
        bw.write("<TR><TD id=drb-row>"
            + stepNo
            + "</TD>"
            // + "<TD id=drb-kw>" + Action + "</TD>"
            // + "<TD id=drb-obj>" + cCellData + "</TD>"
            // + "<TD id=drb-act>" + dCellData + "</TD>"
            + "<TD id=drb-desc>" + fCellData + "</TD>" + "<TD id=drb-et>" + str_time + "</TD>"
            + "<TD id=drb-st-f><A TARGET=_BLANK HREF=../Screenshots"
            + takeScreenshotObseletePath[1].replace("//", "/") + ">" + "Screenshot" + "</A></TD></TR>");
      
      }
    
    
  }


}
