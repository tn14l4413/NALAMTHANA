/**
 * FileName   : ScreenShot.java
 * LastUpdated: 17-Aug-2014.
 * Description: Collections of methods to handle taking screenshots of the AUT.
 */
package com.automation.selenium;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.Augmenter;

public class ScreenShot extends BaseClass {
  /**
   * Function is used to take screenshot of a step.
   * @param loopn
   * @param rown
   * @param Sname
   * @throws Exception
   */
  	
  public void screenshot(int loopn, int rown, String Sname) throws Exception {
    try {
      DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
      Date date = new Date();
      String strTime = dateFormat.format(date);

      if (gs_runWebdriverOn.equalsIgnoreCase("remote")
          || automationEnvironment.equalsIgnoreCase("Appium")) {
        D8 = new Augmenter().augment(D8);
      }

      File screenshot = ((TakesScreenshot) D8).getScreenshotAs(OutputType.FILE);
      //String filenamer = TestReport + Sname + "_" + loopn + "_" + (j + 1) + "_" + strTime + ".png";
      String filenamer = TestReport + "/" + testExecutionFunctionality + "/Screenshots/" + Sname + "_" + loopn + "_" + (j + 1) + "_" + strTime + ".png";
      
      FileUtils.copyFile(screenshot, new File(filenamer));
    } catch (Exception e) {
      log("error", "DEBUG:Exception caught in screenshot function:" + e.getMessage());
      // System.out.println("Getting Screenshot is failed. Please confirm the test report whether the operation is executed or not.");
      // System.out.println("This message may be displayed when closing the dialog.");
    }
  }

  /**
   * Function used to take screenshot of a step.
   * @param loopn
   * @param rown
   * @param Sname
   * @return link to the screeshot file
   * @throws Exception
   */
  public String screenshotLink(int loopn, int rown, String Sname) throws Exception {
    String returnValue = "";
    try {
      DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
      Date date = new Date();
      String strTime = dateFormat.format(date);

      if (gs_runWebdriverOn.equalsIgnoreCase("remote")
          || automationEnvironment.equalsIgnoreCase("Appium")) {
        D8 = new Augmenter().augment(D8);
      }

      File screenshot = ((TakesScreenshot) D8).getScreenshotAs(OutputType.FILE);

      //String hrefLink = TestReport + Sname + "_" + loopn + "_" + (j + 1) + "_" + strTime + ".png";
      String hrefLink = TestReport +  "/" + testExecutionFunctionality + "/Screenshots/" + Sname + "_" + loopn + "_" + (j + 1) + "_" + strTime + ".png";
      
      
      FileUtils.copyFile(screenshot, new File(hrefLink));
      returnValue = hrefLink;
    } catch (Exception e) {
      log("error", "Exception caught in screenshotLink function:" + e.getMessage());
      return "";
    }
    return returnValue;
  }

}
