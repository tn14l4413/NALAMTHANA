package com.automation.selenium;

import java.util.HashMap;

import org.openqa.selenium.JavascriptExecutor;

public class MobileGesturesAppium extends BaseClass {
  public void executeMobileGesturesInAppium() {
    switch (dCellData.toLowerCase().trim()) {
      case "tap":
        break;
      case "swipeleft":
        break;
      case "swiperight":
        JavascriptExecutor js = (JavascriptExecutor) D8;
        HashMap<String, Double> swipeObject = new HashMap<String, Double>();
        swipeObject.put("startX", 0.95);
        swipeObject.put("startY", 0.5);
        swipeObject.put("endX", 0.05);
        swipeObject.put("endY", 0.5);
        swipeObject.put("duration", 1.0);
        js.executeScript("mobile: swipe", swipeObject);
        break;
      case "flick":
        break;
      case "scroll":
        break;
      case "doubletap":
        break;
      default:
        break;
    }
  }
}
