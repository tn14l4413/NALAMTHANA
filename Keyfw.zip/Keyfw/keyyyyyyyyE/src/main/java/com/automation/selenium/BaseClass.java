package com.automation.selenium;

//import io.selendroid.SelendroidLauncher;

import java.io.BufferedWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

//import com.mercury.qualitycenter.otaclient.IList;
//import com.mercury.qualitycenter.otaclient.ITDConnection;
//import com.mercury.qualitycenter.otaclient.ITestSet;

public class BaseClass {

  static BufferedWriter bw = null;
  static BufferedWriter bwSummaryRpt = null;
  static WebDriver D8;
  static Date cur_dt = null;
  static String TestSuite;
  static String TestScript;
  static String ObjectRepository;
  static String ReportsPath;
  static String strResultPath;
  static String TestReport;
  static String summaryReportPath;
  static String strSummaryReportPath;
  static String summaryReportHTML = "";
  static String detailHTMLReport;
  static String runTimeValue;
  static Map<String, String> testResultsMap = new HashMap<String, String>();
  static int stepNo = 0;
  static int rowcnt;
  static int dtrownum = 1;
  static int DTrowcount = 1;
  static int ORrowcount = 0;
  static int TSORrowcount = 0;
  static String ORvalname = "";
  static String ORvalue = "";
  static String Action = "";
  static String cCellData = "";
  static String dCellData = "";
  static String eCellData = "";
  static String fCellData = "";
  static Sheet DTsheet = null;
  static Sheet ORsheet;
  static Sheet TSORsheet;
  static String Searchtext;
  static int iflag = 0;
  static int j = 0;
  static int scriptNum = 0;
  static boolean captureperform = false;
  static boolean capturecheckvalue = false;
  static boolean capturestorevalue = false;
  static Sheet TScsheet;
  static Workbook TScworkbook;
  static int TScrowcount = 0;
  static int loopnum = 1;
  static String TScname;
  static String ActionVal;
  static String BrowserType = "IE"; // Assign the browser Type here
  static int DTcolumncount = 0;
  static WebElement elem = null;
  static Map<String, String> map = new HashMap<String, String>();
  static String errorDesc = "";
  static String testStatus = "executed";
  static boolean objectFoundInRepository = false;
  static int staleElemExCtr = 0;
  static int staleElemChecker;
  static String[] seleniumDir = null;
  static String parentWindow = "";
  static boolean setUpSuccess = true;
  static String automationEnvironment = "";
  static String testRunEnvironment = "";
  static String testRunLanguage = "";
  static int testExecutionRowNo = 0;
  static String testExecutionFunctionality = "";
  static String testExecutionTestcaseID = "";
  static String testExecutionTestDataID = "";
  static String testExecutionType = "";
  static String testExecutionBrowserName = "";

  // Variables for handling Data Table
  static String dataTableExcel = "";
  static String dataTableSheet = "";

  // Variables for Object Repository Map
  static Map<String, String> sharedORMAP = new HashMap<String, String>();
  static Map<String, String> scriptORMAP = new HashMap<String, String>();

  // Variables for Email Operations
  static String testResultsZipFile;
  static double totalScriptsPassed = 0;
  static double totalScriptsFailed = 0;

  // Variables for Quality Center Operations
  //static ITDConnection itdc = null;
  //static IList tstestlist;
  // static ITestSet testSet;
  static boolean existTest = false;

  // Variables for Execution time monitor
  static String executionStartTime = "";
  static String executionEndTime = "";
  static String totalExecutionTime = "";


  // Global Settings Variable to be read from settings.xls
  static String gs_closeBrowserAfterTest = "";
  static String gs_sendEmailAfterTest = "";
  static String gs_emailSMTP = "";
  static String gs_emailAuth = "";
  static String gs_emailFROM = "";
  static String gs_emailTO = "";
  static String gs_emailCC = "";
  static String gs_emailSubject = "";
  static String gs_testEnvironment = "";
  static String gs_updateQCAfterTest = "";
  static String gs_QCUrl = "";
  static String gs_QCAuth = "";
  static String gs_QCTestSet = "";
  static String gs_dateTimeFormat = "";
  static String gs_timeZone = "";
  static String gs_cleanTestResultsFolder = "";
  static String gs_runWebdriverOn = "";
  static String gs_testSuiteToRun = "";

  // Variables for Database operations.
  Connection conn = null;
  Statement stmt = null;
  ResultSet rs = null;
  Map<String, String> DBResultSet2D = new HashMap<String, String>();

  // Variables for selendroid.
  //static SelendroidLauncher selendroidServer = null;
  
  //Variables for DataSheet
  static String dataSheetName = "";
  static String dataSheetColumnHeader = "";
  


  public void log(String type, String message) {
    if (type.equalsIgnoreCase("error")) {
      System.out.println("\n");
      System.out
          .println("ERROR:********************************************************************************************");
      System.out.println(message);
      System.out
          .println("ERROR:********************************************************************************************");
      System.out.println("\n");
    } else {
      DateFormat formatter = new SimpleDateFormat("hh:mm:ss.SSS");
      Date log_dt = new Date();
      System.out.println("[" + formatter.format(log_dt) + "]" + " INFO: " + message);
    }
  }
}
