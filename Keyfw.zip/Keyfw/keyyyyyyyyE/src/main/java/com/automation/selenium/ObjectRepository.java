package com.automation.selenium;

import java.io.File;
import java.io.FileInputStream;
import java.util.Locale;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;

public class ObjectRepository extends BaseClass {

  public void generateSharedORMAP() throws Exception {
    try {
      log("info", "Started Generating Shared OR MAP...");

      String sharedORExcelPath = ObjectRepository + "OR_SHARED.xls";
      FileInputStream fs = null;
      WorkbookSettings ws = null;
      fs = new FileInputStream(new File(sharedORExcelPath));
      ws = new WorkbookSettings();
      ws.setLocale(new Locale("en", "EN"));
      Workbook SharedORworkbook = Workbook.getWorkbook(fs, ws);
      Sheet sharedORSheet = SharedORworkbook.getSheet(0);

      for (int k = 0; k < sharedORSheet.getRows(); k++) {
        String ORKey = sharedORSheet.getCell(2, k).getContents();
        String ORValue = sharedORSheet.getCell(3, k).getContents();
        sharedORMAP.put(ORKey, ORValue);
      }

      fs.close();

      log("info", "Completed Generating Shared OR MAP.(Total items=" + sharedORSheet.getRows()
          + ")");
    } catch (Exception e) {

      log("error", "Exception caught while Generating Shared OR MAP.(" + e.getMessage() + ")");
    }


  }


  public void generateScriptORMAP(String scriptORExcelPath) throws Exception {
    try {
      log("info", "Started Generating Script OR MAP...");

      FileInputStream fs = null;
      WorkbookSettings ws = null;
      fs = new FileInputStream(new File(scriptORExcelPath));
      ws = new WorkbookSettings();
      ws.setLocale(new Locale("en", "EN"));
      Workbook scriptORworkbook = Workbook.getWorkbook(fs, ws);
      Sheet scriptORSheet = scriptORworkbook.getSheet(0);
      scriptORMAP.clear();

      for (int k = 0; k < scriptORSheet.getRows(); k++) {
        String ORKey = scriptORSheet.getCell(2, k).getContents();
        String ORValue = scriptORSheet.getCell(3, k).getContents();
        scriptORMAP.put(ORKey, ORValue);
      }

      fs.close();

      log("info", "Completed Generating Script OR MAP.(Total items=" + scriptORSheet.getRows()
          + ")");
    } catch (Exception e) {

      log("error", "Exception caught while Generating Shared OR MAP.(" + e.getMessage() + ")");
    }


  }


  public String getObjectLocator(String objectName) throws Exception {
    String objectLocator = null;
    try {

      log("info", "Searching for object locator in the OR MAP.....");
      if (sharedORMAP.get(objectName) != null) {
        objectLocator = sharedORMAP.get(objectName);
        log("info", "Object locator Found in Shared OR MAP.");
      }

      else if (scriptORMAP.get(objectName) != null) {
        objectLocator = scriptORMAP.get(objectName);
        log("info", "Object locator Found in Script OR MAP.");
      } else {
        log("error", "Object locator NOT Found in OR.");
      }

    } catch (Exception e) {
      log("error", "Exception caught while searching for Object Locator.(" + e.getMessage() + ")");
    }
    return objectLocator;

  }

  public String getObjectNodeAndValue(String objName) throws Exception {

    String objectNodeAndValue = null;

    String getObjectLocatorString = getObjectLocator(objName);

    if (getObjectLocatorString == null) {

      throw new Exception("ObjectLocatorNotFoundInOR");
    } else {

      if (getObjectLocatorString.contains("==") == false) {
        throw new Exception("SyntaxErrorInORLocator");
      }

      String[] objectLocatorDetails = getObjectLocatorString.split("==");
      ORvalname = objectLocatorDetails[0];
      ORvalue = objectLocatorDetails[1];
      objectNodeAndValue = ORvalname + "&&" + ORvalue;
    }
    return objectNodeAndValue;
  }
}
