package com.automation.selenium;

import java.io.File;
import java.io.IOException;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

public class DataTable extends BaseClass {
	
DateTimeFunctions dtfObj = new DateTimeFunctions();	

  public String getDataTableValue(String columnname, int rownum) throws IOException, BiffException {
    String dataTableValue = "COLUMN NOT FOUND";
    try {
      Workbook readWB = Workbook.getWorkbook(new File(dataTableExcel));
      Sheet dataSheet = readWB.getSheet(dataTableSheet);
      for (int i = 0; i < dataSheet.getColumns(); i++) {
        if (dataSheet.getCell(i, 0).getContents().toString()
            .equalsIgnoreCase(columnname.substring(3, columnname.length()))) {
          // Column found in Data sheet
          dataTableValue = dataSheet.getCell(i, rownum).getContents().toString();
          if (dataTableValue.trim() == "") {
            dataTableValue = "NO DATA IN CELL";
          }
          break;
        }
      }
      readWB.close();

    } catch (IOException e) {
      log("error", e.getMessage());
    }
    return dataTableValue;
  }

  public String getDataTableValueFor(String columnname) throws IOException, BiffException {
	  log("debug","Tryng to get value for data column :" + columnname);
        String dataTableValue = "COLUMN NOT FOUND";
       try {
    	   
	    String dataSheetToLookup = "";
	    String columnNameToLookup = "";
	    int rowNumberForLookup = 0;
	    
	    if(columnname.startsWith("#")) {
 		   log("debug","Tryng to get value from user variable for :" + columnname);
 		   dataTableValue  = map.get(columnname.replace("#", ""));
 		   return dataTableValue;
	        }
	    
	    else if(columnname.startsWith("$$")) {
    		   log("debug","Tryng to get value from System variable for :" + columnname);
    		   dataTableValue  = dtfObj.getSystemVariable(columnname);
    		   return dataTableValue;
 	        }
	    else if(columnname.startsWith("Env_")) {
	    	 log("debug","Tryng to get value from Environment data sheet for column :" + columnname);
	    	  dataSheetToLookup = "TestConfiguration";
	 	      columnNameToLookup = columnname;
	 	      rowNumberForLookup = getDataTableRowOfEnvironment("TestConfiguration");
	 	    
	    } else {
	    	   String[] columnValueArray = columnname.split("_p_");
	   	       log("debug","Data column value array length:" + columnValueArray.length);
	   	       if(columnValueArray.length == 2) {
	   	    	   log("debug","Data sheet to lookup is:" + columnValueArray[0]);
	   	    	  log("debug","Data column to lookup is:" + "p_" + columnValueArray[1]);
	   	    	  dataSheetToLookup =  columnValueArray[0];
		 	      columnNameToLookup =  "p_" + columnValueArray[1];
		 	      rowNumberForLookup = getDataTableRowOfCurrentExecution( columnValueArray[0].trim());
		 	      
	   	       } else {
	   	    	   log("debug","This loos like raw data. Passing as it is:" + columnname);
	   	           dataTableValue = columnname;
	   	          return dataTableValue;
	   	       }
	   	       
	    }
	    
	    if(rowNumberForLookup == 0) {
	    	log("error", "NO MATCHING ROW IN TEST DATA SHEET");
	    	return null;
	    }
	    
	    dataTableValue = searchForColumnInSheet(dataSheetToLookup, columnNameToLookup, rowNumberForLookup);
	    
	    if(dataTableValue.equalsIgnoreCase("COLUMN NOT FOUND") & dataSheetToLookup != "TestConfiguration") {
	    	dataTableValue = searchForColumnInSheet(dataSheetToLookup, columnNameToLookup + "_" + testRunLanguage , rowNumberForLookup);
	    }
	    
	    } catch (IOException e) {
	      log("error", e.getMessage());
	    }
	    log("debug","Data table value for column " + columnname + "is : " + dataTableValue);
	    
	    if(dataTableValue.startsWith("$$")) {
    		   log("debug","Tryng to get value from System variable for :" + dataTableValue);
    		   dataTableValue  = dtfObj.getSystemVariable(dataTableValue);
    		   log("debug","System variable value is :" + dataTableValue);
    		   return dataTableValue;
 	        }
	    
	    return dataTableValue;
	  }
  
  public String searchForColumnInSheet(String dataSheetToLookup, String columnNameToLookup, int rowNumberForLookup) {
	   String dataTableValue = "COLUMN NOT FOUND";
	  try{
		  String testDataFile = seleniumDir[0].replace("\\", "//")
                  + "//ProjectFramework//TestData//TestData.xls";	
		  log("info", "Test Data file:" + testDataFile);


		  Workbook readWB = Workbook.getWorkbook(new File(testDataFile));
		  Sheet dataSheet = readWB.getSheet(dataSheetToLookup);
		  for (int i = 0; i < dataSheet.getColumns(); i++) {
			  if (dataSheet.getCell(i, 0).getContents().toString()
					  	.equalsIgnoreCase(columnNameToLookup)) {
				  	// Column found in Data sheet
				  	dataTableValue = dataSheet.getCell(i, rowNumberForLookup).getContents().toString();
				  		if (dataTableValue.trim() == "") {
				  				dataTableValue = "NO DATA IN CELL";
				  		}
				  		break;
			  	}
		  	}
		  readWB.close();
	    } catch(Exception e) {
		  log("error","Exception in searchForColumnInSheet: " +  e.getMessage());
		  return null;
	  }
	 return  dataTableValue;
  }
  
  public int getDataTableRowOfCurrentExecution(String dataSheetToLookup) throws IOException, BiffException {
	    int dataTableRowNum = 0;
	    try {
	    	String testDataFile = seleniumDir[0].replace("\\", "//")
                    + "//ProjectFramework//TestData//TestData.xls";	
	    			//log("info", "Test Data file:" + testDataFile);
	    			//log("info", "Test Run Environment:" + testRunEnvironment);
	    			//log("info", "Test Run Language:" + testRunLanguage);
	    			//log("info", "Test Run Functionaity" + testExecutionFunctionality);
	    			//log("info", "Test Run Testcase ID" + testExecutionTestcaseID);
	    			//log("info", "Test Run Test Data ID" + testExecutionTestDataID);
	    			
	    			Workbook readWB = Workbook.getWorkbook(new File(testDataFile));
	    			Sheet dataSheet = readWB.getSheet(dataSheetToLookup);
	    			for (int i = 0; i < dataSheet.getRows(); i++) {
	    				if ( (dataSheet.getCell(0, i).getContents().toString().equalsIgnoreCase(testExecutionFunctionality)) &
	    					(dataSheet.getCell(1, i).getContents().toString().equalsIgnoreCase(testExecutionTestcaseID)) &
	    					(dataSheet.getCell(2, i).getContents().toString().equalsIgnoreCase(testExecutionTestDataID)) 
	    				   )	
	    				  {
	    					// Data Row found in Data sheet
	    					dataTableRowNum = i;
	    					break;
	    				}
	    			}
	    			readWB.close();

	    } catch (IOException e) {
	      log("error", e.getMessage());
	    }
	    log("info", "Test Data ID is found at row:  " + dataTableRowNum + " in sheet: " + dataSheetToLookup );
	    return dataTableRowNum;
	  }
  
  public int getDataTableRowOfEnvironment(String dataSheetToLookup) throws IOException, BiffException {
	    int dataTableRowNum = 0;
	    try {
	    	String testDataFile = seleniumDir[0].replace("\\", "//")
                  + "//ProjectFramework//TestData//TestData.xls";	
	    			log("info", "Test Data file:" + testDataFile);
	    			log("info", "Test Run Environment:" + testRunEnvironment);
	    			log("info", "Test Run Language:" + testRunLanguage);
	    			
	    			
	    			Workbook readWB = Workbook.getWorkbook(new File(testDataFile));
	    			Sheet dataSheet = readWB.getSheet(dataSheetToLookup);
	    			for (int i = 0; i < dataSheet.getRows(); i++) {
	    				if  (dataSheet.getCell(0, i).getContents().toString().equalsIgnoreCase(testRunEnvironment)) 
	    				  {
	    					// Data Row found in Data sheet
	    					dataTableRowNum = i;
	    					break;
	    				}
	    			}
	    			readWB.close();

	    } catch (IOException e) {
	      log("error", e.getMessage());
	    }
	    log("info", "Test Data ID is found at row:  " + dataTableRowNum + " in sheet: " + dataSheetToLookup );
	    return dataTableRowNum;
	  }
  
  public void putValueToDataTable(String columnname, int rownum, String value) throws IOException,
      BiffException, RowsExceededException, WriteException {
    try {
      Workbook writeWB = Workbook.getWorkbook(new File(dataTableExcel));
      WritableWorkbook copy = Workbook.createWorkbook(new File(dataTableExcel), writeWB);
      WritableSheet writableSheet = copy.getSheet(dataTableSheet);
      boolean columnFound = false;
      int writeToColumn = 0;
      for (int i = 0; i < writableSheet.getColumns(); i++) {
        if (writableSheet.getCell(i, 0).getContents().toString()
            .equalsIgnoreCase(columnname.substring(3, columnname.length()))) {
          // Column found in Data sheet.
          columnFound = true;
          writeToColumn = i;
          break;
        }
      }

      if (columnFound == false) {
        // Add the column name to the data table
        writeToColumn = writableSheet.getColumns();
        Label newDataTableColumn =
            new Label(writeToColumn, 0, columnname.substring(3, columnname.length()));
        writableSheet.addCell(newDataTableColumn);
        log("info", "New column added to data table.");
      }

      Label label = new Label(writeToColumn, rownum, value);
      writableSheet.addCell(label);
      copy.write();
      copy.close();
      log("info", "Value inserted into data table");
      writeWB.close();
    } catch (IOException e) {
      log("error", e.getMessage());
    }
  }

  public int getDataTableRowCount() throws IOException, BiffException {
    int dataTableRowCount = 0;
    try {
      Workbook readRowCountOfWB = Workbook.getWorkbook(new File(dataTableExcel));
      Sheet dataCountSheet = readRowCountOfWB.getSheet(dataTableSheet);
      dataTableRowCount = dataCountSheet.getRows() - 1; // exclude header
      log("info", "No of rows in Data table =" + dataTableRowCount);
      readRowCountOfWB.close();

    } catch (IOException e) {
      log("error", e.getMessage());
    }
    return dataTableRowCount;
  }

  

}
