package com.automation.selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class StoreValue extends BaseClass {

  ObjectRepository orObj = new ObjectRepository();
  DateTimeFunctions dtfObj = new DateTimeFunctions();
  TestDetailedReport tdrObj = new TestDetailedReport();
  FindElement fEObj = new FindElement();
  ScreenShot ssObj = new ScreenShot();
  DataTable dtObj = new DataTable();



  
  public void storeValueInVarible(String variableName, String valueType) throws Exception {	  
    String actval = null;
    Boolean boolval = null;
    int xcord;
    String varName;
    

    switch (valueType.toLowerCase()) {
      case "readonly":
        actval = elem.getAttribute("readonly");
        break;
      case "enabled":
         boolval = elem.isEnabled();
        actval = boolval.toString();
        break;
      case "text":
        actval = elem.getText().toString().trim();
        break;
      case "numfromtext":
        actval = elem.getText().replaceFirst(".*?(\\d+).*", "$1");
        break;
      case "value":
          actval = elem.getAttribute("value").toString().trim();
          break;
      case "dropdownvalue":
        actval = new Select(elem).getFirstSelectedOption().getText().toString();
        break;
      case "visible":
        boolval = elem.isDisplayed();
        actval = boolval.toString();
        break;
      case "checked":
         boolval = elem.isSelected();
        actval = boolval.toString();
        if (actval.equalsIgnoreCase("True"))
          actval = "on";
        else
          actval = "Off";
        break;
      case "linktext":
        actval = elem.getText();
      case "linkurl":
    	  actval =elem.getAttribute("href");
        break;
      case "xposition":
    	  Point point=elem.getLocation();
    	  xcord =point.getX();
    	  actval =Integer.toString(xcord);
        break;
      default:
       
          break;
        }

       log("info", "Started performing storevalue operation..");

        // Decide whether to store in variable or data table
        if (variableName.substring(0, 1).equalsIgnoreCase("#")) {
          // Store the actual value in variable
        	varName = variableName.substring(1, (variableName.length()));
          if (map.containsKey(varName)) {
            map.put(varName, actval);
            tdrObj.Update_Report("executed" + "Prt_Msg" + map.get(varName));
            log("info", "Variable already exists.Value {" + actval + "} overwritten into the variable{ " + varName
                + "}.");
          } else {
            map.put(varName, actval);
            tdrObj.Update_Report("executed" + "Prt_Msg" + map.get(varName));
            log("info", "Value {" + actval + "} stored into the new variable{ " + varName + "}.");
          }
        }

  
        else {
          // Storage variable in invalid.
          throw new Exception("InvalidStorageVariableFoundInTS");
        }


       

      if (capturestorevalue == true) {
        ssObj.screenshot(loopnum, TScrowcount, TScname);
      }
   
      
      
  }
}
