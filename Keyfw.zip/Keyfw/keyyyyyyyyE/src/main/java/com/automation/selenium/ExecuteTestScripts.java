package com.automation.selenium;

import java.io.File;
import java.io.FileInputStream;
import java.util.Locale;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;

public class ExecuteTestScripts extends BaseClass {

  TestSummaryReport tsrObj = new TestSummaryReport();
  DateTimeFunctions dtfObj = new DateTimeFunctions();
  ObjectRepository orObj = new ObjectRepository();
  ExecuteKeywordScript eksObj = new ExecuteKeywordScript();
  CustomKeywords custKeyObj = new CustomKeywords();

  String packageName = "NOT_INITIALISED";
  String scriptName = "NOT_INITIALISED";
  String testDataID =  "NOT_INITIALISED";
  //String scriptORName = "NOT_INITIALISED";


  public void FindExecTestscript(String TestSuite, String TestScript, String ObjectRepository,String language, String suiteType, String testEnvironment)
      throws Exception {
    // Place holder for summary report header...
    tsrObj.createSummaryRptHeader();
    log("info", "Finding TestScripts....");
    FileInputStream fs = null;
    WorkbookSettings ws = null;
    fs = new FileInputStream(new File(TestSuite));
    ws = new WorkbookSettings();
    ws.setLocale(new Locale("en", "EN"));
    Workbook TSworkbook = Workbook.getWorkbook(fs, ws);
    Sheet TSsheet = TSworkbook.getSheet(0);
    TSsheet.getRows();
    for (int i = 0; i < TSsheet.getRows(); i++) {
      try {
    	  testExecutionRowNo = i;
        int runColumn;
        if(suiteType.equalsIgnoreCase("Sanity")) {
         runColumn = 4;	
        } else {
        	runColumn =5;
        }
        
        if (((TSsheet.getCell(runColumn, i).getContents()).equalsIgnoreCase("Y") == true)) {
          scriptNum = i;
          // String TCStatus = "Pass";
          packageName = TSsheet.getCell(0, i).getContents();
          scriptName = TSsheet.getCell(1, i).getContents();
          testDataID  = TSsheet.getCell(2, i).getContents();
          //scriptORName = TSsheet.getCell(2, i).getContents();
          
          testExecutionFunctionality = packageName;
          testExecutionTestcaseID = scriptName;
          testExecutionTestDataID = testDataID;
          
          log("info", "Executing TestScript{" + scriptName + "} for test data {" + testDataID + "} in Package {" + packageName + "}");
          stepNo = 0;
          testStatus = "PASS";

          //String scriptORExcelPath = ObjectRepository + scriptORName;
          //orObj.generateScriptORMAP(scriptORExcelPath);
          eksObj.ExecKeywordScript(packageName, scriptName, TestScript, ObjectRepository);

          // Place holder to update the summary report after each test script completion-Yuva.
          if (testStatus.equalsIgnoreCase("PASS") == true) {
            log("info",
                "Updating summary report [after ExecKeywordScript completion] with test status as: "
                    + testStatus);
            tsrObj.updateSummaryReport(scriptName, "executed");
          }
          if (testStatus.equalsIgnoreCase("FAIL") == true) {
            log("info",
                "Updating summary report [after ExecKeywordScript completion] with test status as: "
                    + testStatus);
            tsrObj.updateSummaryReport(scriptName, "failed");
          }

          log("info","Trying to Log out of the application....");
          custKeyObj.logOutOfWealthManagementApp();
          log("info","Successfully Logged out of the application !");
        }
        /*
         * else { System.out.println(TSvalidate); }
         */
      } catch (Exception exTSuite) {
        log("error", "Exception in executing test script {"+ scriptName +"}" + exTSuite.getMessage());
      }
    }
    log("info","Completed executing All tests scripts in the test Suite {" + TestSuite + "}");
    // Close the summary report bufferwriter here...Yuva
    executionEndTime = dtfObj.getDateTimeWithZone();
    totalExecutionTime = dtfObj.getElapsedTime(executionStartTime, executionEndTime);
    tsrObj.createSummaryRptFooter();
    bwSummaryRpt.close();
  }

}
