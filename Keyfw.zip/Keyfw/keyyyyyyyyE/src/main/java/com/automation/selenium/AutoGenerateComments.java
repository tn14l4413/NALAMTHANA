package com.automation.selenium;

public class AutoGenerateComments extends BaseClass {
  public String generateComments(String keyword, String object, String action) {
    String autoComment = "[" + keyword + "][" + object + "][" + action + "].";

    if (keyword.equalsIgnoreCase("launchApp")) {
      autoComment = "Launch the application URL:" + object;
    }
    
    if (keyword.equalsIgnoreCase("set")) {
        autoComment = "Enter the value %RUNTIMEVALUE% in the " + object;
      }
      
    if (keyword.equalsIgnoreCase("wait")) {
      autoComment = "[Wait for " + object + " secs]";
    }
    if (keyword.equalsIgnoreCase("perform")) {
      if (action.toLowerCase().startsWith("set:"))
        autoComment = "Enter the value %RUNTIMEVALUE% in the " + object;

      if (action.toLowerCase().startsWith("select:"))
        autoComment = "Select the value %RUNTIMEVALUE% from the " + object;

      if (action.toLowerCase().startsWith("check:"))
        autoComment = "Check %RUNTIMEVALUE% the " + object;

      if (action.toLowerCase().startsWith("clear")) autoComment = "Clear the " + object;

      if (action.toLowerCase().startsWith("click")) autoComment = "Click on the " + object;

      if (action.toLowerCase().startsWith("frame:"))
        autoComment = "[Switch %RUNTIMEVALUE% the " + object + "].";

      if (action.toLowerCase().startsWith("attachfile:"))
        autoComment = "Attach the file  %RUNTIMEVALUE% to " + object;

      if (action.toLowerCase().startsWith("listselect:"))
        autoComment = "Select the values %RUNTIMEVALUE% from " + object;

    }
    if (keyword.equalsIgnoreCase("check")) {
      String prop[] = action.split(":");
      autoComment =
          "Verify whether the " + prop[0] + " property of " + object + " is %RUNTIMEVALUE%.";
    }
    if (keyword.equalsIgnoreCase("storevalue")) {
      String prop[] = action.split(":");
      String var_or_dt = prop[1].startsWith("#") ? "Variable" : "DataTable";
      autoComment =
          "Store the " + prop[0] + " property value %RUNTIMEVALUE% of " + object + " into the "
              + var_or_dt + " " + prop[1];
    }
    if (keyword.equalsIgnoreCase("checkpagecontent")) {
      autoComment = "Verify whether the page contains the text {" + object + "}";

    }
    if (keyword.equalsIgnoreCase("switchToFrame")) {
      autoComment = "[Switch to the frame with name " + object + "].";
    }
    if (keyword.equalsIgnoreCase("saveFileAs")) {
      autoComment = "Save the file as " + object + " to the Test Data folder.";
    }
    if (keyword.equalsIgnoreCase("switchTo")) {
      autoComment = "[Switch to the " + object + "].";
    }

    return autoComment;

  }
}
