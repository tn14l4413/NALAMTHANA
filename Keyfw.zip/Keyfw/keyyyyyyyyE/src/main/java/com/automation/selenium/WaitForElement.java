package com.automation.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WaitForElement extends BaseClass {

  public void waitTillClickable(String ObjectSetVal) throws Exception {

    WebElement elementClickable = null;

    if (ORvalname.equalsIgnoreCase("id")) {
      elementClickable =
          new WebDriverWait(D8, Integer.parseInt(ObjectSetVal)).until(ExpectedConditions
              .elementToBeClickable(By.id(ORvalue)));
    } else if (ORvalname.equalsIgnoreCase("name")) {
      elementClickable =
          new WebDriverWait(D8, Integer.parseInt(ObjectSetVal)).until(ExpectedConditions
              .elementToBeClickable(By.name(ORvalue)));
    } else if (ORvalname.equalsIgnoreCase("xpath")) {
      elementClickable =
          new WebDriverWait(D8, Integer.parseInt(ObjectSetVal)).until(ExpectedConditions
              .elementToBeClickable(By.xpath(ORvalue)));
    } else if (ORvalname.equalsIgnoreCase("link")) {
      elementClickable =
          new WebDriverWait(D8, Integer.parseInt(ObjectSetVal)).until(ExpectedConditions
              .elementToBeClickable(By.linkText(ORvalue)));
    } else if (ORvalname.equalsIgnoreCase("partiallink")) {
      elementClickable =
          new WebDriverWait(D8, Integer.parseInt(ObjectSetVal)).until(ExpectedConditions
              .elementToBeClickable(By.partialLinkText(ORvalue)));
    } else if (ORvalname.equalsIgnoreCase("css")) {
      elementClickable =
          new WebDriverWait(D8, Integer.parseInt(ObjectSetVal)).until(ExpectedConditions
              .elementToBeClickable(By.cssSelector(ORvalue)));
    } else if (ORvalname.equalsIgnoreCase("class")) {
      elementClickable =
          new WebDriverWait(D8, Integer.parseInt(ObjectSetVal)).until(ExpectedConditions
              .elementToBeClickable(By.className(ORvalue)));
    } else if (ORvalname.equalsIgnoreCase("tag")) {
      elementClickable =
          new WebDriverWait(D8, Integer.parseInt(ObjectSetVal)).until(ExpectedConditions
              .elementToBeClickable(By.tagName(ORvalue)));
    }



    if (elementClickable == null) {
      throw new Exception("Timedout after 60 secs.Element not clickable in the application.");
    }

  }

  public void waitTillVisible(String ObjectSetVal) throws Exception {

    WebElement elementVisible = null;


    if (ORvalname.equalsIgnoreCase("id")) {
      elementVisible =
          new WebDriverWait(D8, Integer.parseInt(ObjectSetVal)).until(ExpectedConditions
              .visibilityOfElementLocated(By.id(ORvalue)));
    } else if (ORvalname.equalsIgnoreCase("name")) {
      elementVisible =
          new WebDriverWait(D8, Integer.parseInt(ObjectSetVal)).until(ExpectedConditions
              .visibilityOfElementLocated(By.name(ORvalue)));
    } else if (ORvalname.equalsIgnoreCase("xpath")) {
      elementVisible =
          new WebDriverWait(D8, Integer.parseInt(ObjectSetVal)).until(ExpectedConditions
              .visibilityOfElementLocated(By.xpath(ORvalue)));
    } else if (ORvalname.equalsIgnoreCase("link")) {
      elementVisible =
          new WebDriverWait(D8, Integer.parseInt(ObjectSetVal)).until(ExpectedConditions
              .visibilityOfElementLocated(By.linkText(ORvalue)));
    } else if (ORvalname.equalsIgnoreCase("partiallink")) {
      elementVisible =
          new WebDriverWait(D8, Integer.parseInt(ObjectSetVal)).until(ExpectedConditions
              .visibilityOfElementLocated(By.partialLinkText(ORvalue)));
    } else if (ORvalname.equalsIgnoreCase("css")) {
      elementVisible =
          new WebDriverWait(D8, Integer.parseInt(ObjectSetVal)).until(ExpectedConditions
              .visibilityOfElementLocated(By.cssSelector(ORvalue)));
    } else if (ORvalname.equalsIgnoreCase("class")) {
      elementVisible =
          new WebDriverWait(D8, Integer.parseInt(ObjectSetVal)).until(ExpectedConditions
              .visibilityOfElementLocated(By.className(ORvalue)));
    } else if (ORvalname.equalsIgnoreCase("tag")) {
      elementVisible =
          new WebDriverWait(D8, Integer.parseInt(ObjectSetVal)).until(ExpectedConditions
              .visibilityOfElementLocated(By.tagName(ORvalue)));
    }

    if (elementVisible == null) {
      throw new Exception("Timedout after 60 secs.Element not Visible application.");
    }
  }


}
