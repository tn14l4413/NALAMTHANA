package com.automation.selenium;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class ZipTestResults extends BaseClass {

  public void zipfolder(String Destloc, String sourceLoc) {
    try {
      // create a ZipOutputStream to zip the data to
      ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(Destloc));
      zipDir(sourceLoc, zos);
      zos.close();
    } catch (Exception e) {
      log("error", "Exception caught in zipfolder function " + e.getMessage());
    }
  }


  public void zipDir(String dir2zip, ZipOutputStream zos) {
    try {
      // create a new File object based on the directory we have to zip File
      File zipDir = new File(dir2zip);
      // get a listing of the directory content
      String[] dirList = zipDir.list();
      byte[] readBuffer = new byte[2156];
      int bytesIn = 0;
      // loop through dirList, and zip the files
      for (int i = 0; i < dirList.length; i++) {
        // System.out.println("DEBUG:ZipDir Function- dir name is " + dirList[i]);
        File f = new File(zipDir, dirList[i]);
        if (f.isDirectory()) {
          // if the File object is a directory, call this function again to add its content
          // recursively
          String filePath = f.getPath();
          zipDir(filePath, zos);
          // loop again
          continue;
        }
        // if we reached here, the File object f was not a directory
        // create a FileInputStream on top of f
        FileInputStream fis = new FileInputStream(f);
        // create a new zip entry
        String zipDirFullPathDetails[] = f.getPath().split("ProjectFramework");
        ZipEntry anEntry = new ZipEntry(zipDirFullPathDetails[1]);
        // place the zip entry in the ZipOutputStream object
        zos.putNextEntry(anEntry);
        // now write the content of the file to the ZipOutputStream
        while ((bytesIn = fis.read(readBuffer)) != -1) {
          zos.write(readBuffer, 0, bytesIn);
        }
        // close the Stream
        fis.close();
      }
      log("info", "Zipping Folder is Done");

    } catch (Exception e) {
      log("error", "Exception in Zipping the folder: " + e.getMessage());
    }

  }



}
