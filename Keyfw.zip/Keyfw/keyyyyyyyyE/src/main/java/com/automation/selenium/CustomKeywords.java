package com.automation.selenium;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import oracle.sql.ROWID;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;



public class CustomKeywords extends BaseClass {

	KeywordRelatedFunctions krfObj = new KeywordRelatedFunctions();
	
	
	
	public boolean tableSort(String tablePath,String columnName)
	{
		boolean status =false;
		try{
		int afterRowCount=0;
		int beforeRowCount=0;
		String columnNum=null;
		String columnHeader=null;
		// xpath of the table body
		String tableBody=tablePath+"/tbody";
		// xpath of the table header
		String tableHeader=tablePath+"/thead";
		WebElement htable = D8.findElement(By.xpath(tableHeader));
		List<WebElement> tableHeaders = htable.findElements(By.tagName("th"));
		Iterator<WebElement> tableItr=tableHeaders.iterator();
		int count=0;
		while(tableItr.hasNext())
			{
			
				WebElement tableRow=tableItr.next();
				String tableHeading=tableRow.getText();
				if(tableHeading.equalsIgnoreCase(columnName))
		        {
		        	count++;
		        	break;
		        	
		        }
				count++;
		        
		        
		      }
		       
		        
		columnNum="col-"+count;
		columnHeader="th[id='header"+count+"']";
	    WebElement btable = D8.findElement(By.xpath(tableBody));
		List<WebElement> beforeRows = btable.findElements(By.tagName("tr"));
		int beforeRowsCount=beforeRows.size();
		String [] beforeSort=new String[beforeRowsCount];
		String [] beforeSortValue= new String[beforeRowsCount];
		Iterator<WebElement> beforeItrRow = beforeRows.iterator();
		// Iterating rows
		while(beforeItrRow.hasNext()){
			WebElement beforeRow=beforeItrRow.next();
			List<WebElement> beforeColumns= beforeRow.findElements(By.className(columnNum));
			
			Iterator<WebElement> beforeItrCol = beforeColumns.iterator();
			// Iterating Columns
			while(beforeItrCol.hasNext()){
				WebElement beforeCol = beforeItrCol.next();
				beforeSort[beforeRowCount]=beforeCol.getText();
				//beforeSortValue[beforeRowCount]=beforeSort[beforeRowCount];
				beforeSortValue[beforeRowCount]=beforeSort[beforeRowCount].substring(0, 3);
							
				}beforeRowCount=beforeRowCount+1;
		}
		
		//Click on the column Header
		
		D8.findElement(By.cssSelector(columnHeader)).click();
		//D8.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		List<WebElement> afterRows = btable.findElements(By.tagName("tr"));
		// Getting Row Count
		int afterRowsCount=afterRows.size();
		String [] afterSort=new String[afterRowsCount];
		String [] afterSortValue= new String[afterRowsCount];
		Iterator<WebElement> afterItr = afterRows.iterator();
		// Iterating rows
		while(afterItr.hasNext()){
			WebElement afterRow=afterItr.next();
			List<WebElement> afterColumns= afterRow.findElements(By.className(columnNum));
			Iterator<WebElement> afterItrCol = afterColumns.iterator();
			// Iterating columns
			while(afterItrCol.hasNext()){
				WebElement afterColumn = afterItrCol.next();
				//Getting ascending values
				afterSort[afterRowCount]=afterColumn.getText();
				afterSortValue[afterRowCount]=afterSort[afterRowCount].substring(0, 3);
				}afterRowCount=afterRowCount+1;
		  	}
		int startRow=0;
		String [] finalSort = new String[afterRowCount];
		for(int d=afterRowCount-1;d>=0;d--)
		{
			finalSort[startRow]=afterSortValue[d];
			// Checking the sorted values in descending or not
			if (beforeSortValue[startRow].equals(finalSort[startRow]))
				status= true;
			
			else
			{
				status= false;
				break;
			}
			
			startRow++;
		}
		
			
		return status;
		
		} catch(Exception e) {
			log("error", "Exception in table sort function:" + e.getMessage());
			return status;
		}
	}


	public void logOutOfWealthManagementApp() {
		try {

			if(D8.findElement(By.xpath(".//*[@id='top-menu']/ul/li[5]")).isDisplayed())
			{
				boolean logOutButton = D8.findElement(
					By.xpath("//*[@id='red-circle-down']")).isDisplayed();
				if (logOutButton == true) {
				D8.findElement(By.xpath("//*[@id='red-circle-down']"))
						.click();
				
				D8.findElement(
						By.xpath("//*[@id='top-menu']/ul/ul/a[1]/li")).click();
				
				} else {
				log("info", "Log Out Button not visible");
				}
			}

		} catch (Exception e) {
			log("error", "Exception caught in log Out:" + e.getMessage());
				}
		
	}
	
	public boolean securitycheck() {
		boolean status=false;
		try {

			//WebElement element=D8.findElement(By.linkText("Continue to this website (not recommended).")).isDisplayed()
			
			if(D8.findElement(By.linkText("Continue to this website (not recommended).")).isDisplayed())
			{
				D8.findElement(By.linkText("Continue to this website (not recommended).")).click();
				status=true;
			}
			if(D8.findElement(By.linkText("ADVANCED")).isDisplayed())
			{
				D8.findElement(By.linkText("ADVANCED")).click();
				status=true;
			}
			if(D8.findElement(By.linkText("Proceed to 10.192.33.72 (unsafe)")).isDisplayed())
			{
				D8.findElement(By.linkText("Proceed to 10.192.33.72 (unsafe)")).click();
				status=true;
			}
			
			status=true;
return status;
			
		} catch (Exception e) {
			log("error", "Exception caught in securitycheck method:" + e.getMessage());
		return status;		
		}
		
	}
	

	public boolean opennewwindow(WebElement obj,String newwindowtitle) {
		boolean status=false;
		try {

			 obj.click();
			  String parentHandle = D8.getWindowHandle(); // get the current window handle
        	 
        	 D8.switchTo().window(parentHandle);
        	status=true;
        	return status;
          	/*  for (String winHandle : D8.getWindowHandles()) {
        	      D8.switchTo().window(winHandle); // switch focus of WebDriver to the next found window handle (that's your newly opened window)
        	      log("info", "Inside for loop" + winHandle);
        	  }
          	
        	  //code to do something on new window
        	  if(D8.getTitle().equalsIgnoreCase(newwindowtitle))
        	  {
        		  log("info", "title of current opened window" + D8.getTitle());
        		  status=true;
        	  }
        	  else
        	  {
        		  status=false;
        	  }
        	  log("info", "OUTSIDE IF LOOP" + D8.getTitle());
        	  D8.close(); // close newly opened window when done with it
        	  D8.switchTo().window(parentHandle); // switch back to the original window
        	  return status;
			*/
		} catch (Exception e) {
			log("error", "Exception caught in open new window method:" + e.getMessage());
		return status;		
		}
		
	}
	
	
	public boolean closenewwindow() {
		boolean status=false;
		try {

        	  D8.close(); // close newly opened window when done with it
        	 status=true;
        	  return status;
			
		} catch (Exception e) {
			log("error", "Exception caught in close new window method:" + e.getMessage());
		return status;		
		}
		
	}
	
	
	public boolean checkCapitalize(String originalText) {
		boolean status=false;
		try {
			
String originalToLower = originalText.toLowerCase();
String finalText= Character.toUpperCase(originalToLower.charAt(0)) + originalToLower.substring(1);
if(originalText.equals(finalText))
	
	{
		log("info", "Capitalize:Text matched successfully");
		status=true;
		return status;
		
	}
	else {
				log("info", "Capitalize: Text Mismatch");
				status=false;
				return status;
				}

			}
 catch (Exception e) {
			log("error", "Exception caught in log Out:" + e.getMessage());
			return status;
				}
		
	}
	
	
	
	
	public boolean datePicker(String date) {
		boolean status = false;
		try {
			
			HashMap<String, String> hmap = new HashMap<String,String>();
			if (testRunLanguage.equalsIgnoreCase("ENG"))
			{
		      /*Adding elements to HashMap*/
		      hmap.put("January","01");
		      hmap.put("February","02");
		      hmap.put("March","03");
		      hmap.put("April","04");
		      hmap.put("May","05");
		      hmap.put("June","06");
		      hmap.put("July","07");
		      hmap.put("August","08");
		      hmap.put("September","09");
		      hmap.put("October","10");
		      hmap.put("November","11");
		      hmap.put("December","12");
			}
		      else
		      {
		    	  hmap.put("janvier","01");
			      hmap.put("f�vrier","02");
			      hmap.put("mars","03");
			      hmap.put("avril","04");
			      hmap.put("mai","05");
			      hmap.put("juin","06");
			      hmap.put("juillet","07");
			      hmap.put("ao�t","08");
			      hmap.put("septembre","09");
			      hmap.put("octobre","10");
			      hmap.put("novembre","11");
			      hmap.put("d�cembre","12");
		      }
		     
		         
		     String calMonth=D8.findElement(By.className("ui-datepicker-month")).getText();
		     int calcMonthValue=0;
		     Set set = hmap.entrySet();
		      Iterator iterator = set.iterator();
		      for (Entry<String, String> entry : hmap.entrySet()) {
		            String key = entry.getKey();
		            String values = entry.getValue();
		            if(key.equalsIgnoreCase(calMonth))
		            {
		            	calcMonthValue=Integer.parseInt(values);
		            	break;
		            }
		            
		      }
		      
			// Getting current system Date
			DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
			Date dateobj = new Date();
			String systemDate = df.format(dateobj);

			String[] systemDateSplit = systemDate.split("/");
			int systemMonth = Integer.parseInt(systemDateSplit[0]);
			int systemDay = Integer.parseInt(systemDateSplit[1]);
			int flag = 0;
			int systemYear = Integer.parseInt(systemDateSplit[2]);
			// Custom date
			log("debug", "Input date format before conversion:" + date);
			date =df.format(new Date(date));
			log("debug", "Converted input date to format:" + date);
			String[] customDateSplit = date.split("/");
			int customMonth = Integer.parseInt(customDateSplit[0]);
			int customYear = Integer.parseInt(customDateSplit[2]);
			int customDate = Integer.parseInt(customDateSplit[1]);
			if (customDate <= 31 && customMonth <= 12 && customDate != 0
					&& customMonth != 0&&customYear<=systemYear) {

				
				// selecting year
				String cssLocatorOfYear = "select.ui-datepicker-year";
				
				//Select selectYear = new Select(D8.findElement(By.className("ui-datepicker-year")));
				//log("debug", "Default year in calendar before selection is:"+ selectYear.getFirstSelectedOption().getText());
				//selectYear.selectByVisibleText(customDateSplit[2]);
				
				krfObj.selectOptionFromDropdown(cssLocatorOfYear, customDateSplit[2]);
				
				//Selecting Month
				int monthToSelect = (customMonth - calcMonthValue);
					if (monthToSelect > 0) {

					for (int i = 1; i <= monthToSelect; i++) {
						//D8.manage().timeouts()
						//		.implicitlyWait(1, TimeUnit.SECONDS);
						D8.findElement(
								By.xpath(".//*[@id='ui-datepicker-div']/div/a[2]"))
								.click();
					}
				} else if (monthToSelect < 0) {
					
					monthToSelect = Math.abs(monthToSelect);
					for (int i = 1; i <= monthToSelect; i++) {
						
						//D8.manage().timeouts()
						//		.implicitlyWait(1, TimeUnit.SECONDS);
						D8.findElement(
								By.xpath(".//*[@id='ui-datepicker-div']/div/a[1]"))
								.click();

					}

				} else if (monthToSelect == 0) {
					if (customYear == systemYear) {
						if (customDate >= systemDay) {
							log("debug","custom date is greater than system date in same year");
						}
					}

				}
					//Selecting Date 
				WebElement datePickerTbody = D8.findElement(By
						.xpath("//*[@id='ui-datepicker-div']/table/tbody"));

				java.util.List<WebElement> noOfColumns = datePickerTbody
						.findElements(By.tagName("a"));
				for (WebElement cell : noOfColumns) {
					
					int cellDay = Integer.parseInt(cell.getText());
					
					if (cellDay == customDate) {
						flag = flag + 1;
						cell.click();
						status = true;
						break;
					}

				}
				if (flag == 0) {
					log("debug","Incorrect Custom Date");
				}

			}

			else {
				log("debug","Incorrect date/Month");
			}
		      
		} catch (Exception e) {
			
			log("debug","Exception caught in selecting date:" + e.getMessage());
		}
		return status;
	}


	
	public boolean nickNameEntry(String accountNumber, String nickName)
	
	{
		   boolean nickNameEntered = false;
		   boolean rowMatch = false;
		   
			List<WebElement> rowsList = elem.findElements(By.tagName("tr"));
			List<WebElement> columnsList = null;
             for (WebElement row : rowsList) {
            	     columnsList = row.findElements(By.tagName("td"));
            	      for (WebElement column : columnsList) {
                            if(column.getText().equalsIgnoreCase(accountNumber)) {
                            	log("info", "Acccount no found on row") ; 
                            	rowMatch = true;
                            }
                        }

            	      if(rowMatch) {
            	    	 //Enter the nick name in the Text box.
            	    	  WebElement nickNameElem =  columnsList.get(2).findElement(By.name("account_nickname"));
            	    	 log("info", "Current data in nickname field is: " + nickNameElem.getAttribute("value"));
            	    	 nickNameElem.clear();
            	    	 nickNameElem.sendKeys(nickName);
            	    	 return true;
            	     } 
          }
             return nickNameEntered;
   
	}
	
	
	public boolean isMarketMoverTableSorted(String sortByValue)

	{
		boolean status =false;
		
		try{
			log("info", "isMarketMoverTableSorted started wth param:" + sortByValue);
			
			//value for column number need to be changed based on the scenario PASSED by user 
			int columnNo=0;
			
			String cellPath;
			
			int rowNo=4;
			//float[] a=new float[10];
			List<Float> floatObtainedList = new ArrayList<Float>(); 
			List<Float> floatSortedList = new ArrayList<Float>();
			if( sortByValue.equalsIgnoreCase("Most Active By Volume") | 
				sortByValue.equalsIgnoreCase("Most Active by $ Value")|
				sortByValue.equalsIgnoreCase("Titres les plus actifs/Valeur en $") |
				sortByValue.equalsIgnoreCase("Titres les plus actifs/Volume") 
		    	)
			{
				log("debug","loop1");
				log("debug",sortByValue);
				columnNo=7;
			
			}
			else if( sortByValue.equalsIgnoreCase("$ Gainers") |
					 sortByValue.equalsIgnoreCase("$ Losers") |
					 sortByValue.equalsIgnoreCase("Gagnants $") |
					 sortByValue.equalsIgnoreCase("Perdants $") 
					)
			{
				log("debug","loop2");
				log("debug",sortByValue);
				columnNo=5;
			}
			else if( sortByValue.equalsIgnoreCase("% Gainers") |
					 sortByValue.equalsIgnoreCase("% Losers") | 
					 sortByValue.equalsIgnoreCase("Gagnants %") |
					 sortByValue.equalsIgnoreCase("Perdants %")
					)
			
			//else if(sortByValue=="% Gainers" | sortByValue=="% Losers" )
			{
				log("debug","loop3");
				log("debug",sortByValue);
				columnNo=6;
			}
			log("debug","cOLUMN nO"+columnNo);
			
			//Value for the row number default for all scenarios
			
			while(rowNo<=13)
			{
				cellPath="//div[3]/form/table/tbody/tr[2]/td/table/tbody/tr[5]/td/table/tbody/tr[" + rowNo +"]/td["+ columnNo +"]";
				String test=D8.findElement(By.xpath(cellPath)).getText();
				//log("debug",Math.abs(i));
			    floatObtainedList.add(Float.parseFloat(test.replaceAll(",","")));
				floatSortedList.add(Float.parseFloat(test.replaceAll(",","")));
				rowNo++;
			}
			
			log("debug",floatObtainedList.toString());
			Collections.sort(floatSortedList);
			if(sortByValue!="$ Losers" && sortByValue!="% Losers" &&  sortByValue!="Perdants %" &&  sortByValue!="Perdants $")
			{
			Collections.reverse(floatSortedList);
			}
			log("debug",floatSortedList.toString());
			if(floatSortedList.equals(floatObtainedList))
					{
				log("debug","true");
				  status = true;
					}
			else
			{
				log("debug","false");
				status=false;
			}
			
			
		}
		
		catch(Exception e)
		{
			log("error", "Exception caught in sortTableMarketMover function:" + e.getMessage());
		
		}
		
		return status;
	}
	 public boolean languageCheck()
	 {
		 log("info", "Inside Language Check");
		 boolean status=false;
		 try
		 {
			 String textContents=D8.findElement(By.xpath("//*[@id='top-menu']/ul/li[4]/a/font")).getText();
			 if(testRunLanguage.equalsIgnoreCase("ENG"))
			 {
				 if(textContents.equalsIgnoreCase("Help"))
				 {
					 log("info", "Account Settings - Language - English");
					 						status=true; 
				 }
				 else
				 {
					 log("info", "Account Settings - Language - French");
					D8.findElement(By.xpath("//*[@id='main-menu']/ul/li[6]/a"));
					D8.findElement(By.xpath("//*[@id='dashboardSection']/account-settings/div/account-settings-nav-bar/div/div[1]/div[1]/h2[1]/a"));
					D8.findElement(By.xpath("//*[@id='dashboardSection']/account-settings/div/user/language-preference/section/div[1]/button/div[1]"));
					Select sc=new Select(D8.findElement(By.xpath("//*[@id='dashboardSection']/account-settings/div/user/language-preference/section/form/div/div[1]/div/select")));
					sc.selectByValue("E");
					D8.findElement(By.xpath("//*[@id='dashboardSection']/account-settings/div/user/language-preference/section/form/div/div[2]/div[1]/button[2]/div[1]")).click();
					D8.findElement(By.xpath("//*[@id='top-menu']/ul/li[5]/span[2]")).click();
				    D8.findElement(By.xpath("//*[@id='sign-out-dropcontent']")).click();
                    D8.findElement(By.xpath("//*[@id='main-menu']/ul/li[1]/a")).click();					
					status=true;  
				 }
			 }
			 else 
			 {
				 if(textContents.equalsIgnoreCase("Aide"))
				 {
					 log("info", "Account Settings - Language - French");
						status=true; 
				 }
				 else
				 {
					 log("info", "Account Settings - Language - English");
					 D8.findElement(By.xpath("//*[@id='main-menu']/ul/li[6]/a"));
						D8.findElement(By.xpath("//*[@id='dashboardSection']/account-settings/div/account-settings-nav-bar/div/div[1]/div[1]/h2[1]/a"));
						D8.findElement(By.xpath("//*[@id='dashboardSection']/account-settings/div/user/language-preference/section/div[1]/button/div[1]"));
						Select sc=new Select(D8.findElement(By.xpath("//*[@id='dashboardSection']/account-settings/div/user/language-preference/section/form/div/div[1]/div/select")));
						sc.selectByValue("F");
						D8.findElement(By.xpath("//*[@id='dashboardSection']/account-settings/div/user/language-preference/section/form/div/div[2]/div[1]/button[2]/div[1]")).click();
						D8.findElement(By.xpath("//*[@id='top-menu']/ul/li[5]/span[2]")).click();
					    D8.findElement(By.xpath("//*[@id='sign-out-dropcontent']")).click();
	                    D8.findElement(By.xpath("//*[@id='main-menu']/ul/li[1]/a")).click();
						status=true; 
				 } 
			 }
			 
		 }
			 catch(Exception e)
				{
					log("error", "Exception caught in language Check:" + e.getMessage());
				}
				return status;
	 }
	
	public boolean compareBalance()
	{
		boolean status=false;
		try
		{
			String previousCloseTotalCost=D8.findElement(By.xpath("//table[2]/tbody/tr[2]/td[2]/span[2]")).getText();
			String previousCloseTotalMarketValue=D8.findElement(By.xpath("//table[2]/tbody/tr[2]/td[3]/span[2]")).getText();
			D8.findElement(By.xpath("html/body/div[4]/form/div/div[1]/a[2]")).click();
			D8.findElement(By.xpath("html/body/div[4]/form/div/div[1]/div[2]/div[3]/a[1]")).click();
			D8.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			String todayTotalCost=D8.findElement(By.xpath("//table[2]/tbody/tr[2]/td[2]/span[2]")).getText();
			String todayTotalMarketValue=D8.findElement(By.xpath("//table[2]/tbody/tr[2]/td[3]/span[2]")).getText();
			if((!previousCloseTotalCost.equals(todayTotalCost))&&(!previousCloseTotalMarketValue.equals(todayTotalMarketValue)))
			{
				log("info", "Today's Total Cost and Total Market Value are not same with Pervious Day's Total Cost and Total Market Value ");
				status=true;
			}
			else
			{
				log("info", "Today's Total Cost and Total Market Value are ame with Pervious Day's Total Cost and Total Market Value ");
				status=false;
			}
			
			
		}catch(Exception e)
		{
			log("error", "Exception caught in compare balance function:" + e.getMessage());
		}
		return status;
		
	}
	public boolean actionDate()
	{
		boolean status=false;
		try
		{
			HashMap<String, String> hmap = new HashMap<String,String>();
			String getActionDate=D8.findElement(By.cssSelector("a[data-link-info='actions: display date: today']")).getText();
			String actionDateSplit=getActionDate.substring(getActionDate.indexOf("(")+1,getActionDate.indexOf(")"));
			String[] actionDate1=actionDateSplit.split(" ");
			String actionDate=actionDate1[0];
			String actionMonth=actionDate1[1];
			String actionYear=actionDate1[2];
			//Getting System Date
			DateFormat df = new SimpleDateFormat("dd/MMMMMMMMM/yyyy");
			Date dateobj = new Date();
			String currentSystemDate = df.format(dateobj);
			String[] systemDateSplit = currentSystemDate.split("/");
			String systemDate=systemDateSplit[0];
			String systemMonth=systemDateSplit[1];
			String systemYear=systemDateSplit[2];
			log("info", "Curent Env:"+testRunLanguage);
			if(testRunLanguage.equalsIgnoreCase("FRE"))
			{
				log("info", "Inside If ");
				/*Adding elements to HashMap*/
				hmap.put("janvier","January");
			    hmap.put("f�vrier","February");
			    hmap.put("mars","March");
			    hmap.put("avril","April");
			    hmap.put("mai","May");
			    hmap.put("juin","June");
			    hmap.put("juillet","July");
			    hmap.put("ao�t","August");
			    hmap.put("septembre","September");
			    hmap.put("octobre","October");
			    hmap.put("novembre","November");
			    hmap.put("d�cembre","December");
			    Set set = hmap.entrySet();
			      Iterator iterator = set.iterator();
			      for (Entry<String, String> entry : hmap.entrySet()) {
			            String key = entry.getKey();
			            String values = entry.getValue();
			            if(key.equalsIgnoreCase(actionMonth))
			            {
			            	actionMonth=values;
			            	break;
			            }
			            
			      }
			    
			}
			
			   
		    if ((actionDate.equals(systemDate))&&(actionMonth.equals(systemMonth))&&(actionYear.equals(systemYear)))
			{
				status=true;
				
			}
			else
			{
				log("debug","Incorrect date is displayed in action dropdown:"+actionDateSplit);
			}
		}catch(Exception e)
		{
			log("error", "Exception caught in action Date function:" + e.getMessage());	
		}
		return status;
	}
	
	public boolean updateonDate(String objelem)
	{
		boolean status=false;
		try
		{
			HashMap<String, String> hmap = new HashMap<String,String>();
			String getUpdateDate=D8.findElement(By.xpath(objelem)).getText();
			String[] engMonths={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
			String[] allDays={"01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"};
			String month = null,day=null,year=null;
			if(testRunLanguage.equalsIgnoreCase("FRE"))
					{
				String[] updateDate=getUpdateDate.split("le ");
				String updateOnText=updateDate[0];
				String updateOnDate=updateDate[1];
				log("error", "updateondate" + updateOnDate);	
				String[] updateDate1=updateOnDate.split(" ");
				 month=updateDate1[0];
				 year=updateDate1[2];
				 log("error", "year" + year);
				 log("error", "month" + month);
				String daycontents=updateDate1[1];
				
				String[] updateDate2=daycontents.split(",");
				 day=updateDate2[0];
				 log("error", "day" + day);
							
					}
			else if(testRunLanguage.equalsIgnoreCase("ENG"))
			{
		String[] updateDate=getUpdateDate.split("on ");
		String updateOnText=updateDate[0];
		String updateOnDate=updateDate[1];
	
		String[] updateDate1=updateOnDate.split(" ");
		 month=updateDate1[0];
		 year=updateDate1[2];
		String daycontents=updateDate1[1];
		
		String[] updateDate2=daycontents.split(",");
		 day=updateDate2[0];
			
					
			}
			boolean monthb = Arrays.asList(engMonths).contains(month);
			boolean dayb=Arrays.asList(allDays).contains(day);
			boolean yearb=false;
			if(year.length()==4)
			{
			yearb=true;
			}
			else
			{
				yearb=false;
			}
			if(monthb==true & dayb==true & yearb==true)
			{
				status=true;
			}
			else
			{
				status=false;
			}
			log("error", "monthb" +monthb);
			log("error", "yearb" +yearb);
			log("error", "dayb" +dayb);
			return status;
		}catch(Exception e)
		{
			log("error", "Exception caught in action Date function:" + e.getMessage());	
		}
		return status;
	}
	
	public boolean updateonTodayDate(String objelem)
	{
		boolean status=false;
		try
		{
			HashMap<String, String> hmap = new HashMap<String,String>();
			String getUpdateDate=D8.findElement(By.xpath(objelem)).getText();
			Calendar c = Calendar.getInstance();
			String todayDate=c.getTime().toString();
			String[] splitDate=todayDate.split(" ");
			String todaymonth=splitDate[1];
			String todayday=splitDate[2];
			String todayyear=splitDate[5];
			
			
			
			//String[] engMonths={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
			//String[] allDays={"01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"};
			String month = null,day=null,year=null;
			if(testRunLanguage.equalsIgnoreCase("FRE"))
					{
				String[] updateDate=getUpdateDate.split("le ");
				String updateOnText=updateDate[0];
				String updateOnDate=updateDate[1];
				log("error", "updateondate" + updateOnDate);	
				String[] updateDate1=updateOnDate.split(" ");
				 month=updateDate1[0];
				 year=updateDate1[2];
				 log("error", "year" + year);
				 log("error", "month" + month);
				String daycontents=updateDate1[1];
				
				String[] updateDate2=daycontents.split(",");
				 day=updateDate2[0];
				 log("error", "day" + day);
							
					}
			else if(testRunLanguage.equalsIgnoreCase("ENG"))
			{
		String[] updateDate=getUpdateDate.split("on ");
		String updateOnText=updateDate[0];
		String updateOnDate=updateDate[1];
	
		String[] updateDate1=updateOnDate.split(" ");
		 month=updateDate1[0];
		 year=updateDate1[2];
		String daycontents=updateDate1[1];
		
		String[] updateDate2=daycontents.split(",");
		 day=updateDate2[0];
			
					
			}
			boolean yearb=false;
			boolean monthb=false;
			boolean dayb=false;
			
			
			if(year.equalsIgnoreCase(todayyear))
			{
			yearb=true;
			}
			else
			{
				yearb=false;
			}
			if(day.equalsIgnoreCase(todayday))
			{
			dayb=true;
			}
			else
			{
				dayb=false;
			}
			if(month.equalsIgnoreCase(todaymonth))
			{
			monthb=true;
			}
			else
			{
				monthb=false;
			}
			
			
			if(monthb==true & dayb==true & yearb==true)
			{
				status=true;
			}
			else
			{
				status=false;
			}
			log("error", "monthb" +monthb);
			log("error", "yearb" +yearb);
			log("error", "dayb" +dayb);
			return status;
		}catch(Exception e)
		{
			log("error", "Exception caught in action Date function:" + e.getMessage());	
		}
		return status;
	}
	
	
	public boolean changeLanguage()
	 {
		 boolean status=false;
		 try
		 {
			 
			 String textContents=D8.findElement(By.xpath("//*[@id='top-menu']/ul/li[4]/a/font")).getText();
			 if(testRunLanguage.equalsIgnoreCase("ENG"))
			 {
				 if(textContents.equalsIgnoreCase("Help"))
				 {
					 log("info", "Language - English - Set Properly");
						status=true; 
				 }
				 else
				 {
					 log("info", "Language - French - Change to English");
				
					 //click on Account Settings
					 D8.findElement(By.cssSelector("a[data-link-info='account settings']"));
					 //click on Language tab
					 D8.findElement(By.xpath("//*[@id='dashboardSection']/account-settings/div/account-settings-nav-bar/div/div[1]/div[1]/h2[7]/a"));
					 //click on the english radio button
					 D8.findElement(By.xpath("//div[3]/form/table/tbody/tr[6]/td/table/tbody/tr[1]/td[2]/input"));
					 //CLICK ON SUBMIT BUTTON
					 D8.findElement(By.xpath("//div[3]/form/table/tbody/tr[6]/td/table/tbody/tr[3]/td/input"));
					 status = true;
					 
				 }
			 }
			 else 
			 {
				 if(textContents.equalsIgnoreCase("Aide"))
				 {
					 log("info", "Language - French - Set properly");
					 status=true; 
				 }
				 else
				 {
					 log("info", "Language - English - Change to French");
					 //click on Account Settings
					 D8.findElement(By.cssSelector("a[data-link-info='account settings']"));
						 //click on Language tab
					 D8.findElement(By.xpath("//*[@id='dashboardSection']/account-settings/div/account-settings-nav-bar/div/div[1]/div[1]/h2[7]/a"));
					 //click on the French radio button
					 D8.findElement(By.xpath("//div[3]/form/table/tbody/tr[6]/td/table/tbody/tr[1]/td[4]/input"));
					 //CLICK ON SUBMIT BUTTON
					 D8.findElement(By.xpath("//div[3]/form/table/tbody/tr[6]/td/table/tbody/tr[3]/td/input"));
					 status = true;
				 } 
			 }
			 
		 }
			 catch(Exception e)
				{
					log("error", "Exception caught in language Check:" + e.getMessage());
				
				}
				return status;
	 }
	
	public boolean tableSortHolding(String tablePath,String columnName)
	{
		boolean status =false;
		try{
		int afterRowCount=0;
		int beforeRowCount=0;
		String columnNum=null;
		String columnHeader=null;
		// xpath of the table body
		String tableBody=tablePath+"/tbody";
		// xpath of the table header
		String tableHeader=tablePath+"/thead";
		WebElement htable = D8.findElement(By.xpath(tableHeader));
		List<WebElement> tableHeaders = htable.findElements(By.tagName("th"));
		Iterator<WebElement> tableItr=tableHeaders.iterator();
		int count=0;
		while(tableItr.hasNext())
			{
			
				WebElement tableRow=tableItr.next();
				String tableHeading=tableRow.getText();
				if(tableHeading.equalsIgnoreCase(columnName))
		        {
		        	count++;
		        	break;
		        	
		        }
				count++;
		        
		        
		      }
		       
		        
		columnNum="col-"+count;
		//columnHeader="th[id='header"+count+"']";
		columnHeader=tableHeader+"/tr/th["+count+"]";
		//*[@id="CADsort"]/thead/tr/th[5]
	    //columnHeader="/tr/th["+count+"]";
	    Thread.sleep(1000);
	    D8.findElement(By.xpath(columnHeader)).click();
	    Thread.sleep(1000);
	    WebElement btable = D8.findElement(By.xpath(tableBody));
		List<WebElement> beforeRows = btable.findElements(By.tagName("tr"));
		int beforeRowsCount=beforeRows.size();
		String [] beforeSort=new String[beforeRowsCount];
		String [] beforeSortValue= new String[beforeRowsCount];
		Iterator<WebElement> beforeItrRow = beforeRows.iterator();
		// Iterating rows
		while(beforeItrRow.hasNext()){
			WebElement beforeRow=beforeItrRow.next();
			List<WebElement> beforeColumns= beforeRow.findElements(By.className(columnNum));
			
			Iterator<WebElement> beforeItrCol = beforeColumns.iterator();
			// Iterating Columns
			while(beforeItrCol.hasNext()){
				WebElement beforeCol = beforeItrCol.next();
				beforeSort[beforeRowCount]=beforeCol.getText();
				beforeSortValue[beforeRowCount]=beforeSort[beforeRowCount];
				//beforeSortValue[beforeRowCount]=beforeSort[beforeRowCount].substring(0, 3);
							
				}beforeRowCount=beforeRowCount+1;
		}
		
		//Click on the column Header
		D8.findElement(By.xpath(columnHeader)).click();
		//D8.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		WebElement btable1 = D8.findElement(By.xpath(tableBody));
		List<WebElement> afterRows = btable1.findElements(By.tagName("tr"));
		// Getting Row Count
		int afterRowsCount=afterRows.size();
		String [] afterSort=new String[afterRowsCount];
		String [] afterSortValue= new String[afterRowsCount];
		Iterator<WebElement> afterItr = afterRows.iterator();
		// Iterating rows
		while(afterItr.hasNext()){
			WebElement afterRow=afterItr.next();
			List<WebElement> afterColumns= afterRow.findElements(By.className(columnNum));
			Iterator<WebElement> afterItrCol = afterColumns.iterator();
			// Iterating columns
			while(afterItrCol.hasNext()){
				WebElement afterColumn = afterItrCol.next();
				//Getting ascending values
				afterSort[afterRowCount]=afterColumn.getText();
				afterSortValue[afterRowCount]=afterSort[afterRowCount];
				}afterRowCount=afterRowCount+1;
		  	}
		int startRow=0;
		String [] finalSort = new String[afterRowCount];
		for(int d=afterRowCount-1;d>=0;d--)
		{
			finalSort[startRow]=afterSortValue[d];
			// Checking the sorted values in descending or not
			if (beforeSortValue[startRow].equals(finalSort[startRow]))
				status= true;
			
			else
			{
				status= false;
				break;
			}
			
			startRow++;
		}
		
			
		return status;
		
		} catch(Exception e) {
			log("error", "Exception in table sort function:" + e.getMessage());
			return status;
		}
	}
	public boolean tableSortConsolidatedTrans(String tablePath,String columnName)
	{
		boolean status =false;
		try{
		int afterRowCount=0;
		int beforeRowCount=0;
		String columnNum=null;
		String columnHeader=null;
		// xpath of the table body
		String tableBody=tablePath+"/tbody";
		// xpath of the table header
		String tableHeader=tablePath+"/thead";
		WebElement htable = D8.findElement(By.xpath(tableHeader));
		List<WebElement> tableHeaders = htable.findElements(By.tagName("th"));
		Iterator<WebElement> tableItr=tableHeaders.iterator();
		int count=0;
		while(tableItr.hasNext())
			{
			
				WebElement tableRow=tableItr.next();
				String tableHeading=tableRow.getText();
				if(tableHeading.equalsIgnoreCase(columnName))
		        {
		        	count++;
		        	break;
		        	
		        }
				count++;
		        
		        
		      }
		       
		   
		columnNum="col-"+count;
		//columnHeader="th[id='header"+count+"']";
		columnHeader=tableHeader+"/tr/th["+count+"]";
		//*[@id="CADsort"]/thead/tr/th[5]
	    //columnHeader="/tr/th["+count+"]";
	    Thread.sleep(1000);
	    D8.findElement(By.xpath(columnHeader)).click();
	    Thread.sleep(1000);
	    WebElement btable = D8.findElement(By.xpath(tableBody));
		List<WebElement> beforeRows = btable.findElements(By.tagName("tr"));
		int beforeRowsCount=beforeRows.size();
		String [] beforeSort=new String[beforeRowsCount];
		String [] beforeSortValue= new String[beforeRowsCount];
		Iterator<WebElement> beforeItrRow = beforeRows.iterator();
		columnNum="col-"+(count-1);
		// Iterating rows
		while(beforeItrRow.hasNext()){
			WebElement beforeRow=beforeItrRow.next();
			List<WebElement> beforeColumns= beforeRow.findElements(By.className(columnNum));
			
			Iterator<WebElement> beforeItrCol = beforeColumns.iterator();
			// Iterating Columns
			while(beforeItrCol.hasNext()){
				WebElement beforeCol = beforeItrCol.next();
				beforeSort[beforeRowCount]=beforeCol.getText();
				beforeSortValue[beforeRowCount]=beforeSort[beforeRowCount];
				//beforeSortValue[beforeRowCount]=beforeSort[beforeRowCount].substring(0, 3);
						
				}beforeRowCount=beforeRowCount+1;
		}
		
		//Click on the column Header
		D8.findElement(By.xpath(columnHeader)).click();
		//D8.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		WebElement btable1 = D8.findElement(By.xpath(tableBody));
		List<WebElement> afterRows = btable1.findElements(By.tagName("tr"));
		// Getting Row Count
		int afterRowsCount=afterRows.size();
		String [] afterSort=new String[afterRowsCount];
		String [] afterSortValue= new String[afterRowsCount];
		Iterator<WebElement> afterItr = afterRows.iterator();
		// Iterating rows
		while(afterItr.hasNext()){
			WebElement afterRow=afterItr.next();
			List<WebElement> afterColumns= afterRow.findElements(By.className(columnNum));
			Iterator<WebElement> afterItrCol = afterColumns.iterator();
			// Iterating columns
			while(afterItrCol.hasNext()){
				WebElement afterColumn = afterItrCol.next();
				//Getting ascending values
				afterSort[afterRowCount]=afterColumn.getText();
				afterSortValue[afterRowCount]=afterSort[afterRowCount];
				}afterRowCount=afterRowCount+1;
		  	}
		int startRow=0;
		String [] finalSort = new String[afterRowCount];
		for(int d=afterRowCount-1;d>=0;d--)
		{
			finalSort[startRow]=afterSortValue[d];
			// Checking the sorted values in descending or not
			if (beforeSortValue[startRow].equals(finalSort[startRow]))
				status= true;
			
			else
			{
				status= false;
				break;
			}
			
			startRow++;
		}
		
			
		return status;
		
		} catch(Exception e) {
			log("error", "Exception in table sort function:" + e.getMessage());
			return status;
		}
	}

	
	public boolean DBConnection(String preRequisite) throws ClassNotFoundException, SQLException
	{
		boolean status= false;
		try{
			String query=null;
			String query1=null;
			String query2=null;
			String query3=null;
		  	 log("info", "in method DBConnection" );
		//Connection URL Syntax: "jdbc:mysql://ipaddress:portnumber/db_name"		
        String dbUrl = "jdbc:oracle:thin:@10.193.16.54:1521:SIRW2";					

		//Database Username		
		String username = "rchanda";	
        
		//Database Password		
		String password = "Welcome2";				

		if(preRequisite.equalsIgnoreCase("USERIDNOTCREATED")&& testRunLanguage.equalsIgnoreCase("ENG"))
				{
		//Query to Execute		
		//String query = "select * from sirw.si_alias where als_alias='MYALIASNAME';";	
			 log("info", "USERIDNOTCREATED(ENGLISH) EXECUTED" );	
		query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid NOT IN (SELECT als_userid FROM sirw.si_alias)AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='E' AND wc_suspind='N' AND WC_SETUP_SECQN_DISABLED = 'N'";
		}
		else if(preRequisite.equalsIgnoreCase("USERIDNOTCREATED")&& testRunLanguage.equalsIgnoreCase("FRE"))
		{
//Query to Execute		
//String query = "select * from sirw.si_alias where als_alias='MYALIASNAME';";	
	 log("info", "USERIDNOTCREATED (FRENCH) EXECUTED " );	
query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid NOT IN (SELECT als_userid FROM sirw.si_alias)AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='F' AND wc_suspind='N' and WC_SETUP_SECQN_DISABLED = 'N'";
}
		else if(preRequisite.equalsIgnoreCase("ALIASNAMECREATED")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "ALIASNAMECREATED(ENGLISH) EXECUTED" );	
			 query = "SELECT als_ALIAS FROM sirw.si_alias WHERE als_userid IN (Select WC_USERID from sirw.si_clients where wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='E' AND wc_suspind='N') AND WC_SETUP_SECQN_DISABLED = 'N'";
				 
		
		}
		else if(preRequisite.equalsIgnoreCase("ALIASNAMECREATED")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "ALIASNAMECREATED(FRENCH) EXECUTED" );	
			 query = "SELECT als_ALIAS FROM sirw.si_alias WHERE als_userid IN (Select WC_USERID from sirw.si_clients where wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='F' AND wc_suspind='N') AND WC_SETUP_SECQN_DISABLED = 'N'";
				 
		
		}
		
		else if(preRequisite.equalsIgnoreCase("TRADINGDISABLED")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "TRADINGDISABLED(ENGLISH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients where wc_suspind='N' AND wc_PASSWD='EZGD2gp80bEQQ'AND WC_LANG='E' AND wc_tradepwd IS NULL AND WC_SETUP_SECQN_DISABLED = 'N'";
				 
		
		}
		else if(preRequisite.equalsIgnoreCase("TRADINGDISABLED")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "TRADINGDISABLED(FRENCH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients where wc_suspind='N' AND wc_PASSWD='EZGD2gp80bEQQ'AND WC_LANG='F' AND wc_tradepwd IS NULL AND WC_SETUP_SECQN_DISABLED = 'N'";
				 
		
		}
		
		else if(preRequisite.equalsIgnoreCase("TRADINGDISABLEDNONMERIDIAN")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "TRADINGDISABLED(ENGLISH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients where wc_userid IN (select cl_clcode from retail.client where cl_freetype<>'W') AND wc_suspind='N' AND wc_PASSWD='EZGD2gp80bEQQ'AND WC_LANG='E' AND wc_tradepwd IS NULL AND WC_SETUP_SECQN_DISABLED = 'N'";
				 
		
		}
		else if(preRequisite.equalsIgnoreCase("TRADINGDISABLEDNONMERIDIAN")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "TRADINGDISABLED(FRENCH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients where wc_userid IN (select cl_clcode from retail.client where cl_freetype<>'W') AND wc_suspind='N' AND wc_PASSWD='EZGD2gp80bEQQ'AND WC_LANG='F' AND wc_tradepwd IS NULL AND WC_SETUP_SECQN_DISABLED = 'N'";
				 
		
		}
		
		
		else if(preRequisite.equalsIgnoreCase("TRADINGENABLED")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "TRADINGENABLED(ENGLISH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients where wc_suspind='N' AND wc_PASSWD='EZGD2gp80bEQQ'AND WC_LANG='E' AND wc_tradepwd IS NOT NULL AND WC_SETUP_SECQN_DISABLED = 'N'";
				 
		
		}
		else if(preRequisite.equalsIgnoreCase("TRADINGENABLED")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "TRADINGENABLED(FRENCH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients where wc_suspind='N' AND wc_PASSWD='EZGD2gp80bEQQ'AND WC_LANG='F' AND wc_tradepwd IS NOT NULL AND WC_SETUP_SECQN_DISABLED = 'N'";
				 
				}
		

		else if(preRequisite.equalsIgnoreCase("TRADINGPWDRESET")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "TRADINGENABLED(ENGLISH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients where wc_suspind='N' AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_TRADEPWD='TRCude38vsiH6' AND WC_LANG='E' AND wc_tradepwd IS NOT NULL AND WC_SETUP_SECQN_DISABLED = 'N'";
				 
		
		}
		else if(preRequisite.equalsIgnoreCase("TRADINGPWDRESET")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "TRADINGENABLED(FRENCH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients where wc_suspind='N' AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_TRADEPWD='TRCude38vsiH6' AND WC_LANG='F' AND wc_tradepwd IS NOT NULL AND WC_SETUP_SECQN_DISABLED = 'N'";
					 
				}
		
		else if(preRequisite.equalsIgnoreCase("AGREEMENTSIGNED")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "TRADINGENABLED(ENGLISH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients where WC_USERID IN(SELECT SA_USERID FROM SIRW.si_statement_agreement) AND wc_suspind='N' AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='E' AND wc_tradepwd IS NOT NULL AND WC_SETUP_SECQN_DISABLED = 'N'";
				 
		
		}
		else if(preRequisite.equalsIgnoreCase("AGREEMENTSIGNED")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "TRADINGENABLED(FRENCH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients where WC_USERID IN(SELECT SA_USERID FROM SIRW.si_statement_agreement) AND wc_suspind='N' AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='F' AND wc_tradepwd IS NOT NULL AND WC_SETUP_SECQN_DISABLED = 'N'";
						 
				}
		
		else if(preRequisite.equalsIgnoreCase("NICKNAMEEMPTY")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "NICKNAMEEMPTY(ENGLISH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid IN (select an_userid from sirw.si_account_nickname where an_nickname IS NULL AND an_display_sequence ='1')AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='E' AND wc_suspind='N' AND WC_SETUP_SECQN_DISABLED = 'N'";
				 
		
		}
		else if(preRequisite.equalsIgnoreCase("NICKNAMEEMPTY")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "NICKNAMEEMPTY(FRENCH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid IN (select an_userid from sirw.si_account_nickname where an_nickname IS NULL AND an_display_sequence ='1')AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='F' AND wc_suspind='N' AND WC_SETUP_SECQN_DISABLED = 'N'";
					 
		
		}
		
		else if(preRequisite.equalsIgnoreCase("NICKNAMEEXIST")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "NICKNAMEEXIST(ENGLISH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid IN (select an_userid from sirw.si_account_nickname where an_nickname IS NOT NULL)AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='E' AND wc_suspind='N' AND WC_SETUP_SECQN_DISABLED = 'N'";
				 
		
		}
		else if(preRequisite.equalsIgnoreCase("NICKNAMEEXIST")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "NICKNAMEEXIST(FRENCH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid IN (select an_userid from sirw.si_account_nickname where an_nickname IS NOT NULL)AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='F' AND wc_suspind='N' AND WC_SETUP_SECQN_DISABLED = 'N'";
					 
		
		}
		else if(preRequisite.equalsIgnoreCase("USERIDCREATED")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "USERIDCREATED(ENGLISH) EXECUTED" );	
			 query = "SELECT als_USERID FROM sirw.si_alias WHERE als_userid IN (Select WC_USERID from sirw.si_clients where wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='E' AND wc_suspind='N') AND WC_SETUP_SECQN_DISABLED = 'N'";
				 
		
		}
		else if(preRequisite.equalsIgnoreCase("USERIDCREATED")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "USERIDCREATED(FRENCH) EXECUTED" );	
			 query = "SELECT als_USERID FROM sirw.si_alias WHERE als_userid IN (Select WC_USERID from sirw.si_clients where wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='F' AND wc_suspind='N') AND WC_SETUP_SECQN_DISABLED = 'N'";
				 
		
		}
		
		else if(preRequisite.equalsIgnoreCase("RESEARCHENABLED")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "RESEARCH ENABLED(ENGLISH) EXECUTED" );	
			 query = "select wc_userid from sirw.si_clients a, retail.client where wc_userid=cl_clcode and cl_freetype='W' and a.WC_NEWRESEARCH is not null and wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='E' AND wc_suspind='N' AND WC_SETUP_SECQN_DISABLED = 'N'";
				 
		
		}
		else if(preRequisite.equalsIgnoreCase("RESEARCHENABLED")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "RESEARCH ENABLED(FRENCH) EXECUTED" );	
			 query = "select wc_userid from sirw.si_clients a, retail.client where wc_userid=cl_clcode and cl_freetype='W' and a.WC_NEWRESEARCH is not null and wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='F' AND wc_suspind='N' AND WC_SETUP_SECQN_DISABLED = 'N'";
			 
				
		}
		
		else if(preRequisite.equalsIgnoreCase("RESEARCHDISABLED")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "RESEARCH DISABLED(ENGLISH) EXECUTED" );	
			 query = "select wc_userid from sirw.si_clients a, retail.client where wc_userid=cl_clcode and cl_freetype='W'  and WC_FEATURE='NNNNNNNNNN' and wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='E' AND wc_suspind='N' AND WC_SETUP_SECQN_DISABLED = 'N'";
		
		}
		else if(preRequisite.equalsIgnoreCase("RESEARCHDISABLED")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "RESEARCH DISABLED(FRENCH) EXECUTED" );	
			 query = "select wc_userid from sirw.si_clients a, retail.client where wc_userid=cl_clcode and cl_freetype='W'  and WC_FEATURE='NNNNNNNNNN' and wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='F' AND wc_suspind='N' AND WC_SETUP_SECQN_DISABLED = 'N'";
				
		}
		
		else if(preRequisite.equalsIgnoreCase("ENABLEFIVETABS")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "ENABLE FIVE TABS(ENGLISH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='E' AND wc_suspind='N' AND wc_frenchresearchdisclaimer='Y' AND wc_tradepwd IS NOT NULL AND WC_SETUP_SECQN_DISABLED = 'N'";
				 
		
		}
		else if(preRequisite.equalsIgnoreCase("ENABLEFIVETABS")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "ENABLE FIVE TABS(FRENCH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='F' AND wc_suspind='N' AND wc_frenchresearchdisclaimer='Y' AND wc_tradepwd IS NOT NULL AND WC_SETUP_SECQN_DISABLED = 'N'";
		}
		else if(preRequisite.equalsIgnoreCase("THREEACCOUNTLINKED")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "THREE ACCOUNT LINKED(ENGLISH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid IN (select an_userid from sirw.si_account_nickname)AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='E' AND wc_suspind='N' AND WC_SETUP_SECQN_DISABLED = 'N'";
				query1="notnull";
		}
		else if(preRequisite.equalsIgnoreCase("THREEACCOUNTLINKED")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "THREE ACCOUNT LINKED(FRENCH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid IN (select an_userid from sirw.si_account_nickname)AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='F' AND wc_suspind='N' AND WC_SETUP_SECQN_DISABLED = 'N'";
			 query1="notnull";
		}
		else if(preRequisite.equalsIgnoreCase("TWOACCOUNTLINKED")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "TWO ACCOUNT LINKED(ENGLISH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid IN (select an_userid from sirw.si_account_nickname)AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='E' AND wc_suspind='N' AND WC_SETUP_SECQN_DISABLED = 'N'";
				query2="notnull";
		}
		else if(preRequisite.equalsIgnoreCase("TWOACCOUNTLINKED")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "TWO ACCOUNT LINKED(FRENCH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid IN (select an_userid from sirw.si_account_nickname)AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='F' AND wc_suspind='N' AND WC_SETUP_SECQN_DISABLED = 'N'";
			 query2="notnull";
		}
		
		else if(preRequisite.equalsIgnoreCase("TWOACCOUNTLINKEDNICKNAMEEMPTY")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "TWO ACCOUNT LINKED(ENGLISH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid IN (select an_userid from sirw.si_account_nickname where an_nickname IS NULL AND an_display_sequence ='1')AND wc_userid IN (select an_userid from sirw.si_account_nickname) AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='E' AND wc_suspind='N' AND WC_SETUP_SECQN_DISABLED = 'N'";
				query2="notnull";
		}
		else if(preRequisite.equalsIgnoreCase("TWOACCOUNTLINKEDNICKNAMEEMPTY")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "TWO ACCOUNT LINKED(FRENCH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid IN (select an_userid from sirw.si_account_nickname where an_nickname IS NULL AND an_display_sequence ='1')AND wc_userid IN (select an_userid from sirw.si_account_nickname) AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='F' AND wc_suspind='N' AND WC_SETUP_SECQN_DISABLED = 'N'";
				 query2="notnull";
		}
		else if(preRequisite.equalsIgnoreCase("ONEACCOUNTLINKED")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "ONE ACCOUNT LINKED(ENGLISH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid IN (select an_userid from sirw.si_account_nickname)AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='E' AND wc_suspind='N' AND WC_SETUP_SECQN_DISABLED = 'N'";
				query3="notnull";
		}
		else if(preRequisite.equalsIgnoreCase("ONEACCOUNTLINKED")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "ONE ACCOUNT LINKED(FRENCH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid IN (select an_userid from sirw.si_account_nickname)AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='F' AND wc_suspind='N' AND WC_SETUP_SECQN_DISABLED = 'N'";
			 query3="notnull";
		}
			
		else if(preRequisite.equalsIgnoreCase("account")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "ONE ACCOUNT LINKED(FRENCH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid IN (select an_userid from sirw.si_account_nickname)AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='F' AND wc_suspind='N' AND WC_SETUP_SECQN_DISABLED = 'N'";
			 query3="notnull";
		}
 	    //Load jdbc driver	
		//com.mysql.jdbc.Driver
   	    Class.forName("oracle.jdbc.driver.OracleDriver");
   	
   	   
   	    
   	 log("info", "First check" );
   
   		//Create Connection to DB		
    	Connection con = DriverManager.getConnection(dbUrl,username,password);
    	 log("info", "second check" );
  
  		//Create Statement Object		
	   Statement stmt = con.createStatement();					

			// Execute the SQL Query. Store results in ResultSet		
 		ResultSet rs= stmt.executeQuery(query);	
 		
 		log("info", "query executed");

 		//log("info", "OUTSIDE CONTENTS 1 ***"+rs.getString(1));
 		//log("info", "OUTSIDE CONTENTS 2 ***"+rs.getString(2));
 		// While Loop to iterate through all data and print results	
 		
 		if(query1==null & query2==null&query3==null)
		{
			log("info", "INside query1,query2,query3 loop");
 		while (rs.next())
		{
			log("info", "********************************************");
			log("info", "INside while loop");
			log("info", "********************************************");
	        		String myName = rs.getString(1);								        
              
	                log("info", "Login UserName : " + myName);
                    
                    enterLoginCreds(myName);
                    status=true;
                   
                    break;
                   
            }	
		}
 	
 		
 	ResultSetMetaData meta = rs.getMetaData();
 		final int columnCount = meta.getColumnCount();
 		List<List<String>> rowList = new LinkedList<List<String>>();
 		List<String> columnList = new LinkedList<String>();
 		while (rs.next())
 		{
 		    
 		    rowList.add(columnList);

 		    for (int column = 1; column <= columnCount; column++) 
 		    {
 		        Object value = rs.getObject(column);
 		        columnList.add(String.valueOf(value));
 		    }
 		}
 		
 		//for(int i = 0; i < columnList.size(); i++) {
 		//	log("info", "****************LIST STRING CONTENST COLUMN***************************"+columnList.get(i).toString());
        // }

 	 
 	if(query1!=null)
        {
 			for(int i = 0; i < columnList.size(); i++) {
 	 			log("info", "**********************"+columnList.get(i).toString());
 	                 log("info", "*********************NOT NULL LOOP ***********************");	
 	          		String queryCount="select count(*) from sirw.si_account_nickname where an_userid='"+columnList.get(i).toString()+"'";
 	                   	ResultSet rs1= stmt.executeQuery(queryCount);
 	         while(rs1.next())
 	          {
 	          	 log("info", "COUNT VALUE : " + rs1.getInt(1));
 	                if(rs1.getInt(1)==3)
 	                {
 	                	log("info", "*********************MATCH FOUND ***********************");	
 	                    enterLoginCreds(columnList.get(i).toString());
 	                    status=true;
 	                    break;
 	                } 
 	         }
 	       if(status==true)
 	       {
 	    	   i=columnList.size();
 	       }
 	          
 	       
 			}	
        	
        	 
        	 
        }
 		if(query3!=null)
        {
 			for(int i = 0; i < columnList.size(); i++) {
 	 			log("info", "**********************"+columnList.get(i).toString());
 	                 log("info", "*********************NOT NULL LOOP ***********************");	
 	          		String queryCount="select count(*) from sirw.si_account_nickname where an_userid='"+columnList.get(i).toString()+"'";
 	                   	ResultSet rs1= stmt.executeQuery(queryCount);
 	         while(rs1.next())
 	          {
 	          	 log("info", "COUNT VALUE : " + rs1.getInt(1));
 	                if(rs1.getInt(1)==1)
 	                {
 	                	log("info", "*********************MATCH FOUND ***********************");	
 	                    enterLoginCreds(columnList.get(i).toString());
 	                    status=true;
 	                    break;
 	                } 
 	         }
 	       if(status==true)
 	       {
 	    	   i=columnList.size();
 	       }
 	          
 	       
 			}	
        	
        	 
        	 
        }
 	 if(query2!=null)
        {
 			for(int i = 0; i < columnList.size(); i++) {
 	 			log("info", "**********************"+columnList.get(i).toString());
 	                 log("info", "*********************NOT NULL LOOP ***********************");	
 	          		String queryCount="select count(*) from sirw.si_account_nickname where an_userid='"+columnList.get(i).toString()+"'";
 	                   	ResultSet rs1= stmt.executeQuery(queryCount);
 	         while(rs1.next())
 	          {
 	          	 log("info", "COUNT VALUE : " + rs1.getInt(1));
 	                if(rs1.getInt(1)==2)
 	                {
 	                	log("info", "*********************MATCH FOUND ***********************");	
 	                    enterLoginCreds(columnList.get(i).toString());
 	                    status=true;
 	                    break;
 	                } 
 	         }
 	       if(status==true)
 	       {
 	    	   i=columnList.size();
 	       }
 	     }	
            } 
 		
		
 		
 		
		log("info", "END OF db Connection");	
		log("info", "********************END OF DB CONNECTION************************");
			 // closing DB Connection		
			con.close();	
			return status;
		}
		catch(Exception e)
		{
			log("error", "Exception caught in DB Connection method" + e.getMessage());
			status= false;
			return status;
		}
}

	public void enterLoginCreds(String userName)
	
	{
	D8.findElement(By.xpath("html/body/div[5]/form/table/tbody/tr[3]/td[2]/input[1]")).sendKeys(userName);
	D8.findElement(By.cssSelector("input[name=password]")).sendKeys("A1aaaaaa");
	
	}

	
	
	
	public boolean DBConnectionTraining(String preRequisite) throws ClassNotFoundException, SQLException
	{
		boolean status= false;
		try{
			String query=null;
			String query1=null;
			String query2=null;
			String query3=null;
		  	 log("info", "in method DBConnection" );
		//Connection URL Syntax: "jdbc:mysql://ipaddress:portnumber/db_name"		
        String dbUrl = "jdbc:oracle:thin:@10.193.17.72:1521:SIRW2";					

		//Database Username		
		String username = "asubbia";	
        
		//Database Password		
		String password = "subbia_123";				

		if(preRequisite.equalsIgnoreCase("USERIDNOTCREATED")&& testRunLanguage.equalsIgnoreCase("ENG"))
				{
		//Query to Execute		
		//String query = "select * from sirw.si_alias where als_alias='MYALIASNAME';";	
			 log("info", "USERIDNOTCREATED(ENGLISH) EXECUTED" );	
		query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid NOT IN (SELECT als_userid FROM sirw.si_alias)AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='E' AND wc_suspind='N'";
		}
		else if(preRequisite.equalsIgnoreCase("USERIDNOTCREATED")&& testRunLanguage.equalsIgnoreCase("FRE"))
		{
//Query to Execute		
//String query = "select * from sirw.si_alias where als_alias='MYALIASNAME';";	
	 log("info", "USERIDNOTCREATED (FRENCH) EXECUTED " );	
query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid NOT IN (SELECT als_userid FROM sirw.si_alias)AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='F' AND wc_suspind='N'";
}
		else if(preRequisite.equalsIgnoreCase("ALIASNAMECREATED")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "ALIASNAMECREATED(ENGLISH) EXECUTED" );	
			 query = "SELECT als_ALIAS FROM sirw.si_alias WHERE als_userid IN (Select WC_USERID from sirw.si_clients where wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='E' AND wc_suspind='N')";
				 
		
		}
		else if(preRequisite.equalsIgnoreCase("ALIASNAMECREATED")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "ALIASNAMECREATED(FRENCH) EXECUTED" );	
			 query = "SELECT als_ALIAS FROM sirw.si_alias WHERE als_userid IN (Select WC_USERID from sirw.si_clients where wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='F' AND wc_suspind='N')";
				 
		
		}
		
		else if(preRequisite.equalsIgnoreCase("TRADINGDISABLED")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "TRADINGDISABLED(ENGLISH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients where wc_suspind='N' AND wc_PASSWD='EZGD2gp80bEQQ'AND WC_LANG='E' AND wc_tradepwd IS NULL";
				 
		
		}
		else if(preRequisite.equalsIgnoreCase("TRADINGDISABLED")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "TRADINGDISABLED(FRENCH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients where wc_suspind='N' AND wc_PASSWD='EZGD2gp80bEQQ'AND WC_LANG='F' AND wc_tradepwd IS NULL";
				 
		
		}
		
		else if(preRequisite.equalsIgnoreCase("TRADINGDISABLEDNONMERIDIAN")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "TRADINGDISABLED(ENGLISH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients where wc_userid IN (select cl_clcode from retail.client where cl_freetype<>'W') AND wc_suspind='N' AND wc_PASSWD='EZGD2gp80bEQQ'AND WC_LANG='E' AND wc_tradepwd IS NULL ";
				 
		
		}
		else if(preRequisite.equalsIgnoreCase("TRADINGDISABLEDNONMERIDIAN")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "TRADINGDISABLED(FRENCH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients where wc_userid IN (select cl_clcode from retail.client where cl_freetype<>'W') AND wc_suspind='N' AND wc_PASSWD='EZGD2gp80bEQQ'AND WC_LANG='F' AND wc_tradepwd IS NULL ";
				 
		
		}
		
		
		else if(preRequisite.equalsIgnoreCase("TRADINGENABLED")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "TRADINGENABLED(ENGLISH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients where wc_suspind='N' AND wc_PASSWD='EZGD2gp80bEQQ'AND WC_LANG='E' AND wc_tradepwd IS NOT NULL";
				 
		
		}
		else if(preRequisite.equalsIgnoreCase("TRADINGENABLED")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "TRADINGENABLED(FRENCH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients where wc_suspind='N' AND wc_PASSWD='EZGD2gp80bEQQ'AND WC_LANG='F' AND wc_tradepwd IS NOT NULL";
				 
				}
		

		else if(preRequisite.equalsIgnoreCase("TRADINGPWDRESET")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "TRADINGENABLED(ENGLISH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients where wc_suspind='N' AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_TRADEPWD='TRCude38vsiH6' AND WC_LANG='E' AND wc_tradepwd IS NOT NULL";
				 
		
		}
		else if(preRequisite.equalsIgnoreCase("TRADINGPWDRESET")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "TRADINGENABLED(FRENCH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients where wc_suspind='N' AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_TRADEPWD='TRCude38vsiH6' AND WC_LANG='F' AND wc_tradepwd IS NOT NULL";
					 
				}
		
		else if(preRequisite.equalsIgnoreCase("AGREEMENTSIGNED")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "TRADINGENABLED(ENGLISH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients where WC_USERID IN(SELECT SA_USERID FROM SIRW.si_statement_agreement) AND wc_suspind='N' AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='E' AND wc_tradepwd IS NOT NULL";
				 
		
		}
		else if(preRequisite.equalsIgnoreCase("AGREEMENTSIGNED")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "TRADINGENABLED(FRENCH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients where WC_USERID IN(SELECT SA_USERID FROM SIRW.si_statement_agreement) AND wc_suspind='N' AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='F' AND wc_tradepwd IS NOT NULL";
						 
				}
		
		else if(preRequisite.equalsIgnoreCase("NICKNAMEEMPTY")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "NICKNAMEEMPTY(ENGLISH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid IN (select an_userid from sirw.si_account_nickname where an_nickname IS NULL AND an_display_sequence ='1')AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='E' AND wc_suspind='N'";
				 
		
		}
		else if(preRequisite.equalsIgnoreCase("NICKNAMEEMPTY")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "NICKNAMEEMPTY(FRENCH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid IN (select an_userid from sirw.si_account_nickname where an_nickname IS NULL AND an_display_sequence ='1')AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='F' AND wc_suspind='N'";
					 
		
		}
		
		else if(preRequisite.equalsIgnoreCase("NICKNAMEEXIST")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "NICKNAMEEXIST(ENGLISH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid IN (select an_userid from sirw.si_account_nickname where an_nickname IS NOT NULL)AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='E' AND wc_suspind='N'";
				 
		
		}
		else if(preRequisite.equalsIgnoreCase("NICKNAMEEXIST")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "NICKNAMEEXIST(FRENCH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid IN (select an_userid from sirw.si_account_nickname where an_nickname IS NOT NULL)AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='F' AND wc_suspind='N'";
					 
		
		}
		else if(preRequisite.equalsIgnoreCase("USERIDCREATED")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "USERIDCREATED(ENGLISH) EXECUTED" );	
			 query = "SELECT als_USERID FROM sirw.si_alias WHERE als_userid IN (Select WC_USERID from sirw.si_clients where wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='E' AND wc_suspind='N')";
				 
		
		}
		else if(preRequisite.equalsIgnoreCase("USERIDCREATED")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "USERIDCREATED(FRENCH) EXECUTED" );	
			 query = "SELECT als_USERID FROM sirw.si_alias WHERE als_userid IN (Select WC_USERID from sirw.si_clients where wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='F' AND wc_suspind='N')";
				 
		
		}
		
		else if(preRequisite.equalsIgnoreCase("RESEARCHENABLED")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "RESEARCH ENABLED(ENGLISH) EXECUTED" );	
			 query = "select wc_userid from sirw.si_clients a, retail.client where wc_userid=cl_clcode and cl_freetype='W' and a.WC_NEWRESEARCH is not null and wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='E' AND wc_suspind='N'";
				 
		
		}
		else if(preRequisite.equalsIgnoreCase("RESEARCHENABLED")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "RESEARCH ENABLED(FRENCH) EXECUTED" );	
			 query = "select wc_userid from sirw.si_clients a, retail.client where wc_userid=cl_clcode and cl_freetype='W' and a.WC_NEWRESEARCH is not null and wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='F' AND wc_suspind='N'";
			 
				
		}
		
		else if(preRequisite.equalsIgnoreCase("RESEARCHDISABLED")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "RESEARCH DISABLED(ENGLISH) EXECUTED" );	
			 query = "select wc_userid from sirw.si_clients a, retail.client where wc_userid=cl_clcode and cl_freetype='W'  and WC_FEATURE='NNNNNNNNNN' and wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='E' AND wc_suspind='N'";
		
		}
		else if(preRequisite.equalsIgnoreCase("RESEARCHDISABLED")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "RESEARCH DISABLED(FRENCH) EXECUTED" );	
			 query = "select wc_userid from sirw.si_clients a, retail.client where wc_userid=cl_clcode and cl_freetype='W'  and WC_FEATURE='NNNNNNNNNN' and wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='F' AND wc_suspind='N'";
				
		}
		
		else if(preRequisite.equalsIgnoreCase("ENABLEFIVETABS")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "ENABLE FIVE TABS(ENGLISH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='E' AND wc_suspind='N' AND wc_frenchresearchdisclaimer='Y' AND wc_tradepwd IS NOT NULL";
				 
		
		}
		else if(preRequisite.equalsIgnoreCase("ENABLEFIVETABS")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "ENABLE FIVE TABS(FRENCH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='F' AND wc_suspind='N' AND wc_frenchresearchdisclaimer='Y' AND wc_tradepwd IS NOT NULL";
		}
		else if(preRequisite.equalsIgnoreCase("THREEACCOUNTLINKED")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "THREE ACCOUNT LINKED(ENGLISH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid IN (select an_userid from sirw.si_account_nickname)AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='E' AND wc_suspind='N'";
				query1="notnull";
		}
		else if(preRequisite.equalsIgnoreCase("THREEACCOUNTLINKED")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "THREE ACCOUNT LINKED(FRENCH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid IN (select an_userid from sirw.si_account_nickname)AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='F' AND wc_suspind='N'";
			 query1="notnull";
		}
		else if(preRequisite.equalsIgnoreCase("TWOACCOUNTLINKED")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "TWO ACCOUNT LINKED(ENGLISH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid IN (select an_userid from sirw.si_account_nickname)AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='E' AND wc_suspind='N'";
				query2="notnull";
		}
		else if(preRequisite.equalsIgnoreCase("TWOACCOUNTLINKED")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "TWO ACCOUNT LINKED(FRENCH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid IN (select an_userid from sirw.si_account_nickname)AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='F' AND wc_suspind='N'";
			 query2="notnull";
		}
		
		else if(preRequisite.equalsIgnoreCase("TWOACCOUNTLINKEDNICKNAMEEMPTY")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "TWO ACCOUNT LINKED(ENGLISH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid IN (select an_userid from sirw.si_account_nickname where an_nickname IS NULL AND an_display_sequence ='1')AND wc_userid IN (select an_userid from sirw.si_account_nickname) AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='E' AND wc_suspind='N'";
				query2="notnull";
		}
		else if(preRequisite.equalsIgnoreCase("TWOACCOUNTLINKEDNICKNAMEEMPTY")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "TWO ACCOUNT LINKED(FRENCH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid IN (select an_userid from sirw.si_account_nickname where an_nickname IS NULL AND an_display_sequence ='1')AND wc_userid IN (select an_userid from sirw.si_account_nickname) AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='F' AND wc_suspind='N'";
				 query2="notnull";
		}
		else if(preRequisite.equalsIgnoreCase("ONEACCOUNTLINKED")&&testRunLanguage.equalsIgnoreCase("ENG"))
		{
			
			 log("info", "ONE ACCOUNT LINKED(ENGLISH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid IN (select an_userid from sirw.si_account_nickname)AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='E' AND wc_suspind='N'";
				query3="notnull";
		}
		else if(preRequisite.equalsIgnoreCase("ONEACCOUNTLINKED")&&testRunLanguage.equalsIgnoreCase("FRE"))
		{
			
			 log("info", "ONE ACCOUNT LINKED(FRENCH) EXECUTED" );	
			 query = "SELECT wc_userid FROM sirw.si_clients WHERE wc_userid IN (select an_userid from sirw.si_account_nickname)AND wc_PASSWD='EZGD2gp80bEQQ' AND WC_LANG='F' AND wc_suspind='N'";
			 query3="notnull";
		}
				
 	    //Load jdbc driver	
		//com.mysql.jdbc.Driver
   	    Class.forName("oracle.jdbc.driver.OracleDriver");
   	
   	   
   	    
   	 log("info", "First check" );
   
   		//Create Connection to DB		
    	Connection con = DriverManager.getConnection(dbUrl,username,password);
    	 log("info", "second check" );
  
  		//Create Statement Object		
	   Statement stmt = con.createStatement();					

			// Execute the SQL Query. Store results in ResultSet		
 		ResultSet rs= stmt.executeQuery(query);	
 		
 		log("info", "query executed");

 		//log("info", "OUTSIDE CONTENTS 1 ***"+rs.getString(1));
 		//log("info", "OUTSIDE CONTENTS 2 ***"+rs.getString(2));
 		// While Loop to iterate through all data and print results	
 		
 		if(query1==null & query2==null&query3==null)
		{
			log("info", "INside query1,query2,query3 loop");
 		while (rs.next())
		{
			log("info", "********************************************");
			log("info", "INside while loop");
			log("info", "********************************************");
	        		String myName = rs.getString(1);								        
              
	                log("info", "Login UserName : " + myName);
                    
                    enterLoginCreds(myName);
                    status=true;
                   
                    break;
                   
            }	
		}
 	
 		
 	ResultSetMetaData meta = rs.getMetaData();
 		final int columnCount = meta.getColumnCount();
 		List<List<String>> rowList = new LinkedList<List<String>>();
 		List<String> columnList = new LinkedList<String>();
 		while (rs.next())
 		{
 		    
 		    rowList.add(columnList);

 		    for (int column = 1; column <= columnCount; column++) 
 		    {
 		        Object value = rs.getObject(column);
 		        columnList.add(String.valueOf(value));
 		    }
 		}
 		
 		//for(int i = 0; i < columnList.size(); i++) {
 		//	log("info", "****************LIST STRING CONTENST COLUMN***************************"+columnList.get(i).toString());
        // }

 	 
 	if(query1!=null)
        {
 			for(int i = 0; i < columnList.size(); i++) {
 	 			log("info", "**********************"+columnList.get(i).toString());
 	                 log("info", "*********************NOT NULL LOOP ***********************");	
 	          		String queryCount="select count(*) from sirw.si_account_nickname where an_userid='"+columnList.get(i).toString()+"'";
 	                   	ResultSet rs1= stmt.executeQuery(queryCount);
 	         while(rs1.next())
 	          {
 	          	 log("info", "COUNT VALUE : " + rs1.getInt(1));
 	                if(rs1.getInt(1)==3)
 	                {
 	                	log("info", "*********************MATCH FOUND ***********************");	
 	                    enterLoginCreds(columnList.get(i).toString());
 	                    status=true;
 	                    break;
 	                } 
 	         }
 	       if(status==true)
 	       {
 	    	   i=columnList.size();
 	       }
 	          
 	       
 			}	
        	
        	 
        	 
        }
 		if(query3!=null)
        {
 			for(int i = 0; i < columnList.size(); i++) {
 	 			log("info", "**********************"+columnList.get(i).toString());
 	                 log("info", "*********************NOT NULL LOOP ***********************");	
 	          		String queryCount="select count(*) from sirw.si_account_nickname where an_userid='"+columnList.get(i).toString()+"'";
 	                   	ResultSet rs1= stmt.executeQuery(queryCount);
 	         while(rs1.next())
 	          {
 	          	 log("info", "COUNT VALUE : " + rs1.getInt(1));
 	                if(rs1.getInt(1)==1)
 	                {
 	                	log("info", "*********************MATCH FOUND ***********************");	
 	                    enterLoginCreds(columnList.get(i).toString());
 	                    status=true;
 	                    break;
 	                } 
 	         }
 	       if(status==true)
 	       {
 	    	   i=columnList.size();
 	       }
 	          
 	       
 			}	
        	
        	 
        	 
        }
 	 if(query2!=null)
        {
 			for(int i = 0; i < columnList.size(); i++) {
 	 			log("info", "**********************"+columnList.get(i).toString());
 	                 log("info", "*********************NOT NULL LOOP ***********************");	
 	          		String queryCount="select count(*) from sirw.si_account_nickname where an_userid='"+columnList.get(i).toString()+"'";
 	                   	ResultSet rs1= stmt.executeQuery(queryCount);
 	         while(rs1.next())
 	          {
 	          	 log("info", "COUNT VALUE : " + rs1.getInt(1));
 	                if(rs1.getInt(1)==2)
 	                {
 	                	log("info", "*********************MATCH FOUND ***********************");	
 	                    enterLoginCreds(columnList.get(i).toString());
 	                    status=true;
 	                    break;
 	                } 
 	         }
 	       if(status==true)
 	       {
 	    	   i=columnList.size();
 	       }
 	     }	
            } 
 		
		
 		
 		
		log("info", "END OF db Connection");	
		log("info", "********************END OF DB CONNECTION************************");
			 // closing DB Connection		
			con.close();	
			return status;
		}
		catch(Exception e)
		{
			log("error", "Exception caught in DB Connection method" + e.getMessage());
			status= false;
			return status;
		}
}

	

	public boolean tableLinkClick(String tablePath,String symbol)
	{
		boolean status =false;
		try{
		// xpath of the table body
		String tableBody=tablePath+"/tbody";
		// xpath of the table header
		String tableHeader=tablePath+"/thead";
		WebElement htable = D8.findElement(By.xpath(tableHeader));
		List<WebElement> tableHeaders = htable.findElements(By.tagName("tr"));
		Iterator<WebElement> tableItr=tableHeaders.iterator();
		
		while(tableItr.hasNext())
			{
			
				WebElement tableRow=tableItr.next();
				String tableHeading=tableRow.getText();
				if(tableHeading.equalsIgnoreCase(symbol))
		        {
		        	
		        	break;
		        	
		        }
				
		        
		        
		      }
		return status;
	
	
		}catch(Exception e)
		{
			log("error", "Exception caught in DB Connection method" + e.getMessage());
			status= false;
			return status;
		}
	}
		
	public boolean setNewUserID(String preRequisite) throws ClassNotFoundException, SQLException
	{
		boolean status= false;
		try{
			String query=null;
			
		  	 log("info", "in method setnewuserid" );
		//Connection URL Syntax: "jdbc:mysql://ipaddress:portnumber/db_name"		
	    String dbUrl = "jdbc:oracle:thin:@10.193.16.54:1521:SIRW2";					

		//Database Username		
		String username = "rchanda";	
	    
		//Database Password		
		String password = "Welcome2";				

		
		query = "select als_alias from sirw.si_alias";
		
		  Class.forName("oracle.jdbc.driver.OracleDriver");
		   	
	   	   
	   	    
		   	 log("info", "First check" );
		   
		   		//Create Connection to DB		
		    	Connection con = DriverManager.getConnection(dbUrl,username,password);
		    	 log("info", "second check" );
		  
		  		//Create Statement Object		
			   Statement stmt = con.createStatement();					

					// Execute the SQL Query. Store results in ResultSet		
		 		ResultSet rs= stmt.executeQuery(query);	
		
		ResultSetMetaData meta = rs.getMetaData();
			final int columnCount = meta.getColumnCount();
			List<List<String>> rowList = new LinkedList<List<String>>();
			List<String> columnList = new LinkedList<String>();
			while (rs.next())
			{
			    
			    rowList.add(columnList);

			    for (int column = 1; column <= columnCount; column++) 
			    {
			        Object value = rs.getObject(column);
			        columnList.add(String.valueOf(value));
			    }
			}
			String newuserid=null;
			int j=0;
			
			if(preRequisite.equalsIgnoreCase("NINECHARACTERS"))
			{
				newuserid="user";
				j=10000;
			}
			else if(preRequisite.equalsIgnoreCase("TENCHARACTERS"))
			{
				newuserid="user";
				j=100000;
			}
			else if(preRequisite.equalsIgnoreCase("TWENTYCHARACTERS"))
			{
				newuserid="useruseruser12";
				j=100000;
			}
			else if(preRequisite.equalsIgnoreCase("TWENTYNINECHARACTERS"))
			{
				newuserid="userabcdefabcdefghijabc";
				j=100000;
			}
			else if(preRequisite.equalsIgnoreCase("THIRTYCHARACTERS"))
			{
				newuserid="userabcdefabcdefghijabc";
				j=1000000;
			}
			else if(preRequisite.equalsIgnoreCase("TENCHARACTERSSPACE"))
			{
				newuserid=" u  s";
				j=10003;
			}
			else if(preRequisite.equalsIgnoreCase("NINECHARACTERSSPACE"))
			{
				newuserid="ab  ";
				j=10000;
			}
			
			else
			{
				newuserid="us45test";
				j=10;
			}
			
			 
			 
			
			String newuserid1=null;
			for(int i = 0; i < columnList.size(); i++) {
				
				log("info", "******LIST STRING CONTENST COLUMN********"+columnList.get(i).toString());
			
		
				newuserid1=newuserid+j;
			
			String contents=columnList.get(i).toString();
			
			if(contents.equalsIgnoreCase(newuserid1))
			{
				log("info", "MATCH FOUND");
				j++;
			
			}
				if(contents.equalsIgnoreCase(newuserid1))
				{
					log("info", "MATCH FOUND");
					j++;
				
				}
		    }
			
			log("info", "****Final user id ********"+newuserid1);
		
			if(!newuserid1.equals(null))
			{
		D8.findElement(By.xpath("//*[@id='aliasUserName']")).sendKeys(newuserid1);
		status=true;
				
			}
	
		log("info", "END OF db Connection");	
		log("info", "********************END OF DB CONNECTION************************");
			 // closing DB Connection		
			con.close();	
			return status;
		}
		catch(Exception e)
		{
			log("error", "Exception caught in DB Connection method" + e.getMessage());
			status= false;
			return status;
		}
	}
			
}//class end
	



