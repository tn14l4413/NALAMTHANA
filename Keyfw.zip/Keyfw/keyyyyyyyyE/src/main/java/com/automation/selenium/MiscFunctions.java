package com.automation.selenium;

import java.io.File;
import java.io.FilenameFilter;


public class MiscFunctions extends BaseClass {

  public String getFullPathOfSoftware(final String Filename) throws Exception {
    String getFullPathOfSoftware = Filename;
    try {
      String softwareRootDir = seleniumDir[0] + "\\ProjectFramework\\Lib";
      log("info","Trying to get full path of software {"+ Filename +"} in path {"+ softwareRootDir+"}");	
      File folderToSearch = new File(softwareRootDir);
      File[] softwares = folderToSearch.listFiles(new FilenameFilter() {
        public boolean accept(File dir, String name) {
          return name.startsWith(Filename);
        }
      });

      if (softwares.length > 0) getFullPathOfSoftware = softwares[softwares.length - 1].toString();

    } catch (Exception e) {
      log("error", "Exception caught while getting full path of software:" + e.getMessage());
    }
    log("info","Full path of sotfware is {"+ getFullPathOfSoftware +"}");
    return getFullPathOfSoftware;
  }


  public void deleteFileIfExists(String deleteFile) throws Exception {
    try {
      File fileToDelete = new File(deleteFile);
      if (fileToDelete.exists()) {
        fileToDelete.delete();
        log("info", "Deleted Existing file: " + deleteFile);
      }
    } catch (Exception e) {
      log("error", "Exception caught while deleting file -" + e.getMessage());
    }
  }

}
