package com.automation.selenium;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class TestEnvInfoReport extends BaseClass {



  public String createSysInfoReport() throws IOException {
    String sysInfoReportHTML = "";
    String sysInforReportName = "";
    try {
      Capabilities caps = ((RemoteWebDriver) D8).getCapabilities();
      BufferedWriter bwSysInfoRpt = null;
      Date cur_dt_sysInfo = new Date();
      DateFormat dateFormat_sysInfo = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
      String strTimeStamp = dateFormat_sysInfo.format(cur_dt_sysInfo);

      if (summaryReportPath.endsWith("\\")) { // checks whether the path ends with
        // '/'
        summaryReportPath = summaryReportPath + "\\";
      }

      sysInforReportName = "SysInfoReport@" + strTimeStamp + ".html";
      sysInfoReportHTML = summaryReportPath + "SysInfoReport@" + strTimeStamp + ".html";

      bwSysInfoRpt = new BufferedWriter(new FileWriter(sysInfoReportHTML));
      bwSysInfoRpt
          .write("<HTML><BODY HEIGHT=50 WIDTH=50><TABLE BORDER=0 CELLPADDING=3 CELLSPACING=1 WIDTH=100%>");
      bwSysInfoRpt.write("<TABLE BORDER=0 BGCOLOR=WHITE CELLPADDING=3 CELLSPACING=1 WIDTH=100%>");
      bwSysInfoRpt
          .write("<TR><TD BGCOLOR=GREEN WIDTH=100%><FONT FACE=VERDANA COLOR=WHITE SIZE=5><B><CENTER>Test Environment Details</CENTER></B></FONT></TD></TR></TABLE>");

      bwSysInfoRpt
          .write("<table border=3 bordercolor=#0000FF style=background-color:#99FF99 width=100% cellpadding=1 cellspacing=3>");
      bwSysInfoRpt.write("<tr><td>Browser Name</td><td>" + caps.getBrowserName() + "</td></tr>");
      bwSysInfoRpt.write("<tr><td>Browser Version</td><td>" + caps.getVersion() + "</td></tr>");
      bwSysInfoRpt.write("<tr><td>Operating System</td><td>" + System.getProperty("os.name")
          + "</td></tr>");
      bwSysInfoRpt.write("<tr><td>Processor Architecture</td><td>"
          + System.getenv("PROCESSOR_ARCHITECTURE") + "</td></tr>");
      bwSysInfoRpt.write("<tr><td>Computer Name</td><td>" + System.getenv("COMPUTERNAME")
          + "</td></tr>");
      bwSysInfoRpt.write("<tr><td>User Name</td><td>" + System.getenv("USERNAME") + "</td></tr>");
      /*
      bwSysInfoRpt.write("<tr><td>JavaScript Enabled</td><td>" + caps.isJavascriptEnabled()
          + "</td></tr>");
      bwSysInfoRpt.write("<tr><td>Handles Alerts</td><td>" + caps.getCapability("handlesAlerts")
          + "</td></tr>");
      bwSysInfoRpt.write("<tr><td>Unexpected Alert Behaviour</td><td>"
          + caps.getCapability("unexpectedAlertBehaviour") + "</td></tr>");
      */
      bwSysInfoRpt.write("<tr><td>Test Run Environment</td><td>" + testRunEnvironment
              + "</td></tr>");
          bwSysInfoRpt.write("<tr><td>Test Run Language</td><td>" + testRunLanguage
              + "</td></tr>");
          bwSysInfoRpt.write("<tr><td>Test Run Type</td><td>"
              + testExecutionType + "</td></tr>");
          
          
      bwSysInfoRpt.write("</table>");

      bwSysInfoRpt
          .write("<TR><TD WIDTH=100%><FONT FACE=VERDANA SIZE=3><B><CENTER><INPUT TYPE=BUTTON VALUE=Close onclick=window.close()></INPUT></CENTER></FONT></TD>");
      bwSysInfoRpt.close();

    } catch (Exception e) {
      log("error", "Exception caught in creating Sys Info report: " + e.getMessage());
    }
    return sysInforReportName;

  }



}
