package com.Gatewaytr.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Admin {
	WebDriver driver;
	By Username_Admin = By.name("userID");
	By Password_Admin = By.name("password");
	By LoginButton_Admin = By.xpath(".//*[@id='login']");
	By Password_Link=By.xpath("/html/body/table[1]/tbody/tr[2]/td/a[3]/img");
	By OverridePassword_Link=By.xpath("/html/body/table[3]/tbody/tr[3]/td/table/tbody/tr[1]/td[3]/a/img");
	By OverrrideClientLogin_UserID=By.xpath("/html/body/table[3]/tbody/tr[3]/td/form/table/tbody/tr[6]/td[2]/input");
	By OverrrideClientLogin_Submit=By.xpath("/html/body/table[3]/tbody/tr[3]/td/form/table/tbody/tr[8]/td/input");
	By OverrrideClientLogin_TmpPassword=By.xpath("/html/body/form/table[2]/tbody/tr[2]/td/table[2]/tbody/tr[8]/td[2]/input");
	By OverrrideClientLogin_SuccessMsg=By.xpath("/html/body/form/table/tbody/tr[5]/td/table/tbody/tr[2]/td");
	
	public String getTemporaryPassword(CharSequence[] accountNumber) {
		
		try{
		driver.findElement(Username_Admin).sendKeys("marty");
		driver.findElement(Password_Admin).sendKeys("aaaaaa");
		driver.findElement(LoginButton_Admin).click();
		driver.findElement(Password_Link).click();
		driver.findElement(OverridePassword_Link).click();
		driver.findElement(OverrrideClientLogin_UserID).sendKeys(accountNumber);
		driver.findElement(OverrrideClientLogin_Submit).click();
		String tmpPassword=driver.findElement(OverrrideClientLogin_TmpPassword).getText();
		return tmpPassword;
		}
		catch(Exception e)
		{
			System.out.println("Exception caught in Admin Method:"+e.getMessage());
		}
		return null;
	
	}
	
}
