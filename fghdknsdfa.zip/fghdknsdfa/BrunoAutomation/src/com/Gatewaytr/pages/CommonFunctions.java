package com.Gatewaytr.pages;

import java.util.Iterator;
import java.util.List;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;







import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;



import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.sikuli.script.*;

import com.Gateway.GlobalParameters.BaseClass;
import com.Gateway.GlobalParameters.FetchingOR;
import com.Gatewaytr.ExcelFile.ExcelJXL;
import com.Gatewaytr.ExcelFile.ReadExcelFile;
import com.Gatewaytr.Testcases.ExtentReport;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.Gatewaytr.PDFFile.*;

public class CommonFunctions extends BaseClass{

	static  WebDriverWait wait;
	public static FetchingOR oFetchingOR =null;
	public static String ORFileName="C:\\GatewayPasswordReset\\Configuration\\ConfigurationPage.property";
	
	
	public static void verifyText(WebDriver driver,String text,String element,String testCaseName) throws IOException{
		try
		{
		
	 if(driver.findElement(By.linkText(element)).getText().equalsIgnoreCase(text))
		 
	 {

		 statusPass("Verification of Text Success:"+text);
	 } 
	 else
	 {

		 statusFail(driver,"Verification of Text Failed:"+text,testCaseName);
	 } 
	 
	 
		} 
		catch(Exception e)
		{
			 System.out.println("Exception caught in VerifyText Method-------"+e.getMessage());
			 statusFail(driver,"Verification of Text Failed:"+text,testCaseName);
			 
		 } 
	} 

	
	public static void verifyElement(WebDriver driver,String text,String element,String testCaseName) throws IOException{
		try
		{
			
			CommonFunctions.waitForElement(driver, element, 40, testCaseName);
		
	 if(driver.findElement(By.xpath(element)).isDisplayed())
		 
	 {

		 statusPass("Element is Displayed Successfully: ---  "+text);
	 } 
	
	 
		} 
		catch(Exception e)
		{
			 System.out.println("Exception caught in VerifyElement Method-------"+e.getMessage());
			 statusFail(driver,"Element is not displayed in Application:" + text,testCaseName);
			 endReporting();
			 driver.close();
			 Assert.fail("Verify elements");
			
			 
		 } 
	} 
	
	public static void verifyElementByName(WebDriver driver,String text,String tmpName,String testCaseName) throws IOException{
		try
		{
			
			//CommonFunctions.waitForElement(driver, element, 40, testCaseName);
	
			java.util.List<WebElement> eletxt1 = driver.findElements(By.xpath(".//input"));			
			for(WebElement e : eletxt1)
			{
				int n =e.getAttribute("name").compareTo(tmpName);
				if(n == 0)
				{
					if(e.isDisplayed())
					 
					 {

						 statusPass("Element Displayed Successfully--"+text);
					 } 
					break;
				}
				
			}
			Thread.sleep(1000);
			
	
		} 
		catch(Exception e)
		{
			 System.out.println("Exception caught in VerifyElement Method-------"+e.getMessage());
			 statusFail(driver,"Element is not displayed in Application:" + text,testCaseName);
			 endReporting();
			 driver.close();
			 Assert.fail("Verify elements");
			
			 
		 } 
	} 
	public static void verifyElementbyValue(WebDriver driver,String text,String element,String testCaseName) throws IOException{
		try
		{
			
			
			
			String tmpxpath = ".//md-radio-button[@value= '" + element +"']";
			
			//CommonFunctions.waitForElement(driver, tmpxpath, 40, testCaseName);
		
	 if(driver.findElement(By.xpath(tmpxpath)).isDisplayed())
		 
	 {

		 statusPass("Element Displayed Successfully:"+text);
	 } 
	
	 
		} 
		catch(Exception e)
		{
			 System.out.println("Exception caught in VerifyElement Method-------"+e.getMessage());
			 statusFail(driver,"Element is not displayed in Application:" + text,testCaseName);
			 endReporting();
			 driver.close();
			 Assert.fail("Verify elements");
			
			 
		 } 
	} 
	
	public static void verifyElementByLabel(WebDriver driver,String text,String element,String testCaseName) throws IOException{
		try
		{

			String tmpxpath = ".//md-radio-button[@aria-label= '" + element +"']";
			//CommonFunctions.waitForElement(driver, tmpxpath, 40, testCaseName);
		
	 if(driver.findElement(By.xpath(tmpxpath)).isDisplayed())
		 
	 {

		 statusPass("Element Displayed Successfully--"+text);
	 } 

		} 
		catch(Exception e)
		{
			 System.out.println("Exception caught in VerifyElement Method-------"+e.getMessage());
			 statusFail(driver,"Element is not displayed in Application:" + text,testCaseName);
			 endReporting();
			 driver.close();
			 Assert.fail("Verify elements");
			 
			
			 
		 } 
	} 
	
	
	public static void waitForElement(WebDriver driver,String element,int Seconds,String testCaseName) throws IOException{
		try{
		
		
			wait=new WebDriverWait(driver, Seconds);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element)));
			//System.out.println("***********Waiting for element***********");
			//statusPass("Element is displayed in Application");
		}
		catch(Exception e)
		{
			System.out.println("Exception caught in Wait For Element Method-------"+e.getMessage());
			 statusFail(driver,"Element is not displayed in Application:" + element,testCaseName);
			 endReporting();
			 driver.close();
			 Assert.fail("Wait for elements");
		}
	 
		 } 
	
	public static void checkDisabled(WebDriver driver,String element,String text,String testCaseName) throws IOException{
		try
		{
		
					
			boolean status=driver.findElement(By.xpath(element)).isEnabled();
			if(status==false)
			{
				 statusPass("Element  "+ text+ " is disabled/Not Editable"); 
			}
			else
			{
				statusFail(driver,"Element is enabled" +text,testCaseName); 
				statusFail(driver, "Element  "+ text+ " is Enabled/Editable", testCaseName);
				
			}
       	 
       	  }
	
	 
		
		catch(Exception e)
		{
			 System.out.println("Exception caught in check disabled Method-------"+e.getMessage());
			 statusFail(driver,"Element is present in the application" + text,testCaseName);
			 endReporting();
			 driver.close();
			 Assert.fail("Verify Element is disabled");
			
			 
		 } 
	}
	
	public static void checkEnabled(WebDriver driver,String element,String text,String testCaseName) throws IOException{
		try
		{
		
					
			boolean status=driver.findElement(By.xpath(element)).isEnabled();
			if(status==true)
			{
				 statusPass("Element  "+ text+ " is Enabled/Editable"); 
			}
			else
			{
				//statusFail(driver,"Element is Disabled" +text,testCaseName); 
				statusFail(driver, "Element  "+ text+ " is Disabled/ Not-Editable", testCaseName);
				 
			}
       	 
       	  }
	
	 
		
		catch(Exception e)
		{
			 System.out.println("Exception caught in check disabled Method-------"+e.getMessage());
			 statusFail(driver,"Element is present in the application" + text,testCaseName);
			 endReporting();
			 driver.close();
			 Assert.fail("Verify Element is disabled");
			
			 
		 } 
	}
	public static void checkDisabledListbox(WebDriver driver,String element,String text,String testCaseName) throws IOException{
		try
		{
			
			WebElement e = driver.findElement(By.xpath(element));
			
		
			
			boolean status = e.getAttribute("aria-disabled").equals("false");		
			//boolean status=driver.findElement(By.xpath(element)).isEnabled();
			if(status==false)
			{
				 statusPass("Element  "+ text+ " is disabled/Not Editable"); 
			}
			else
			{
				statusFail(driver,"Element is enabled" +text,testCaseName); 
				statusFail(driver, "Element  "+ text+ " is Enabled/Editable", testCaseName);
			}
       	 
       	  }
	
	 
		
		catch(Exception e)
		{
			 System.out.println("Exception caught in check disabled Method-------"+e.getMessage());
			 statusFail(driver,"Disabled check operation Failed" + text,testCaseName);
			 endReporting();
			 driver.close();
			 Assert.fail("Verify Element is disabled");
			
			 
		 } 
	}
	
	public static void checkDisabledTextbox(WebDriver driver,String element,String text,String testCaseName) throws IOException{
        try
        {
               
               WebElement e = driver.findElement(By.xpath(element));
               
               boolean status = e.getAttribute("ng-disabled").equals("false"); 
              
               String att = e.getAttribute("ng-disabled");
              // String a = e.getText();
              // System.out.println(att);
               
               if(status==false)
               {
                     statusPass("Element  "+ text+ " is Editable"); 
               }
               else
               {
                     statusFail(driver,"Element is enabled" +text,testCaseName); 
                     statusFail(driver, "Element  "+ text+ " is not Enabled/ Not Editable", testCaseName);
               }
         
          }
 
        
        catch(Exception e)
        {
               System.out.println("Exception caught in check disabled Method-------"+e.getMessage());
               statusFail(driver,"Disabled check operation Failed" + text,testCaseName);
               endReporting();
               driver.close();
               Assert.fail("Verify Element is disabled");
               
               
         } 
 }	
	
	
	public static void checkBold(WebDriver driver,String element,String text,String testCaseName) throws IOException{
        try
        {
               
               WebElement e = driver.findElement(By.xpath(element));
               
               boolean status = e.getCssValue("font-weight").equals("bold"); 
                 
               if(status==true)
               {
                     statusPass("Element  "+ text+ " is Bold"); 
               }
               else
               {
                    statusFail(driver, "Element  "+ text+ " is not Bold", testCaseName);
               }
         
          }
 
        
        catch(Exception e)
        {
               System.out.println("Exception caught in check Bold Method-------"+e.getMessage());
               statusFail(driver,"Check Bold operation Failed" + text,testCaseName);
               endReporting();
               driver.close();
               Assert.fail("CheckBold Operation is Failed");
               
               
         } 
 }	
	
	
	public static void waitForElementMouse(WebDriver driver,String element,int Seconds,String txt) throws IOException{
		try{
		
			statusPass("Login Successful, Home Page is Displayed");
			wait=new WebDriverWait(driver, Seconds);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.className(element)));
			//System.out.println("***********Waiting for element***********");
			//statusPass("Element is displayed in Application within waitingTime:" + element);
			statusPass(txt+" is Displayed in Home Page");
		}
		catch(Exception e)
		{
			System.out.println("Exception caught in Wait For Element Method-------"+e.getMessage());
			// statusFail(driver,"Element is not displayed in Application:" + element,testCaseName);
			 statusFail(driver,"Element is not displayed in Application:",txt);
			 endReporting();
			 driver.close();
			 Assert.fail("Waiting for element :  "+txt);
		}
	 
		 } 

	public static void verifyMasked(WebDriver driver,String element,String text,String testCaseName) throws IOException{
		try
		{
		
			 String passwordContents = driver.findElement(By.xpath(element)).getAttribute("type");
			 statusPass("Text field contents are masked" +passwordContents); 
       	  if (passwordContents.equalsIgnoreCase("password")) {
       		 statusPass("Text field contents are masked" +text);  
       		  
       		  
       	  }
       	  }
		
		catch(Exception e)
		{
			 System.out.println("Exception caught in Verify Masked Method-------"+e.getMessage());
			 statusFail(driver,"Text field contents are not masked" + text,testCaseName);
			 endReporting();
			 driver.close();
			 Assert.fail("Verify masked");
			
		}	 
	}
	
	public static void clickAround(WebDriver driver,String element0,String element1,String element2,String element3,String iFrame,String element4,String testCaseName) throws IOException{
		try
		{ 	   		 
       		 //System.out.println("Inside ClickAround");
       		 
			driver.findElement(By.className(element1)).click();
			
			Thread.sleep(5000);
			driver.findElement(By.xpath(element2)).click();
			statusPass("Clicked Cilents Menu in Slider");
			Thread.sleep(5000);
			driver.findElement(By.xpath(element3)).click();
			
			Thread.sleep(5000);			
					
			//System.out.println("before mouse move");
			Actions action = new Actions(driver);
	        WebElement mainMenu = driver.findElement(By.xpath(element0));
	        action.moveToElement(mainMenu).click().build().perform();			
			//System.out.println("After Mouse move");
			Thread.sleep(5000);
			
			//statusPass("Click Around Operation is performed in the Application " + element4);
       		 
       	  }	 	
		catch(Exception e)
		{
			 System.out.println("Exception caught in ClickAround Method-------"+e.getMessage());
			 statusFail(driver,"ClickAround Operation is not performed in the Application ",testCaseName);
			 endReporting();
			 driver.close();
			 Assert.fail("ClickAround");
						 
		 } 
	}

	public static void NavigateToNewProposal(WebDriver driver,String iFrame,String element1,String testCaseName) throws IOException{
		try
		{ 	   		 
       		 //System.out.println("Inside NavigateToNewProposal");			
			//Select iFrame
			driver.switchTo().frame(driver.findElement(By.xpath(iFrame)));
			//Thread.sleep(5000);
			//Click on 'New Investment Proposal
			driver.findElement(By.xpath(element1)).click();
			statusPass("New Investment Proposal Button is Displayed in Home page" );
			Thread.sleep(5000);
			statusPass("New Investment Proposal Button is Clicked in Home page" );
				 
       	  }	 	
		catch(Exception e)
		{
			 System.out.println("Exception caught in Navigate to New Proposal Method-------"+e.getMessage());
			 statusFail(driver,"New Investment Proposal Button is not Displayed in Home page",testCaseName);
			 endReporting();
			 Assert.fail("Navigate to New Proposal");
						 
		 } 
	}
	public static void NavigateToInprogressProposal(WebDriver driver,String iFrame,String element1,String testCaseName) throws IOException{
		try
		{ 	   		 
       		 //System.out.println("Inside NavigateToInprogressProposal");			
			//Select iFrame
			driver.switchTo().frame(driver.findElement(By.xpath(iFrame)));
			//Thread.sleep(5000);
			//Click on 'New Investment Proposal
			driver.findElement(By.xpath(element1)).click();
			statusPass("New Investment Proposal Button is Displayed in Home page" );
			Thread.sleep(5000);
			statusPass("New Investment Proposal Button is Clicked in Home page" );
				 
       	  }	 	
		catch(Exception e)
		{
			 System.out.println("Exception caught in Navigate to New Proposal Method-------"+e.getMessage());
			 statusFail(driver,"New Investment Proposal Button is not Displayed in Home page",testCaseName);
			 endReporting();
			 Assert.fail("Navigate to New Proposal");
						 
		 } 
	}
	public static void waitforobject(String tmpxpath) throws IOException{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver,120);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tmpxpath)));
		}
		catch (Exception e)
		{
			System.out.println("Exception caught in waitforobject Method-------"+e.getMessage());
			 statusFail(driver,"waitforobject Operation is not performed","");
			 endReporting();
			 driver.close();
			 Assert.fail("waitforobject");	
		}
	}
	
	@SuppressWarnings("null")
	public static void SetText(WebDriver driver,String tmpxpath,String strText) throws IOException{
		try
		{
			driver.findElement(By.xpath(tmpxpath)).clear();
			driver.findElement(By.xpath(tmpxpath)).sendKeys(strText);
			
			Thread.sleep(1000);
		}
		catch (Exception e)
		{
			 System.out.println("Exception caught in setText Method-------"+e.getMessage());
			 statusFail(driver,"Set Text Operation is not performed","");
			 endReporting();
			 driver.close();
			 Assert.fail("SetText");	
		}
	}
	
	@SuppressWarnings("null")
	public static void SetTextByName(WebDriver driver,String tmpName,String strText) throws IOException{
		try
		{
			java.util.List<WebElement> eletxt1 = driver.findElements(By.xpath(".//input"));			
			for(WebElement e : eletxt1)
			{
				int n =e.getAttribute("name").compareTo(tmpName);
				if(n == 0)
				{
					e.clear();
					e.sendKeys(strText);
					break;
				}
				
			}
			Thread.sleep(1000);
			
		}
		catch (Exception e)
		{
			 System.out.println("Exception caught in setText Method-------"+e.getMessage());
			 statusFail(driver,"Set Text Operation is not performed","");
			 endReporting();
			 driver.close();
			 Assert.fail("SetText");	
		}
	}
	
	@SuppressWarnings("null")
	public static void SetTextByClass(WebDriver driver,String tmpName,String strText) throws IOException{
		try
		{
			java.util.List<WebElement> eletxt1 = driver.findElements(By.xpath(".//input"));			
			for(WebElement e : eletxt1)
			{
				int n =e.getAttribute("class").compareTo(tmpName);
				if(n == 0)
				{
					e.clear();
					e.sendKeys(strText);
					break;
				}
				
			}
			Thread.sleep(1000);
			
		}
		catch (Exception e)
		{
			 System.out.println("Exception caught in setText Method-------"+e.getMessage());
			 statusFail(driver,"Set Text Operation is not performed","");
			 endReporting();
			 driver.close();
			 Assert.fail("SetText");	
		}
	}
	
	@SuppressWarnings("null")
	public static void SetDate(WebDriver driver,String tmpxpath, String strDate) throws IOException{
		try
		{
			Thread.sleep(1000);	
			System.out.println("inside set date: "+ tmpxpath); 
			driver.findElement(By.xpath(tmpxpath)).click();
			Thread.sleep(2000);
			java.util.List<WebElement> eledobtxt = driver.findElements(By.xpath(tmpxpath + "/input"));			
			for(WebElement e : eledobtxt)
			{
		
				int n =e.getAttribute("class").compareTo("md-datepicker-input md-input");
				if(n == 0)
				{
					e.clear();
					e.sendKeys(strDate);
					break;
				}
				
			}
			
			Thread.sleep(2000);
			
		}
		catch (Exception e)
		{
			 System.out.println("Exception caught in SetDate Method-------"+e.getMessage());
			 statusFail(driver,"Set Date Operation is not performed","");
			 endReporting();
			 driver.close();
			 Assert.fail("SetDate");	
		}
	}
	
	@SuppressWarnings("null")
	public static void ClickButton(WebDriver driver,String tmpxpath) throws IOException{
		try
		{
			
			
			
			Thread.sleep(2000);
			driver.findElement(By.xpath(tmpxpath)).click();
			
			
			
			//System.out.println("Ater Inside ClickButton: " + tmpxpath);
			Thread.sleep(1000);
		}
		catch (Exception e)
		{
			 System.out.println("Exception caught in ClickButton Method-------"+e.getMessage());
			 statusFail(driver,"Click Operation is Failed","");
			 endReporting();
			
			 driver.close();  //Added on 26/07/2017
			 Assert.fail("ClickButton");	
		}
	}
	
	@SuppressWarnings("null")
	public static void SelectRadioButton(WebDriver driver,String tmpValue) throws IOException{
		try
		{
			//wait = new WebDriverWait(driver, 120);
			Thread.sleep(2000);
			String tmpxpath = ".//md-radio-button[contains (@value, '" + tmpValue +"')]";
			//driver.findElement(By.xpath(tmpxpath)).click();
			//WebElement SelectRadio = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className(tmpxpath)));
			//SelectRadio.click();
			WebElement elemen = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tmpxpath)));		
			elemen.click();
			Thread.sleep(2000);
		}
		catch (Exception e)
		{
			 System.out.println("Exception caught in SelectRadio Button Method-------"+e.getMessage());
			 statusFail(driver,"SelectRadio button Operation is not performed","");
			 endReporting();
			 driver.close();
			 Assert.fail("SelectRadio Button");	
		}
	}
	
	@SuppressWarnings("null")
	public static void SelectRadioButtonXpath(WebDriver driver,String tmpValue) throws IOException{
		try
		{
			//wait = new WebDriverWait(driver, 120);
			Thread.sleep(2000);
			String tmpxpath = ".//md-radio-button[@aria-label= '" + tmpValue +"']";
			//driver.findElement(By.xpath(tmpxpath)).click();
			//WebElement SelectRadio = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className(tmpxpath)));
			//SelectRadio.click();
			WebElement elemen = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tmpxpath)));		
			elemen.click();
			Thread.sleep(2000);
		}
		catch (Exception e)
		{
			 System.out.println("Exception caught in SelectOption Method-------"+e.getMessage());
			 statusFail(driver,"SelectOption  is not performed **","");
			 endReporting();
			 driver.close();
			 Assert.fail("SelectOption");	
		}
	}
	public static void PDFDownload(WebDriver driver,String TestCaseID,String Functionality, String testCaseName,String ImageName) throws IOException{
		
		try
		{
			 
			Screen s=new Screen();
			Pattern image = new Pattern("C:\\BrunoAutomationFramework\\Sikuli Images\\"+ImageName);
			s.wait(image, 10);
			s.click(image)	;
				         
	               
		}
			
		
		catch(Exception e)
		{
			
			 statusFail(driver,"Unable to select the check box",testCaseName);
			 endReporting();
			 Assert.fail("Unable to select the check box");
			
			 
		 } 
		
	}
	
	public static void checkMandatoryField(WebDriver driver,String element,String text,String testCaseName) throws IOException{
        try
        {
               
               WebElement e = driver.findElement(By.xpath(element));
               
               boolean status = e.getAttribute("required").equals("true"); 
              
               if(status==true)
               {
                     statusPass("Element  "+ text+ " is a Mandatory Field"); 
               }
               else
               {
                     statusFail(driver,"Element is enabled--" +text,testCaseName); 
                     statusFail(driver, "Element  "+ text+ " is not a Mandatory Field", testCaseName);
               }
         
          }

        
        catch(Exception e)
        {
               System.out.println("Exception caught in check Mandatory Field Method-------"+e.getMessage());
               statusFail(driver,"check Mandatory Field operation Failed" + text,testCaseName);
                             
               
         } 
 }

	
	@SuppressWarnings("null")
	public static void SelectListBox(WebDriver driver,String tmpxpath,String tmpOption) throws IOException{
		try
		{
			Thread.sleep(1000);
			//System.out.println("Inside Select: "+ tmpxpath);
			driver.findElement(By.xpath(tmpxpath)).click();
			Thread.sleep(1000);
			
			java.util.List<WebElement> ele = driver.findElements(By.xpath(".//md-option"));			
			for(WebElement e : ele)
			{
				//System.out.println(e.getText());
				int n = e.getText().compareTo(tmpOption);
				//System.out.println(n);
				if(n == 0)
				{
				//	System.out.println("inside RE4");
					e.click();
					break;
				}
				
			}
			
			Thread.sleep(2000);
			
		}
		catch (Exception e)
		{
			 System.out.println("Exception caught in SelectOption Method-------"+e.getMessage());
			 statusFail(driver,"SelectOption Operation is not performed ++","");
			 endReporting();
			 driver.close();
			 Assert.fail("SelectOption");	
		}
	}
	
	public static void VerifyListBoxValue(WebDriver driver,String tmpxpath,String[] exp) throws IOException{
		try
		{
			
					 
     		Thread.sleep(1000);
			//System.out.println("Inside Select: "+ tmpxpath);
			driver.findElement(By.xpath(tmpxpath)).click();
			Thread.sleep(1000);
			
			java.util.List<WebElement> ele = driver.findElements(By.xpath(".//md-option"));			
			for(WebElement e : ele)
			{
			
				  for (int i=0; i<exp.length; i++){
				      if (e.getText().equals(exp[i]))
				      {
				    		
				    		break;
				      }
				    }
			
				  //System.out.println("Select List Box Value Verified");
				
			}
				
			
			
			Thread.sleep(2000);
			
		}
		catch (Exception e)
		{
			 System.out.println("Exception caught in SelectOption Method-------"+e.getMessage());
			 statusFail(driver,"SelectOption Operation is not performed","");
			 endReporting();
			 driver.close();
			 Assert.fail("SelectOption");	
		}
	}
	
	
	@SuppressWarnings("null")
	public static void CreateNewProposal(WebDriver driver,String TestcaseID,String Functionality,String testCaseName) throws IOException{
	//	public static void CreateNewProposal(WebDriver driver,String iFrame,String element1,String TestcaseID,String Functionality,String testCaseName) throws IOException{
		try
		{ 	
			//oFetchingOR = new FetchingOR(ORFileName);
			
			obj = new FetchingOR(fileName);
			
       		//System.out.println("Inside CreateNewProposal");		
       		
       		//System.out.println("****************************INVESTMENT PROPOSAL SCREEN*******************************************************");
       		//New investment Solution - Radio button    
       		Thread.sleep(1000);
       	    SelectRadioButton(driver, ReadExcelFile.getTestData(TestcaseID,Functionality,"p_NewInvestmentSolutionPageRadiobtn_Eng"));
       		
			//Name - Input box	
			SetText(driver,obj.getNewInvestmentName(), ReadExcelFile.getTestData(TestcaseID,Functionality,"p_NewInvestmentSolutionPageName_Eng"));
			
			//New Investment -Save Changes Button
			ClickButton(driver,obj.getButtonSaveChanges());
			
			//New Investment -Next Button
			ClickButton(driver,obj.getNextButton());
			Thread.sleep(5000);
			
			//System.out.println("*******************************SETTINGS SCREEN***************************************************");
								
			//Sales Code - List box
			SelectListBox(driver, obj.getSalesCode(), ReadExcelFile.getTestData(TestcaseID,Functionality,"p_SettingsPageSalesCode_Eng"));			
			
			//Select Joey Ding
			SelectListBox(driver, obj.getInvestmentAdvisor(),ReadExcelFile.getTestData(TestcaseID,Functionality,"p_SettingsPageIAName_Eng"));	
			
					
			//Select Currency
			SelectListBox(driver, obj.getCurrencyType(), ReadExcelFile.getTestData(TestcaseID,Functionality,"p_SettingsPageCurrencyType_Eng"));
			
			//Enter amount
			SetText(driver, obj.getInvestmentAmt(),ReadExcelFile.getTestData(TestcaseID,Functionality,"p_SettingsPageInvestmentAmt_Eng"));
			
			//Settings -Save Changes Button
			ClickButton(driver,obj.getButtonSaveChanges());
			Thread.sleep(1000);
			
			//Settings -Next Button
			ClickButton(driver,obj.getNextButton());
			Thread.sleep(5000);
			
			//System.out.println("***************************CLIENTS SCREEN********************************************************");
			
							
			//Settings -Save Changes Button
			//getAddNewIndividualButton
			//System.out.println("In the main class: " +obj.getAddNewIndividualButton());
			ClickButton(driver, obj.getAddNewIndividualButton());
						
			
			//External Client No
			SetTextByName(driver, ReadExcelFile.getTestData(TestcaseID,Functionality, "p_ClientsPageCusIDPropName_Eng"), ReadExcelFile.getTestData(TestcaseID,Functionality,"p_ClientsPageCusID_Eng"));
			
			//First Name	
			SetTextByName(driver, ReadExcelFile.getTestData(TestcaseID,Functionality,"p_ClientsPageFirstNamePropName_Eng"), ReadExcelFile.getTestData(TestcaseID,Functionality,"p_ClientsPageFirstName_Eng"));

			
			//Surename 
			SetTextByName(driver,ReadExcelFile.getTestData(TestcaseID,Functionality,"p_ClientsPageSureNamePropName_Eng"),ReadExcelFile.getTestData(TestcaseID,Functionality,"p_ClientsPageSureName_Eng"));
			
			//Select Gender
			SelectListBox(driver, obj.getGender(), ReadExcelFile.getTestData(TestcaseID,Functionality,"p_ClientsPageGender_Eng"));	
			
			//Salutation
			SelectListBox(driver, obj.getSalutation(), ReadExcelFile.getTestData(TestcaseID,Functionality,"p_ClientsPageSalutation_Eng"));
			
			//Date of birth
			SetTextByClass(driver, obj.getDateofBirth(), ReadExcelFile.getTestData(TestcaseID,Functionality,"p_ClientsPageDateofBirth_Eng"));
			//SetTextByClass(driver, obj.getDateofBirth(),"24/01/81");
			
			
			//Settings -Save Changes Button
			ClickButton(driver, obj.getButtonSaveandClose());
			
			//(14/07/2017)- Manoj 
			
			//radio_NewIndividual 
			SelectRadioButton(driver, ReadExcelFile.getTestData(TestcaseID,Functionality,"p_ClientsPageSelection_Eng"));
			
			//Next button click in Clients page 
			ClickButton(driver,obj.getNextButton());					
			
			Thread.sleep(5000);
			
			//System.out.println("********************************Investment Objective page*********************************************");
			
			//Investment Objective page
			//17-07-2017 SelectRadioButtonXpath(driver,"Income: Seeking a steady stream of income and capital preservation.");
			  
			SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestcaseID,Functionality,"p_InvestmentObjPage_Eng"));
			
			
			//System.out.println("********************************Time Horizon page *********************************************");
			
			//Time Horizon page		
			//17-07-2017 SelectRadioButtonXpath(driver, "Less than 1 year");
			SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestcaseID,Functionality,"p_TimeHorizonPage_Eng"));	
			

			//System.out.println("********************************Return Expectation page *********************************************");
			
			//Return Expectation page
			
			//17-07-2017 SelectRadioButtonXpath(driver, "2% - 4%");
			SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestcaseID,Functionality,"p_ReturnExpectationPage_Eng"));
			
			//System.out.println("********************************Market Fluctuacion page *********************************************");
			//Market Fluctuacion page
			
			SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestcaseID,Functionality,"p_MarketFluctuacionPage _Eng"));
			
			//System.out.println("********************************Inflation Protection page *********************************************");
			//Inflation Protection
			SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestcaseID,Functionality, "p_InflationProtectionpage_Eng"));

		//	WebElement inflation = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//md-radio-button[@aria-label='Preserving the long-term purchasing power of the client�s portfolio is not their primary concern according to the stated Investment Objective of this portfolio.']")));		
		//	inflation.click();
			
			//driver.findElement(By.xpath("//*[@id='radio_1353']")).click();
		//	Thread.sleep(5000);
			
			//System.out.println("********************************Income Requirement page *********************************************");
			//Income Requirement
			
			SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestcaseID,Functionality, "p_IncomeRequirementPage_Eng"));
			
			//WebElement incomereq = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//md-radio-button[@aria-label='No, the client does not require income from this portfolio.']")));		
			//incomereq.click();
			
			//driver.findElement(By.xpath("//*[@id='radio_1356']")).click();
	//		Thread.sleep(1000);
			
			
			//Income Requirement  -Save changes button
			//Settings -Save Changes Button
			ClickButton(driver,obj.getButtonSaveChanges());
			Thread.sleep(1000);
			
			//Settings -Next Button
			ClickButton(driver,obj.getNextButton());
			Thread.sleep(5000);
			
			//System.out.println("********************************Account page *********************************************");
			//Arun - 14 July 2017
			
			//Registered - Radio button
			SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestcaseID,Functionality, "p_AccountPageAccSelect_Eng")); 
			
			//WebElement registered = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//md-radio-button[@aria-label='Registered']")));
			//registered.click();
			//Thread.sleep(2000);
			
			//driver.findElement(By.xpath(""));
			//Account type - List Box
			SelectListBox(driver, obj.getselect_AccountPage_AccountType(), ReadExcelFile.getTestData(TestcaseID,Functionality, "p_AccountPageAccType_Eng"));

			/*
			WebElement accounttype = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//md-select[@aria-label='Account Type']")));
			accounttype.click();
			Thread.sleep(1000);
					
			WebElement accounttypeopt = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//md-option[@value='REGISTERED_RETIREMENT_SAVINGS_PLAN']")));
			accounttypeopt.click();
			Thread.sleep(2000);
			*/
			
			
			//Foregin Jurisdiction - Radio button
			SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestcaseID,Functionality, "p_ForeginJurisdiction_Eng"));
					
			//WebElement foreginJuri = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//md-radio-button[@aria-label='No']")));
			//foreginJuri.click();
			//Thread.sleep(2000);
			
			//Registered -Next Button
			ClickButton(driver,obj.getNextButton());
			Thread.sleep(5000);
			
			//System.out.println("********************************Account Program Page*********************************************");
			//Account Program - Radio button
			SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestcaseID,Functionality, "p_AccountProgramType_Eng"));

			//WebElement accountProgram = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//md-radio-button[@aria-label='Architect']")));
			//accountProgram.click();
			//Thread.sleep(2000);
			
			//Settings -Save Changes Button
			ClickButton(driver,obj.getButtonSaveChanges());
			Thread.sleep(1000);
			
			//Settings -Next Button
			ClickButton(driver,obj.getNextButton());
			Thread.sleep(5000);
			
			//System.out.println("********************************Client Directed Sleeve Page*********************************************");
			//Client Directed Sleeve  - Radio button
			SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestcaseID,Functionality, "p_ClientDirectedSleeveSelect_Eng"));
			//WebElement portfoliosolution = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//md-radio-button[@aria-label='No']")));
			//portfoliosolution.click();
			//Thread.sleep(2000);
			
			ClickButton(driver,obj.getButtonSaveChanges());
			Thread.sleep(1000);
			
			//Settings -Next Button
			ClickButton(driver,obj.getNextButton());
			Thread.sleep(5000);
			
			//System.out.println("********************************Blue Print Page*********************************************");
			//Blue Print
			ClickButton(driver,obj.getButtonSaveChanges());
			Thread.sleep(1000);
			
			//Blue Print-Next Button
			ClickButton(driver,obj.getNextButton());
			Thread.sleep(5000);
											
			//Manoj
			// Bug raised already by manual Team
			/*
			
			driver.findElement(By.xpath("//*[@id='content clx-content']/div/div[1]/ip-add/div/form/div[1]/div/ip-client/div/md-content[1]/div/clx-button[2]/span/button")).click();
			Thread.sleep(1000);
			//Address tab Click	
			driver.findElement(By.xpath("//*[@id='content clx-content']/div/div[1]/ip-add/div/form/div[1]/div/ip-client/div/md-content[2]/div[2]/div[2]/add-client-individual/div/div/div/form/div[1]/div/clx-tabs/div/md-content/md-tabs/md-tabs-wrapper/md-tabs-canvas/md-pagination-wrapper/md-tab-item[2]")).click();
			Thread.sleep(1000);
			// Add Address Button Click	
			driver.findElement(By.xpath("//*[text()='Add Address']")).click();
			Thread.sleep(1000);
			
			System.out.println("Add address Button clicked");
			
			driver.findElement(By.xpath("//input[@name='adress_number']")).sendKeys("987");
			
			System.out.println("Number entered");
			
			driver.findElement(By.xpath("//input[@name='street']")).sendKeys("Ashokstreet");
			driver.findElement(By.xpath("//input[@name='city']")).sendKeys("Toranto");
			driver.findElement(By.xpath("//input[@name='postal_code']")).sendKeys("603103");
			
			System.out.println("postal code Entered");
			driver.findElement(By.xpath("//md-select[@name='address_country']")).click();
			
			System.out.println("Country value clicked");
			
			java.util.List<WebElement> countryelement = driver.findElements(By.xpath(".//md-option"));			
			for(WebElement e : countryelement)
			{
				//System.out.println(e.getText());
				int n = e.getText().compareTo("Canada");
				System.out.println(e.getText());
				if(n == 0)
				{
					System.out.println("canada county selected");
					e.click();
					break;
				}
				
			}
			
			Thread.sleep(2000);	
			
			
			
			
			driver.findElement(By.xpath("//md-select[@name='province']")).click();
			
			System.out.println("Country value clicked");
			
			java.util.List<WebElement> stateelement = driver.findElements(By.xpath(".//md-option"));			
			for(WebElement e : countryelement)
			{
				//System.out.println(e.getText());
				int n = e.getText().compareTo("Alberta");
				System.out.println(e.getText());
				if(n == 0)
				{
					System.out.println("Alberta State selected");
					e.click();
					break;
				}
				
			}
			
			Thread.sleep(2000);	
			
			driver.findElement(By.xpath(".//*[@id='content clx-content']/div/div[1]/ip-add/div/form/div[1]/div/ip-client/div/md-content[2]/div[2]/div[2]/add-client-individual/div/div/div/form/div[2]/div/clx-button[2]/span/button")).click();
			
			*/ 
			
			//Manoj
			
			
		//	statusPass("CreateNew Proposal operation is Performed" + element);
						
			statusPass("CreateNew Proposal operation is Performed");
			
		}	 	
		catch(Exception e)
		{
			 System.out.println("Exception caught in CreateNewProposal Method-------"+e.getMessage());
			 statusFail(driver,"CreateNewProposal Operation is not performed",testCaseName);
			 endReporting();
			 driver.close();
			 Assert.fail("CreateNewProposal");
						 
		 } 
	}
	public static void VerifyTextinaPage(WebDriver driver,String SearchText,String testCaseName) throws IOException{
        try
        {
        
               boolean textPresent=driver.getPageSource().contains(SearchText);
               if(textPresent==true)
        
               {

            	   statusPass("Verification of Text Success:"+SearchText);
               } 
               else
               {

            	   statusFail(driver,"Verification of Text Failed:"+SearchText,testCaseName);
               } 
  
  
        } 
        catch(Exception e)
        {
               System.out.println("Exception caught in VerifyText Method-------"+e.getMessage());
               statusFail(driver,"Verification of Text Failed:"+SearchText,testCaseName);
               endReporting();
               driver.close();
               Assert.fail("Verify Text");
               
         } 
 } 

	public static void tableSelect(WebDriver driver,String ColumnName,String testcaseName) throws IOException
	{
		try
		{
			//System.out.println("Inside Try ");
			
			// xpath of the table body
			
			String tableBody1="//*[@id='content-table']/tbody";
			Thread.sleep(1000);
			WebElement htable1 = driver.findElement(By.xpath(tableBody1));
			Thread.sleep(1000);
			List<WebElement> tableHeaders1 = htable1.findElements(By.tagName("tr"));
			
			
			
			int trSize=tableHeaders1.size();
			//System.out.println("Size$$$$$$$$$$$$$$$$"+trSize);
				
			
			int irt=0;
			for (int i=1;i<=10;i++)
			{
				boolean flag=false;
			String tableBody="//*[@id='content-table']/tbody/tr["+i+"]";
			WebElement htable = driver.findElement(By.xpath(tableBody));
			List<WebElement> tableHeaders = htable.findElements(By.tagName("td"));
					
			Iterator<WebElement> tableItr=tableHeaders.iterator();
			int count=0;
			while(tableItr.hasNext())
				{
				//System.out.println("Inside While ");
					WebElement tableRow=tableItr.next();
					String tableHeading=tableRow.getText();
					//System.out.println(tableHeading);
			        if(tableHeading.equalsIgnoreCase(ColumnName))
			        {
			        	//System.out.println("Inside if ");
			        	count++;
			        	flag=true;
			        	break;
			        	
			        }
			        
			        
			      }
			irt++;
			
			//System.out.println("count====="+irt);
			//System.out.println("Before Download button click");
			
			if(flag==true)
			{
				//*[@id="clx_eventContent_0"]/div/button
				irt--;
				String downloadXpath="//*[@id='clx_eventContent_"+irt+"']/div/button";
				driver.findElement(By.xpath(downloadXpath)).click();
				//System.out.println("Clicked Download Button");
				break;
			}
			       
			        
			
			
			}
		}catch(Exception e)
		{
			System.out.println("Exception caught in table Select (Generate Documents) Method -------"+e.getMessage());
			 statusFail(driver,"Unable to get value from the table",testcaseName);
			 endReporting();
			 driver.close();
			 Assert.fail("Unable get the value from the table.");
		}
	}

	
	
	public static void PDFSave(WebDriver driver,String testcaseName) throws IOException
	{
		try
		{
			Robot robot = new  Robot();
		      robot.keyPress(KeyEvent.VK_CONTROL);
		      robot.keyPress(KeyEvent.VK_S);
		      robot.keyRelease(KeyEvent.VK_S);
		      robot.keyRelease(KeyEvent.VK_CONTROL);
		      Thread.sleep(3000);
		      robot.keyPress(KeyEvent.VK_ENTER);
		      robot.keyRelease(KeyEvent.VK_ENTER);
		      statusPass("PDF file downloaded");
		      Thread.sleep(5000);
			
		}catch(Exception e)
		{
			System.out.println("Exception caught in PDF Download Method-------"+e.getMessage());
			 statusFail(driver,"Unable to Download the PDF file",testcaseName);
			 endReporting();
			 driver.close();
			 Assert.fail("Unable to Download the PDF");
		}
	}

	public static String FileMoveAndRename(WebDriver driver,String sourceDirPath,String DestDirPath,String testcaseName) throws IOException
	{
		File lastModified=ImageUtil.getLatestFilefromDir(sourceDirPath);
		// converting file type to string.
	    String FileName=lastModified.toString();
	    File afile =new File(FileName);
	    Date date = new Date();  
    	DateFormat df = new SimpleDateFormat("dd MMMM yyyy HH-mm-ss");
        String Date = df.format(date);
                
        String uniq = Date ;
        DateFormat df1 = new SimpleDateFormat("dd MMMM yyyy");
        String folderName= df1.format(date);  
        FileOutputStream outFile = null;
		try{
			
	        File f =  new File("C:\\BrunoAutomationFramework\\PDFfiles\\"+folderName);
	        if (!f.exists() && !f.isDirectory()) {
	        	
	           f.mkdir();
	                   }
		}catch (Exception e)
		{
			 System.out.println("Exception caught in creating file Method-------"+e.getMessage());
		}
	    
		try
	    {
	    		
	    	String PDFToBeVerified = "C:\\BrunoAutomationFramework\\PDFfiles\\"+folderName+"\\"+Date+"_"+testcaseName;
	    	//srcFile.renameTo(new File(destDir, "a.txt"));
	    	
	    	if(afile.renameTo(new File("C:\\BrunoAutomationFramework\\PDFfiles\\"+folderName+"\\"+Date+"_"+testcaseName+".pdf" ))){
	    		//System.out.println("File is moved successful!");
	    		}else{
	    			System.out.println("File is failed to move!");
	    		}
 	   }catch (Exception e)
 	   {
 		   System.out.println("Exception caught in File Move and Rename Method-------"+e.getMessage());
			 statusFail(driver,"Unable to move the file",testcaseName);
			 endReporting();
			 driver.close();
			 Assert.fail("Unable to move the file");
 	   }
	    String PDFToBeVerified = "C:\\BrunoAutomationFramework\\PDFfiles\\"+folderName+"\\"+Date+"_"+testcaseName+".pdf";
	    return PDFToBeVerified;
	
	    /*File lastModifiedDest=ImageUtil.getLatestFilefromDir(DestDirPath);
		// converting file type to string.
	    String FileName1=lastModifiedDest.toString();  
	    Path source = Paths.get("path/here");
	    Files.move(source, source.resolveSibling("newname"));*/
}
	

	
	public static void tableSelectSearchIndividual(WebDriver driver,String ColumnName,String testcaseName) throws IOException
	{
		try
		{
			
			
			//System.out.println("=================Inside TableSelectSearchIndividual=================");
			// xpath of the table body
			
			String tableBody1="//*[@id='content-table']/tbody";
			Thread.sleep(1000);
						
			WebElement htable1 = driver.findElement(By.xpath(tableBody1));
			Thread.sleep(1000);
			List<WebElement> tableHeaders1 = htable1.findElements(By.tagName("tr"));
			
			
			
			int trSize=tableHeaders1.size();
			
				
			
			int irt=0;
			for (int i=1;i<=10;i++)
			{
				boolean flag=false;
			String tableBody="//*[@id='content-table']/tbody/tr["+i+"]";
						
			WebElement htable = driver.findElement(By.xpath(tableBody));
			List<WebElement> tableHeaders = htable.findElements(By.tagName("td"));
					
			Iterator<WebElement> tableItr=tableHeaders.iterator();
			int count=0;
			while(tableItr.hasNext())
				{
				
					WebElement tableRow=tableItr.next();
					String tableHeading=tableRow.getText();
										
					//System.out.println(tableHeading);
			        if(tableHeading.contains(ColumnName))
			        {
			        	//System.out.println("Inside if ");
			        	count++;
			        	flag=true;
			        	break;
			        	
			        }
			        
			        
			      }
			irt++;
			
			//System.out.println("count====="+irt);
			
			if(flag==true)
			{
				
				irt--;
				//String downloadXpath="//*[@id='clx_eventContent_"+irt+"']/div/button";
								
				//  old //String s = "//*[@id='clx_checkboxContent_0000000184']/div/label/span";
								
				String s1  = "//*[@id='clx_checkboxContent_89816']/div/label/span";
				driver.findElement(By.xpath(s1)).click();
				break;
			}
			       
			  
			
			
			}
		}catch(Exception e)
		{
			System.out.println("Exception caught in TableSelect Search for Individual  Method-------"+e.getMessage());
			 statusFail(driver,"Unable to get value from the table",testcaseName);
			 endReporting();
			 driver.close();
			 Assert.fail("Unable get the value from the table.");
		}
	}

	
	public static void scrollandClickElement(WebDriver driver,String element) throws IOException{
	       try
	       {
	
	              WebElement ele=driver.findElement(By.xpath(element));
	              JavascriptExecutor jse = (JavascriptExecutor)driver;
	              
	              
	       
	              jse.executeScript("arguments[0].scrollIntoView(true);",ele);
	              jse.executeScript("arguments[0].click();", ele);
	              
	              

	       } 
	       catch(Exception e)
	       {
	              System.out.println("Exception caught in scrollToElement Method-------"+e.getMessage());
	              statusFail(driver,"Screenshot not properly Captured",element);
	              
	        } 
	}
	public static void ScrollView(WebDriver driver,String element) throws IOException{
	       try
	       {
	
	              WebElement ele=driver.findElement(By.xpath(element));
	              JavascriptExecutor jse = (JavascriptExecutor)driver;
	              
	              
	       
	              jse.executeScript("arguments[0].scrollIntoView(true);",ele);
	            //  jse.executeScript("arguments[0].click();", ele);
	              
	              

	       } 
	       catch(Exception e)
	       {
	              System.out.println("Exception caught in scrollToElement Method-------"+e.getMessage());
	              statusFail(driver,"Screenshot not properly Captured",element);
	              
	        } 
	}
	
	public static void select(WebDriver driver,String dropDownText,String element,String testCaseName) throws IOException{
		try
		{
	
			//System.out.println("Inside Select ");		
       		
       		//WebDriverWait wait = new WebDriverWait(driver,120);
			//WebElement selectvalue = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element)));
			
			
			Select sl=new Select(driver.findElement(By.xpath(element)));
			//System.out.println("Exception select------"+dropDownText);
			sl.selectByVisibleText(dropDownText);
			
		} 
		catch(Exception e)
		{
			 System.out.println("Exception caught in Select Method-------"+e.getMessage());
			 statusFail(driver,"Selection of DropDown Text Failed"+dropDownText,testCaseName);
			 
		 } 
	}
	
	public static void sikuliClick(WebDriver driver,String ImageName,String testCaseName) throws IOException{
		
		try
		{
			 
			Screen s=new Screen();
			Pattern image = new Pattern("C:<\\BrunoAutomationFramework\\Sikuli Images\\"+ImageName+">");
			
			s.wait(image, 10);
			s.click(image)	;			                       
		}
				
		catch(Exception e)
		{
			
			 statusFail(driver,"Sikuli-> Unable to perform Click operation ",testCaseName);
			 endReporting();
		}
	}
	 
}
