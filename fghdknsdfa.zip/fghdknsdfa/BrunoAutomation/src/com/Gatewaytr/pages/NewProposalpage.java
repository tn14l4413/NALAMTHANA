package com.Gatewaytr.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.WebDriver;

import com.Gateway.GlobalParameters.BaseClass;
import com.Gatewaytr.ExcelFile.ReadExcelFile;

public class NewProposalpage extends BaseClass {

	
	
	
	
	
	/* 15-07-2017 get input value from Excel for Dropdown box 
	static WebDriverWait wait;
	
	public static void getValueDropdown( String TestCaseID, String Functionality)throws Exception
	{
	
	WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(obj.getSalesCodeOR())));
	element.click();
	Thread.sleep(1000);
			
	java.util.List<WebElement> ele = driver.findElements(By.xpath(obj.getDropdownOR()));			
	for(WebElement e : ele)
	{
		//System.out.println(e.getText());
		
			
		int n = e.getText().compareTo(ReadExcelFile.getTestData(TestCaseID,Functionality,"p_DropdownValue_Eng"));
		//System.out.println(e.getText());
		if(n == 0)
		{
		//	System.out.println("inside RE4");
			e.click();
			break;
		}
		
	}
	
	Thread.sleep(2000);
	}    */
}