package com.Gatewaytr.pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;



import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.Gateway.GlobalParameters.BaseClass;
import com.Gateway.GlobalParameters.FetchingOR;
import com.Gatewaytr.ExcelFile.ExcelJXL;
import com.Gatewaytr.Testcases.ExtentReport;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class LoginPage extends BaseClass
{
	//public static WebDriver driver;
	public static WebDriver LaunchBrowser(String browserName) 
	{
		if (browserName.equalsIgnoreCase("chrome"))
		{
			try
			{
				
				System.setProperty("webdriver.chrome.driver", "C:\\BrunoAutomationFramework\\Drivers\\chromedriver.exe");
				
				
				// Added Chrome options code to stop  error message  
				ChromeOptions options = new ChromeOptions();
				
				options.addArguments("window-size=1300,720");   // Added on 23/01/2018
			    options.setExperimentalOption("useAutomationExtension", false);
			    		
				
							
				/* new code for Unpacked extension
				ChromeOptions options = new ChromeOptions();
				//options.addArguments("load-extension=C:\\Users\\BRUNO2~1.PCD\\AppData\\Local\\Temp");
				
				DesiredCapabilities capabilities = new DesiredCapabilities();
				capabilities.setCapability(ChromeOptions.CAPABILITY, options);
				//ChromeDriver driver = new ChromeDriver(capabilities);
				
				new code end - Unpacked Extension is not working */
				
				driver = new ChromeDriver(options);
				
				Thread.sleep(2000);
				System.out.println("Launched Browser:Chrome");	
				
			}
			catch(Exception e)
			{
				System.out.println("Exceptuion caught in LaunchBrowser"+e.getMessage());
			}
		
		}
		return driver;
	}
// Launch URL 
	
	public static void LaunchURL(WebDriver driver) 
	{
		
		
		driver.get(BRUNOURL);
		
		
		
		// Maximize()  commented due to Failed to load unpack extension 
		//  driver.manage().window().maximize();
		
		/*
		// Dimension Added to maximize the Window.
		Dimension d = new Dimension(1200,600);
		//Resize the current window to the given dimension
		driver.manage().window().setSize(d);
		
		System.out.println("Window Size Changed to Normal");
		
		*/
			
		//System.out.println("Launched URL");
		
	
	}

		
//Login to the Gateway Application
	public static void Login(int rowNumber,String userName,String password,String testCaseName) throws IOException {
	try{
		obj = new FetchingOR(fileName);
		CommonFunctions.waitForElement(driver, obj.getUserName(), 20,"Username Text Field");
		
		driver.findElement(By.xpath(obj.getUserName())).sendKeys(userName);
		driver.findElement(By.xpath(obj.getPassword())).sendKeys(password);
		driver.findElement(By.xpath(obj.getLoginButton())).click();
		statusPass("Login Success");
		}
	
	catch(Exception e)
	{
		System.out.println("Exception caught in Login Function:"+ e.getMessage());
		statusFail(driver, "Log In Unsuccesful",testCaseName);
		outPut(0, 7, rowNumber, "FAIL");
		endReporting();
		Assert.fail("Login Error");
		
		
		
	}
		
	}
	public static void closeDriver()
	{
		driver.close();
	}
	
	
}
