/**
 * 
 */
package com.Gatewaytr.Testcases;

import net.sf.cglib.core.Transformer;

import org.junit.AfterClass;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.server.browserlaunchers.Sleeper;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;














import java.util.HashMap;

import javax.xml.bind.Element;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.soap.Node;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
//import jxl.common.Assert;
import jxl.read.biff.BiffException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import com.Gateway.GlobalParameters.BaseClass;
import com.Gateway.GlobalParameters.FetchingOR;
import com.Gatewaytr.ExcelFile.ReadExcelFile;
import com.Gatewaytr.PDFFile.ImageUtil;
import com.Gatewaytr.PDFFile.PDFPageVerification;
import com.Gatewaytr.PDFFile.ReadDynamicPDF;
import com.Gatewaytr.PDFFile.ReadImagesPDF;
import com.Gatewaytr.PDFFile.ReadStaticPDF;
import com.Gatewaytr.pages.CommonFunctions;
import com.Gatewaytr.pages.LoginPage;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.sun.jna.platform.unix.X11.Window;


public class BrunoFormsValidation extends BaseClass {
	private static final String TestcaseID = null;
	WebDriver driver;
	ExtentReports extent;
	ExtentTest logger;
	public FetchingOR obj=null;
	public String fileName="C:\\BrunoAutomationFramework\\Configuration\\ConfigurationPage.property";
	File src = new File("C:\\BrunoAutomationFramework\\DriverSheet\\DriveSheet.xls");
	int rowNumber;
	

	@DataProvider(name="DriverSheet")
	public Object[][] driverSheetData() {
		Object[][] arrayObject = getExcelData("C:\\BrunoAutomationFramework\\DriverSheet\\DriveSheet.xls","Sheet1");
		return arrayObject;
	}

	public String[][] getExcelData(String fileName, String sheetName) {
		String[][] arrayExcelData = null;
		try {
			
			FileInputStream fs = new FileInputStream(fileName);
			Workbook wb = Workbook.getWorkbook(fs);
			Sheet sh = wb.getSheet(sheetName);

			int totalNoOfCols = sh.getColumns();
			int totalNoOfRows = sh.getRows();
			
			arrayExcelData = new String[totalNoOfRows-1][totalNoOfCols];
			
			for (int i= 1 ; i < totalNoOfRows; i++) 
			{
				
				for (int j=0; j < totalNoOfCols; j++) {
					arrayExcelData[i-1][j] = sh.getCell(j, i).getContents();
					
				}

			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
			e.printStackTrace();
		} catch (BiffException e) {
			e.printStackTrace();
		}
		return arrayExcelData;
	}	


@BeforeSuite
public void beforeSuite() throws Exception
{
	 	     
     setReport();
    
}

@BeforeTest
@Parameters({ "browserName" ,"language"})
public void beforeTest(String browserName,String language) throws Exception
{
	String Browser,LanguageSettings;
	Browser=browserName;
	LanguageSettings=language;
	//System.out.println("*****************"+Browser);
	//System.out.println("*****************"+LanguageSettings);
	obj = new FetchingOR(fileName);
	ReadExcelFile.setExcelFile(filePath, LanguageSettings);
	//driver=LoginPage.LaunchBrowser(Browser);    // commented on 25/07/2017
	
	
}
@Test(dataProvider="DriverSheet")
public void BlueprintAgreementEnglish(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Browser, String Language, String Execution, String Status)throws Throwable
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC002")&&Execution.equalsIgnoreCase("Y") &&Functionality.equalsIgnoreCase("BLUEPRINT-AGREEMENT-ENGLISH"))
	{
		
		driver=LoginPage.LaunchBrowser(Browser); 
		LoginPage.LaunchURL(driver);
	    startReporting("Blueprint Program Account Agreement PDF Static content validation");
	   //Login Page
	    LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),Functionality + TestCaseID);
	    CommonFunctions.waitForElementMouse(driver, obj.getMouseHoverIcon(),100,"Slider Menu");
	    Thread.sleep(10000);
	    CommonFunctions.clickAround(driver,obj.getMenuButton(),obj.getMouseHoverIcon(),obj.getClients_menu(),obj.getGoalPlanning(),obj.getiFrame(), obj.getNewInvestmentProposal(),TestCaseID);
	    statusPassWithScreenshot(driver, "Clicked Goal planning Option inside Cilents menu", TestCaseDescription);
	    CommonFunctions.NavigateToNewProposal(driver,obj.getiFrame(),obj.getNewInvestmentProposal(), TestCaseID);
	    Thread.sleep(5000);
	    // Investment Proposal Screen
  		CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageRadiobtn_Eng"));
 		CommonFunctions.SetText(driver,obj.getNewInvestmentName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageName_Eng"));
   		statusPassWithScreenshot(driver, "New Investment Solution Name Entered and Investment Type Selected", TestCaseDescription);
 		//CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());
 		//statusPass("Clicked Save changes Button in New Investment Proposal Page");
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal Page");
		Thread.sleep(5000);
		//Settings Screen
		CommonFunctions.SelectListBox(driver, obj.getSalesCode(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageSalesCode_Eng"));			
		Thread.sleep(500);
		CommonFunctions.SelectListBox(driver, obj.getCurrencyType(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageCurrencyType_Eng"));
		CommonFunctions.SetText(driver, obj.getInvestmentAmt(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageInvestmentAmt_Eng"));
		Thread.sleep(1000);
		statusPassWithScreenshot(driver, "Salescode,Currency,Investment Amount, Investment Advisor Name are entered in Settings page ", TestCaseDescription);
		CommonFunctions.scrollandClickElement(driver, "//button[contains(text(),'Save Changes')]");
		Thread.sleep(1000);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal-Setting  Page");
		Thread.sleep(5000);
		// Clients Screen
		statusPassWithScreenshot(driver,"Add New individual Button is Displayed in Cilents Page",TestCaseDescription);
		// Adding New Individual	
		CommonFunctions.ClickButton(driver, obj.getAddNewIndividualButton());
		statusPass("Clicked Add New individual Button in Clients page");
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ClientsPageCusIDPropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageCusID_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstNamePropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstName_Eng"));
		CommonFunctions.SetTextByName(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureNamePropName_Eng"),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureName_Eng"));
		CommonFunctions.SelectListBox(driver, obj.getGender(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageGender_Eng"));	
		CommonFunctions.SelectListBox(driver, obj.getSalutation(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSalutation_Eng"));
		CommonFunctions.SetTextByClass(driver, obj.getDateofBirth(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageDateofBirth_Eng"));
		
		CommonFunctions.ScrollView(driver, obj.getButtonSaveandClose());
		Thread.sleep(1000);
		CommonFunctions.ClickButton(driver, obj.getButtonSaveandClose());
		CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSelection_Eng"));
		statusPassWithScreenshot(driver, "Customer ID ,Name,Gender,DOB are Entered in Clients page", TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());	
		statusPass("Clicked Next Button in Add New Individual Page");
		Thread.sleep(5000);
		
		// Below code for clicking Add button when we user search option
		//CommonFunctions.scrollandClickElement(driver, "//button[contains(text(),'Add')]");
		//CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSelection_Eng"));
		//CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
		//CommonFunctions.ClickButton(driver,obj.getNextButton());	
		//statusPass("Clicked Next Button in Add New Individual Page");
		
		// Investment Objective page
		statusPassWithScreenshot(driver, "Investment Objective page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_InvestmentObjPage_Eng"));
		Thread.sleep(1000);
		//Time Horizon Page
		
		statusPassWithScreenshot(driver, "Time Horizon Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TimeHorizonPage_Eng"));	
		Thread.sleep(1000);
		// Return Expectation page
		statusPassWithScreenshot(driver, "Return Expectation Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ReturnExpectationPage_Eng"));
		Thread.sleep(1000);
		//Market Fluctuacion Page
		statusPassWithScreenshot(driver, "Market Fluctuacion page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_MarketFluctuacionPage _Eng"));
		Thread.sleep(1000);
		//Inflation Protection Page
		statusPassWithScreenshot(driver, "Inflation Protection page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_InflationProtectionpage_Eng"));				
		Thread.sleep(1000);
		//Income Requirement Page
		statusPassWithScreenshot(driver, "Income Requirement Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_IncomeRequirementPage_Eng"));
		//Settings -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPassWithScreenshot(driver, "Clicked Next Button in Income requirement Page", TestCaseDescription);
		Thread.sleep(8000);
		//Account Page
		//Registered - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccSelect_Eng")); 
		//Account type - List Box
		CommonFunctions.SelectListBox(driver, obj.getselect_AccountPage_AccountType(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccType_Eng"));
		//Foregin Jurisdiction - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ForeginJurisdiction_Eng"));
		statusPassWithScreenshot(driver, "Selected Account Type & Foreign Jurisdiction Values in Account Page", TestCaseDescription);
		//Registered -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPass("Clicked Next button in Account Page");
		// Account Program
		//Account Program - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountProgramType_Eng"));
		statusPassWithScreenshot(driver,"Selected Account Program in Account Program page",TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPass("Clicked Next button in Account Program Page");
		// Models Page
		statusPass("Entered into Models page");
        CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ProgramModelSelect_Eng"));
        statusPassWithScreenshot(driver,"Selected the radio button",TestCaseDescription);
         
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        //CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(8000);
        //Historical Page
        statusPassWithScreenshot(driver,"Historical Performance Page dispalyed",TestCaseDescription);
        CommonFunctions.ClickButton(driver, obj.getbutton_Historical_Perf());
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        //CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());
        statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
        CommonFunctions.ClickButton(driver, obj.getNextButton());
		Thread.sleep(8000);
		// Account Details Page
		statusPass("Entered into Account Details page");
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_AccountDetail_AccountName_Eng"));
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountNumber(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_AccountNumber_Eng"));
		//CommonFunctions.SelectListBox(driver, obj.getAccountDetails_ReviewFrequency(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_ReviewFrequency_Eng"));
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        //CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());
		//Thread.sleep(1000);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		// Fee Schedule Page
		statusPass("Entered into FEE Schedule page");
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        //CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());
		//Thread.sleep(1000);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		CommonFunctions.ClickButton(driver, obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		CommonFunctions.SetText(driver, obj.gettext_TeamName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TeamName_Eng"));
		Thread.sleep(3000);
		CommonFunctions.SetText(driver, obj.gettext_IATitle(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IATitle_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAemail(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAEmail_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAphone(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAPhone_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstNameValue_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastNameValue_Eng"));
		statusPassWithScreenshot(driver,"Team Name,Title,Name,Email,Phone Numbe Details are entered in Investment Advisor Profile page",TestCaseDescription);
		statusPassWithScreenshot(driver, "Entered into IA Profile Page", TestCaseDescription);
		//CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());				
		//Thread.sleep(8000);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPassWithScreenshot(driver, "Entered into Administrative Question page", TestCaseDescription);
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
		//CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());				
		Thread.sleep(8000);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(4000);
		CommonFunctions.ClickButton(driver,obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		// Generate Documents Page
		statusPassWithScreenshot(driver, "Entered into generate Document page", TestCaseDescription);
		CommonFunctions.tableSelect(driver, "Blueprint Managed Account Agreement",TestCaseDescription);
		
		
		statusPass("Blueprint Agreement Download Button Clicked ");
		Thread.sleep(10000);
		
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		
		Thread.sleep(8000);
		// Saving PDF to download folder
		CommonFunctions.PDFSave(driver,TestCaseID);
		
		// Source file Location commented as we are generating from Online
		//String SourceFile = ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SourcefileLocation_Eng");
		
		
		String generatedFile=CommonFunctions.FileMoveAndRename(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_FileDownloadLocation_Eng"),"C:\\BrunoAutomationFramework\\PDFfiles\\GeneratedFiles", TestCaseID);
		
		String SourceFile = "C:\\BrunoAutomationFramework\\SourceFiles\\BluePrint_MAA_Source.pdf";
					
		statusPass("Blueprint Agreement Page Verification-Page-1 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,1,1);
		
		
		statusPass("Blueprint Agreement Page Verification-Page-2 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,2,2);
		Thread.sleep(200);
		statusPass("Blueprint Agreement Page Verification-Page-3 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,3,3);
		Thread.sleep(200);
		statusPass("Blueprint Agreement Page Verification-Page-4 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,4,4);
		Thread.sleep(200);
		statusPass("Blueprint Agreement Page Verification-Page-5");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,5,5);
		Thread.sleep(200);
		statusPass("Blueprint Agreement Page Verification-Page-6 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,6,6);
		Thread.sleep(200);
		statusPass("Blueprint Agreement Page Verification-Page-7");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,7,7);
		Thread.sleep(200);
		statusPass("Blueprint Agreement Page Verification-Page-8 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,8,8);
		Thread.sleep(200);
		statusPass("Blueprint Agreement Page Verification-Page-9 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,9,9);
		Thread.sleep(200);
		statusPass("Comparison Done, Please Evaluate Each ScreenShot in Test Report");
		endReporting();
		driver.close();
		
		
	}

}

@Test(dataProvider="DriverSheet")
public void ArchitectAgreementEnglish(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Browser, String Language, String Execution, String Status)throws Throwable
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC001")&&Execution.equalsIgnoreCase("Y") &&Functionality.equalsIgnoreCase("ARCHITECT-AGREEMENT-ENGLISH"))
	{
		
		driver=LoginPage.LaunchBrowser(Browser); 
		LoginPage.LaunchURL(driver);
		startReporting("Architect Program Account Agreement PDF Static content validation");
	   
		LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),Functionality + TestCaseID);
	    CommonFunctions.waitForElementMouse(driver, obj.getMouseHoverIcon(),100,"Slider Menu");
	    Thread.sleep(10000);
	    CommonFunctions.clickAround(driver,obj.getMenuButton(),obj.getMouseHoverIcon(),obj.getClients_menu(),obj.getGoalPlanning(),obj.getiFrame(), obj.getNewInvestmentProposal(),TestCaseID);
	    statusPassWithScreenshot(driver, "Clicked Goal planning Option inside Cilents menu", TestCaseDescription);
	    CommonFunctions.NavigateToNewProposal(driver,obj.getiFrame(),obj.getNewInvestmentProposal(), TestCaseID);
  		// INVESTMENT PROPOSAL SCREEN
	    CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageRadiobtn_Eng"));
 		CommonFunctions.SetText(driver,obj.getNewInvestmentName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageName_Eng"));
   		statusPassWithScreenshot(driver, "New Investment Solution Name Entered and Investment Type Selected", TestCaseDescription);
 		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal Page");
		Thread.sleep(5000);
		// SETTINGS SCREEN
		CommonFunctions.SelectListBox(driver, obj.getSalesCode(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageSalesCode_Eng"));			
		Thread.sleep(5000);
		//CommonFunctions.SelectListBox(driver, obj.getInvestmentAdvisor(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageIAName_Eng"));	
		CommonFunctions.SelectListBox(driver, obj.getCurrencyType(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageCurrencyType_Eng"));
		CommonFunctions.SetText(driver, obj.getInvestmentAmt(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageInvestmentAmt_Eng"));
		Thread.sleep(500);
		statusPassWithScreenshot(driver, "Salescode,Currency,Investment Amount, Investment Advisor Name are entered in Settings page ", TestCaseDescription);
		CommonFunctions.scrollandClickElement(driver, "//button[contains(text(),'Save Changes')]");
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal-Setting  Page");
		Thread.sleep(5000);
		//CLIENTS SCREEN
		statusPassWithScreenshot(driver,"Add New individual Button is Displayed in Cilents Page",TestCaseDescription);
		// Search Starts Here
		/*CommonFunctions.ClickButton(driver, obj.getSearchForIndividualButton());
		CommonFunctions.SetText(driver, obj.getSearchIndividual_Textbox(), "John");
		Thread.sleep(5000);
		Robot robot = new  Robot();
	    robot.keyPress(KeyEvent.VK_ENTER);
	    robot.keyRelease(KeyEvent.VK_ENTER);
	    tatusPass("Search Text Entered in  Search For Individual text Box");
	    CommonFunctions.ScrollView(driver, "//button[contains(text(),'Close')]");
	    CommonFunctions.tableSelectSearchIndividual(driver,"Smith", TestCaseDescription);*/
		// Search Ends Here
		
		// Add new Individual
		CommonFunctions.ClickButton(driver, obj.getAddNewIndividualButton());
		statusPass("Clicked Add New individual Button in Clients page");
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ClientsPageCusIDPropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageCusID_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstNamePropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstName_Eng"));
		CommonFunctions.SetTextByName(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureNamePropName_Eng"),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureName_Eng"));
		CommonFunctions.SelectListBox(driver, obj.getGender(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageGender_Eng"));	
		CommonFunctions.SelectListBox(driver, obj.getSalutation(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSalutation_Eng"));
		CommonFunctions.SetTextByClass(driver, obj.getDateofBirth(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageDateofBirth_Eng"));
		CommonFunctions.ScrollView(driver, obj.getButtonSaveandClose());
		CommonFunctions.ClickButton(driver, obj.getButtonSaveandClose());
		CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSelection_Eng"));
		statusPassWithScreenshot(driver, "Customer ID ,Name,Gender,DOB are Entered in Clients page", TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());	
		statusPass("Clicked Next Button in Add New Individual Page");
		Thread.sleep(5000);
		statusPass("Entered into Investment Objective Page");
		//Investment Objective page
		statusPassWithScreenshot(driver, "Investment Objective page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_InvestmentObjPage_Eng"));
		Thread.sleep(1000);
		statusPass("Entered into Time Horizon  Page");
		//Time Horizon page 
		statusPassWithScreenshot(driver, "Time Horizon Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TimeHorizonPage_Eng"));	
		Thread.sleep(1000);
		//System.out.println("********************************Return Expectation page *********************************************");
		statusPassWithScreenshot(driver, "Return Expectation Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ReturnExpectationPage_Eng"));
		Thread.sleep(1000);
		statusPassWithScreenshot(driver, "Market Fluctuacion page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_MarketFluctuacionPage _Eng"));
		Thread.sleep(1000);
		statusPassWithScreenshot(driver, "Inflation Protection page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_InflationProtectionpage_Eng"));				
		Thread.sleep(1000);
		//Income Requirement
		statusPassWithScreenshot(driver, "Income Requirement Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_IncomeRequirementPage_Eng"));
		//Settings -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPassWithScreenshot(driver, "Clicked Next Button in Income requirement Page", TestCaseDescription);
		Thread.sleep(5000);
		//Registered - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccSelect_Eng")); 
		//Account type - List Box
		CommonFunctions.SelectListBox(driver, obj.getselect_AccountPage_AccountType(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccType_Eng"));
		//Foregin Jurisdiction - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ForeginJurisdiction_Eng"));
		statusPassWithScreenshot(driver, "Selected Account Type & Foreign Jurisdiction Values in Account Page", TestCaseDescription);
		//Registered -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPass("Clicked Next button in Account Page");
		//Account Program - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountProgramType_Eng"));
		statusPassWithScreenshot(driver,"Selected Account Program in Account Program page",TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPass("Clicked Next button in Account Program Page");
		//Client-directed Sleeve page
		statusPass("Entered into Client Directed Sleeve page");
        CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ClientDirectedSleeveSelect_Eng"));
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(8000);
        statusPass("Entered into Model Schem page");
        CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ModelSchemSelect_Eng"));
        statusPassWithScreenshot(driver,"Selected the radio button",TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(8000);
        //Portfolio construction Page
        statusPassWithScreenshot(driver,"Entered Into Port Folio Construction Page",TestCaseDescription);
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(8000);
        //Historical Performance Page
        statusPassWithScreenshot(driver,"Historical Performance Page dispalyed",TestCaseDescription);
        CommonFunctions.ClickButton(driver, obj.getbutton_Historical_Perf());
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
        CommonFunctions.ClickButton(driver, obj.getNextButton());
		Thread.sleep(8000);
		// Account Details page
        statusPass("Entered into Account Details page");
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_AccountDetail_AccountName_Eng"));
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountNumber(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_AccountNumber_Eng"));
		//CommonFunctions.SelectListBox(driver, obj.getAccountDetails_ReviewFrequency(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_ReviewFrequency_Eng"));
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		// Fee Schedule
		statusPass("Entered into FEE Schedule page");
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(5000);
		CommonFunctions.ClickButton(driver, obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		CommonFunctions.SetText(driver, obj.gettext_TeamName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TeamName_Eng"));
		Thread.sleep(3000);
		CommonFunctions.SetText(driver, obj.gettext_IATitle(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IATitle_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAemail(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAEmail_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAphone(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAPhone_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstNameValue_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastNameValue_Eng"));
		statusPassWithScreenshot(driver,"Team Name,Title,Name,Email,Phone Numbe Details are entered in Investment Advisor Profile page",TestCaseDescription);
		statusPassWithScreenshot(driver, "Entered into IA Profile Page", TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPassWithScreenshot(driver, "Entered into Administrative Question page", TestCaseDescription);
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(1000);
		CommonFunctions.ClickButton(driver,obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		// Generate Documents Page
		statusPassWithScreenshot(driver, "Entered into generate Document page", TestCaseDescription);
		CommonFunctions.tableSelect(driver, "Architect Managed Account Agreement",TestCaseDescription);
		statusPass("Architect Agreement Download Button Clicked ");
		Thread.sleep(10000);
		// Getting child window details
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		Thread.sleep(1000);
		// Saving PDF to download folder
		CommonFunctions.PDFSave(driver,TestCaseID);
		// Source file Location commented as we are generating from Online
		//String SourceFile = ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SourcefileLocation_Eng");
		String generatedFile=CommonFunctions.FileMoveAndRename(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_FileDownloadLocation_Eng"),"C:\\BrunoAutomationFramework\\PDFfiles\\GeneratedFiles", TestCaseID);
		String SourceFile = "C:\\BrunoAutomationFramework\\SourceFiles\\Architect_MAA_Source.pdf";
		Thread.sleep(2000);
		// Form verification starts here
		statusPass("Architect Agreement Page Verification-Page-1 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,1,1);
		Thread.sleep(500);
		statusPass("Architect Agreement Page Verification-Page-2 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,2,2);
		Thread.sleep(500);
		statusPass("Architect Agreement Page Verification-Page-3 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,3,3);
		Thread.sleep(500);
		statusPass("Architect Agreement Page Verification-Page-4 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,4,4);
		Thread.sleep(500);
		statusPass("Architect Agreement Page Verification-Page-5");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,5,5);
		Thread.sleep(500);
		statusPass("Architect Agreement Page Verification-Page-6 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,6,6);
		Thread.sleep(1000);
		statusPass("Architect Agreement Page Verification-Page-7");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,7,7);
		Thread.sleep(500);
		statusPass("Architect Agreement Page Verification-Page-8 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,8,8);
		Thread.sleep(500);
		statusPass("Architect Agreement Page Verification-Page-9");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,9,9);
		Thread.sleep(500);
		statusPass("Architect Agreement Page Verification-Page-10");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,10,10);
		Thread.sleep(500);
		statusPass("Architect Agreement Page Verification-Page-11");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,11,11);
		Thread.sleep(500);
		statusPass("Architect Agreement Page Verification-Page-12");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,12,12);
		Thread.sleep(500);
		statusPass("Architect Agreement Page Verification-Page-13");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,13,13);
		Thread.sleep(500);	
		statusPass("Comparison Done, Please Evaluate Each ScreenShot in Test Report");
		endReporting();
		driver.close();
			
	}

}

@Test(dataProvider="DriverSheet")
public void QuadrantAgreementEnglish(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Browser, String Language, String Execution, String Status)throws Throwable
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC003")&&Execution.equalsIgnoreCase("Y") &&Functionality.equalsIgnoreCase("QUADRANT-AGREEMENT-ENGLISH"))
	{
		
		driver=LoginPage.LaunchBrowser(Browser); 
		LoginPage.LaunchURL(driver);
	    startReporting("Quadrant Program Account Agreement PDF Static content validation");
	    LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),Functionality + TestCaseID);
	    CommonFunctions.waitForElementMouse(driver, obj.getMouseHoverIcon(),100,"Slider Menu");
	    Thread.sleep(10000);
	    CommonFunctions.clickAround(driver,obj.getMenuButton(),obj.getMouseHoverIcon(),obj.getClients_menu(),obj.getGoalPlanning(),obj.getiFrame(), obj.getNewInvestmentProposal(),TestCaseID);
	    statusPassWithScreenshot(driver, "Clicked Goal planning Option inside Cilents menu", TestCaseDescription);
	    CommonFunctions.NavigateToNewProposal(driver,obj.getiFrame(),obj.getNewInvestmentProposal(), TestCaseID);
	    // Investment Proposal Screen
	    CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageRadiobtn_Eng"));
 		CommonFunctions.SetText(driver,obj.getNewInvestmentName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageName_Eng"));
   		statusPassWithScreenshot(driver, "New Investment Solution Name Entered and Investment Type Selected", TestCaseDescription);
 		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal Page");
		Thread.sleep(5000);
		//Settings Screen
		CommonFunctions.SelectListBox(driver, obj.getSalesCode(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageSalesCode_Eng"));			
		Thread.sleep(1000);
		//CommonFunctions.SelectListBox(driver, obj.getInvestmentAdvisor(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageIAName_Eng"));	
		CommonFunctions.SelectListBox(driver, obj.getCurrencyType(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageCurrencyType_Eng"));
		CommonFunctions.SetText(driver, obj.getInvestmentAmt(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageInvestmentAmt_Eng"));
		Thread.sleep(1000);
		statusPassWithScreenshot(driver, "Salescode,Currency,Investment Amount, Investment Advisor Name are entered in Settings page ", TestCaseDescription);
		// Scroll Down	 
		CommonFunctions.scrollandClickElement(driver, "//button[contains(text(),'Save Changes')]");
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal-Setting  Page");
		Thread.sleep(8000);
		// Clients Screen
		statusPassWithScreenshot(driver,"Add New individual Button is Displayed in Cilents Page",TestCaseDescription);
		// Client Search functionality starts here
		/*CommonFunctions.ClickButton(driver, obj.getSearchForIndividualButton());
		CommonFunctions.SetText(driver, obj.getSearchIndividual_Textbox(), "John");
		Thread.sleep(5000);
		Robot robot = new  Robot();
	    robot.keyPress(KeyEvent.VK_ENTER);
	    robot.keyRelease(KeyEvent.VK_ENTER);
	    statusPass("Search Text Entered in  Search For Individual text Box");
	    CommonFunctions.ScrollView(driver, "//button[contains(text(),'Close')]");
	    CommonFunctions.tableSelectSearchIndividual(driver, "natarajan", TestCaseDescription);*/
		// Client Search ends here
		// Add new Individual Client
		CommonFunctions.ClickButton(driver, obj.getAddNewIndividualButton());
		statusPass("Clicked Add New individual Button in Clients page");
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ClientsPageCusIDPropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageCusID_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstNamePropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstName_Eng"));
		CommonFunctions.SetTextByName(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureNamePropName_Eng"),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureName_Eng"));
		CommonFunctions.SelectListBox(driver, obj.getGender(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageGender_Eng"));	
		CommonFunctions.SelectListBox(driver, obj.getSalutation(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSalutation_Eng"));
		CommonFunctions.SetTextByClass(driver, obj.getDateofBirth(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageDateofBirth_Eng"));
		CommonFunctions.ScrollView(driver, obj.getButtonSaveandClose());
		CommonFunctions.ClickButton(driver, obj.getButtonSaveandClose());
		CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSelection_Eng"));
		statusPassWithScreenshot(driver, "Customer ID ,Name,Gender,DOB are Entered in Clients page", TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());	
		statusPass("Clicked Next Button in Add New Individual Page");
	    Thread.sleep(8000);
		/*CommonFunctions.scrollandClickElement(driver, "//button[contains(text(),'Add')]");
		CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSelection_Eng"));
		CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
		CommonFunctions.ClickButton(driver,obj.getNextButton());	
		statusPass("Clicked Next Button in Add New Individual Page");*/
		// Investment Objective page
		statusPassWithScreenshot(driver, "Investment Objective page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_InvestmentObjPage_Eng"));
		Thread.sleep(1000);
		//Time Horizon page
		statusPassWithScreenshot(driver, "Time Horizon Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TimeHorizonPage_Eng"));	
		Thread.sleep(1000);
		//Return Expectation page
		statusPassWithScreenshot(driver, "Return Expectation Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ReturnExpectationPage_Eng"));
		Thread.sleep(500);
		//Market Fluctuacion page
		statusPassWithScreenshot(driver, "Market Fluctuacion page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_MarketFluctuacionPage _Eng"));
		Thread.sleep(1000);
		//Inflation Protection page
		statusPassWithScreenshot(driver, "Inflation Protection page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_InflationProtectionpage_Eng"));				
		Thread.sleep(1000);
		//Income Requirement page
		statusPassWithScreenshot(driver, "Income Requirement Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_IncomeRequirementPage_Eng"));
		//Settings -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPassWithScreenshot(driver, "Clicked Next Button in Income requirement Page", TestCaseDescription);
		Thread.sleep(8000);
		//Account Page-Registered - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccSelect_Eng")); 
		//Account type - List Box
		CommonFunctions.SelectListBox(driver, obj.getselect_AccountPage_AccountType(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccType_Eng"));
		//Foregin Jurisdiction - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ForeginJurisdiction_Eng"));
		statusPassWithScreenshot(driver, "Selected Account Type & Foreign Jurisdiction Values in Account Page", TestCaseDescription);
		//Registered -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(5000);
		statusPass("Clicked Next button in Account Page");
		//Account Program - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountProgramType_Eng"));
		statusPassWithScreenshot(driver,"Selected Account Program in Account Program page",TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(5000);
		statusPass("Clicked Next button in Account Program Page");
		// Models Page
		statusPass("Entered into Models page");
        CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ProgramModelSelect_Eng"));
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(8000);
        //Historical Page
        statusPassWithScreenshot(driver,"Historical Performance Page dispalyed",TestCaseDescription);
        CommonFunctions.ClickButton(driver, obj.getbutton_Historical_Perf());
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
        CommonFunctions.ClickButton(driver, obj.getNextButton());
		Thread.sleep(8000);
		// Account Dewtails Page
		statusPass("Entered into Account Details page");
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_AccountDetail_AccountName_Eng"));
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountNumber(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_AccountNumber_Eng"));
		//CommonFunctions.SelectListBox(driver, obj.getAccountDetails_ReviewFrequency(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_ReviewFrequency_Eng"));
		 // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(3000);
		// Fee Schedule
		statusPass("Entered into FEE Schedule page");
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Save Changes')]");
        CommonFunctions.ClickButton(driver, obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		CommonFunctions.SetText(driver, obj.gettext_TeamName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TeamName_Eng"));
		Thread.sleep(3000);
		CommonFunctions.SetText(driver, obj.gettext_IATitle(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IATitle_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAemail(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAEmail_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAphone(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAPhone_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstNameValue_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastNameValue_Eng"));
		statusPassWithScreenshot(driver,"Team Name,Title,Name,Email,Phone Numbe Details are entered in Investment Advisor Profile page",TestCaseDescription);
		statusPassWithScreenshot(driver, "Entered into IA Profile Page", TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(5000);
		statusPassWithScreenshot(driver, "Entered into Administrative Question page", TestCaseDescription);
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(5000);
		CommonFunctions.ClickButton(driver,obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		// Generate Documents Page
		statusPassWithScreenshot(driver, "Entered into generate Document page", TestCaseDescription);
		CommonFunctions.tableSelect(driver, "Quadrant Program Account Agreement",TestCaseDescription);
		statusPass("Quadrant Agreement Download Button Clicked ");
		Thread.sleep(20000);
		// Getting child window details
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		Thread.sleep(2000);
		// Saving PDF to download folder
		CommonFunctions.PDFSave(driver,TestCaseID);
		String generatedFile=CommonFunctions.FileMoveAndRename(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_FileDownloadLocation_Eng"),"C:\\BrunoAutomationFramework\\PDFfiles\\GeneratedFiles", TestCaseID);
		String SourceFile = "C:\\BrunoAutomationFramework\\SourceFiles\\Quadrant_MAA_Source.pdf";
		// PDF file verification
		statusPass("Quadrant Agreement Page Verification-Page-1 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,1,1);
				
		statusPass("Quadrant Agreement Page Verification-Page-2 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,2,2);
		
		statusPass("Quadrant Agreement Page Verification-Page-3 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,3,3);
		
		statusPass("Quadrant Agreement Page Verification-Page-4 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,4,4);
		
		statusPass("Quadrant Agreement Page Verification-Page-5");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,5,5);
		
		statusPass("Quadrant Agreement Page Verification-Page-6 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,6,6);
		
		statusPass("Quadrant Agreement Page Verification-Page-7");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,7,7);
		
		statusPass("Comparison Done, Please Evaluate Each ScreenShot in Test Report");
		endReporting();
		driver.close();
	
			
		
	}

}

@Test(dataProvider="DriverSheet")
public void ArchitectAgreementFrench(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Browser, String Language, String Execution, String Status)throws Throwable
{
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC005")&&Execution.equalsIgnoreCase("Y") &&Functionality.equalsIgnoreCase("ARCHITECT-AGREEMENT-FRENCH"))

	{
	
		driver=LoginPage.LaunchBrowser(Browser); 
		LoginPage.LaunchURL(driver);
		startReporting("Architect Program Account Agreement PDF Static content validation");
	   
		LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),Functionality + TestCaseID);
	    CommonFunctions.waitForElementMouse(driver, obj.getMouseHoverIcon(),100,"Slider Menu");
	    Thread.sleep(10000);
	    CommonFunctions.clickAround(driver,obj.getMenuButton(),obj.getMouseHoverIcon(),obj.getClients_menu(),obj.getGoalPlanning(),obj.getiFrame(), obj.getNewInvestmentProposal(),TestCaseID);
	    statusPassWithScreenshot(driver, "Clicked Goal planning Option inside Cilents menu", TestCaseDescription);
	    CommonFunctions.NavigateToNewProposal(driver,obj.getiFrame(),obj.getNewInvestmentProposal(), TestCaseID);
  		// INVESTMENT PROPOSAL SCREEN
	    CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageRadiobtn_Eng"));
 		CommonFunctions.SetText(driver,obj.getNewInvestmentName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageName_Eng"));
   		statusPassWithScreenshot(driver, "New Investment Solution Name Entered and Investment Type Selected", TestCaseDescription);
 		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal Page");
		Thread.sleep(5000);
		// SETTINGS SCREEN
		CommonFunctions.SelectListBox(driver, obj.getSalesCode(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageSalesCode_Eng"));			
		Thread.sleep(3000);
		//CommonFunctions.SelectListBox(driver, obj.getInvestmentAdvisor(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageIAName_Eng"));	
		CommonFunctions.SelectListBox(driver, obj.getCurrencyType(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageCurrencyType_Eng"));
		CommonFunctions.SetText(driver, obj.getInvestmentAmt(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageInvestmentAmt_Eng"));
		Thread.sleep(500);
		statusPassWithScreenshot(driver, "Salescode,Currency,Investment Amount, Investment Advisor Name are entered in Settings page ", TestCaseDescription);
		CommonFunctions.scrollandClickElement(driver, "//button[contains(text(),'Save Changes')]");
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal-Setting  Page");
		Thread.sleep(3000);
		//CLIENTS SCREEN
		statusPassWithScreenshot(driver,"Add New individual Button is Displayed in Cilents Page",TestCaseDescription);
		// Search Starts Here
		/*CommonFunctions.ClickButton(driver, obj.getSearchForIndividualButton());
		CommonFunctions.SetText(driver, obj.getSearchIndividual_Textbox(), "John");
		Thread.sleep(5000);
		Robot robot = new  Robot();
	    robot.keyPress(KeyEvent.VK_ENTER);
	    robot.keyRelease(KeyEvent.VK_ENTER);
	    tatusPass("Search Text Entered in  Search For Individual text Box");
	    CommonFunctions.ScrollView(driver, "//button[contains(text(),'Close')]");
	    CommonFunctions.tableSelectSearchIndividual(driver,"Smith", TestCaseDescription);*/
		// Search Ends Here
		
		// Add new Individual
		CommonFunctions.ClickButton(driver, obj.getAddNewIndividualButton());
		statusPass("Clicked Add New individual Button in Clients page");
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ClientsPageCusIDPropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageCusID_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstNamePropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstName_Eng"));
		CommonFunctions.SetTextByName(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureNamePropName_Eng"),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureName_Eng"));
		CommonFunctions.SelectListBox(driver, obj.getGender(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageGender_Eng"));	
		CommonFunctions.SelectListBox(driver, obj.getSalutation(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSalutation_Eng"));
		CommonFunctions.SetTextByClass(driver, obj.getDateofBirth(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageDateofBirth_Eng"));
		CommonFunctions.ScrollView(driver, obj.getButtonSaveandClose());
		CommonFunctions.ClickButton(driver, obj.getButtonSaveandClose());
		CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSelection_Eng"));
		statusPassWithScreenshot(driver, "Customer ID ,Name,Gender,DOB are Entered in Clients page", TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());	
		statusPass("Clicked Next Button in Add New Individual Page");
		Thread.sleep(5000);
		statusPass("Entered into Investment Objective Page");
		//Investment Objective page
		statusPassWithScreenshot(driver, "Investment Objective page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_InvestmentObjPage_Eng"));
		Thread.sleep(1000);
		statusPass("Entered into Time Horizon  Page");
		//Time Horizon page 
		statusPassWithScreenshot(driver, "Time Horizon Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TimeHorizonPage_Eng"));	
		Thread.sleep(1000);
		//System.out.println("********************************Return Expectation page *********************************************");
		statusPassWithScreenshot(driver, "Return Expectation Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ReturnExpectationPage_Eng"));
		Thread.sleep(1000);
		statusPassWithScreenshot(driver, "Market Fluctuacion page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_MarketFluctuacionPage _Eng"));
		Thread.sleep(1000);
		statusPassWithScreenshot(driver, "Inflation Protection page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_InflationProtectionpage_Eng"));				
		Thread.sleep(1000);
		//Income Requirement
		statusPassWithScreenshot(driver, "Income Requirement Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_IncomeRequirementPage_Eng"));
		//Settings -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPassWithScreenshot(driver, "Clicked Next Button in Income requirement Page", TestCaseDescription);
		Thread.sleep(5000);
		//Registered - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccSelect_Eng")); 
		//Account type - List Box
		CommonFunctions.SelectListBox(driver, obj.getselect_AccountPage_AccountType(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccType_Eng"));
		//Foregin Jurisdiction - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ForeginJurisdiction_Eng"));
		statusPassWithScreenshot(driver, "Selected Account Type & Foreign Jurisdiction Values in Account Page", TestCaseDescription);
		//Registered -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPass("Clicked Next button in Account Page");
		//Account Program - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountProgramType_Eng"));
		statusPassWithScreenshot(driver,"Selected Account Program in Account Program page",TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(5000);
		statusPass("Clicked Next button in Account Program Page");
		//Client-directed Sleeve page
		statusPass("Entered into Client Directed Sleeve page");
        CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ClientDirectedSleeveSelect_Eng"));
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(8000);
        statusPass("Entered into Model Schem page");
        CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ModelSchemSelect_Eng"));
        statusPassWithScreenshot(driver,"Selected the radio button",TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(8000);
        //Portfolio construction Page
        statusPassWithScreenshot(driver,"Entered Into Port Folio Construction Page",TestCaseDescription);
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(8000);
        //Historical Performance Page
        statusPassWithScreenshot(driver,"Historical Performance Page dispalyed",TestCaseDescription);
        CommonFunctions.ClickButton(driver, obj.getbutton_Historical_Perf());
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
        CommonFunctions.ClickButton(driver, obj.getNextButton());
		Thread.sleep(8000);
		// Account Details page
        statusPass("Entered into Account Details page");
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_AccountDetail_AccountName_Eng"));
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountNumber(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_AccountNumber_Eng"));
		//CommonFunctions.SelectListBox(driver, obj.getAccountDetails_ReviewFrequency(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_ReviewFrequency_Eng"));
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(5000);
		// Fee Schedule
		statusPass("Entered into FEE Schedule page");
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(5000);
		CommonFunctions.ClickButton(driver, obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		CommonFunctions.SetText(driver, obj.gettext_TeamName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TeamName_Eng"));
		Thread.sleep(3000);
		CommonFunctions.SetText(driver, obj.gettext_IATitle(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IATitle_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAemail(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAEmail_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAphone(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAPhone_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstNameValue_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastNameValue_Eng"));
		statusPassWithScreenshot(driver,"Team Name,Title,Name,Email,Phone Numbe Details are entered in Investment Advisor Profile page",TestCaseDescription);
		statusPassWithScreenshot(driver, "Entered into IA Profile Page", TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(5000);
		statusPassWithScreenshot(driver, "Entered into Administrative Question page", TestCaseDescription);
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(5000);
		// Clicking French Radio Button
		CommonFunctions.ClickButton(driver, obj.getRadio_French_Document());
		Thread.sleep(1000);
		CommonFunctions.ClickButton(driver,obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		// Generate Documents Page
		statusPassWithScreenshot(driver, "Entered into generate Document page", TestCaseDescription);
		CommonFunctions.tableSelect(driver, "CCG Architecte",TestCaseDescription);
		
		statusPass("Architect Agreement Download Button Clicked ");
		Thread.sleep(10000);
		// Getting child window details
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		Thread.sleep(1000);
		// Saving PDF to download folder
		CommonFunctions.PDFSave(driver,TestCaseID);
		// Source file Location commented as we are generating from Online
		//String SourceFile = ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SourcefileLocation_Eng");
		String generatedFile=CommonFunctions.FileMoveAndRename(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_FileDownloadLocation_Eng"),"C:\\BrunoAutomationFramework\\PDFfiles\\GeneratedFiles", TestCaseID);
		String SourceFile = "C:\\BrunoAutomationFramework\\SourceFiles\\Architect_MAA_Source_Fre.pdf";
		Thread.sleep(2000);
		// Form verification starts here
		statusPass("Architect Agreement Page Verification-Page-1 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,1,1);
		Thread.sleep(500);
		statusPass("Architect Agreement Page Verification-Page-2 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,2,2);
		Thread.sleep(500);
		statusPass("Architect Agreement Page Verification-Page-3 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,3,3);
		Thread.sleep(500);
		statusPass("Architect Agreement Page Verification-Page-4 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,4,4);
		Thread.sleep(500);
		statusPass("Architect Agreement Page Verification-Page-5");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,5,5);
		Thread.sleep(500);
		statusPass("Architect Agreement Page Verification-Page-6 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,6,6);
		Thread.sleep(1000);
		statusPass("Architect Agreement Page Verification-Page-7");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,7,7);
		Thread.sleep(500);
		statusPass("Architect Agreement Page Verification-Page-8 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,8,8);
		Thread.sleep(500);
		statusPass("Architect Agreement Page Verification-Page-9");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,9,9);
		Thread.sleep(500);
		statusPass("Architect Agreement Page Verification-Page-10");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,10,10);
		Thread.sleep(500);
		statusPass("Architect Agreement Page Verification-Page-11");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,11,11);
		Thread.sleep(500);
		statusPass("Architect Agreement Page Verification-Page-12");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,12,12);
		Thread.sleep(500);
		statusPass("Architect Agreement Page Verification-Page-13");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,13,13);
		Thread.sleep(500);	
		statusPass("Comparison Done, Please Evaluate Each ScreenShot in Test Report");
		endReporting();
		driver.close();
			
	}

}

@Test(dataProvider="DriverSheet")
public void BlueprintAgreementFrench(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Browser, String Language, String Execution, String Status)throws Throwable
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC006")&&Execution.equalsIgnoreCase("Y") &&Functionality.equalsIgnoreCase("BLUEPRINT-AGREEMENT-FRENCH"))	
	{
		
		driver=LoginPage.LaunchBrowser(Browser); 
		LoginPage.LaunchURL(driver);
	    startReporting("Blueprint Program Account Agreement PDF Static content validation");
	   //Login Page
	    LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),Functionality + TestCaseID);
	    CommonFunctions.waitForElementMouse(driver, obj.getMouseHoverIcon(),100,"Slider Menu");
	    Thread.sleep(10000);
	    CommonFunctions.clickAround(driver,obj.getMenuButton(),obj.getMouseHoverIcon(),obj.getClients_menu(),obj.getGoalPlanning(),obj.getiFrame(), obj.getNewInvestmentProposal(),TestCaseID);
	    statusPassWithScreenshot(driver, "Clicked Goal planning Option inside Cilents menu", TestCaseDescription);
	    CommonFunctions.NavigateToNewProposal(driver,obj.getiFrame(),obj.getNewInvestmentProposal(), TestCaseID);
	    Thread.sleep(5000);
	    // Investment Proposal Screen
  		CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageRadiobtn_Eng"));
 		CommonFunctions.SetText(driver,obj.getNewInvestmentName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageName_Eng"));
   		statusPassWithScreenshot(driver, "New Investment Solution Name Entered and Investment Type Selected", TestCaseDescription);
 		//CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());
 		//statusPass("Clicked Save changes Button in New Investment Proposal Page");
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal Page");
		Thread.sleep(5000);
		//Settings Screen
		CommonFunctions.SelectListBox(driver, obj.getSalesCode(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageSalesCode_Eng"));			
		Thread.sleep(500);
		CommonFunctions.SelectListBox(driver, obj.getCurrencyType(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageCurrencyType_Eng"));
		CommonFunctions.SetText(driver, obj.getInvestmentAmt(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageInvestmentAmt_Eng"));
		Thread.sleep(1000);
		statusPassWithScreenshot(driver, "Salescode,Currency,Investment Amount, Investment Advisor Name are entered in Settings page ", TestCaseDescription);
		CommonFunctions.scrollandClickElement(driver, "//button[contains(text(),'Save Changes')]");
		Thread.sleep(1000);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal-Setting  Page");
		Thread.sleep(5000);
		// Clients Screen
		statusPassWithScreenshot(driver,"Add New individual Button is Displayed in Cilents Page",TestCaseDescription);
		// Adding New Individual	
		CommonFunctions.ClickButton(driver, obj.getAddNewIndividualButton());
		statusPass("Clicked Add New individual Button in Clients page");
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ClientsPageCusIDPropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageCusID_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstNamePropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstName_Eng"));
		CommonFunctions.SetTextByName(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureNamePropName_Eng"),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureName_Eng"));
		CommonFunctions.SelectListBox(driver, obj.getGender(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageGender_Eng"));	
		CommonFunctions.SelectListBox(driver, obj.getSalutation(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSalutation_Eng"));
		CommonFunctions.SetTextByClass(driver, obj.getDateofBirth(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageDateofBirth_Eng"));
		
		CommonFunctions.ScrollView(driver, obj.getButtonSaveandClose());
		Thread.sleep(1000);
		CommonFunctions.ClickButton(driver, obj.getButtonSaveandClose());
		CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSelection_Eng"));
		statusPassWithScreenshot(driver, "Customer ID ,Name,Gender,DOB are Entered in Clients page", TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());	
		statusPass("Clicked Next Button in Add New Individual Page");
		Thread.sleep(5000);
		
		// Below code for clicking Add button when we user search option
		//CommonFunctions.scrollandClickElement(driver, "//button[contains(text(),'Add')]");
		//CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSelection_Eng"));
		//CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
		//CommonFunctions.ClickButton(driver,obj.getNextButton());	
		//statusPass("Clicked Next Button in Add New Individual Page");
		
		// Investment Objective page
		statusPassWithScreenshot(driver, "Investment Objective page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_InvestmentObjPage_Eng"));
		Thread.sleep(1000);
		//Time Horizon Page
		
		statusPassWithScreenshot(driver, "Time Horizon Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TimeHorizonPage_Eng"));	
		Thread.sleep(1000);
		// Return Expectation page
		statusPassWithScreenshot(driver, "Return Expectation Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ReturnExpectationPage_Eng"));
		Thread.sleep(1000);
		//Market Fluctuacion Page
		statusPassWithScreenshot(driver, "Market Fluctuacion page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_MarketFluctuacionPage _Eng"));
		Thread.sleep(1000);
		//Inflation Protection Page
		statusPassWithScreenshot(driver, "Inflation Protection page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_InflationProtectionpage_Eng"));				
		Thread.sleep(1000);
		//Income Requirement Page
		statusPassWithScreenshot(driver, "Income Requirement Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_IncomeRequirementPage_Eng"));
		//Settings -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPassWithScreenshot(driver, "Clicked Next Button in Income requirement Page", TestCaseDescription);
		Thread.sleep(8000);
		//Account Page
		//Registered - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccSelect_Eng")); 
		//Account type - List Box
		CommonFunctions.SelectListBox(driver, obj.getselect_AccountPage_AccountType(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccType_Eng"));
		//Foregin Jurisdiction - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ForeginJurisdiction_Eng"));
		statusPassWithScreenshot(driver, "Selected Account Type & Foreign Jurisdiction Values in Account Page", TestCaseDescription);
		//Registered -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPass("Clicked Next button in Account Page");
		// Account Program
		//Account Program - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountProgramType_Eng"));
		statusPassWithScreenshot(driver,"Selected Account Program in Account Program page",TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPass("Clicked Next button in Account Program Page");
		// Models Page
		statusPass("Entered into Models page");
        CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ProgramModelSelect_Eng"));
        statusPassWithScreenshot(driver,"Selected the radio button",TestCaseDescription);
         
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        //CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(8000);
        //Historical Page
        statusPassWithScreenshot(driver,"Historical Performance Page dispalyed",TestCaseDescription);
        CommonFunctions.ClickButton(driver, obj.getbutton_Historical_Perf());
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        //CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());
        statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
        CommonFunctions.ClickButton(driver, obj.getNextButton());
		Thread.sleep(8000);
		// Account Details Page
		statusPass("Entered into Account Details page");
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_AccountDetail_AccountName_Eng"));
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountNumber(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_AccountNumber_Eng"));
		//CommonFunctions.SelectListBox(driver, obj.getAccountDetails_ReviewFrequency(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_ReviewFrequency_Eng"));
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        //CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());
		//Thread.sleep(1000);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		// Fee Schedule Page
		statusPass("Entered into FEE Schedule page");
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        //CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());
		//Thread.sleep(1000);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		CommonFunctions.ClickButton(driver, obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		CommonFunctions.SetText(driver, obj.gettext_TeamName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TeamName_Eng"));
		Thread.sleep(3000);
		CommonFunctions.SetText(driver, obj.gettext_IATitle(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IATitle_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAemail(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAEmail_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAphone(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAPhone_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstNameValue_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastNameValue_Eng"));
		statusPassWithScreenshot(driver,"Team Name,Title,Name,Email,Phone Numbe Details are entered in Investment Advisor Profile page",TestCaseDescription);
		statusPassWithScreenshot(driver, "Entered into IA Profile Page", TestCaseDescription);
		//CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());				
		//Thread.sleep(8000);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPassWithScreenshot(driver, "Entered into Administrative Question page", TestCaseDescription);
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
		//CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());				
		Thread.sleep(8000);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(4000);
		// Clicking French Radio Button
		CommonFunctions.ClickButton(driver, obj.getRadio_French_Document());
		Thread.sleep(2000);
		CommonFunctions.ClickButton(driver,obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		// Generate Documents Page
		statusPassWithScreenshot(driver, "Entered into generate Document page", TestCaseDescription);
		CommonFunctions.tableSelect(driver, "CCG L�Orienteur",TestCaseDescription);
		
		
		statusPass("Blueprint Agreement Download Button Clicked ");
		Thread.sleep(10000);
		
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		
		Thread.sleep(8000);
		// Saving PDF to download folder
		CommonFunctions.PDFSave(driver,TestCaseID);
		
		// Source file Location commented as we are generating from Online
		//String SourceFile = ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SourcefileLocation_Eng");
		
		
		String generatedFile=CommonFunctions.FileMoveAndRename(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_FileDownloadLocation_Eng"),"C:\\BrunoAutomationFramework\\PDFfiles\\GeneratedFiles", TestCaseID);
		
		String SourceFile = "C:\\BrunoAutomationFramework\\SourceFiles\\BluePrint_MAA_Source_Fre.pdf";
					
		statusPass("Blueprint Agreement Page Verification-Page-1 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,1,1);
				
		statusPass("Blueprint Agreement Page Verification-Page-2 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,2,2);
		Thread.sleep(200);
		statusPass("Blueprint Agreement Page Verification-Page-3 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,3,3);
		Thread.sleep(200);
		statusPass("Blueprint Agreement Page Verification-Page-4 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,4,4);
		Thread.sleep(200);
		statusPass("Blueprint Agreement Page Verification-Page-5");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,5,5);
		Thread.sleep(200);
		statusPass("Blueprint Agreement Page Verification-Page-6 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,6,6);
		Thread.sleep(200);
		statusPass("Blueprint Agreement Page Verification-Page-7");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,7,7);
		Thread.sleep(200);
		statusPass("Blueprint Agreement Page Verification-Page-8 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,8,8);
		Thread.sleep(200);
		statusPass("Blueprint Agreement Page Verification-Page-9 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,9,9);
		Thread.sleep(200);
		statusPass("Blueprint Agreement Page Verification-Page-10 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,10,10);
		statusPass("Comparison Done, Please Evaluate Each ScreenShot in Test Report");
		endReporting();
		driver.close();
		
		
	}

}

@Test(dataProvider="DriverSheet")
public void QuadrantAgreementFrench(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Browser, String Language, String Execution, String Status)throws Throwable
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC007")&&Execution.equalsIgnoreCase("Y") &&Functionality.equalsIgnoreCase("QUADRANT-AGREEMENT-FRENCH"))
	{
		
		driver=LoginPage.LaunchBrowser(Browser); 
		LoginPage.LaunchURL(driver);
	    startReporting("Quadrant Program Account Agreement PDF Static content validation");
	    LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),Functionality + TestCaseID);
	    CommonFunctions.waitForElementMouse(driver, obj.getMouseHoverIcon(),100,"Slider Menu");
	    Thread.sleep(10000);
	    CommonFunctions.clickAround(driver,obj.getMenuButton(),obj.getMouseHoverIcon(),obj.getClients_menu(),obj.getGoalPlanning(),obj.getiFrame(), obj.getNewInvestmentProposal(),TestCaseID);
	    statusPassWithScreenshot(driver, "Clicked Goal planning Option inside Cilents menu", TestCaseDescription);
	    CommonFunctions.NavigateToNewProposal(driver,obj.getiFrame(),obj.getNewInvestmentProposal(), TestCaseID);
	    // Investment Proposal Screen
	    CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageRadiobtn_Eng"));
 		CommonFunctions.SetText(driver,obj.getNewInvestmentName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageName_Eng"));
   		statusPassWithScreenshot(driver, "New Investment Solution Name Entered and Investment Type Selected", TestCaseDescription);
 		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal Page");
		Thread.sleep(5000);
		//Settings Screen
		CommonFunctions.SelectListBox(driver, obj.getSalesCode(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageSalesCode_Eng"));			
		Thread.sleep(1000);
		//CommonFunctions.SelectListBox(driver, obj.getInvestmentAdvisor(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageIAName_Eng"));	
		CommonFunctions.SelectListBox(driver, obj.getCurrencyType(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageCurrencyType_Eng"));
		CommonFunctions.SetText(driver, obj.getInvestmentAmt(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageInvestmentAmt_Eng"));
		Thread.sleep(1000);
		statusPassWithScreenshot(driver, "Salescode,Currency,Investment Amount, Investment Advisor Name are entered in Settings page ", TestCaseDescription);
		// Scroll Down	 
		CommonFunctions.scrollandClickElement(driver, "//button[contains(text(),'Save Changes')]");
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal-Setting  Page");
		Thread.sleep(8000);
		// Clients Screen
		statusPassWithScreenshot(driver,"Add New individual Button is Displayed in Cilents Page",TestCaseDescription);
		// Client Search functionality starts here
		/*CommonFunctions.ClickButton(driver, obj.getSearchForIndividualButton());
		CommonFunctions.SetText(driver, obj.getSearchIndividual_Textbox(), "John");
		Thread.sleep(5000);
		Robot robot = new  Robot();
	    robot.keyPress(KeyEvent.VK_ENTER);
	    robot.keyRelease(KeyEvent.VK_ENTER);
	    statusPass("Search Text Entered in  Search For Individual text Box");
	    CommonFunctions.ScrollView(driver, "//button[contains(text(),'Close')]");
	    CommonFunctions.tableSelectSearchIndividual(driver, "natarajan", TestCaseDescription);*/
		// Client Search ends here
		// Add new Individual Client
		CommonFunctions.ClickButton(driver, obj.getAddNewIndividualButton());
		statusPass("Clicked Add New individual Button in Clients page");
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ClientsPageCusIDPropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageCusID_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstNamePropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstName_Eng"));
		CommonFunctions.SetTextByName(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureNamePropName_Eng"),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureName_Eng"));
		CommonFunctions.SelectListBox(driver, obj.getGender(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageGender_Eng"));	
		CommonFunctions.SelectListBox(driver, obj.getSalutation(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSalutation_Eng"));
		CommonFunctions.SetTextByClass(driver, obj.getDateofBirth(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageDateofBirth_Eng"));
		CommonFunctions.ScrollView(driver, obj.getButtonSaveandClose());
		CommonFunctions.ClickButton(driver, obj.getButtonSaveandClose());
		CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSelection_Eng"));
		statusPassWithScreenshot(driver, "Customer ID ,Name,Gender,DOB are Entered in Clients page", TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());	
		statusPass("Clicked Next Button in Add New Individual Page");
	    Thread.sleep(8000);
		/*CommonFunctions.scrollandClickElement(driver, "//button[contains(text(),'Add')]");
		CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSelection_Eng"));
		CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
		CommonFunctions.ClickButton(driver,obj.getNextButton());	
		statusPass("Clicked Next Button in Add New Individual Page");*/
		// Investment Objective page
		statusPassWithScreenshot(driver, "Investment Objective page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_InvestmentObjPage_Eng"));
		Thread.sleep(1000);
		//Time Horizon page
		statusPassWithScreenshot(driver, "Time Horizon Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TimeHorizonPage_Eng"));	
		Thread.sleep(1000);
		//Return Expectation page
		statusPassWithScreenshot(driver, "Return Expectation Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ReturnExpectationPage_Eng"));
		Thread.sleep(500);
		//Market Fluctuacion page
		statusPassWithScreenshot(driver, "Market Fluctuacion page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_MarketFluctuacionPage _Eng"));
		Thread.sleep(1000);
		//Inflation Protection page
		statusPassWithScreenshot(driver, "Inflation Protection page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_InflationProtectionpage_Eng"));				
		Thread.sleep(1000);
		//Income Requirement page
		statusPassWithScreenshot(driver, "Income Requirement Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_IncomeRequirementPage_Eng"));
		//Settings -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPassWithScreenshot(driver, "Clicked Next Button in Income requirement Page", TestCaseDescription);
		Thread.sleep(8000);
		//Account Page-Registered - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccSelect_Eng")); 
		//Account type - List Box
		CommonFunctions.SelectListBox(driver, obj.getselect_AccountPage_AccountType(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccType_Eng"));
		//Foregin Jurisdiction - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ForeginJurisdiction_Eng"));
		statusPassWithScreenshot(driver, "Selected Account Type & Foreign Jurisdiction Values in Account Page", TestCaseDescription);
		//Registered -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(5000);
		statusPass("Clicked Next button in Account Page");
		//Account Program - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountProgramType_Eng"));
		statusPassWithScreenshot(driver,"Selected Account Program in Account Program page",TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPass("Clicked Next button in Account Program Page");
		// Models Page
		statusPass("Entered into Models page");
        CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ProgramModelSelect_Eng"));
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(8000);
        //Historical Page
        statusPassWithScreenshot(driver,"Historical Performance Page dispalyed",TestCaseDescription);
        CommonFunctions.ClickButton(driver, obj.getbutton_Historical_Perf());
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
        CommonFunctions.ClickButton(driver, obj.getNextButton());
		Thread.sleep(8000);
		// Account Dewtails Page
		statusPass("Entered into Account Details page");
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_AccountDetail_AccountName_Eng"));
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountNumber(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_AccountNumber_Eng"));
		//CommonFunctions.SelectListBox(driver, obj.getAccountDetails_ReviewFrequency(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_ReviewFrequency_Eng"));
		 // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(3000);
		// Fee Schedule
		statusPass("Entered into FEE Schedule page");
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Save Changes')]");
        CommonFunctions.ClickButton(driver, obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		CommonFunctions.SetText(driver, obj.gettext_TeamName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TeamName_Eng"));
		Thread.sleep(3000);
		CommonFunctions.SetText(driver, obj.gettext_IATitle(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IATitle_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAemail(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAEmail_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAphone(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAPhone_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstNameValue_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastNameValue_Eng"));
		statusPassWithScreenshot(driver,"Team Name,Title,Name,Email,Phone Numbe Details are entered in Investment Advisor Profile page",TestCaseDescription);
		statusPassWithScreenshot(driver, "Entered into IA Profile Page", TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(5000);
		statusPassWithScreenshot(driver, "Entered into Administrative Question page", TestCaseDescription);
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(5000);
		// Selecting French Radio Button
		CommonFunctions.ClickButton(driver, obj.getRadio_French_Document());
		Thread.sleep(1000);
		CommonFunctions.ClickButton(driver,obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		// Generate Documents Page
		statusPassWithScreenshot(driver, "Entered into generate Document page", TestCaseDescription);
		CommonFunctions.tableSelect(driver, "CCG Quadrant",TestCaseDescription);
		statusPass("Quadrant Agreement Download Button Clicked ");
		Thread.sleep(20000);
		// Getting child window details
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		Thread.sleep(2000);
		// Saving PDF to download folder
		CommonFunctions.PDFSave(driver,TestCaseID);
		String generatedFile=CommonFunctions.FileMoveAndRename(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_FileDownloadLocation_Eng"),"C:\\BrunoAutomationFramework\\PDFfiles\\GeneratedFiles", TestCaseID);
		String SourceFile = "C:\\BrunoAutomationFramework\\SourceFiles\\Quadrant_MAA_Source_Fre.pdf";
		// PDF file verification
		statusPass("Quadrant Agreement Page Verification-Page-1 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,1,1);
				
		statusPass("Quadrant Agreement Page Verification-Page-2 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,2,2);
		
		statusPass("Quadrant Agreement Page Verification-Page-3 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,3,3);
		
		statusPass("Quadrant Agreement Page Verification-Page-4 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,4,4);
		
		statusPass("Quadrant Agreement Page Verification-Page-5");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,5,5);
		
		statusPass("Quadrant Agreement Page Verification-Page-6 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,6,6);
		
		statusPass("Quadrant Agreement Page Verification-Page-7");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,7,7);
		
		statusPass("Quadrant Agreement Page Verification-Page-8");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,8,8);
		
		statusPass("Comparison Done, Please Evaluate Each ScreenShot in Test Report");
		endReporting();
		driver.close();
	
			
		
	}

}
@Test(dataProvider="DriverSheet")
public void ArchitectIPSEnglish(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Browser, String Language, String Execution, String Status)throws Throwable
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC009")&&Execution.equalsIgnoreCase("Y") &&Functionality.equalsIgnoreCase("ARCHITECT-IPS-ENGLISH"))
	{
		
		driver=LoginPage.LaunchBrowser(Browser); 
		LoginPage.LaunchURL(driver);
		startReporting("Architect IPS Form Static content validation");
	   
		LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),Functionality + TestCaseID);
	    CommonFunctions.waitForElementMouse(driver, obj.getMouseHoverIcon(),100,"Slider Menu");
	    Thread.sleep(10000);
	    CommonFunctions.clickAround(driver,obj.getMenuButton(),obj.getMouseHoverIcon(),obj.getClients_menu(),obj.getGoalPlanning(),obj.getiFrame(), obj.getNewInvestmentProposal(),TestCaseID);
	    statusPassWithScreenshot(driver, "Clicked Goal planning Option inside Cilents menu", TestCaseDescription);
	    CommonFunctions.NavigateToNewProposal(driver,obj.getiFrame(),obj.getNewInvestmentProposal(), TestCaseID);
  		// INVESTMENT PROPOSAL SCREEN
	    CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageRadiobtn_Eng"));
 		CommonFunctions.SetText(driver,obj.getNewInvestmentName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageName_Eng"));
   		statusPassWithScreenshot(driver, "New Investment Solution Name Entered and Investment Type Selected", TestCaseDescription);
 		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal Page");
		Thread.sleep(5000);
		// SETTINGS SCREEN
		CommonFunctions.SelectListBox(driver, obj.getSalesCode(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageSalesCode_Eng"));			
		Thread.sleep(5000);
		//CommonFunctions.SelectListBox(driver, obj.getInvestmentAdvisor(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageIAName_Eng"));	
		CommonFunctions.SelectListBox(driver, obj.getCurrencyType(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageCurrencyType_Eng"));
		CommonFunctions.SetText(driver, obj.getInvestmentAmt(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageInvestmentAmt_Eng"));
		Thread.sleep(500);
		statusPassWithScreenshot(driver, "Salescode,Currency,Investment Amount, Investment Advisor Name are entered in Settings page ", TestCaseDescription);
		CommonFunctions.scrollandClickElement(driver, "//button[contains(text(),'Save Changes')]");
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal-Setting  Page");
		Thread.sleep(5000);
		//CLIENTS SCREEN
		statusPassWithScreenshot(driver,"Add New individual Button is Displayed in Cilents Page",TestCaseDescription);
		// Search Starts Here
		/*CommonFunctions.ClickButton(driver, obj.getSearchForIndividualButton());
		CommonFunctions.SetText(driver, obj.getSearchIndividual_Textbox(), "John");
		Thread.sleep(5000);
		Robot robot = new  Robot();
	    robot.keyPress(KeyEvent.VK_ENTER);
	    robot.keyRelease(KeyEvent.VK_ENTER);
	    tatusPass("Search Text Entered in  Search For Individual text Box");
	    CommonFunctions.ScrollView(driver, "//button[contains(text(),'Close')]");
	    CommonFunctions.tableSelectSearchIndividual(driver,"Smith", TestCaseDescription);*/
		// Search Ends Here
		
		// Add new Individual
		CommonFunctions.ClickButton(driver, obj.getAddNewIndividualButton());
		statusPass("Clicked Add New individual Button in Clients page");
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ClientsPageCusIDPropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageCusID_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstNamePropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstName_Eng"));
		CommonFunctions.SetTextByName(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureNamePropName_Eng"),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureName_Eng"));
		CommonFunctions.SelectListBox(driver, obj.getGender(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageGender_Eng"));	
		CommonFunctions.SelectListBox(driver, obj.getSalutation(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSalutation_Eng"));
		CommonFunctions.SetTextByClass(driver, obj.getDateofBirth(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageDateofBirth_Eng"));
		CommonFunctions.ScrollView(driver, obj.getButtonSaveandClose());
		CommonFunctions.ClickButton(driver, obj.getButtonSaveandClose());
		CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSelection_Eng"));
		statusPassWithScreenshot(driver, "Customer ID ,Name,Gender,DOB are Entered in Clients page", TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());	
		statusPass("Clicked Next Button in Add New Individual Page");
		Thread.sleep(5000);
		statusPass("Entered into Investment Objective Page");
		//Investment Objective page
		statusPassWithScreenshot(driver, "Investment Objective page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_InvestmentObjPage_Eng"));
		Thread.sleep(1000);
		statusPass("Entered into Time Horizon  Page");
		//Time Horizon page 
		statusPassWithScreenshot(driver, "Time Horizon Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TimeHorizonPage_Eng"));	
		Thread.sleep(1000);
		//System.out.println("********************************Return Expectation page *********************************************");
		statusPassWithScreenshot(driver, "Return Expectation Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ReturnExpectationPage_Eng"));
		Thread.sleep(1000);
		statusPassWithScreenshot(driver, "Market Fluctuacion page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_MarketFluctuacionPage _Eng"));
		Thread.sleep(1000);
		statusPassWithScreenshot(driver, "Inflation Protection page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_InflationProtectionpage_Eng"));				
		Thread.sleep(1000);
		//Income Requirement
		statusPassWithScreenshot(driver, "Income Requirement Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_IncomeRequirementPage_Eng"));
		//Settings -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPassWithScreenshot(driver, "Clicked Next Button in Income requirement Page", TestCaseDescription);
		Thread.sleep(5000);
		//Registered - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccSelect_Eng")); 
		//Account type - List Box
		CommonFunctions.SelectListBox(driver, obj.getselect_AccountPage_AccountType(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccType_Eng"));
		//Foregin Jurisdiction - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ForeginJurisdiction_Eng"));
		statusPassWithScreenshot(driver, "Selected Account Type & Foreign Jurisdiction Values in Account Page", TestCaseDescription);
		//Registered -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPass("Clicked Next button in Account Page");
		//Account Program - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountProgramType_Eng"));
		statusPassWithScreenshot(driver,"Selected Account Program in Account Program page",TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPass("Clicked Next button in Account Program Page");
		//Client-directed Sleeve page
		statusPass("Entered into Client Directed Sleeve page");
        CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ClientDirectedSleeveSelect_Eng"));
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(8000);
        statusPass("Entered into Model Schem page");
        CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ModelSchemSelect_Eng"));
        statusPassWithScreenshot(driver,"Selected the radio button",TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(8000);
        //Portfolio construction Page
        statusPassWithScreenshot(driver,"Entered Into Port Folio Construction Page",TestCaseDescription);
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(8000);
        //Historical Performance Page
        statusPassWithScreenshot(driver,"Historical Performance Page dispalyed",TestCaseDescription);
        CommonFunctions.ClickButton(driver, obj.getbutton_Historical_Perf());
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
        CommonFunctions.ClickButton(driver, obj.getNextButton());
		Thread.sleep(8000);
		// Account Details page
        statusPass("Entered into Account Details page");
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_AccountDetail_AccountName_Eng"));
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountNumber(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_AccountNumber_Eng"));
		//CommonFunctions.SelectListBox(driver, obj.getAccountDetails_ReviewFrequency(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_ReviewFrequency_Eng"));
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		// Fee Schedule
		statusPass("Entered into FEE Schedule page");
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(5000);
		CommonFunctions.ClickButton(driver, obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		CommonFunctions.SetText(driver, obj.gettext_TeamName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TeamName_Eng"));
		Thread.sleep(3000);
		CommonFunctions.SetText(driver, obj.gettext_IATitle(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IATitle_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAemail(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAEmail_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAphone(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAPhone_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstNameValue_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastNameValue_Eng"));
		statusPassWithScreenshot(driver,"Team Name,Title,Name,Email,Phone Numbe Details are entered in Investment Advisor Profile page",TestCaseDescription);
		statusPassWithScreenshot(driver, "Entered into IA Profile Page", TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPassWithScreenshot(driver, "Entered into Administrative Question page", TestCaseDescription);
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(1000);
		CommonFunctions.ClickButton(driver,obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		// Generate Documents Page
		statusPassWithScreenshot(driver, "Entered into generate Document page", TestCaseDescription);
		CommonFunctions.tableSelect(driver, "Investment Policy Statement",TestCaseDescription);
		statusPass("Investment Policy Statment Download Button Clicked ");
		Thread.sleep(10000);
		// Getting child window details
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		Thread.sleep(1000);
		// Saving PDF to download folder
		CommonFunctions.PDFSave(driver,TestCaseID);
		// Source file Location commented as we are generating from Online
		//String SourceFile = ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SourcefileLocation_Eng");
		String generatedFile=CommonFunctions.FileMoveAndRename(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_FileDownloadLocation_Eng"),"C:\\BrunoAutomationFramework\\PDFfiles\\GeneratedFiles", TestCaseID);
		String SourceFile = "C:\\BrunoAutomationFramework\\SourceFiles\\Architect_IPS_Source.pdf";
		Thread.sleep(2000);
		// Form verification starts here
		statusPass("Architect IPS Form Page Verification-Page-1 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,1,1);
		Thread.sleep(500);
		statusPass("Architect IPS Form Page Verification-Page-2 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,2,2);
		Thread.sleep(500);
		statusPass("Architect IPS Form Page Verification-Page-3 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,3,3);
		Thread.sleep(500);
		statusPass("Architect IPS Form Page Verification-Page-4 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,4,4);
		Thread.sleep(500);
		statusPass("Architect IPS Form Page Verification-5");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,5,5);
		Thread.sleep(500);
		statusPass("Architect IPS Form Page Verification-6 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,6,6);
		Thread.sleep(1000);
		statusPass("Architect IPS Form Page Verification-7");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,7,7);
		Thread.sleep(500);
		statusPass("Architect IPS Form Page Verification-8 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,8,8);
		statusPass("Comparison Done, Please Evaluate Each ScreenShot in Test Report");
		
		endReporting();
		driver.close();
			
	}

}

@Test(dataProvider="DriverSheet")
public void BlueprintIPSEnglish(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Browser, String Language, String Execution, String Status)throws Throwable
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC010")&&Execution.equalsIgnoreCase("Y") &&Functionality.equalsIgnoreCase("BLUEPRINT-IPS-ENGLISH"))
	{

		
		driver=LoginPage.LaunchBrowser(Browser); 
		LoginPage.LaunchURL(driver);
	    startReporting("Blueprint IPS French Form Static content validation");
	   //Login Page
	    LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),Functionality + TestCaseID);
	    CommonFunctions.waitForElementMouse(driver, obj.getMouseHoverIcon(),100,"Slider Menu");
	    Thread.sleep(10000);
	    CommonFunctions.clickAround(driver,obj.getMenuButton(),obj.getMouseHoverIcon(),obj.getClients_menu(),obj.getGoalPlanning(),obj.getiFrame(), obj.getNewInvestmentProposal(),TestCaseID);
	    statusPassWithScreenshot(driver, "Clicked Goal planning Option inside Cilents menu", TestCaseDescription);
	    CommonFunctions.NavigateToNewProposal(driver,obj.getiFrame(),obj.getNewInvestmentProposal(), TestCaseID);
	    Thread.sleep(5000);
	    // Investment Proposal Screen
  		CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageRadiobtn_Eng"));
 		CommonFunctions.SetText(driver,obj.getNewInvestmentName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageName_Eng"));
   		statusPassWithScreenshot(driver, "New Investment Solution Name Entered and Investment Type Selected", TestCaseDescription);
 		//CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());
 		//statusPass("Clicked Save changes Button in New Investment Proposal Page");
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal Page");
		Thread.sleep(5000);
		//Settings Screen
		CommonFunctions.SelectListBox(driver, obj.getSalesCode(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageSalesCode_Eng"));			
		Thread.sleep(500);
		CommonFunctions.SelectListBox(driver, obj.getCurrencyType(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageCurrencyType_Eng"));
		CommonFunctions.SetText(driver, obj.getInvestmentAmt(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageInvestmentAmt_Eng"));
		Thread.sleep(1000);
		statusPassWithScreenshot(driver, "Salescode,Currency,Investment Amount, Investment Advisor Name are entered in Settings page ", TestCaseDescription);
		CommonFunctions.scrollandClickElement(driver, "//button[contains(text(),'Save Changes')]");
		Thread.sleep(1000);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal-Setting  Page");
		Thread.sleep(5000);
		// Clients Screen
		statusPassWithScreenshot(driver,"Add New individual Button is Displayed in Cilents Page",TestCaseDescription);
		// Adding New Individual	
		CommonFunctions.ClickButton(driver, obj.getAddNewIndividualButton());
		statusPass("Clicked Add New individual Button in Clients page");
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ClientsPageCusIDPropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageCusID_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstNamePropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstName_Eng"));
		CommonFunctions.SetTextByName(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureNamePropName_Eng"),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureName_Eng"));
		CommonFunctions.SelectListBox(driver, obj.getGender(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageGender_Eng"));	
		CommonFunctions.SelectListBox(driver, obj.getSalutation(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSalutation_Eng"));
		CommonFunctions.SetTextByClass(driver, obj.getDateofBirth(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageDateofBirth_Eng"));
		
		CommonFunctions.ScrollView(driver, obj.getButtonSaveandClose());
		Thread.sleep(1000);
		CommonFunctions.ClickButton(driver, obj.getButtonSaveandClose());
		CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSelection_Eng"));
		statusPassWithScreenshot(driver, "Customer ID ,Name,Gender,DOB are Entered in Clients page", TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());	
		statusPass("Clicked Next Button in Add New Individual Page");
		Thread.sleep(5000);
		
		// Below code for clicking Add button when we user search option
		//CommonFunctions.scrollandClickElement(driver, "//button[contains(text(),'Add')]");
		//CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSelection_Eng"));
		//CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
		//CommonFunctions.ClickButton(driver,obj.getNextButton());	
		//statusPass("Clicked Next Button in Add New Individual Page");
		
		// Investment Objective page
		statusPassWithScreenshot(driver, "Investment Objective page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_InvestmentObjPage_Eng"));
		Thread.sleep(1000);
		//Time Horizon Page
		
		statusPassWithScreenshot(driver, "Time Horizon Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TimeHorizonPage_Eng"));	
		Thread.sleep(1000);
		// Return Expectation page
		statusPassWithScreenshot(driver, "Return Expectation Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ReturnExpectationPage_Eng"));
		Thread.sleep(1000);
		//Market Fluctuacion Page
		statusPassWithScreenshot(driver, "Market Fluctuacion page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_MarketFluctuacionPage _Eng"));
		Thread.sleep(1000);
		//Inflation Protection Page
		statusPassWithScreenshot(driver, "Inflation Protection page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_InflationProtectionpage_Eng"));				
		Thread.sleep(1000);
		//Income Requirement Page
		statusPassWithScreenshot(driver, "Income Requirement Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_IncomeRequirementPage_Eng"));
		//Settings -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPassWithScreenshot(driver, "Clicked Next Button in Income requirement Page", TestCaseDescription);
		Thread.sleep(8000);
		//Account Page
		//Registered - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccSelect_Eng")); 
		//Account type - List Box
		CommonFunctions.SelectListBox(driver, obj.getselect_AccountPage_AccountType(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccType_Eng"));
		//Foregin Jurisdiction - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ForeginJurisdiction_Eng"));
		statusPassWithScreenshot(driver, "Selected Account Type & Foreign Jurisdiction Values in Account Page", TestCaseDescription);
		//Registered -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPass("Clicked Next button in Account Page");
		// Account Program
		//Account Program - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountProgramType_Eng"));
		statusPassWithScreenshot(driver,"Selected Account Program in Account Program page",TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPass("Clicked Next button in Account Program Page");
		// Models Page
		statusPass("Entered into Models page");
        CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ProgramModelSelect_Eng"));
        statusPassWithScreenshot(driver,"Selected the radio button",TestCaseDescription);
         
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        //CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(8000);
        //Historical Page
        statusPassWithScreenshot(driver,"Historical Performance Page dispalyed",TestCaseDescription);
        CommonFunctions.ClickButton(driver, obj.getbutton_Historical_Perf());
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        //CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());
        statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
        CommonFunctions.ClickButton(driver, obj.getNextButton());
		Thread.sleep(8000);
		// Account Details Page
		statusPass("Entered into Account Details page");
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_AccountDetail_AccountName_Eng"));
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountNumber(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_AccountNumber_Eng"));
		//CommonFunctions.SelectListBox(driver, obj.getAccountDetails_ReviewFrequency(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_ReviewFrequency_Eng"));
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        //CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());
		//Thread.sleep(1000);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		// Fee Schedule Page
		statusPass("Entered into FEE Schedule page");
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        //CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());
		//Thread.sleep(1000);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		CommonFunctions.ClickButton(driver, obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		CommonFunctions.SetText(driver, obj.gettext_TeamName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TeamName_Eng"));
		Thread.sleep(3000);
		CommonFunctions.SetText(driver, obj.gettext_IATitle(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IATitle_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAemail(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAEmail_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAphone(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAPhone_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstNameValue_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastNameValue_Eng"));
		statusPassWithScreenshot(driver,"Team Name,Title,Name,Email,Phone Numbe Details are entered in Investment Advisor Profile page",TestCaseDescription);
		statusPassWithScreenshot(driver, "Entered into IA Profile Page", TestCaseDescription);
		//CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());				
		//Thread.sleep(8000);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPassWithScreenshot(driver, "Entered into Administrative Question page", TestCaseDescription);
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
		//CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());				
		Thread.sleep(8000);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(4000);
		
		CommonFunctions.ClickButton(driver,obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		// Generate Documents Page
		statusPassWithScreenshot(driver, "Entered into generate Document page", TestCaseDescription);
		CommonFunctions.tableSelect(driver, "Investment Policy Statement",TestCaseDescription);
		
		
		statusPass("Blueprint IPS form Download Button Clicked ");
		Thread.sleep(10000);
		
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		
		Thread.sleep(8000);
		// Saving PDF to download folder
		CommonFunctions.PDFSave(driver,TestCaseID);
		
		// Source file Location commented as we are generating from Online
		//String SourceFile = ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SourcefileLocation_Eng");
		
		
		String generatedFile=CommonFunctions.FileMoveAndRename(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_FileDownloadLocation_Eng"),"C:\\BrunoAutomationFramework\\PDFfiles\\GeneratedFiles", TestCaseID);
		
		String SourceFile = "C:\\BrunoAutomationFramework\\SourceFiles\\BluePrint_IPS_Source.pdf";
					
		statusPass("Blueprint IPS Form Verification-Page-1 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,1,1);
		statusPass("Blueprint IPS Form Verification-Page-2 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,2,2);
		Thread.sleep(200);
		statusPass("Blueprint IPS Form Verification-Page-3 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,3,3);
		Thread.sleep(200);
		statusPass("Blueprint IPS Form Verification-Page-4 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,4,4);
		Thread.sleep(200);
		statusPass("Blueprint IPS Form Verification-Page-5");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,5,5);
		Thread.sleep(200);
		statusPass("Blueprint IPS Form Verification-Page-6 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,6,6);
		Thread.sleep(200);
		statusPass("Blueprint IPS Form Verification-Page-7");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,7,7);
		Thread.sleep(200);
		statusPass("Blueprint IPS Form Verification-Page-8 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,8,8);
		Thread.sleep(200);
		
		statusPass("Comparison Done, Please Evaluate Each ScreenShot in Test Report");
		endReporting();
		driver.close();
		
		
	}

}
@Test(dataProvider="DriverSheet")
public void QuadrantIPSFrench(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Browser, String Language, String Execution, String Status)throws Throwable
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC015")&&Execution.equalsIgnoreCase("Y") &&Functionality.equalsIgnoreCase("QUADRANT-IPS-FRENCH"))
	{
		
		driver=LoginPage.LaunchBrowser(Browser); 
		LoginPage.LaunchURL(driver);
	    startReporting("Quadrant IPS French Form Static content validation");
	    LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),Functionality + TestCaseID);
	    CommonFunctions.waitForElementMouse(driver, obj.getMouseHoverIcon(),100,"Slider Menu");
	    Thread.sleep(10000);
	    CommonFunctions.clickAround(driver,obj.getMenuButton(),obj.getMouseHoverIcon(),obj.getClients_menu(),obj.getGoalPlanning(),obj.getiFrame(), obj.getNewInvestmentProposal(),TestCaseID);
	    statusPassWithScreenshot(driver, "Clicked Goal planning Option inside Cilents menu", TestCaseDescription);
	    CommonFunctions.NavigateToNewProposal(driver,obj.getiFrame(),obj.getNewInvestmentProposal(), TestCaseID);
	    // Investment Proposal Screen
	    CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageRadiobtn_Eng"));
 		CommonFunctions.SetText(driver,obj.getNewInvestmentName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageName_Eng"));
   		statusPassWithScreenshot(driver, "New Investment Solution Name Entered and Investment Type Selected", TestCaseDescription);
 		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal Page");
		Thread.sleep(5000);
		//Settings Screen
		CommonFunctions.SelectListBox(driver, obj.getSalesCode(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageSalesCode_Eng"));			
		Thread.sleep(1000);
		//CommonFunctions.SelectListBox(driver, obj.getInvestmentAdvisor(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageIAName_Eng"));	
		CommonFunctions.SelectListBox(driver, obj.getCurrencyType(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageCurrencyType_Eng"));
		CommonFunctions.SetText(driver, obj.getInvestmentAmt(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageInvestmentAmt_Eng"));
		Thread.sleep(1000);
		statusPassWithScreenshot(driver, "Salescode,Currency,Investment Amount, Investment Advisor Name are entered in Settings page ", TestCaseDescription);
		// Scroll Down	 
		CommonFunctions.scrollandClickElement(driver, "//button[contains(text(),'Save Changes')]");
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal-Setting  Page");
		Thread.sleep(8000);
		// Clients Screen
		statusPassWithScreenshot(driver,"Add New individual Button is Displayed in Cilents Page",TestCaseDescription);
		// Client Search functionality starts here
		/*CommonFunctions.ClickButton(driver, obj.getSearchForIndividualButton());
		CommonFunctions.SetText(driver, obj.getSearchIndividual_Textbox(), "John");
		Thread.sleep(5000);
		Robot robot = new  Robot();
	    robot.keyPress(KeyEvent.VK_ENTER);
	    robot.keyRelease(KeyEvent.VK_ENTER);
	    statusPass("Search Text Entered in  Search For Individual text Box");
	    CommonFunctions.ScrollView(driver, "//button[contains(text(),'Close')]");
	    CommonFunctions.tableSelectSearchIndividual(driver, "natarajan", TestCaseDescription);*/
		// Client Search ends here
		// Add new Individual Client
		CommonFunctions.ClickButton(driver, obj.getAddNewIndividualButton());
		statusPass("Clicked Add New individual Button in Clients page");
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ClientsPageCusIDPropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageCusID_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstNamePropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstName_Eng"));
		CommonFunctions.SetTextByName(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureNamePropName_Eng"),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureName_Eng"));
		CommonFunctions.SelectListBox(driver, obj.getGender(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageGender_Eng"));	
		CommonFunctions.SelectListBox(driver, obj.getSalutation(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSalutation_Eng"));
		CommonFunctions.SetTextByClass(driver, obj.getDateofBirth(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageDateofBirth_Eng"));
		CommonFunctions.ScrollView(driver, obj.getButtonSaveandClose());
		CommonFunctions.ClickButton(driver, obj.getButtonSaveandClose());
		CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSelection_Eng"));
		statusPassWithScreenshot(driver, "Customer ID ,Name,Gender,DOB are Entered in Clients page", TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());	
		statusPass("Clicked Next Button in Add New Individual Page");
	    Thread.sleep(8000);
		/*CommonFunctions.scrollandClickElement(driver, "//button[contains(text(),'Add')]");
		CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSelection_Eng"));
		CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
		CommonFunctions.ClickButton(driver,obj.getNextButton());	
		statusPass("Clicked Next Button in Add New Individual Page");*/
		// Investment Objective page
		statusPassWithScreenshot(driver, "Investment Objective page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_InvestmentObjPage_Eng"));
		Thread.sleep(1000);
		//Time Horizon page
		statusPassWithScreenshot(driver, "Time Horizon Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TimeHorizonPage_Eng"));	
		Thread.sleep(1000);
		//Return Expectation page
		statusPassWithScreenshot(driver, "Return Expectation Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ReturnExpectationPage_Eng"));
		Thread.sleep(500);
		//Market Fluctuacion page
		statusPassWithScreenshot(driver, "Market Fluctuacion page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_MarketFluctuacionPage _Eng"));
		Thread.sleep(1000);
		//Inflation Protection page
		statusPassWithScreenshot(driver, "Inflation Protection page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_InflationProtectionpage_Eng"));				
		Thread.sleep(1000);
		//Income Requirement page
		statusPassWithScreenshot(driver, "Income Requirement Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_IncomeRequirementPage_Eng"));
		//Settings -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPassWithScreenshot(driver, "Clicked Next Button in Income requirement Page", TestCaseDescription);
		Thread.sleep(8000);
		//Account Page-Registered - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccSelect_Eng")); 
		//Account type - List Box
		CommonFunctions.SelectListBox(driver, obj.getselect_AccountPage_AccountType(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccType_Eng"));
		//Foregin Jurisdiction - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ForeginJurisdiction_Eng"));
		statusPassWithScreenshot(driver, "Selected Account Type & Foreign Jurisdiction Values in Account Page", TestCaseDescription);
		//Registered -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(5000);
		statusPass("Clicked Next button in Account Page");
		//Account Program - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountProgramType_Eng"));
		statusPassWithScreenshot(driver,"Selected Account Program in Account Program page",TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(5000);
		statusPass("Clicked Next button in Account Program Page");
		// Models Page
		statusPass("Entered into Models page");
        CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ProgramModelSelect_Eng"));
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(8000);
        //Historical Page
        statusPassWithScreenshot(driver,"Historical Performance Page dispalyed",TestCaseDescription);
        CommonFunctions.ClickButton(driver, obj.getbutton_Historical_Perf());
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
        CommonFunctions.ClickButton(driver, obj.getNextButton());
		Thread.sleep(8000);
		// Account Dewtails Page
		statusPass("Entered into Account Details page");
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_AccountDetail_AccountName_Eng"));
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountNumber(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_AccountNumber_Eng"));
		//CommonFunctions.SelectListBox(driver, obj.getAccountDetails_ReviewFrequency(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_ReviewFrequency_Eng"));
		 // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(3000);
		// Fee Schedule
		statusPass("Entered into FEE Schedule page");
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Save Changes')]");
        CommonFunctions.ClickButton(driver, obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		CommonFunctions.SetText(driver, obj.gettext_TeamName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TeamName_Eng"));
		Thread.sleep(3000);
		CommonFunctions.SetText(driver, obj.gettext_IATitle(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IATitle_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAemail(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAEmail_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAphone(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAPhone_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstNameValue_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastNameValue_Eng"));
		statusPassWithScreenshot(driver,"Team Name,Title,Name,Email,Phone Numbe Details are entered in Investment Advisor Profile page",TestCaseDescription);
		statusPassWithScreenshot(driver, "Entered into IA Profile Page", TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(5000);
		statusPassWithScreenshot(driver, "Entered into Administrative Question page", TestCaseDescription);
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(5000);
		// Selecting French Radio Button
		CommonFunctions.ClickButton(driver, obj.getRadio_French_Document());
		Thread.sleep(1000);

		CommonFunctions.ClickButton(driver,obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		// Generate Documents Page
		statusPassWithScreenshot(driver, "Entered into generate Document page", TestCaseDescription);
		CommonFunctions.tableSelect(driver, "�nonc� de politique de placement",TestCaseDescription);
		statusPass("Quadrant IPS form Download Button Clicked ");
		Thread.sleep(20000);
		// Getting child window details
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		Thread.sleep(2000);
		// Saving PDF to download folder
		CommonFunctions.PDFSave(driver,TestCaseID);
		String generatedFile=CommonFunctions.FileMoveAndRename(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_FileDownloadLocation_Eng"),"C:\\BrunoAutomationFramework\\PDFfiles\\GeneratedFiles", TestCaseID);
		String SourceFile = "C:\\BrunoAutomationFramework\\SourceFiles\\Quadrant_IPS_Source_Fre.pdf";
		// PDF file verification
		statusPass("Quadrant IPS French Form Verification-Page-1 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,1,1);
				
		statusPass("Quadrant IPS French Form Verification-Page-2 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,2,2);
		
		statusPass("Quadrant IPS French Form Verification-Page-3 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,3,3);
		
		statusPass("Quadrant IPS French Form Verification-Page-4 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,4,4);
		
		statusPass("Quadrant IPS French Form Verification-Page-5");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,5,5);
		
		statusPass("Quadrant IPS French Form Verification-Page-6 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,6,6);
		
		statusPass("Quadrant IPS French  Verification-Page-7");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,7,7);
		
		statusPass("Quadrant IPS French Form Verification-Page-8");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,8,8);
		
		statusPass("Comparison Done, Please Evaluate Each ScreenShot in Test Report");
		endReporting();
		driver.close();
	
			
		
	}

}

@Test(dataProvider="DriverSheet")
public void ArchitectIPSFrench(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Browser, String Language, String Execution, String Status)throws Throwable
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC013")&&Execution.equalsIgnoreCase("Y") &&Functionality.equalsIgnoreCase("ARCHITECT-IPS-FRENCH"))
	{
		
		driver=LoginPage.LaunchBrowser(Browser); 
		LoginPage.LaunchURL(driver);
		startReporting("Architect IPS French Form Static content validation");
	   
		LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),Functionality + TestCaseID);
	    CommonFunctions.waitForElementMouse(driver, obj.getMouseHoverIcon(),100,"Slider Menu");
	    Thread.sleep(10000);
	    CommonFunctions.clickAround(driver,obj.getMenuButton(),obj.getMouseHoverIcon(),obj.getClients_menu(),obj.getGoalPlanning(),obj.getiFrame(), obj.getNewInvestmentProposal(),TestCaseID);
	    statusPassWithScreenshot(driver, "Clicked Goal planning Option inside Cilents menu", TestCaseDescription);
	    CommonFunctions.NavigateToNewProposal(driver,obj.getiFrame(),obj.getNewInvestmentProposal(), TestCaseID);
  		// INVESTMENT PROPOSAL SCREEN
	    CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageRadiobtn_Eng"));
 		CommonFunctions.SetText(driver,obj.getNewInvestmentName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageName_Eng"));
   		statusPassWithScreenshot(driver, "New Investment Solution Name Entered and Investment Type Selected", TestCaseDescription);
 		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal Page");
		Thread.sleep(5000);
		// SETTINGS SCREEN
		CommonFunctions.SelectListBox(driver, obj.getSalesCode(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageSalesCode_Eng"));			
		Thread.sleep(5000);
		//CommonFunctions.SelectListBox(driver, obj.getInvestmentAdvisor(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageIAName_Eng"));	
		CommonFunctions.SelectListBox(driver, obj.getCurrencyType(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageCurrencyType_Eng"));
		CommonFunctions.SetText(driver, obj.getInvestmentAmt(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageInvestmentAmt_Eng"));
		Thread.sleep(500);
		statusPassWithScreenshot(driver, "Salescode,Currency,Investment Amount, Investment Advisor Name are entered in Settings page ", TestCaseDescription);
		CommonFunctions.scrollandClickElement(driver, "//button[contains(text(),'Save Changes')]");
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal-Setting  Page");
		Thread.sleep(5000);
		//CLIENTS SCREEN
		statusPassWithScreenshot(driver,"Add New individual Button is Displayed in Cilents Page",TestCaseDescription);
		// Search Starts Here
		/*CommonFunctions.ClickButton(driver, obj.getSearchForIndividualButton());
		CommonFunctions.SetText(driver, obj.getSearchIndividual_Textbox(), "John");
		Thread.sleep(5000);
		Robot robot = new  Robot();
	    robot.keyPress(KeyEvent.VK_ENTER);
	    robot.keyRelease(KeyEvent.VK_ENTER);
	    tatusPass("Search Text Entered in  Search For Individual text Box");
	    CommonFunctions.ScrollView(driver, "//button[contains(text(),'Close')]");
	    CommonFunctions.tableSelectSearchIndividual(driver,"Smith", TestCaseDescription);*/
		// Search Ends Here
		
		// Add new Individual
		CommonFunctions.ClickButton(driver, obj.getAddNewIndividualButton());
		statusPass("Clicked Add New individual Button in Clients page");
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ClientsPageCusIDPropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageCusID_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstNamePropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstName_Eng"));
		CommonFunctions.SetTextByName(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureNamePropName_Eng"),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureName_Eng"));
		CommonFunctions.SelectListBox(driver, obj.getGender(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageGender_Eng"));	
		CommonFunctions.SelectListBox(driver, obj.getSalutation(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSalutation_Eng"));
		CommonFunctions.SetTextByClass(driver, obj.getDateofBirth(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageDateofBirth_Eng"));
		CommonFunctions.ScrollView(driver, obj.getButtonSaveandClose());
		CommonFunctions.ClickButton(driver, obj.getButtonSaveandClose());
		CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSelection_Eng"));
		statusPassWithScreenshot(driver, "Customer ID ,Name,Gender,DOB are Entered in Clients page", TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());	
		statusPass("Clicked Next Button in Add New Individual Page");
		Thread.sleep(5000);
		statusPass("Entered into Investment Objective Page");
		//Investment Objective page
		statusPassWithScreenshot(driver, "Investment Objective page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_InvestmentObjPage_Eng"));
		Thread.sleep(1000);
		statusPass("Entered into Time Horizon  Page");
		//Time Horizon page 
		statusPassWithScreenshot(driver, "Time Horizon Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TimeHorizonPage_Eng"));	
		Thread.sleep(1000);
		//System.out.println("********************************Return Expectation page *********************************************");
		statusPassWithScreenshot(driver, "Return Expectation Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ReturnExpectationPage_Eng"));
		Thread.sleep(1000);
		statusPassWithScreenshot(driver, "Market Fluctuacion page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_MarketFluctuacionPage _Eng"));
		Thread.sleep(1000);
		statusPassWithScreenshot(driver, "Inflation Protection page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_InflationProtectionpage_Eng"));				
		Thread.sleep(1000);
		//Income Requirement
		statusPassWithScreenshot(driver, "Income Requirement Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_IncomeRequirementPage_Eng"));
		//Settings -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPassWithScreenshot(driver, "Clicked Next Button in Income requirement Page", TestCaseDescription);
		Thread.sleep(5000);
		//Registered - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccSelect_Eng")); 
		//Account type - List Box
		CommonFunctions.SelectListBox(driver, obj.getselect_AccountPage_AccountType(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccType_Eng"));
		//Foregin Jurisdiction - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ForeginJurisdiction_Eng"));
		statusPassWithScreenshot(driver, "Selected Account Type & Foreign Jurisdiction Values in Account Page", TestCaseDescription);
		//Registered -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPass("Clicked Next button in Account Page");
		//Account Program - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountProgramType_Eng"));
		statusPassWithScreenshot(driver,"Selected Account Program in Account Program page",TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPass("Clicked Next button in Account Program Page");
		//Client-directed Sleeve page
		statusPass("Entered into Client Directed Sleeve page");
        CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ClientDirectedSleeveSelect_Eng"));
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(8000);
        statusPass("Entered into Model Schem page");
        CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ModelSchemSelect_Eng"));
        statusPassWithScreenshot(driver,"Selected the radio button",TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(8000);
        //Portfolio construction Page
        statusPassWithScreenshot(driver,"Entered Into Port Folio Construction Page",TestCaseDescription);
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(8000);
        //Historical Performance Page
        statusPassWithScreenshot(driver,"Historical Performance Page dispalyed",TestCaseDescription);
        CommonFunctions.ClickButton(driver, obj.getbutton_Historical_Perf());
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
        CommonFunctions.ClickButton(driver, obj.getNextButton());
		Thread.sleep(8000);
		// Account Details page
        statusPass("Entered into Account Details page");
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_AccountDetail_AccountName_Eng"));
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountNumber(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_AccountNumber_Eng"));
		//CommonFunctions.SelectListBox(driver, obj.getAccountDetails_ReviewFrequency(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_ReviewFrequency_Eng"));
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		// Fee Schedule
		statusPass("Entered into FEE Schedule page");
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(5000);
		CommonFunctions.ClickButton(driver, obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		CommonFunctions.SetText(driver, obj.gettext_TeamName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TeamName_Eng"));
		Thread.sleep(3000);
		CommonFunctions.SetText(driver, obj.gettext_IATitle(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IATitle_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAemail(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAEmail_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAphone(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAPhone_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstNameValue_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastNameValue_Eng"));
		statusPassWithScreenshot(driver,"Team Name,Title,Name,Email,Phone Numbe Details are entered in Investment Advisor Profile page",TestCaseDescription);
		statusPassWithScreenshot(driver, "Entered into IA Profile Page", TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPassWithScreenshot(driver, "Entered into Administrative Question page", TestCaseDescription);
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(1000);
		// Selecting French Radio Button
		CommonFunctions.ClickButton(driver, obj.getRadio_French_Document());
		Thread.sleep(1000);
		CommonFunctions.ClickButton(driver,obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		// Generate Documents Page
		statusPassWithScreenshot(driver, "Entered into generate Document page", TestCaseDescription);
		CommonFunctions.tableSelect(driver, "�nonc� de politique de placement",TestCaseDescription);
		statusPass("French Investment Policy Statment Download Button Clicked ");
		Thread.sleep(20000);
		// Getting child window details
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		Thread.sleep(1000);
		// Saving PDF to download folder
		CommonFunctions.PDFSave(driver,TestCaseID);
		// Source file Location commented as we are generating from Online
		//String SourceFile = ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SourcefileLocation_Eng");
		String generatedFile=CommonFunctions.FileMoveAndRename(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_FileDownloadLocation_Eng"),"C:\\BrunoAutomationFramework\\PDFfiles\\GeneratedFiles", TestCaseID);
		String SourceFile = "C:\\BrunoAutomationFramework\\SourceFiles\\Architect_IPS_Source_Fre.pdf";
		Thread.sleep(2000);
		// Form verification starts here
		statusPass("Architect IPS French Form Page Verification-Page-1 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,1,1);
		Thread.sleep(500);
		statusPass("Architect IPS French Form Page Verification-Page-2 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,2,2);
		Thread.sleep(500);
		statusPass("Architect IPS French Form Page Verification-Page-3 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,3,3);
		Thread.sleep(500);
		statusPass("Architect IPS French Form Page Verification-Page-4 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,4,4);
		Thread.sleep(500);
		statusPass("Architect IPS French Form Page Verification-5");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,5,5);
		Thread.sleep(500);
		statusPass("Architect IPS French Form Page Verification-6 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,6,6);
		Thread.sleep(500);
		statusPass("Architect IPS French Form Page Verification-7");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,7,7);
		Thread.sleep(500);
		statusPass("Architect IPS French Form Page Verification-8 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,8,8);
		statusPass("Comparison Done, Please Evaluate Each ScreenShot in Test Report");
		
		endReporting();
		driver.close();
			
	}

}
@Test(dataProvider="DriverSheet")
public void BlueprintIPSFrench(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Browser, String Language, String Execution, String Status)throws Throwable
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC014")&&Execution.equalsIgnoreCase("Y") &&Functionality.equalsIgnoreCase("BLUEPRINT-IPS-FRENCH"))
	{

		
		driver=LoginPage.LaunchBrowser(Browser); 
		LoginPage.LaunchURL(driver);
	    startReporting("Blueprint IPS French Form Static content validation");
	   //Login Page
	    LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),Functionality + TestCaseID);
	    CommonFunctions.waitForElementMouse(driver, obj.getMouseHoverIcon(),100,"Slider Menu");
	    Thread.sleep(10000);
	    CommonFunctions.clickAround(driver,obj.getMenuButton(),obj.getMouseHoverIcon(),obj.getClients_menu(),obj.getGoalPlanning(),obj.getiFrame(), obj.getNewInvestmentProposal(),TestCaseID);
	    statusPassWithScreenshot(driver, "Clicked Goal planning Option inside Cilents menu", TestCaseDescription);
	    CommonFunctions.NavigateToNewProposal(driver,obj.getiFrame(),obj.getNewInvestmentProposal(), TestCaseID);
	    Thread.sleep(5000);
	    // Investment Proposal Screen
  		CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageRadiobtn_Eng"));
 		CommonFunctions.SetText(driver,obj.getNewInvestmentName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageName_Eng"));
   		statusPassWithScreenshot(driver, "New Investment Solution Name Entered and Investment Type Selected", TestCaseDescription);
 		//CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());
 		//statusPass("Clicked Save changes Button in New Investment Proposal Page");
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal Page");
		Thread.sleep(5000);
		//Settings Screen
		CommonFunctions.SelectListBox(driver, obj.getSalesCode(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageSalesCode_Eng"));			
		Thread.sleep(500);
		CommonFunctions.SelectListBox(driver, obj.getCurrencyType(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageCurrencyType_Eng"));
		CommonFunctions.SetText(driver, obj.getInvestmentAmt(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageInvestmentAmt_Eng"));
		Thread.sleep(1000);
		statusPassWithScreenshot(driver, "Salescode,Currency,Investment Amount, Investment Advisor Name are entered in Settings page ", TestCaseDescription);
		CommonFunctions.scrollandClickElement(driver, "//button[contains(text(),'Save Changes')]");
		Thread.sleep(1000);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal-Setting  Page");
		Thread.sleep(5000);
		// Clients Screen
		statusPassWithScreenshot(driver,"Add New individual Button is Displayed in Cilents Page",TestCaseDescription);
		// Adding New Individual	
		CommonFunctions.ClickButton(driver, obj.getAddNewIndividualButton());
		statusPass("Clicked Add New individual Button in Clients page");
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ClientsPageCusIDPropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageCusID_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstNamePropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstName_Eng"));
		CommonFunctions.SetTextByName(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureNamePropName_Eng"),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureName_Eng"));
		CommonFunctions.SelectListBox(driver, obj.getGender(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageGender_Eng"));	
		CommonFunctions.SelectListBox(driver, obj.getSalutation(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSalutation_Eng"));
		CommonFunctions.SetTextByClass(driver, obj.getDateofBirth(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageDateofBirth_Eng"));
		
		CommonFunctions.ScrollView(driver, obj.getButtonSaveandClose());
		Thread.sleep(1000);
		CommonFunctions.ClickButton(driver, obj.getButtonSaveandClose());
		CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSelection_Eng"));
		statusPassWithScreenshot(driver, "Customer ID ,Name,Gender,DOB are Entered in Clients page", TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());	
		statusPass("Clicked Next Button in Add New Individual Page");
		Thread.sleep(5000);
		
		// Below code for clicking Add button when we user search option
		//CommonFunctions.scrollandClickElement(driver, "//button[contains(text(),'Add')]");
		//CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSelection_Eng"));
		//CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
		//CommonFunctions.ClickButton(driver,obj.getNextButton());	
		//statusPass("Clicked Next Button in Add New Individual Page");
		
		// Investment Objective page
		statusPassWithScreenshot(driver, "Investment Objective page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_InvestmentObjPage_Eng"));
		Thread.sleep(1000);
		//Time Horizon Page
		
		statusPassWithScreenshot(driver, "Time Horizon Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TimeHorizonPage_Eng"));	
		Thread.sleep(1000);
		// Return Expectation page
		statusPassWithScreenshot(driver, "Return Expectation Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ReturnExpectationPage_Eng"));
		Thread.sleep(1000);
		//Market Fluctuacion Page
		statusPassWithScreenshot(driver, "Market Fluctuacion page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_MarketFluctuacionPage _Eng"));
		Thread.sleep(1000);
		//Inflation Protection Page
		statusPassWithScreenshot(driver, "Inflation Protection page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_InflationProtectionpage_Eng"));				
		Thread.sleep(1000);
		//Income Requirement Page
		statusPassWithScreenshot(driver, "Income Requirement Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_IncomeRequirementPage_Eng"));
		//Settings -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPassWithScreenshot(driver, "Clicked Next Button in Income requirement Page", TestCaseDescription);
		Thread.sleep(8000);
		//Account Page
		//Registered - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccSelect_Eng")); 
		//Account type - List Box
		CommonFunctions.SelectListBox(driver, obj.getselect_AccountPage_AccountType(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccType_Eng"));
		//Foregin Jurisdiction - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ForeginJurisdiction_Eng"));
		statusPassWithScreenshot(driver, "Selected Account Type & Foreign Jurisdiction Values in Account Page", TestCaseDescription);
		//Registered -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPass("Clicked Next button in Account Page");
		// Account Program
		//Account Program - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountProgramType_Eng"));
		statusPassWithScreenshot(driver,"Selected Account Program in Account Program page",TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPass("Clicked Next button in Account Program Page");
		// Models Page
		statusPass("Entered into Models page");
        CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ProgramModelSelect_Eng"));
        statusPassWithScreenshot(driver,"Selected the radio button",TestCaseDescription);
         
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        //CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(8000);
        //Historical Page
        statusPassWithScreenshot(driver,"Historical Performance Page dispalyed",TestCaseDescription);
        CommonFunctions.ClickButton(driver, obj.getbutton_Historical_Perf());
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        //CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());
        statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
        CommonFunctions.ClickButton(driver, obj.getNextButton());
		Thread.sleep(8000);
		// Account Details Page
		statusPass("Entered into Account Details page");
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_AccountDetail_AccountName_Eng"));
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountNumber(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_AccountNumber_Eng"));
		//CommonFunctions.SelectListBox(driver, obj.getAccountDetails_ReviewFrequency(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_ReviewFrequency_Eng"));
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        //CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());
		//Thread.sleep(1000);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		// Fee Schedule Page
		statusPass("Entered into FEE Schedule page");
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        //CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());
		//Thread.sleep(1000);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		CommonFunctions.ClickButton(driver, obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		CommonFunctions.SetText(driver, obj.gettext_TeamName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TeamName_Eng"));
		Thread.sleep(3000);
		CommonFunctions.SetText(driver, obj.gettext_IATitle(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IATitle_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAemail(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAEmail_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAphone(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAPhone_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstNameValue_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastNameValue_Eng"));
		statusPassWithScreenshot(driver,"Team Name,Title,Name,Email,Phone Numbe Details are entered in Investment Advisor Profile page",TestCaseDescription);
		statusPassWithScreenshot(driver, "Entered into IA Profile Page", TestCaseDescription);
		//CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());				
		//Thread.sleep(8000);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPassWithScreenshot(driver, "Entered into Administrative Question page", TestCaseDescription);
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
		//CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());				
		Thread.sleep(8000);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(4000);
		// Selecting French Radio Button
		CommonFunctions.ClickButton(driver, obj.getRadio_French_Document());
		Thread.sleep(1000);
		CommonFunctions.ClickButton(driver,obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		// Generate Documents Page
		statusPassWithScreenshot(driver, "Entered into generate Document page", TestCaseDescription);
		CommonFunctions.tableSelect(driver, "�nonc� de politique de placement",TestCaseDescription);
		
		
		statusPass("Blueprint IPS French form Download Button Clicked ");
		Thread.sleep(10000);
		
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		
		Thread.sleep(8000);
		// Saving PDF to download folder
		CommonFunctions.PDFSave(driver,TestCaseID);
		
		// Source file Location commented as we are generating from Online
		//String SourceFile = ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SourcefileLocation_Eng");
		
		
		String generatedFile=CommonFunctions.FileMoveAndRename(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_FileDownloadLocation_Eng"),"C:\\BrunoAutomationFramework\\PDFfiles\\GeneratedFiles", TestCaseID);
		
		String SourceFile = "C:\\BrunoAutomationFramework\\SourceFiles\\BluePrint_IPS_Source_Fre.pdf";
					
		statusPass("Blueprint IPS French Form Verification-Page-1 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,1,1);
		statusPass("Blueprint IPS French Form Verification-Page-2 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,2,2);
		Thread.sleep(200);
		statusPass("Blueprint IPS French Form Verification-Page-3 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,3,3);
		Thread.sleep(200);
		statusPass("Blueprint IPS French Form Verification-Page-4 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,4,4);
		Thread.sleep(200);
		statusPass("Blueprint IPS French Form Verification-Page-5");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,5,5);
		Thread.sleep(200);
		statusPass("Blueprint IPS French Form Verification-Page-6 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,6,6);
		Thread.sleep(200);
		statusPass("Blueprint IPS French Form Verification-Page-7");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,7,7);
		Thread.sleep(200);
		statusPass("Blueprint IPS French Form Verification-Page-8 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,8,8);
		Thread.sleep(200);
		
		statusPass("Comparison Done, Please Evaluate Each ScreenShot in Test Report");
		endReporting();
		driver.close();
		
		
	}

}
@Test(dataProvider="DriverSheet")
public void QuadrantIPSEnglish(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Browser, String Language, String Execution, String Status)throws Throwable
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC011")&&Execution.equalsIgnoreCase("Y") &&Functionality.equalsIgnoreCase("QUADRANT-IPS-ENGLISH"))
	{
		
		driver=LoginPage.LaunchBrowser(Browser); 
		LoginPage.LaunchURL(driver);
	    startReporting("Quadrant IPS Form Static content validation");
	    LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),Functionality + TestCaseID);
	    CommonFunctions.waitForElementMouse(driver, obj.getMouseHoverIcon(),100,"Slider Menu");
	    Thread.sleep(10000);
	    CommonFunctions.clickAround(driver,obj.getMenuButton(),obj.getMouseHoverIcon(),obj.getClients_menu(),obj.getGoalPlanning(),obj.getiFrame(), obj.getNewInvestmentProposal(),TestCaseID);
	    statusPassWithScreenshot(driver, "Clicked Goal planning Option inside Cilents menu", TestCaseDescription);
	    CommonFunctions.NavigateToNewProposal(driver,obj.getiFrame(),obj.getNewInvestmentProposal(), TestCaseID);
	    // Investment Proposal Screen
	    CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageRadiobtn_Eng"));
 		CommonFunctions.SetText(driver,obj.getNewInvestmentName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageName_Eng"));
   		statusPassWithScreenshot(driver, "New Investment Solution Name Entered and Investment Type Selected", TestCaseDescription);
 		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal Page");
		Thread.sleep(5000);
		//Settings Screen
		CommonFunctions.SelectListBox(driver, obj.getSalesCode(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageSalesCode_Eng"));			
		Thread.sleep(1000);
		//CommonFunctions.SelectListBox(driver, obj.getInvestmentAdvisor(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageIAName_Eng"));	
		CommonFunctions.SelectListBox(driver, obj.getCurrencyType(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageCurrencyType_Eng"));
		CommonFunctions.SetText(driver, obj.getInvestmentAmt(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageInvestmentAmt_Eng"));
		Thread.sleep(1000);
		statusPassWithScreenshot(driver, "Salescode,Currency,Investment Amount, Investment Advisor Name are entered in Settings page ", TestCaseDescription);
		// Scroll Down	 
		CommonFunctions.scrollandClickElement(driver, "//button[contains(text(),'Save Changes')]");
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal-Setting  Page");
		Thread.sleep(8000);
		// Clients Screen
		statusPassWithScreenshot(driver,"Add New individual Button is Displayed in Cilents Page",TestCaseDescription);
		// Client Search functionality starts here
		/*CommonFunctions.ClickButton(driver, obj.getSearchForIndividualButton());
		CommonFunctions.SetText(driver, obj.getSearchIndividual_Textbox(), "John");
		Thread.sleep(5000);
		Robot robot = new  Robot();
	    robot.keyPress(KeyEvent.VK_ENTER);
	    robot.keyRelease(KeyEvent.VK_ENTER);
	    statusPass("Search Text Entered in  Search For Individual text Box");
	    CommonFunctions.ScrollView(driver, "//button[contains(text(),'Close')]");
	    CommonFunctions.tableSelectSearchIndividual(driver, "natarajan", TestCaseDescription);*/
		// Client Search ends here
		// Add new Individual Client
		CommonFunctions.ClickButton(driver, obj.getAddNewIndividualButton());
		statusPass("Clicked Add New individual Button in Clients page");
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ClientsPageCusIDPropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageCusID_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstNamePropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstName_Eng"));
		CommonFunctions.SetTextByName(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureNamePropName_Eng"),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureName_Eng"));
		CommonFunctions.SelectListBox(driver, obj.getGender(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageGender_Eng"));	
		CommonFunctions.SelectListBox(driver, obj.getSalutation(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSalutation_Eng"));
		CommonFunctions.SetTextByClass(driver, obj.getDateofBirth(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageDateofBirth_Eng"));
		CommonFunctions.ScrollView(driver, obj.getButtonSaveandClose());
		CommonFunctions.ClickButton(driver, obj.getButtonSaveandClose());
		CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSelection_Eng"));
		statusPassWithScreenshot(driver, "Customer ID ,Name,Gender,DOB are Entered in Clients page", TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());	
		statusPass("Clicked Next Button in Add New Individual Page");
	    Thread.sleep(8000);
		/*CommonFunctions.scrollandClickElement(driver, "//button[contains(text(),'Add')]");
		CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSelection_Eng"));
		CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
		CommonFunctions.ClickButton(driver,obj.getNextButton());	
		statusPass("Clicked Next Button in Add New Individual Page");*/
		// Investment Objective page
		statusPassWithScreenshot(driver, "Investment Objective page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_InvestmentObjPage_Eng"));
		Thread.sleep(1000);
		//Time Horizon page
		statusPassWithScreenshot(driver, "Time Horizon Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TimeHorizonPage_Eng"));	
		Thread.sleep(1000);
		//Return Expectation page
		statusPassWithScreenshot(driver, "Return Expectation Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ReturnExpectationPage_Eng"));
		Thread.sleep(500);
		//Market Fluctuacion page
		statusPassWithScreenshot(driver, "Market Fluctuacion page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_MarketFluctuacionPage _Eng"));
		Thread.sleep(1000);
		//Inflation Protection page
		statusPassWithScreenshot(driver, "Inflation Protection page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_InflationProtectionpage_Eng"));				
		Thread.sleep(1000);
		//Income Requirement page
		statusPassWithScreenshot(driver, "Income Requirement Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_IncomeRequirementPage_Eng"));
		//Settings -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPassWithScreenshot(driver, "Clicked Next Button in Income requirement Page", TestCaseDescription);
		Thread.sleep(8000);
		//Account Page-Registered - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccSelect_Eng")); 
		//Account type - List Box
		CommonFunctions.SelectListBox(driver, obj.getselect_AccountPage_AccountType(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccType_Eng"));
		//Foregin Jurisdiction - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ForeginJurisdiction_Eng"));
		statusPassWithScreenshot(driver, "Selected Account Type & Foreign Jurisdiction Values in Account Page", TestCaseDescription);
		//Registered -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(5000);
		statusPass("Clicked Next button in Account Page");
		//Account Program - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountProgramType_Eng"));
		statusPassWithScreenshot(driver,"Selected Account Program in Account Program page",TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(5000);
		statusPass("Clicked Next button in Account Program Page");
		// Models Page
		statusPass("Entered into Models page");
        CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ProgramModelSelect_Eng"));
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(8000);
        //Historical Page
        statusPassWithScreenshot(driver,"Historical Performance Page dispalyed",TestCaseDescription);
        CommonFunctions.ClickButton(driver, obj.getbutton_Historical_Perf());
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
        CommonFunctions.ClickButton(driver, obj.getNextButton());
		Thread.sleep(8000);
		// Account Dewtails Page
		statusPass("Entered into Account Details page");
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_AccountDetail_AccountName_Eng"));
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountNumber(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_AccountNumber_Eng"));
		//CommonFunctions.SelectListBox(driver, obj.getAccountDetails_ReviewFrequency(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_ReviewFrequency_Eng"));
		 // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(3000);
		// Fee Schedule
		statusPass("Entered into FEE Schedule page");
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Save Changes')]");
        CommonFunctions.ClickButton(driver, obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		CommonFunctions.SetText(driver, obj.gettext_TeamName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TeamName_Eng"));
		Thread.sleep(3000);
		CommonFunctions.SetText(driver, obj.gettext_IATitle(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IATitle_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAemail(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAEmail_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAphone(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAPhone_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstNameValue_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastNameValue_Eng"));
		statusPassWithScreenshot(driver,"Team Name,Title,Name,Email,Phone Numbe Details are entered in Investment Advisor Profile page",TestCaseDescription);
		statusPassWithScreenshot(driver, "Entered into IA Profile Page", TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(5000);
		statusPassWithScreenshot(driver, "Entered into Administrative Question page", TestCaseDescription);
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(5000);
		CommonFunctions.ClickButton(driver,obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		// Generate Documents Page
		statusPassWithScreenshot(driver, "Entered into generate Document page", TestCaseDescription);
		CommonFunctions.tableSelect(driver, "Investment Policy Statement",TestCaseDescription);
		statusPass("Quadrant IPS form Download Button Clicked ");
		Thread.sleep(20000);
		// Getting child window details
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		Thread.sleep(2000);
		// Saving PDF to download folder
		CommonFunctions.PDFSave(driver,TestCaseID);
		String generatedFile=CommonFunctions.FileMoveAndRename(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_FileDownloadLocation_Eng"),"C:\\BrunoAutomationFramework\\PDFfiles\\GeneratedFiles", TestCaseID);
		String SourceFile = "C:\\BrunoAutomationFramework\\SourceFiles\\Quadrant_IPS_Source.pdf";
		// PDF file verification
		statusPass("Quadrant IPS Form Verification-Page-1 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,1,1);
				
		statusPass("Quadrant IPS Form Verification-Page-2 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,2,2);
		
		statusPass("Quadrant IPS Form Verification-Page-3 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,3,3);
		
		statusPass("Quadrant IPS Form Verification-Page-4 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,4,4);
		
		statusPass("Quadrant IPS Form Verification-Page-5");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,5,5);
		
		statusPass("Quadrant IPS Form Verification-Page-6 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,6,6);
		
		statusPass("Quadrant IPS Form Verification-Page-7");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,7,7);
		
		statusPass("Quadrant IPS Form Verification-Page-8");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,8,8);
		
		statusPass("Comparison Done, Please Evaluate Each ScreenShot in Test Report");
		endReporting();
		driver.close();
	
			
		
	}

}

@Test(dataProvider="DriverSheet")
public void BlueprintMPSEnglish(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Browser, String Language, String Execution, String Status)throws Throwable
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC020")&&Execution.equalsIgnoreCase("Y") &&Functionality.equalsIgnoreCase("BLUEPRINT-MPS-ENGLISH"))
	{
		
		driver=LoginPage.LaunchBrowser(Browser); 
		LoginPage.LaunchURL(driver);
	    startReporting("Blueprint Program MPS form Static content validation");
	   //Login Page
	    LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),Functionality + TestCaseID);
	    CommonFunctions.waitForElementMouse(driver, obj.getMouseHoverIcon(),100,"Slider Menu");
	    Thread.sleep(10000);
	    CommonFunctions.clickAround(driver,obj.getMenuButton(),obj.getMouseHoverIcon(),obj.getClients_menu(),obj.getGoalPlanning(),obj.getiFrame(), obj.getNewInvestmentProposal(),TestCaseID);
	    statusPassWithScreenshot(driver, "Clicked Goal planning Option inside Cilents menu", TestCaseDescription);
	    CommonFunctions.NavigateToNewProposal(driver,obj.getiFrame(),obj.getNewInvestmentProposal(), TestCaseID);
	    Thread.sleep(5000);
	    // Investment Proposal Screen
  		CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageRadiobtn_Eng"));
 		CommonFunctions.SetText(driver,obj.getNewInvestmentName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageName_Eng"));
   		statusPassWithScreenshot(driver, "New Investment Solution Name Entered and Investment Type Selected", TestCaseDescription);
 		//CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());
 		//statusPass("Clicked Save changes Button in New Investment Proposal Page");
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal Page");
		Thread.sleep(5000);
		//Settings Screen
		CommonFunctions.SelectListBox(driver, obj.getSalesCode(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageSalesCode_Eng"));			
		Thread.sleep(500);
		CommonFunctions.SelectListBox(driver, obj.getCurrencyType(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageCurrencyType_Eng"));
		CommonFunctions.SetText(driver, obj.getInvestmentAmt(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageInvestmentAmt_Eng"));
		Thread.sleep(1000);
		statusPassWithScreenshot(driver, "Salescode,Currency,Investment Amount, Investment Advisor Name are entered in Settings page ", TestCaseDescription);
		CommonFunctions.scrollandClickElement(driver, "//button[contains(text(),'Save Changes')]");
		Thread.sleep(1000);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal-Setting  Page");
		Thread.sleep(5000);
		// Clients Screen
		statusPassWithScreenshot(driver,"Add New individual Button is Displayed in Cilents Page",TestCaseDescription);
		// Adding New Individual	
		CommonFunctions.ClickButton(driver, obj.getAddNewIndividualButton());
		statusPass("Clicked Add New individual Button in Clients page");
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ClientsPageCusIDPropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageCusID_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstNamePropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstName_Eng"));
		CommonFunctions.SetTextByName(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureNamePropName_Eng"),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureName_Eng"));
		CommonFunctions.SelectListBox(driver, obj.getGender(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageGender_Eng"));	
		CommonFunctions.SelectListBox(driver, obj.getSalutation(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSalutation_Eng"));
		CommonFunctions.SetTextByClass(driver, obj.getDateofBirth(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageDateofBirth_Eng"));
		
		CommonFunctions.ScrollView(driver, obj.getButtonSaveandClose());
		Thread.sleep(1000);
		CommonFunctions.ClickButton(driver, obj.getButtonSaveandClose());
		CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSelection_Eng"));
		statusPassWithScreenshot(driver, "Customer ID ,Name,Gender,DOB are Entered in Clients page", TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());	
		statusPass("Clicked Next Button in Add New Individual Page");
		Thread.sleep(5000);
		
		// Below code for clicking Add button when we user search option
		//CommonFunctions.scrollandClickElement(driver, "//button[contains(text(),'Add')]");
		//CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSelection_Eng"));
		//CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
		//CommonFunctions.ClickButton(driver,obj.getNextButton());	
		//statusPass("Clicked Next Button in Add New Individual Page");
		
		// Investment Objective page
		statusPassWithScreenshot(driver, "Investment Objective page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_InvestmentObjPage_Eng"));
		Thread.sleep(1000);
		//Time Horizon Page
		
		statusPassWithScreenshot(driver, "Time Horizon Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TimeHorizonPage_Eng"));	
		Thread.sleep(1000);
		// Return Expectation page
		statusPassWithScreenshot(driver, "Return Expectation Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ReturnExpectationPage_Eng"));
		Thread.sleep(1000);
		//Market Fluctuacion Page
		statusPassWithScreenshot(driver, "Market Fluctuacion page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_MarketFluctuacionPage _Eng"));
		Thread.sleep(1000);
		//Inflation Protection Page
		statusPassWithScreenshot(driver, "Inflation Protection page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_InflationProtectionpage_Eng"));				
		Thread.sleep(1000);
		//Income Requirement Page
		statusPassWithScreenshot(driver, "Income Requirement Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_IncomeRequirementPage_Eng"));
		//Settings -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPassWithScreenshot(driver, "Clicked Next Button in Income requirement Page", TestCaseDescription);
		Thread.sleep(8000);
		//Account Page
		//Registered - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccSelect_Eng")); 
		//Account type - List Box
		CommonFunctions.SelectListBox(driver, obj.getselect_AccountPage_AccountType(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccType_Eng"));
		//Foregin Jurisdiction - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ForeginJurisdiction_Eng"));
		statusPassWithScreenshot(driver, "Selected Account Type & Foreign Jurisdiction Values in Account Page", TestCaseDescription);
		//Registered -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPass("Clicked Next button in Account Page");
		// Account Program
		//Account Program - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountProgramType_Eng"));
		statusPassWithScreenshot(driver,"Selected Account Program in Account Program page",TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPass("Clicked Next button in Account Program Page");
		// Models Page
		statusPass("Entered into Models page");
        CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ProgramModelSelect_Eng"));
        statusPassWithScreenshot(driver,"Selected the radio button",TestCaseDescription);
         
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        //CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(8000);
        //Historical Page
        statusPassWithScreenshot(driver,"Historical Performance Page dispalyed",TestCaseDescription);
        CommonFunctions.ClickButton(driver, obj.getbutton_Historical_Perf());
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        //CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());
        statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
        CommonFunctions.ClickButton(driver, obj.getNextButton());
		Thread.sleep(8000);
		// Account Details Page
		statusPass("Entered into Account Details page");
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_AccountDetail_AccountName_Eng"));
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountNumber(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_AccountNumber_Eng"));
		//CommonFunctions.SelectListBox(driver, obj.getAccountDetails_ReviewFrequency(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_ReviewFrequency_Eng"));
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        //CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());
		//Thread.sleep(1000);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		// Fee Schedule Page
		statusPass("Entered into FEE Schedule page");
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        //CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());
		//Thread.sleep(1000);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		CommonFunctions.ClickButton(driver, obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		CommonFunctions.SetText(driver, obj.gettext_TeamName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TeamName_Eng"));
		Thread.sleep(3000);
		CommonFunctions.SetText(driver, obj.gettext_IATitle(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IATitle_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAemail(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAEmail_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAphone(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAPhone_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstNameValue_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastNameValue_Eng"));
		statusPassWithScreenshot(driver,"Team Name,Title,Name,Email,Phone Numbe Details are entered in Investment Advisor Profile page",TestCaseDescription);
		statusPassWithScreenshot(driver, "Entered into IA Profile Page", TestCaseDescription);
		//CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());				
		//Thread.sleep(8000);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPassWithScreenshot(driver, "Entered into Administrative Question page", TestCaseDescription);
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
		//CommonFunctions.ClickButton(driver,obj.getButtonSaveChanges());				
		Thread.sleep(8000);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(4000);
		CommonFunctions.ClickButton(driver,obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		// Generate Documents Page
		statusPassWithScreenshot(driver, "Entered into generate Document page", TestCaseDescription);
		CommonFunctions.tableSelect(driver, "MPS Instruction Sheet",TestCaseDescription);
		
		
		statusPass("Blueprint MPS Forms Download Button Clicked ");
		Thread.sleep(10000);
		
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		
		Thread.sleep(8000);
		// Saving PDF to download folder
		CommonFunctions.PDFSave(driver,TestCaseID);
		
		// Source file Location commented as we are generating from Online
		//String SourceFile = ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SourcefileLocation_Eng");
		
		
		String generatedFile=CommonFunctions.FileMoveAndRename(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_FileDownloadLocation_Eng"),"C:\\BrunoAutomationFramework\\PDFfiles\\GeneratedFiles", TestCaseID);
		
		String SourceFile = "C:\\BrunoAutomationFramework\\SourceFiles\\BluePrint_MPS_Source.pdf";
					
		statusPass("Blueprint MPS form Verification-Page-1 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,1,1);
		
		
		statusPass("Blueprint MPS form Verification-Page-2 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,2,2);
		Thread.sleep(200);
		statusPass("Blueprint MPS form Verification-Page-3 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,3,3);
		Thread.sleep(200);
		statusPass("Blueprint MPS form Verification-Page-4 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,4,4);
		statusPass("Comparison Done, Please Evaluate Each ScreenShot in Test Report");
		endReporting();
		driver.close();
		
		
	}

}

@Test(dataProvider="DriverSheet")
public void ArchitectMPSEnglish(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Browser, String Language, String Execution, String Status)throws Throwable
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC017")&&Execution.equalsIgnoreCase("Y") &&Functionality.equalsIgnoreCase("ARCHITECT-MPS-ENGLISH"))
	{
		
		driver=LoginPage.LaunchBrowser(Browser); 
		LoginPage.LaunchURL(driver);
		startReporting("Architect Program MPS Form Static content validation");
	   
		LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),Functionality + TestCaseID);
	    CommonFunctions.waitForElementMouse(driver, obj.getMouseHoverIcon(),100,"Slider Menu");
	    Thread.sleep(10000);
	    CommonFunctions.clickAround(driver,obj.getMenuButton(),obj.getMouseHoverIcon(),obj.getClients_menu(),obj.getGoalPlanning(),obj.getiFrame(), obj.getNewInvestmentProposal(),TestCaseID);
	    statusPassWithScreenshot(driver, "Clicked Goal planning Option inside Cilents menu", TestCaseDescription);
	    CommonFunctions.NavigateToNewProposal(driver,obj.getiFrame(),obj.getNewInvestmentProposal(), TestCaseID);
  		// INVESTMENT PROPOSAL SCREEN
	    CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageRadiobtn_Eng"));
 		CommonFunctions.SetText(driver,obj.getNewInvestmentName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageName_Eng"));
   		statusPassWithScreenshot(driver, "New Investment Solution Name Entered and Investment Type Selected", TestCaseDescription);
 		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal Page");
		Thread.sleep(5000);
		// SETTINGS SCREEN
		CommonFunctions.SelectListBox(driver, obj.getSalesCode(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageSalesCode_Eng"));			
		Thread.sleep(5000);
		//CommonFunctions.SelectListBox(driver, obj.getInvestmentAdvisor(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageIAName_Eng"));	
		CommonFunctions.SelectListBox(driver, obj.getCurrencyType(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageCurrencyType_Eng"));
		CommonFunctions.SetText(driver, obj.getInvestmentAmt(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageInvestmentAmt_Eng"));
		Thread.sleep(500);
		statusPassWithScreenshot(driver, "Salescode,Currency,Investment Amount, Investment Advisor Name are entered in Settings page ", TestCaseDescription);
		CommonFunctions.scrollandClickElement(driver, "//button[contains(text(),'Save Changes')]");
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal-Setting  Page");
		Thread.sleep(5000);
		//CLIENTS SCREEN
		statusPassWithScreenshot(driver,"Add New individual Button is Displayed in Cilents Page",TestCaseDescription);
		// Search Starts Here
		/*CommonFunctions.ClickButton(driver, obj.getSearchForIndividualButton());
		CommonFunctions.SetText(driver, obj.getSearchIndividual_Textbox(), "John");
		Thread.sleep(5000);
		Robot robot = new  Robot();
	    robot.keyPress(KeyEvent.VK_ENTER);
	    robot.keyRelease(KeyEvent.VK_ENTER);
	    tatusPass("Search Text Entered in  Search For Individual text Box");
	    CommonFunctions.ScrollView(driver, "//button[contains(text(),'Close')]");
	    CommonFunctions.tableSelectSearchIndividual(driver,"Smith", TestCaseDescription);*/
		// Search Ends Here
		
		// Add new Individual
		CommonFunctions.ClickButton(driver, obj.getAddNewIndividualButton());
		statusPass("Clicked Add New individual Button in Clients page");
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ClientsPageCusIDPropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageCusID_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstNamePropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstName_Eng"));
		CommonFunctions.SetTextByName(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureNamePropName_Eng"),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureName_Eng"));
		CommonFunctions.SelectListBox(driver, obj.getGender(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageGender_Eng"));	
		CommonFunctions.SelectListBox(driver, obj.getSalutation(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSalutation_Eng"));
		CommonFunctions.SetTextByClass(driver, obj.getDateofBirth(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageDateofBirth_Eng"));
		CommonFunctions.ScrollView(driver, obj.getButtonSaveandClose());
		CommonFunctions.ClickButton(driver, obj.getButtonSaveandClose());
		CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSelection_Eng"));
		statusPassWithScreenshot(driver, "Customer ID ,Name,Gender,DOB are Entered in Clients page", TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());	
		statusPass("Clicked Next Button in Add New Individual Page");
		Thread.sleep(5000);
		statusPass("Entered into Investment Objective Page");
		//Investment Objective page
		statusPassWithScreenshot(driver, "Investment Objective page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_InvestmentObjPage_Eng"));
		Thread.sleep(1000);
		statusPass("Entered into Time Horizon  Page");
		//Time Horizon page 
		statusPassWithScreenshot(driver, "Time Horizon Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TimeHorizonPage_Eng"));	
		Thread.sleep(1000);
		//System.out.println("********************************Return Expectation page *********************************************");
		statusPassWithScreenshot(driver, "Return Expectation Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ReturnExpectationPage_Eng"));
		Thread.sleep(1000);
		statusPassWithScreenshot(driver, "Market Fluctuacion page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_MarketFluctuacionPage _Eng"));
		Thread.sleep(1000);
		statusPassWithScreenshot(driver, "Inflation Protection page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_InflationProtectionpage_Eng"));				
		Thread.sleep(1000);
		//Income Requirement
		statusPassWithScreenshot(driver, "Income Requirement Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_IncomeRequirementPage_Eng"));
		//Settings -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPassWithScreenshot(driver, "Clicked Next Button in Income requirement Page", TestCaseDescription);
		Thread.sleep(5000);
		//Registered - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccSelect_Eng")); 
		//Account type - List Box
		CommonFunctions.SelectListBox(driver, obj.getselect_AccountPage_AccountType(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccType_Eng"));
		//Foregin Jurisdiction - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ForeginJurisdiction_Eng"));
		statusPassWithScreenshot(driver, "Selected Account Type & Foreign Jurisdiction Values in Account Page", TestCaseDescription);
		//Registered -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPass("Clicked Next button in Account Page");
		//Account Program - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountProgramType_Eng"));
		statusPassWithScreenshot(driver,"Selected Account Program in Account Program page",TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPass("Clicked Next button in Account Program Page");
		//Client-directed Sleeve page
		statusPass("Entered into Client Directed Sleeve page");
        CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ClientDirectedSleeveSelect_Eng"));
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(8000);
        statusPass("Entered into Model Schem page");
        CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ModelSchemSelect_Eng"));
        statusPassWithScreenshot(driver,"Selected the radio button",TestCaseDescription);
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(8000);
        //Portfolio construction Page
        statusPassWithScreenshot(driver,"Entered Into Port Folio Construction Page",TestCaseDescription);
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(8000);
        //Historical Performance Page
        statusPassWithScreenshot(driver,"Historical Performance Page dispalyed",TestCaseDescription);
        CommonFunctions.ClickButton(driver, obj.getbutton_Historical_Perf());
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
        CommonFunctions.ClickButton(driver, obj.getNextButton());
		Thread.sleep(8000);
		// Account Details page
        statusPass("Entered into Account Details page");
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_AccountDetail_AccountName_Eng"));
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountNumber(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_AccountNumber_Eng"));
		//CommonFunctions.SelectListBox(driver, obj.getAccountDetails_ReviewFrequency(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_ReviewFrequency_Eng"));
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		// Fee Schedule
		statusPass("Entered into FEE Schedule page");
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(5000);
		CommonFunctions.ClickButton(driver, obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		CommonFunctions.SetText(driver, obj.gettext_TeamName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TeamName_Eng"));
		Thread.sleep(3000);
		CommonFunctions.SetText(driver, obj.gettext_IATitle(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IATitle_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAemail(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAEmail_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAphone(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAPhone_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstNameValue_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastNameValue_Eng"));
		statusPassWithScreenshot(driver,"Team Name,Title,Name,Email,Phone Numbe Details are entered in Investment Advisor Profile page",TestCaseDescription);
		statusPassWithScreenshot(driver, "Entered into IA Profile Page", TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(8000);
		statusPassWithScreenshot(driver, "Entered into Administrative Question page", TestCaseDescription);
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(1000);
		CommonFunctions.ClickButton(driver,obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		// Generate Documents Page
		statusPassWithScreenshot(driver, "Entered into generate Document page", TestCaseDescription);
		CommonFunctions.tableSelect(driver, "MPS Instruction Sheet",TestCaseDescription);
		statusPass("Architect MPS form's Download Button Clicked ");
		Thread.sleep(10000);
		// Getting child window details
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		Thread.sleep(1000);
		// Saving PDF to download folder
		CommonFunctions.PDFSave(driver,TestCaseID);
		// Source file Location commented as we are generating from Online
		//String SourceFile = ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SourcefileLocation_Eng");
		String generatedFile=CommonFunctions.FileMoveAndRename(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_FileDownloadLocation_Eng"),"C:\\BrunoAutomationFramework\\PDFfiles\\GeneratedFiles", TestCaseID);
		String SourceFile = "C:\\BrunoAutomationFramework\\SourceFiles\\Architect_MPS_Source.pdf";
		Thread.sleep(2000);
		// Form verification starts here
		statusPass("Architect Program MPS form Verification-Page-1 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,1,1);
		Thread.sleep(500);
		statusPass("Architect Program MPS form Verification-Page-2 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,2,2);
		Thread.sleep(500);
		statusPass("Architect Program MPS form Verification-Page-3 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,3,3);
		Thread.sleep(500);
		statusPass("Architect Program MPS form Verification-Page-4 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,4,4);
		
		statusPass("Comparison Done, Please Evaluate Each ScreenShot in Test Report");
		endReporting();
		driver.close();
			
	}

}

@Test(dataProvider="DriverSheet")
public void QuadrantMPSEnglish(String RowNumber,String Functionality, String TestCaseID, String TestCaseDescription, String Browser, String Language, String Execution, String Status)throws Throwable
{
	
	int rowNumber = Integer.parseInt(RowNumber);
	if(TestCaseID.equalsIgnoreCase("TC019")&&Execution.equalsIgnoreCase("Y") &&Functionality.equalsIgnoreCase("QUADRANT-MPS-ENGLISH"))
	{
		
		driver=LoginPage.LaunchBrowser(Browser); 
		LoginPage.LaunchURL(driver);
	    startReporting("Quadrant Program MPS form Static content validation");
	    LoginPage.Login(rowNumber,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Username_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_Password_Eng"),Functionality + TestCaseID);
	    CommonFunctions.waitForElementMouse(driver, obj.getMouseHoverIcon(),100,"Slider Menu");
	    Thread.sleep(10000);
	    CommonFunctions.clickAround(driver,obj.getMenuButton(),obj.getMouseHoverIcon(),obj.getClients_menu(),obj.getGoalPlanning(),obj.getiFrame(), obj.getNewInvestmentProposal(),TestCaseID);
	    statusPassWithScreenshot(driver, "Clicked Goal planning Option inside Cilents menu", TestCaseDescription);
	    CommonFunctions.NavigateToNewProposal(driver,obj.getiFrame(),obj.getNewInvestmentProposal(), TestCaseID);
	    // Investment Proposal Screen
	    CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageRadiobtn_Eng"));
 		CommonFunctions.SetText(driver,obj.getNewInvestmentName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_NewInvestmentSolutionPageName_Eng"));
   		statusPassWithScreenshot(driver, "New Investment Solution Name Entered and Investment Type Selected", TestCaseDescription);
 		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal Page");
		Thread.sleep(5000);
		//Settings Screen
		CommonFunctions.SelectListBox(driver, obj.getSalesCode(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageSalesCode_Eng"));			
		Thread.sleep(1000);
		//CommonFunctions.SelectListBox(driver, obj.getInvestmentAdvisor(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageIAName_Eng"));	
		CommonFunctions.SelectListBox(driver, obj.getCurrencyType(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageCurrencyType_Eng"));
		CommonFunctions.SetText(driver, obj.getInvestmentAmt(),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_SettingsPageInvestmentAmt_Eng"));
		Thread.sleep(1000);
		statusPassWithScreenshot(driver, "Salescode,Currency,Investment Amount, Investment Advisor Name are entered in Settings page ", TestCaseDescription);
		// Scroll Down	 
		CommonFunctions.scrollandClickElement(driver, "//button[contains(text(),'Save Changes')]");
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPass("Clicked Next Button in New Investment Proposal-Setting  Page");
		Thread.sleep(8000);
		// Clients Screen
		statusPassWithScreenshot(driver,"Add New individual Button is Displayed in Cilents Page",TestCaseDescription);
		// Client Search functionality starts here
		/*CommonFunctions.ClickButton(driver, obj.getSearchForIndividualButton());
		CommonFunctions.SetText(driver, obj.getSearchIndividual_Textbox(), "John");
		Thread.sleep(5000);
		Robot robot = new  Robot();
	    robot.keyPress(KeyEvent.VK_ENTER);
	    robot.keyRelease(KeyEvent.VK_ENTER);
	    statusPass("Search Text Entered in  Search For Individual text Box");
	    CommonFunctions.ScrollView(driver, "//button[contains(text(),'Close')]");
	    CommonFunctions.tableSelectSearchIndividual(driver, "natarajan", TestCaseDescription);*/
		// Client Search ends here
		// Add new Individual Client
		CommonFunctions.ClickButton(driver, obj.getAddNewIndividualButton());
		statusPass("Clicked Add New individual Button in Clients page");
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ClientsPageCusIDPropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageCusID_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstNamePropName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageFirstName_Eng"));
		CommonFunctions.SetTextByName(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureNamePropName_Eng"),ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSureName_Eng"));
		CommonFunctions.SelectListBox(driver, obj.getGender(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageGender_Eng"));	
		CommonFunctions.SelectListBox(driver, obj.getSalutation(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSalutation_Eng"));
		CommonFunctions.SetTextByClass(driver, obj.getDateofBirth(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageDateofBirth_Eng"));
		CommonFunctions.ScrollView(driver, obj.getButtonSaveandClose());
		CommonFunctions.ClickButton(driver, obj.getButtonSaveandClose());
		CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSelection_Eng"));
		statusPassWithScreenshot(driver, "Customer ID ,Name,Gender,DOB are Entered in Clients page", TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());	
		statusPass("Clicked Next Button in Add New Individual Page");
	    Thread.sleep(8000);
		/*CommonFunctions.scrollandClickElement(driver, "//button[contains(text(),'Add')]");
		CommonFunctions.SelectRadioButton(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ClientsPageSelection_Eng"));
		CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
		CommonFunctions.ClickButton(driver,obj.getNextButton());	
		statusPass("Clicked Next Button in Add New Individual Page");*/
		// Investment Objective page
		statusPassWithScreenshot(driver, "Investment Objective page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_InvestmentObjPage_Eng"));
		Thread.sleep(1000);
		//Time Horizon page
		statusPassWithScreenshot(driver, "Time Horizon Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TimeHorizonPage_Eng"));	
		Thread.sleep(1000);
		//Return Expectation page
		statusPassWithScreenshot(driver, "Return Expectation Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver,ReadExcelFile.getTestData(TestCaseID,Functionality,"p_ReturnExpectationPage_Eng"));
		Thread.sleep(500);
		//Market Fluctuacion page
		statusPassWithScreenshot(driver, "Market Fluctuacion page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_MarketFluctuacionPage _Eng"));
		Thread.sleep(1000);
		//Inflation Protection page
		statusPassWithScreenshot(driver, "Inflation Protection page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_InflationProtectionpage_Eng"));				
		Thread.sleep(1000);
		//Income Requirement page
		statusPassWithScreenshot(driver, "Income Requirement Page is Dispalyed", TestCaseDescription);
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_IncomeRequirementPage_Eng"));
		//Settings -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		statusPassWithScreenshot(driver, "Clicked Next Button in Income requirement Page", TestCaseDescription);
		Thread.sleep(8000);
		//Account Page-Registered - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccSelect_Eng")); 
		//Account type - List Box
		CommonFunctions.SelectListBox(driver, obj.getselect_AccountPage_AccountType(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountPageAccType_Eng"));
		//Foregin Jurisdiction - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ForeginJurisdiction_Eng"));
		statusPassWithScreenshot(driver, "Selected Account Type & Foreign Jurisdiction Values in Account Page", TestCaseDescription);
		//Registered -Next Button
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(5000);
		statusPass("Clicked Next button in Account Page");
		//Account Program - Radio button
		CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountProgramType_Eng"));
		statusPassWithScreenshot(driver,"Selected Account Program in Account Program page",TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(5000);
		statusPass("Clicked Next button in Account Program Page");
		// Models Page
		statusPass("Entered into Models page");
        CommonFunctions.SelectRadioButtonXpath(driver, ReadExcelFile.getTestData(TestCaseID,Functionality, "p_ProgramModelSelect_Eng"));
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        CommonFunctions.ClickButton(driver,obj.getNextButton());
        Thread.sleep(8000);
        //Historical Page
        statusPassWithScreenshot(driver,"Historical Performance Page dispalyed",TestCaseDescription);
        CommonFunctions.ClickButton(driver, obj.getbutton_Historical_Perf());
        // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        statusPassWithScreenshot(driver,"Screenshot done",Functionality + TestCaseID);
        CommonFunctions.ClickButton(driver, obj.getNextButton());
		Thread.sleep(8000);
		// Account Dewtails Page
		statusPass("Entered into Account Details page");
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_AccountDetail_AccountName_Eng"));
		CommonFunctions.SetText(driver, obj.getAccountDetails_AccountNumber(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_AccountNumber_Eng"));
		//CommonFunctions.SelectListBox(driver, obj.getAccountDetails_ReviewFrequency(), ReadExcelFile.getTestData(TestCaseID,Functionality, "p_AccountDetail_ReviewFrequency_Eng"));
		 // Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
        CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(3000);
		// Fee Schedule
		statusPass("Entered into FEE Schedule page");
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Save Changes')]");
        CommonFunctions.ClickButton(driver, obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		CommonFunctions.SetText(driver, obj.gettext_TeamName(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_TeamName_Eng"));
		Thread.sleep(3000);
		CommonFunctions.SetText(driver, obj.gettext_IATitle(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IATitle_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAemail(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAEmail_Eng"));
		CommonFunctions.SetText(driver, obj.gettext_IAphone(), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAPhone_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IAFirstNameValue_Eng"));
		CommonFunctions.SetTextByName(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastName_Eng"), ReadExcelFile.getTestData(TestCaseID,Functionality,"p_IALastNameValue_Eng"));
		statusPassWithScreenshot(driver,"Team Name,Title,Name,Email,Phone Numbe Details are entered in Investment Advisor Profile page",TestCaseDescription);
		statusPassWithScreenshot(driver, "Entered into IA Profile Page", TestCaseDescription);
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(5000);
		statusPassWithScreenshot(driver, "Entered into Administrative Question page", TestCaseDescription);
		// Javascript Scroll View
        CommonFunctions.ScrollView(driver, "//button[contains(text(),'Next')]");
		CommonFunctions.ClickButton(driver,obj.getNextButton());
		Thread.sleep(5000);
		CommonFunctions.ClickButton(driver,obj.getbutton_generateDocuments());
		Thread.sleep(10000);
		// Generate Documents Page
		statusPassWithScreenshot(driver, "Entered into generate Document page", TestCaseDescription);
		CommonFunctions.tableSelect(driver, "MPS Instruction Sheet",TestCaseDescription);
		statusPass("Quadrant MPS forms Download Button Clicked ");
		Thread.sleep(20000);
		// Getting child window details
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		Thread.sleep(2000);
		// Saving PDF to download folder
		CommonFunctions.PDFSave(driver,TestCaseID);
		String generatedFile=CommonFunctions.FileMoveAndRename(driver, ReadExcelFile.getTestData(TestCaseID,Functionality,"p_FileDownloadLocation_Eng"),"C:\\BrunoAutomationFramework\\PDFfiles\\GeneratedFiles", TestCaseID);
		String SourceFile = "C:\\BrunoAutomationFramework\\SourceFiles\\Quadrant_MPS_Source.pdf";
		// PDF file verification
		statusPass("Quadrant Program MPS form Verification-Page-1 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,1,1);
				
		statusPass("Quadrant Program MPS form Verification-Page-2 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,2,2);
		
		statusPass("Quadrant Program MPS form Verification-Page-3 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,3,3);
		
		statusPass("Quadrant Program MPS form Verification-Page-4 ");
		PDFPageVerification.compare(driver,SourceFile, generatedFile,4,4);
		
		statusPass("Comparison Done, Please Evaluate Each ScreenShot in Test Report");
		endReporting();
		driver.close();
	
			
		
	}

}

/* @AfterMethod       // after Method added on 25/07/2017
public void afterMethod()
{
	
	LoginPage.closeDriver(); 
	
} 
*/

@AfterTest
public void afterTest() throws Exception
{
	
	//LoginPage.closeDriver();    //added on 25/07/2017

}
	
@AfterSuite
public void afterSuite() throws Exception
{
      closeReporting();
  		driver.close();
      //LoginPage.closeDriver();   //commented on 26/07/2017
}
}
