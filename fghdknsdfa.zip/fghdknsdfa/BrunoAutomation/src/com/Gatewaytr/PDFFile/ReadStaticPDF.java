package com.Gatewaytr.PDFFile;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDDocumentCatalog;
import org.apache.pdfbox.pdmodel.common.function.type4.Parser;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDField;
import org.apache.pdfbox.text.PDFTextStripper;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.Gateway.GlobalParameters.BaseClass;
import com.testautomationguru.utility.CompareMode;
import com.testautomationguru.utility.PDFUtil;

import java.io.File;
import java.io.IOException;
import java.util.List;

//created by Arun
public class ReadStaticPDF {    
	
	
	@SuppressWarnings("resource")
	public static void ReadStaticPDF() throws IOException {
		// TODO Auto-generated method stub
		try
		{
			PDDocument pd = new PDDocument();
			File file = new File("C:\\Selenium\\BMO - Bruno - Architect Program Account Agreement Mockup_02282017.pdf");
			pd = PDDocument.load(file);
			
			//System.out.println("Total pages:  "+pd.getNumberOfPages()+"\n");
			PDFTextStripper pdf = new PDFTextStripper();
			
			//System.out.println(pdf.getText(pd));
			
						
			pd.close();	
		}
		 
		catch(Exception e)
		{
			 System.out.println("Exception caught in ReadStaticPDF Method-------"+e.getMessage());	
		}
		
	}


//Created by Manoj on 10/08/2017
@SuppressWarnings("resource")
public static void Verifypdfcontent(WebDriver driver,String SourceFile,String tmptxt,int startPage,int endPage,String testcaseName) throws IOException {
			// TODO Auto-generated method stub
			
			String pdftext =null;
			
			
			try
			{
				PDDocument pd = new PDDocument();
				File file = new File(SourceFile);
				pd = PDDocument.load(file);
				
				
				PDFTextStripper pdf = new PDFTextStripper();
				
				//System.out.println(pdf.getText(pd));
				
				pdf.setStartPage(startPage);
				pdf.setEndPage(endPage);
				
				pdftext = pdf.getText(pd);
				
				String ScreenShot=PDFPageVerification.savePDFAsImage(SourceFile, startPage, endPage);
				
								
				
				File lastModified=ImageUtil.getLatestFilefromDir(ScreenShot);
				// converting file type to string.
			    String LastModifiedPDFScreenShot=lastModified.toString();
				
				if(pdftext.contains(tmptxt)) 
				{

					BaseClass.statusPassPDFWithScreenshot(tmptxt+"--is present in the PDF", testcaseName, LastModifiedPDFScreenShot);
				}
				else
				{
					PDFPageVerification.savePDFAsImage(SourceFile, startPage, endPage);
					
					 BaseClass.statusFailpdf(tmptxt+"--is not present in the PDF", testcaseName, LastModifiedPDFScreenShot);
					 BaseClass.endReporting();
					 driver.quit();
					 Assert.fail("Unable to Download the PDF");
				}
							
				pd.close();	
			}
			 
			catch(Exception e)
			{
				 System.out.println("Exception caught in  Verify PDF content  Method-------"+e.getMessage());	
								
				 BaseClass.statusFail(driver, "Exception caught in PDF validation", testcaseName);
				 BaseClass.endReporting();
				 driver.quit();
				 Assert.fail("Unable to Download the PDF");
			}
			
		}




@SuppressWarnings("resource")
public static void ReadStaticPDFManoj(String strtxt) throws IOException {
	// TODO Auto-generated method stub



	
	try
	{
		/*PDDocument pd = new PDDocument();
		File file = new File("C:\\Selenium\\BMO - Bruno - Architect Program Account Agreement Mockup_02282017.pdf");
		pd = PDDocument.load(file);
		
		System.out.println("Total pages:  "+pd.getNumberOfPages()+"\n");
		PDFTextStripper pdf = new PDFTextStripper(); */
		
		PDFUtil pdfUtil = new PDFUtil();
		//pdf.setStartPage(1);
		//pdf.setEndPage(1); 
		
		//System.out.println("Inside Try block");
	    // System.out.println(pdf.getText(pd));
		
	    // text = pdf.getText(pd);
	     
	  
	     
	     String file1="C:\\Selenium\\BMO - Bruno - Architect Program Account Agreement Mockup_02282017.pdf";
	     String file2="C:\\Selenium\\BMO Bruno - Mockup Programme Architecte - Supplement IA Discretion_02282017.pdf";

	     // compares the pdf documents and returns a boolean
	     // true if both files have same content. false otherwise.
	     // Default is CompareMode.TEXT_MODE
	     pdfUtil.setCompareMode(CompareMode.VISUAL_MODE);
	    // pdfUtil.compare(file1, file2);  // 10/08/2017
	     
	     // compare the 3rd page alone
	     
	    
	     
	     boolean result =  pdfUtil.compare(file1, file2,2,2);
   
	     if(result==false)
	     
	     {
	    	 //System.out.println(" Inside If loop");
	    	 pdfUtil.highlightPdfDifference(true);
		     pdfUtil.setImageDestinationPath("C:\\Selenium");
		     pdfUtil.compare(file1, file2,2,2);
		     pdfUtil.savePdfAsImage("C://Selenium//BMO - Bruno - Architect Program Account Agreement Mockup_02282017.pdf"); 
	     }
	     
	     
	     
	   //if you need to store the result
	  // pdfUtil.highlightPdfDifference(true);
	   pdfUtil.setImageDestinationPath("C:\\Users\\rvanith\\Documents\\New folder");
	  // pdfUtil.compare(file1, file2);
	     
	 
	   pdfUtil.extractImages("C:\\Selenium\\BMO - Bruno - Architect Program Account Agreement Mockup_02282017.pdf"); 
	     
	}
	 
	catch(Exception e)
	{
		 System.out.println("Exception caught in ReadStaticPDF Method-------"+e.getMessage());	
	}
	//public boolean compare(String file1, String file2, int startPage, int endPage) throws IOException{
		//return this.comparePdfFiles(file1, file2, startPage, endPage);
	//}
	
}


}