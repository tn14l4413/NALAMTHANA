package com.Gatewaytr.PDFFile;


import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Logger;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;

import com.Gateway.GlobalParameters.BaseClass;
import com.Gatewaytr.ExcelFile.ReadExcelFile;
import com.Gatewaytr.pages.CommonFunctions;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class ImageUtil {

public static ExtentTest logger;
	
	
	public static boolean compareAndHighlight(final BufferedImage img1, final BufferedImage img2, String fileName, boolean highlight, int colorCode) throws IOException {
		
	    final int w = img1.getWidth();
	    final int h = img1.getHeight();
	    final int[] p1 = img1.getRGB(0, 0, w, h, null, 0, w);
	    final int[] p2 = img2.getRGB(0, 0, w, h, null, 0, w);

	    if(!(java.util.Arrays.equals(p1, p2))){
	    	
	    	if(highlight){
	    	    for (int i = 0; i < p1.length; i++) {
	    	    	
	    	    	
	    	        if (p1[i] != p2[i]){
	    	            p1[i] = colorCode;
	    	          
	    	        } 
	    	    }
	    	    
	    	    
	    	    final BufferedImage out = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
	    	    out.setRGB(0, 0, w, h, p1, 0, w);
	    	    
	    	    String Dir=saveImage(out, fileName);
	    	    //System.out.println("Dir Name"+Dir);
	    	    //Code Modifiend here
	    	    //Getting last modified file details for attaching in the report
	    	   // File lastModified=getLatestFilefromDir(Dir);
	    	    // converting file type to string.
	    	    //String screenShotPath=lastModified.toString();
	    	    // End here
	    	    
	    	    String screenShotPath=Dir;
	    	    
	    	    // Updating result in report	        	       	  
	    	   BaseClass.statusFailpdf("Agreement page content verification is UnSuccessful, Differences highlighted in Red color,Please refer below screen shot for detailed information.", "", screenShotPath);
	    	   	    
	    	    
	    	}
	    	return false;
	    }
	    else{
	    	
	    	  return true;
	    }
	}

	public static String saveImage(BufferedImage image, String file) throws IOException{
		File outputfile = new File(file);
		
		ImageIO.write(image, "png", outputfile);	
		Date date = new Date();  
    	DateFormat df = new SimpleDateFormat("dd MMMM yyyy HH-mm-ss");
        String Date = df.format(date);
               
        String uniq = Date ;
        DateFormat df1 = new SimpleDateFormat("dd MMMM yyyy");
        String folderName= df1.format(date);  
        
		try{
			
	        File f =  new File("C:\\BrunoAutomationFramework\\TestReports\\"+folderName+"\\");
	        if (!f.exists() && !f.isDirectory()) {
	        	
	           f.mkdir();
	                   }
	        
	        File f1= new File("C:\\BrunoAutomationFramework\\TestReports\\"+folderName+"\\Screenshot\\");
	        if (!f1.exists() && !f1.isDirectory()) 
	        {
	        	
	           f1.mkdir();
	        
	        }
	        
	        
	       // Below file move is not working in BAT file, so not moved the screen shot to screen shot folder.
	        //CommonFunctions.FileMoveAndRename(driver, sourceDirPath, DestDirPath, testcaseName)
	        
	      //FileUtils.moveFileToDirectory(outputfile, new File("C:\\BrunoAutomationFramework\\TestReports\\"+folderName+"\\Screenshot\\"), false);
	      
	      
	      
		}catch(Exception e){
			
			e.printStackTrace();
		}
		//String Dir="C:\\BrunoAutomationFramework\\TestReports\\"+folderName+"\\Screenshot\\";
		String Dir=file;
				
		return Dir;
				
	
	}
	public static File getLatestFilefromDir(String dirPath){
	    File dir = new File(dirPath);
	    File[] files = dir.listFiles();
	    if (files == null || files.length == 0) {
	        return null;
	    }

	    File lastModifiedFile = files[0];
	    for (int i = 1; i < files.length; i++) {
	       if (lastModifiedFile.lastModified() < files[i].lastModified()) {
	           lastModifiedFile = files[i];
	       }
	    }
	    return lastModifiedFile;
	}
	}	
