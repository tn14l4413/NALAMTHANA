
package com.Gatewaytr.PDFFile;
import java.io.File;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;

import java.io.IOException;

import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageTree;
import org.apache.pdfbox.pdmodel.PDResources;
import org.apache.pdfbox.pdmodel.graphics.PDXObject;

public class ReadImagesPDF {
	
	public static void ReadImagesPDF() throws IOException {
		// TODO Auto-generated method stub
		try {
			
						
            String sourceDir = "C:\\Selenium\\PDF Image\\BMO Bruno - Mockup Programme Architecte - Supplement IA Discretion_02282017.pdf";// Paste pdf files in PDFCopy folder to read
            String destinationDir = "C:\\Selenium\\PDF Image\\";
            File oldFile = new File(sourceDir);
            if (oldFile.exists()) {
            PDDocument document = PDDocument.load(oldFile);
            PDPageTree list = document.getPages();
           

            String fileName = oldFile.getName().replace(".pdf", "_cover");
            int totalImages = 1;
            for (PDPage page : list) {
                PDResources pdResources = page.getResources();
                
               
                for (COSName c : pdResources.getXObjectNames()) {  
                	PDXObject o = pdResources.getXObject(c);
                
                	
                	 if (o instanceof org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject) {
                         File file = new File("C:\\Selenium\\PDF Image\\image" + System.nanoTime() + ".png");
                         ImageIO.write(((org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject)o).getImage(), "png", file);
                     }
                	

                }
            }
        } else {
            System.err.println("File not exists");
        }
    } catch (Exception e) {
        e.printStackTrace();
		
		
		    }
		}
		
}
		
