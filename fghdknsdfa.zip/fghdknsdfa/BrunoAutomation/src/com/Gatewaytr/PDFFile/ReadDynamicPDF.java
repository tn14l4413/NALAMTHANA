
package com.Gatewaytr.PDFFile;



import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDDocumentCatalog;
import org.apache.pdfbox.pdmodel.common.function.type4.Parser;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDField;
import org.apache.pdfbox.text.PDFTextStripper;

import java.io.File;
import java.io.IOException;
import java.util.List;


public class ReadDynamicPDF {
	
	
	
	@SuppressWarnings("resource")
	public static void readDynamicPDF() throws IOException {
		// TODO Auto-generated method stub
		try
		{
			PDDocument pd = new PDDocument();
			File file = new File("C:\\Selenium\\BMO - Bruno - Architect Program Account Agreement Mockup_02282017.pdf");
			pd = PDDocument.load(file);
			
			//System.out.println("Total pages:  "+pd.getNumberOfPages());
				
			PDDocumentCatalog pdCatalog = pd.getDocumentCatalog();
			PDAcroForm pdAcroForm = pdCatalog.getAcroForm();
			List<PDField> fields = pdAcroForm.getFields();
			
			for (PDField field: fields) 
			{
	            Object value = field.getValueAsString();
	            String name = field.getFullyQualifiedName();
	            //System.out.print(name);
	            //System.out.print(" = ");
	            //System.out.print(value);
	            //System.out.println();
			}
			
			
			
			pd.close();	
		}
		catch(Exception e)
		{
			System.out.println("Exception caught in readDynamicPDF-------"+e.getMessage());
			// statusFail(driver,"readDynamicPDFFailed"+dropDownText,testCaseName);	
		}
		
	}

}
