package com.Gateway.GlobalParameters;



import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

public class FetchingOR {
	public String RepositoryFile;
	
	Properties prop;
	
	
	
	public FetchingOR(String fileName) throws Exception
	{
		this.RepositoryFile = fileName;
			
		FileInputStream fis = new FileInputStream(fileName);
		
		prop = new Properties();
		
		prop.load(fis);
		
	}
	
	public String getbrowser()
	{
	
		return prop.getProperty("CHROME");
	}
    
	
	/*public String geturl()
	{
		
		return prop.getProperty("URL");
	}
	*/
	public String getUserName()
	{
	
		return prop.getProperty("User_Id");
	}
	public String getPassword()
	{
		
		return prop.getProperty("Password");
	}
	public String getLoginButton()
	{
		
		return prop.getProperty("Sign_In");
	}

	public String getMenuButton()
	{
		return prop.getProperty("Menu_Button");
	
	}
	public String getClients_menu()
	{
		return prop.getProperty("Clients_menu");
	
	}
	public String getMouseHoverIcon()
	{
		return prop.getProperty("MouseHoverIcon");
	}

	public String getGoalPlanning() {
		
		return prop.getProperty("GoalPlanning");
		
	}

	public String getNewInvestmentProposal() {
		
		return prop.getProperty("NewInvestmentProposal");
	}
	
	public String getNewInvestmentName(){
		//System.out.println("Inside Fetching OR Class"+prop.getProperty("NewInvestment_Name"));
		return prop.getProperty("NewInvestment_Name");
	}
	
	public String getiFrame(){
		return prop.getProperty("iFrame");
	}
	
	public String getRadioIndividual(){
		return prop.getProperty("radio_Individual");
	}
	
	public String  getSalesCode()
	{
		return prop.getProperty("select_SalesCode");
	
	}
	public String  getInvestmentAdvisor()
	{
		return prop.getProperty("select_InvestmentAdvisor");
	
	}
	public String  getCurrencyType()
	{
		return prop.getProperty("Select_currency_Type");
	
	}
	
	public String  getInvestmentAmt()
	{
		return prop.getProperty("Investment_Amt");
	
	}
	
	public String  getNextButtonNIPage()
	{
		return prop.getProperty("Next_Button_NIPage");
	
	}
	public String  getSalesCodeOR()
	{
		return prop.getProperty("salescodeOR");
	
	}
	public String  getDropdownOR()
	{
		return prop.getProperty("DropdownOR");
	
	}
		
	public String getButtonSaveChanges()
	{
		return prop.getProperty("button_SaveChanges");
	}
	
	public String getNextButton()
	{
		return prop.getProperty("button_Next");
	}
	
	public String getAddNewIndividualButton()
	{
		return prop.getProperty("button_AddNewIndividual");
	}
	
	public String getSearchForIndividualButton()
	{
		return prop.getProperty("button_SearchForIndividual");
	}
	public String gettext_CustomerID()
	{
		return prop.getProperty("text_CustomerID");
	}
	
	
	public String getGender()
	{
		return prop.getProperty("select_Gender");
	}
	
	public String getSalutation()
	{
		return prop.getProperty("select_Salutation");
	}
	

	public String getNewIndividual_CoWorker()
	{
		return prop.getProperty("NewIndividual_CoWorker");
	}
	
	public String getNewIndividual_Language()
	{
		return prop.getProperty("NewIndividual_Language");
	}
	
		
	public String getButtonSaveandClose()
	{
		return prop.getProperty("button_SaveandClose");
	}
	
	public String getButton_Back()
	{
		return prop.getProperty("button_Back");
	}
	
	public String getButton_Close()
	{
		return prop.getProperty("button_Close");
	}
	
	
	public String getDateofBirth()
	{
		return prop.getProperty("DateofBirth");
	}
	public String getRadioNewIndividual()
	{
		return prop.getProperty("radio_NewIndividual");
	}
	
	public String getradio_InvestmentObjective()
	{
		return prop.getProperty("radio_InvestmentObjective");
	}
	
	public String getradio_TimeHorizon()
	{
		return prop.getProperty("radio_TimeHorizon");
	}
	
	public String getradio_ReturnExpectation()
	{
		return prop.getProperty("radio_ReturnExpectation");
	}
	
	public String getradio_MarkerFluctutaion()
	{
		return prop.getProperty("radio_MarkerFluctutaion");
	}
	public String getradio_InflationProtection()
	{
		return prop.getProperty("radio_InflationProtection");
	}
	
	public String getradio_IncomeRequriement()
	{
		return prop.getProperty("radio_IncomeRequriement");
	}
		
	public String getradio_AccountPage_Registered()
	{
		return prop.getProperty("radio_AccountPage_Registered");
	}
	
	public String getselect_AccountPage_AccountType()
	{
		return prop.getProperty("select_AccountPage_AccountType");
	}
	
	public String getradio_AccountPage_REGISTERED_RETIREMENT_SAVINGS_PLAN()
	{
		return prop.getProperty("radio_AccountPage_REGISTERED_RETIREMENT_SAVINGS_PLAN");
	}
	
	public String getradio_AccountPage_ForeginJurisdiction()
	{
		return prop.getProperty("radio_AccountPage_ForeginJurisdiction");
	}
	
	public String getradio_AccountProgramePage_Architect()
	{
		return prop.getProperty("radio_AccountProgramePage_Architect");
	}
	
	public String getradio_ClientDirectedSleevePage_ClientDirect()
	{
		return prop.getProperty("radio_ClientDirectedSleevePage_ClientDirect");
	}	
	
	
	public String getbutton_GenerateProposal()
	{
		return prop.getProperty("button_GenerateProposal");
	}	
	public String getbutton_generateDocuments()
	{
		return prop.getProperty("button_generateDocuments");
	}
	
	public String getbutton_Historical_Perf()
	{
		return prop.getProperty("button_Historical_Perf");
	}
	
	public String gettext_TeamName()
	{
		return prop.getProperty("text_TeamName");
	}
	
	public String gettext_IATitle()
	{
		return prop.getProperty("text_IATitle");
	}
	public String gettext_IAemail()
	{
		return prop.getProperty("text_IAemail");
	}
	public String gettext_IAphone()
	{
		return prop.getProperty("text_IAphone");
	}
	public String gettext_Percentage()
	{
		return prop.getProperty("text_Percentage");
	}
	public String gettext_ProposalComments()
	{
		return prop.getProperty("text_ProposalComments");
	}
	public String getCheckbox_Printoptions1()
	{
		return prop.getProperty("Checkbox_Printoptions1");
	}
	public String getCheckbox_Printoptions2()
	{
		return prop.getProperty("Checkbox_Printoptions2");
	}
	public String getCheckbox_Printoptions3()
	{
		return prop.getProperty("Checkbox_Printoptions3");
	}
	public String getSwitchbox_Printoptions1()
	{
		return prop.getProperty("Switchbox_Printoptions1");
	}
	public String getSwitchbox_Printoptions2()
	{
		return prop.getProperty("Switchbox_Printoptions2");
	}
	public String getSwitchbox_Printoptions3()
	{
		return prop.getProperty("Switchbox_Printoptions3");
	}
	public String getbutton_generateclientsummary()
	{
		return prop.getProperty("button_generateclientsummary");
	}
	public String getSwitchbox_Directsleeve()
	{
		return prop.getProperty("Switchbox_Directsleeve");
	}
	public String getAccountDtail_FiscalYearEndDate()
	{
		return prop.getProperty("AccountDetail_FiscalyearendDate");
	}
	
	public String getAccountDtail_FiscalYearEndMonth()
	{
		return prop.getProperty("AccountDetail_FiscalyearendMonth");
	}
	
	public String getSwitchbox_AccountDetail()
	{
		return prop.getProperty("Switchbox_AccountDetail");
	}
	public String getAccountDetails_AccountNumber()
	{
		return prop.getProperty("AccountDetails_AccountNumber");
	}
	public String getAccountDetails_ReviewFrequency()
	{
		return prop.getProperty("AccountDetails_ReviewFrequency");
	}
	
	public String getAccountDetails_AccountName()
	{
		return prop.getProperty("AccountDetail_AccountName");
	}
	public String getInprogress_button()
	{
		return prop.getProperty("Inprogress_button");
	}
	
	public String getSettingsProposalNamebutton()
	{
		return prop.getProperty("Settings_ProposalName");
	}
	public String getSettingsProposalcommentsbutton()
	{
		return prop.getProperty("Settings_Proposalcomments");
	}
	
	public String getSettingsQuestionfield()
	{
		return prop.getProperty("Settings_Question");
	}
	public String getbutton_CreateIndividual()
	{
		return prop.getProperty("button_CreateIndividual");
	}
	
	public String getClients_InvestmentProposallabel()
	{
		return prop.getProperty("Clients_InvestmentProposallabel");
	}
	public String getNavigationflow_Clients()
	{
		return prop.getProperty("Navigationflow_Clients");
	}
	public String getClientstable_Heading()
	{
		return prop.getProperty("Clientstable_Heading");
	}
	
	public String getClientstable_ColumnHeading1()
	{
		return prop.getProperty("Clientstable_ColumnHeading1");
	}
	public String getClientstable_ColumnHeading2()
	{
		return prop.getProperty("Clientstable_ColumnHeading2");
	}
	public String getClientstable_ColumnHeading3()
	{
		return prop.getProperty("Clientstable_ColumnHeading3");
	}
	public String getClientstable_ColumnHeading4()
	{
		return prop.getProperty("Clientstable_ColumnHeading4");
	}
	public String getClients_ClientID()
	{
		return prop.getProperty("Clients_ClientID");
	}
	public String getClients_Salescode()
	{
		return prop.getProperty("Clients_SalesCode");
	}
	public String getClients_ContactInformation()
	{
		return prop.getProperty("Clients_ContactInformation");
	}
	public String getClients_Firstname()
	{
		return prop.getProperty("Clients_Firstname");
	}
	public String getClients_Lastname()
	{
		return prop.getProperty("Clients_Lastname");
	}
	
	public String getSearchIndividual_Textbox()
	{
		return prop.getProperty("SearchIndividual_Textbox");
	}
	
	public String getCash_Textbox()
	{
		return prop.getProperty("Cash_Textbox");
	}
	
	public String getEquities_Textbox()
	{
		return prop.getProperty("Equities_Textbox");
	}
	public String getFixedIncome_Textbox()
	{
		return prop.getProperty("FixedIncome_Textbox");
	}
	
	public String getFee_Accounttype_Editbutton()
	{
		return prop.getProperty("Fee_Accounttype_Editbutton");
	}
	public String getbutton_UpdateAccount()
	{
		return prop.getProperty("button_UpdateAccount");
	} 
	 
	public String getNo_foreignjuristiction_account()
	{
		return prop.getProperty("No_foreignjuristiction_account");
	}
	public String getRadio_French_Document()
	{
		return prop.getProperty("Radio_French_Document");
	}
	 
	public String getRadio_foreign_jurisdiction_account()
	{
		return prop.getProperty("Is_this_a_foreign_jurisdiction_account");
	}
	
} 